package com.mclauncher.app.ui.home

import com.mclauncher.app.data.versions.InstalledVersion
import com.mclauncher.app.data.versions.VersionType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FeaturedVersionTest {

    private fun version(id: String, releaseTime: String?, installedAt: Long = 1L) =
        InstalledVersion(id, VersionType.RELEASE, "Main", "17", 21, releaseTime, installedAt)

    private val old = version("1.20.1", "2023-06-12T10:00:00+00:00")
    private val mid = version("1.21", "2024-06-13T10:00:00+00:00")
    private val new = version("1.21.10", "2026-10-22T10:00:00+00:00")

    @Test
    fun noVersionsGiveNothing() {
        assertNull(pickFeaturedVersion(emptyList(), null))
        assertNull(pickFeaturedVersion(emptyList(), "1.21"))
    }

    @Test
    fun theSelectedVersionWins() {
        assertEquals(old, pickFeaturedVersion(listOf(old, mid, new), "1.20.1"))
    }

    @Test
    fun withoutSelectionTheNewestByReleaseDateIsShown() {
        assertEquals(new, pickFeaturedVersion(listOf(old, new, mid), null))
        assertEquals(new, pickFeaturedVersion(listOf(new, mid, old), null))
    }

    @Test
    fun aSelectionThatIsNotInstalledIsIgnored() {
        assertEquals(new, pickFeaturedVersion(listOf(old, new), "1.19"))
    }

    @Test
    fun equalDatesFallBackToInstallTime() {
        val a = version("a", "2024-01-01T00:00:00+00:00", installedAt = 10)
        val b = version("b", "2024-01-01T00:00:00+00:00", installedAt = 20)
        assertEquals(b, pickFeaturedVersion(listOf(a, b), null))
        assertEquals(b, pickFeaturedVersion(listOf(b, a), null))
    }

    @Test
    fun versionsWithoutDateLoseToDatedOnes() {
        val undated = version("custom", null, installedAt = 999)
        assertEquals(old, pickFeaturedVersion(listOf(undated, old), null))
    }

    @Test
    fun onlyUndatedVersionsPickTheLatestInstalled() {
        val a = version("a", null, installedAt = 1)
        val b = version("b", null, installedAt = 2)
        assertEquals(b, pickFeaturedVersion(listOf(a, b), null))
    }
}
