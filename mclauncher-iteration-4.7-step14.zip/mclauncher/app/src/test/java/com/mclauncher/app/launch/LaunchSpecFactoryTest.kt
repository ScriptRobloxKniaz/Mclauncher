package com.mclauncher.app.launch

import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.account.AccountType
import com.mclauncher.app.data.versions.EngineLibraryPolicy
import com.mclauncher.app.data.versions.Fixtures
import com.mclauncher.app.data.versions.GameVersion
import com.mclauncher.app.data.versions.InstallPlanner
import com.mclauncher.app.data.versions.Library
import com.mclauncher.app.data.versions.OsEnvironment
import com.mclauncher.app.data.versions.RemoteFile
import com.mclauncher.app.data.versions.VersionLayout
import com.mclauncher.app.data.versions.VersionParser
import com.mclauncher.engine.EngineEnvironment
import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.LaunchCommandBuilder
import com.mclauncher.engine.LwjglRequirement
import com.mclauncher.engine.LwjglVersion
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class LaunchSpecFactoryTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val dirs by lazy { GameDirectories(File(tmp.root, ".minecraft")) }
    private val layout by lazy { VersionLayout(dirs) }
    private val account = Account(1, AccountType.OFFLINE, "Steve", "5627dd98-e6be-3c21-b8a8-e92344183641", true, 0L)

    private fun factory(env: OsEnvironment = OsEnvironment.LINUX_ARM64) = LaunchSpecFactory(
        layout = layout,
        env = env,
        planner = InstallPlanner(
            layout = layout,
            env = env,
            libraryFilter = EngineLibraryPolicy::isNeeded,
            libraryReplacement = EngineLibraryPolicy::replacement,
        ),
        launcherName = "MCLauncher",
        launcherVersion = "0.1.0",
    )

    private val modern: GameVersion by lazy { VersionParser.parseVersion(Fixtures.text("version_modern.json")) }
    private val legacy: GameVersion by lazy { VersionParser.parseVersion(Fixtures.text("version_legacy.json")) }

    private fun create(version: GameVersion, env: OsEnvironment = OsEnvironment.LINUX_ARM64) =
        factory(env).create(version, account, dirs, ramMb = 2048)

    private fun library(name: String, path: String, sha1: String = "a".repeat(40)) = Library(
        name = name,
        artifact = RemoteFile("https://libraries.minecraft.net/$path", sha1, 1L, path),
        classifiers = emptyMap(),
        natives = emptyMap(),
        extractExcludes = emptyList(),
        rules = emptyList(),
    )

    // ---------------------------------------------------------------- современная версия

    @Test
    fun modernVersionBasics() {
        val spec = create(modern)

        assertEquals("1.21.1", spec.versionId)
        assertEquals(21, spec.javaMajor)
        assertEquals("net.minecraft.client.main.Main", spec.mainClass)
        assertEquals(layout.clientJar("1.21.1").path, spec.clientJar)
        assertEquals(2048, spec.ramMb)
    }

    @Test
    fun userArgumentsComeLastSoTheyWinOverVersionDefaults() {
        val spec = factory(OsEnvironment.LINUX_ARM64).create(
            modern, account, dirs, ramMb = 2048, extraJvmArgs = listOf("-Dminecraft.launcher.brand=mine", "-XX:+UseZGC"),
        )

        assertEquals(listOf("-Dminecraft.launcher.brand=mine", "-XX:+UseZGC"), spec.jvmArgs.takeLast(2))
        assertEquals(0, create(modern).jvmArgs.count { it == "-XX:+UseZGC" })
    }

    @Test
    fun onlyPlainJavaLibrariesReachTheClasspath() {
        val spec = create(modern)

        // gson остаётся; LWJGL, его нативы, macOS-обвязка и jinput-platform — нет.
        assertEquals(listOf(layout.library("com/google/code/gson/gson/2.10.1/gson-2.10.1.jar")!!.path), spec.libraryJars)
    }

    @Test
    fun lwjglIsDetectedFromTheFullLibraryList() {
        assertEquals(LwjglRequirement(LwjglVersion.V3_3_3, legacyLwjgl2 = false), create(modern).lwjgl)
    }

    @Test
    fun jvmArgumentsAreFilteredForLinuxArm64() {
        val jvm = create(modern).jvmArgs

        assertFalse("-XstartOnFirstThread" in jvm)
        assertFalse("-Xss1M" in jvm) // только для x86
        assertFalse(jvm.any { it.startsWith("-Dos.name=") })
        assertTrue("-Djava.library.path=\${natives_directory}" in jvm)
        assertTrue("-cp" in jvm && "\${classpath}" in jvm)
    }

    @Test
    fun x86GetsItsStackSizeOption() {
        val jvm = create(modern, OsEnvironment("linux", "x86")).jvmArgs

        assertTrue("-Xss1M" in jvm)
    }

    @Test
    fun launcherIdentityIsNotDuplicatedWhenTheVersionAlreadyAsksForIt() {
        val jvm = create(modern).jvmArgs

        assertEquals(1, jvm.count { it.startsWith("-Dminecraft.launcher.brand=") })
        assertEquals(1, jvm.count { it.startsWith("-Dminecraft.launcher.version=") })
        assertTrue("-Dminecraft.client.jar=${layout.clientJar("1.21.1").path}" in jvm)
    }

    @Test
    fun gameArgumentsSkipDemoAndCustomResolution() {
        val game = create(modern).gameArgs

        assertFalse("--demo" in game)
        assertFalse("--width" in game)
        assertEquals("--username", game.first())
        assertTrue("\${auth_player_name}" in game)
    }

    @Test
    fun variablesDescribeTheAccountAndFolders() {
        val v = create(modern).variables

        assertEquals("Steve", v["auth_player_name"])
        assertEquals("5627dd98e6be3c21b8a8e92344183641", v["auth_uuid"])
        assertEquals("0", v["auth_access_token"])
        assertEquals("msa", v["user_type"])
        assertEquals(dirs.root.path, v["game_directory"])
        assertEquals(dirs.assets.path, v["assets_root"])
        assertEquals("17", v["assets_index_name"])
        assertEquals(dirs.libraries.path, v["library_directory"])
        assertEquals("1.21.1", v["version_name"])
        assertEquals("release", v["version_type"])
        assertEquals("MCLauncher", v["launcher_name"])
        assertEquals("0.1.0", v["launcher_version"])
    }

    @Test
    fun theLoggingOptionIsAddedOnlyWhenTheFileIsDownloaded() {
        assertFalse(create(modern).jvmArgs.any { it.startsWith("-Dlog4j.configurationFile=") })

        val config = layout.logConfig("client-1.12.xml")!!.apply { parentFile.mkdirs(); writeText("<xml/>") }

        assertTrue("-Dlog4j.configurationFile=${config.path}" in create(modern).jvmArgs)
    }

    // ---------------------------------------------------------------- старая версия

    @Test
    fun legacyVersionHasNoJvmArgumentsOfItsOwn() {
        val spec = create(legacy)

        assertEquals(8, spec.javaMajor)
        assertEquals(
            listOf(
                "-Dminecraft.client.jar=${layout.clientJar("1.8.9").path}",
                "-Dminecraft.launcher.brand=\${launcher_name}",
                "-Dminecraft.launcher.version=\${launcher_version}",
            ),
            spec.jvmArgs,
        )
    }

    @Test
    fun theArgumentFormatIsPassedToTheEngine() {
        assertEquals(true, create(modern).newArgumentFormat)
        assertEquals(false, create(legacy).newArgumentFormat)
    }

    @Test
    fun legacyGameArgumentsComeFromTheSingleString() {
        val game = create(legacy).gameArgs

        assertEquals(listOf("--username", "\${auth_player_name}"), game.take(2))
        assertTrue("--userProperties" in game)
        assertTrue("\${user_properties}" in game)
    }

    @Test
    fun legacyLibrariesDropLwjgl2AndTwitch() {
        val jars = create(legacy).libraryJars

        assertTrue(jars.any { it.endsWith("netty-1.8.8.jar") })
        assertFalse(jars.any { it.contains("lwjgl") || it.contains("twitch") })
    }

    @Test
    fun lwjgl2IsDetectedWhenTheVersionListsItsCoreLibrary() {
        // В сокращённом образце нет `org.lwjgl.lwjgl:lwjgl`, в настоящем 1.8.9 он есть.
        val core = library("org.lwjgl.lwjgl:lwjgl:2.9.4-nightly-20150209", "org/lwjgl/lwjgl/lwjgl/2.9.4/lwjgl-2.9.4.jar")

        val spec = create(legacy.copy(libraries = legacy.libraries + core))

        assertEquals(LwjglRequirement(LwjglVersion.V3_3_3, legacyLwjgl2 = true), spec.lwjgl)
        assertFalse(spec.libraryJars.any { it.contains("lwjgl") })
    }

    // ---------------------------------------------------------------- прочее

    @Test
    fun asmAllIsDroppedWhenModernAsmIsPresent() {
        val asm = library("org.ow2.asm:asm:9.6", "org/ow2/asm/asm/9.6/asm-9.6.jar")
        val asmAll = library("org.ow2.asm:asm-all:5.0.3", "org/ow2/asm/asm-all/5.0.3/asm-all-5.0.3.jar")

        val spec = create(modern.copy(libraries = modern.libraries + asmAll + asm))

        assertTrue(spec.libraryJars.any { it.endsWith("asm-9.6.jar") })
        assertFalse(spec.libraryJars.any { it.contains("asm-all") })
    }

    @Test
    fun asmAllStaysWhenThereIsNoModernAsm() {
        val asmAll = library("org.ow2.asm:asm-all:5.0.3", "org/ow2/asm/asm-all/5.0.3/asm-all-5.0.3.jar")

        val spec = create(modern.copy(libraries = modern.libraries + asmAll))

        assertTrue(spec.libraryJars.any { it.contains("asm-all") })
    }

    @Test
    fun unsafeLibraryPathsAreDropped() {
        val evil = library("com.evil:lib:1.0", "../../etc/passwd")

        val spec = create(modern.copy(libraries = modern.libraries + evil))

        assertFalse(spec.libraryJars.any { it.contains("passwd") })
    }

    // ---------------------------------------------------------------- вместе с ядром

    @Test
    fun theWholeChainProducesACommandWithCoreNativesAndNoLeftoverTemplates() {
        val engineLayout = EngineLayout(
            componentsDir = File(tmp.root, "components"),
            runtimesDir = File(tmp.root, "runtimes"),
            nativeLibraryDir = File(tmp.root, "lib"),
            abi = "arm64-v8a",
        )
        val env = EngineEnvironment(
            gameDir = dirs.root, userHome = tmp.root, cacheDir = File(tmp.root, "cache"),
            timezone = "Asia/Baku", androidRelease = "15", screenWidth = 2400, screenHeight = 1080, cpuCores = 8,
        )
        val spec = create(modern)

        val command = LaunchCommandBuilder(engineLayout, env).build(spec)

        val natives = engineLayout.lwjglNativesDir(LwjglVersion.V3_3_3).path
        assertEquals(listOf("-Djava.library.path=$natives"), command.args.filter { it.startsWith("-Djava.library.path=") })
        assertFalse(command.args.any { it.contains("\${") })
        assertTrue(command.warnings.toString(), command.warnings.isEmpty())
        val wrapper = command.args.indexOf("mio.Wrapper")
        assertEquals("net.minecraft.client.main.Main", command.args[wrapper + 1])
        assertEquals("Steve", command.args[command.args.indexOf("--username") + 1])
        assertEquals("5627dd98e6be3c21b8a8e92344183641", command.args[command.args.indexOf("--uuid") + 1])
        assertEquals("********", command.redacted()[command.redacted().indexOf("--accessToken") + 1])
    }
}
