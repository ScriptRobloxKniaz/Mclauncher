package com.mclauncher.app.data.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class JvmArgumentsTest {

    private fun accepted(text: String) = JvmArguments.parse(text).accepted

    private fun reasons(text: String) = JvmArguments.parse(text).rejected.associate { it.argument to it.reason }

    @Test
    fun emptyAndBlankTextGiveNothing() {
        assertTrue(JvmArguments.parse("").accepted.isEmpty())
        assertTrue(JvmArguments.parse("   \n\t ").accepted.isEmpty())
        assertTrue(JvmArguments.parse("   ").rejected.isEmpty())
    }

    @Test
    fun argumentsAreSplitByAnyWhitespace() {
        assertEquals(listOf("-XX:+UseG1GC", "-Dfoo=bar", "-Xss1M"), accepted("-XX:+UseG1GC   -Dfoo=bar\n-Xss1M"))
    }

    @Test
    fun quotesGroupAnArgumentWithSpacesAndAreDropped() {
        assertEquals(listOf("-Dname=a b", "-Dx=1"), accepted("\"-Dname=a b\" -Dx=1"))
        assertEquals(listOf("-Dname=a b"), accepted("-Dname=\"a b\""))
    }

    @Test
    fun anUnterminatedQuoteKeepsTheRestAsOneArgument() {
        assertEquals(listOf("-Dname=a b -Dx=1"), accepted("-Dname=\"a b -Dx=1"))
    }

    @Test
    fun emptyQuotesProduceNoArgument() {
        assertTrue(JvmArguments.parse("\"\"").accepted.isEmpty())
    }

    @Test
    fun aStrayWordIsRejectedBecauseTheJvmWouldTakeItForTheMainClass() {
        val parsed = JvmArguments.parse("-Dok=1 net.minecraft.Main")
        assertEquals(listOf("-Dok=1"), parsed.accepted)
        assertEquals(RejectReason.NOT_AN_OPTION, parsed.rejected.single().reason)
    }

    @Test
    fun memoryFlagsBelongToTheSlider() {
        val r = reasons("-Xmx4G -Xms1G -XX:MaxHeapSize=2g -XX:InitialHeapSize=1g -Xmn256m")
        assertEquals(RejectReason.MEMORY, r["-Xmx4G"])
        assertEquals(RejectReason.MEMORY, r["-Xms1G"])
        assertEquals(RejectReason.MEMORY, r["-XX:MaxHeapSize=2g"])
        assertEquals(RejectReason.MEMORY, r["-XX:InitialHeapSize=1g"])
        assertEquals("-Xmn is allowed", null, r["-Xmn256m"])
    }

    @Test
    fun classpathAndLibraryPathsAreManagedByTheLauncher() {
        val text = "-cp x -classpath y --class-path z --class-path=w -jar a.jar " +
            "-Djava.library.path=/x -Dorg.lwjgl.librarypath=/y -Dorg.lwjgl.opengl.libname=z -Dminecraft.client.jar=q"
        val parsed = JvmArguments.parse(text)
        assertTrue(parsed.accepted.isEmpty())
        // Значения после -cp и т. п. — отдельные слова, их отсеивает правило про главный класс.
        assertTrue(parsed.rejected.any { it.argument == "-cp" && it.reason == RejectReason.MANAGED })
        assertTrue(parsed.rejected.any { it.argument == "x" && it.reason == RejectReason.NOT_AN_OPTION })
        assertTrue(parsed.rejected.any { it.argument == "-Djava.library.path=/x" && it.reason == RejectReason.MANAGED })
        assertTrue(parsed.rejected.any { it.argument == "-Dorg.lwjgl.opengl.libname=z" && it.reason == RejectReason.MANAGED })
        assertTrue(parsed.rejected.any { it.argument == "--class-path=w" && it.reason == RejectReason.MANAGED })
    }

    @Test
    fun flagsThatPrintAndExitAreRejected() {
        for (flag in listOf("-version", "--version", "-help", "--help", "-h", "-?", "-X", "-showversion")) {
            assertEquals(flag, RejectReason.MANAGED, reasons(flag)[flag])
        }
    }

    @Test
    fun templatesAreRejected() {
        assertEquals(RejectReason.TEMPLATE, reasons("-Dx=\${auth_player_name}")["-Dx=\${auth_player_name}"])
    }

    @Test
    fun usefulFlagsPass() {
        val text = "-XX:+UseZGC -XX:+UnlockExperimentalVMOptions -Dfml.ignoreInvalidMinecraftCertificates=true " +
            "-javaagent:/sdcard/agent.jar -Dsun.java2d.opengl=false"
        assertEquals(5, accepted(text).size)
        assertTrue(JvmArguments.parse(text).rejected.isEmpty())
    }

    @Test
    fun anOverlongTextIsCutAtTheLimit() {
        val flag = "-Da=1 "
        val text = flag.repeat(1000)
        assertTrue(JvmArguments.parse(text).accepted.size <= JvmArguments.MAX_TEXT_LENGTH / flag.length + 1)
    }
}
