package com.mclauncher.app.data.background

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoImportPolicyTest {

    @Test
    fun aVideoMimeTypeIsAccepted() {
        assertTrue(VideoImportPolicy.isAcceptable("video/mp4", "clip.mp4"))
        assertTrue(VideoImportPolicy.isAcceptable("video/webm", null))
        assertTrue(VideoImportPolicy.isAcceptable("VIDEO/MP4", "x"))
    }

    @Test
    fun anotherKnownTypeIsRejectedEvenWithAVideoExtension() {
        assertFalse(VideoImportPolicy.isAcceptable("image/png", "fake.mp4"))
        assertFalse(VideoImportPolicy.isAcceptable("text/plain", "notes.mp4"))
    }

    @Test
    fun anUnknownTypeIsDecidedByTheExtension() {
        assertTrue(VideoImportPolicy.isAcceptable(null, "background.mp4"))
        assertTrue(VideoImportPolicy.isAcceptable("application/octet-stream", "Background.MP4"))
        assertTrue(VideoImportPolicy.isAcceptable("", "loop.mkv"))
    }

    @Test
    fun anUnknownTypeWithoutAVideoExtensionIsRejected() {
        assertFalse(VideoImportPolicy.isAcceptable(null, null))
        assertFalse(VideoImportPolicy.isAcceptable(null, "photo.jpg"))
        assertFalse(VideoImportPolicy.isAcceptable(null, "mp4"))
        assertFalse(VideoImportPolicy.isAcceptable("application/octet-stream", "archive.zip"))
    }

    @Test
    fun theSizeLimitIsInclusive() {
        assertFalse(VideoImportPolicy.isTooLarge(VideoImportPolicy.MAX_BYTES))
        assertTrue(VideoImportPolicy.isTooLarge(VideoImportPolicy.MAX_BYTES + 1))
        assertFalse(VideoImportPolicy.isTooLarge(0))
    }

    @Test
    fun spaceMustCoverTheFileAndTheReserve() {
        val reserve = VideoImportPolicy.SPACE_RESERVE_BYTES
        val file = 100L * 1024 * 1024

        assertTrue(VideoImportPolicy.hasEnoughSpace(file, usable = file + reserve))
        assertFalse(VideoImportPolicy.hasEnoughSpace(file, usable = file + reserve - 1))
        assertFalse(VideoImportPolicy.hasEnoughSpace(file, usable = 0))
    }

    @Test
    fun theExceptionKeepsItsReason() {
        val e = VideoImportException(VideoImportReason.TOO_LARGE)

        assertEquals(VideoImportReason.TOO_LARGE, e.reason)
        assertEquals("TOO_LARGE", e.message)
    }
}
