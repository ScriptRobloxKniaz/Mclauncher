package com.mclauncher.app.core

import com.mclauncher.engine.install.ComponentState
import com.mclauncher.engine.install.CoreInstallException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreStateTest {

    private fun known(vararg states: ComponentState) = CoreDisk.Known(
        states.mapIndexed { i, s -> CoreComponentInfo("c$i", s, bytes = 100L * (i + 1)) },
    )

    private val done = known(ComponentState.INSTALLED, ComponentState.INSTALLED)
    private val partial = known(ComponentState.INSTALLED, ComponentState.MISSING, ComponentState.OUTDATED)

    // ---------------------------------------------------------------- по диску

    @Test
    fun allInstalledMeansReady() {
        val s = reduceCoreState(done, CoreWork())

        assertEquals(CorePhase.READY, s.phase)
        assertEquals(2, s.installedCount)
        assertFalse(s.canInstall)
        assertFalse(s.canCancel)
    }

    @Test
    fun somethingMissingMeansInstallIsNeeded() {
        val s = reduceCoreState(partial, CoreWork())

        assertEquals(CorePhase.NEEDS_INSTALL, s.phase)
        assertEquals(1, s.installedCount)
        assertTrue(s.canInstall)
    }

    @Test
    fun theMissingSizeCountsOnlyWhatIsNotInstalled() {
        // c0 установлен (100), c1 — нет (200), c2 устарел (300).
        assertEquals(500L, reduceCoreState(partial, CoreWork()).missingBytes)
    }

    @Test
    fun aBuildWithoutTheCoreIsReportedAsSuch() {
        val s = reduceCoreState(CoreDisk.NotBundled, CoreWork())

        assertEquals(CorePhase.NOT_BUNDLED, s.phase)
        assertFalse(s.canInstall)
    }

    @Test
    fun anUnsupportedDeviceIsReportedWithItsAbi() {
        val s = reduceCoreState(CoreDisk.UnsupportedDevice("x86", "arm64-v8a"), CoreWork())

        assertEquals(CorePhase.UNSUPPORTED, s.phase)
        assertEquals("x86", s.detail)
        assertFalse(s.canInstall)
    }

    @Test
    fun beforeTheFirstCheckTheStateIsChecking() {
        assertEquals(CorePhase.CHECKING, reduceCoreState(null, CoreWork()).phase)
    }

    // ---------------------------------------------------------------- фоновая установка

    @Test
    fun aRunningInstallShowsProgress() {
        val s = reduceCoreState(partial, CoreWork(WorkPhase.RUNNING, doneBytes = 25, totalBytes = 100, label = "lib/rt.jar"))

        assertEquals(CorePhase.INSTALLING, s.phase)
        assertEquals(0.25f, s.progress, 0.0001f)
        assertEquals("lib/rt.jar", s.label)
        assertTrue(s.canCancel)
        assertFalse(s.canInstall)
    }

    @Test
    fun progressStaysInRangeAndHandlesAnUnknownTotal() {
        assertEquals(1f, reduceCoreState(partial, CoreWork(WorkPhase.RUNNING, 500, 100)).progress, 0f)
        assertEquals(0f, reduceCoreState(partial, CoreWork(WorkPhase.RUNNING, 5, 0)).progress, 0f)
    }

    @Test
    fun aQueuedInstallCanBeCancelled() {
        val s = reduceCoreState(partial, CoreWork(WorkPhase.QUEUED))

        assertEquals(CorePhase.QUEUED, s.phase)
        assertTrue(s.canCancel)
    }

    @Test
    fun aRunningInstallWinsEvenIfTheDiskCheckIsStale() {
        assertEquals(CorePhase.INSTALLING, reduceCoreState(done, CoreWork(WorkPhase.RUNNING, 1, 2)).phase)
        assertEquals(CorePhase.INSTALLING, reduceCoreState(null, CoreWork(WorkPhase.RUNNING, 1, 2)).phase)
    }

    // ---------------------------------------------------------------- итог работы

    @Test
    fun aFailedInstallShowsTheReasonAndCanBeRetried() {
        val s = reduceCoreState(partial, CoreWork(WorkPhase.FAILED, failure = CoreFailure.NO_SPACE, detail = "need 5"))

        assertEquals(CorePhase.FAILED, s.phase)
        assertEquals(CoreFailure.NO_SPACE, s.failure)
        assertEquals("need 5", s.detail)
        assertTrue(s.canInstall)
    }

    @Test
    fun aFailureWithoutAReasonIsTheGenericOne() {
        assertEquals(CoreFailure.OTHER, reduceCoreState(partial, CoreWork(WorkPhase.FAILED)).failure)
    }

    @Test
    fun anOldFailureIsForgottenOnceEverythingIsInstalled() {
        assertEquals(CorePhase.READY, reduceCoreState(done, CoreWork(WorkPhase.FAILED, failure = CoreFailure.CORRUPT)).phase)
    }

    @Test
    fun aCancelledOrFinishedWorkThatLeftGapsAsksForInstall() {
        assertEquals(CorePhase.NEEDS_INSTALL, reduceCoreState(partial, CoreWork(WorkPhase.CANCELLED)).phase)
        assertEquals(CorePhase.NEEDS_INSTALL, reduceCoreState(partial, CoreWork(WorkPhase.SUCCEEDED)).phase)
    }

    @Test
    fun aBuildWithoutTheCoreIgnoresAStaleFailure() {
        assertEquals(CorePhase.NOT_BUNDLED, reduceCoreState(CoreDisk.NotBundled, CoreWork(WorkPhase.FAILED, failure = CoreFailure.OTHER)).phase)
    }

    // ---------------------------------------------------------------- ошибки движка

    @Test
    fun engineErrorsMapToScreenFailures() {
        assertEquals(CoreFailure.NOT_BUNDLED, CoreInstallException.AssetMissing("core/x").toFailure())
        assertEquals(CoreFailure.NO_SPACE, CoreInstallException.NoSpace(10, 1).toFailure())
        assertEquals(CoreFailure.CORRUPT, CoreInstallException.Corrupt("core/x").toFailure())
        assertEquals(CoreFailure.OTHER, CoreInstallException.UnknownComponent("x").toFailure())
        assertEquals(CoreFailure.OTHER, CoreInstallException.Failed("jre-8", java.io.IOException("boom")).toFailure())
    }

    @Test
    fun aFailureCodeRoundTripsThroughWorkData() {
        for (f in CoreFailure.entries) assertEquals(f, failureFromCode(f.name))
        assertEquals(CoreFailure.OTHER, failureFromCode("from the future"))
        assertEquals(CoreFailure.OTHER, failureFromCode(null))
        assertNull(reduceCoreState(done, CoreWork()).failure)
    }
}
