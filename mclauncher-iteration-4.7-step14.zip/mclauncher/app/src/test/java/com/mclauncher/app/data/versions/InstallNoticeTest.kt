package com.mclauncher.app.data.versions

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InstallNoticeTest {

    private fun progress(done: Long, total: Long, speed: Long = 0) =
        InstallProgress(InstallPhase.DOWNLOADING, bytesDone = done, bytesTotal = total, bytesPerSecond = speed)

    @Test
    fun idleHasNothingToReport() {
        assertEquals(InstallNotice.None, InstallNotice.of(InstallState.Idle))
        assertFalse(InstallNotice.None.keepsServiceAlive)
    }

    @Test
    fun aRunningInstallWithoutProgressIsIndeterminate() {
        val notice = InstallNotice.of(InstallState.Running("1.21.1", progress = null))

        assertEquals(InstallNotice.Running("1.21.1", percent = null, bytesPerSecond = 0), notice)
        assertTrue(notice.keepsServiceAlive)
    }

    @Test
    fun theSizeIsUnknownUntilTheTotalIsKnown() {
        val notice = InstallNotice.of(InstallState.Running("1.21.1", progress(done = 5, total = 0))) as InstallNotice.Running

        assertEquals(null, notice.percent)
    }

    @Test
    fun percentIsRoundedDownAndKeptInRange() {
        fun percent(done: Long, total: Long) =
            (InstallNotice.of(InstallState.Running("v", progress(done, total))) as InstallNotice.Running).percent

        assertEquals(0, percent(0, 200))
        assertEquals(49, percent(499, 1000)) // 49,9 % — не «50», пока не дошло
        assertEquals(100, percent(200, 200))
        assertEquals(100, percent(300, 200)) // лишние байты не уводят за 100
    }

    @Test
    fun theSpeedIsPassedAndNeverNegative() {
        val fast = InstallNotice.of(InstallState.Running("v", progress(1, 10, speed = 5_000_000))) as InstallNotice.Running
        val odd = InstallNotice.of(InstallState.Running("v", progress(1, 10, speed = -7))) as InstallNotice.Running

        assertEquals(5_000_000L, fast.bytesPerSecond)
        assertEquals(0L, odd.bytesPerSecond)
    }

    @Test
    fun onlyARunningInstallKeepsTheServiceAlive() {
        assertTrue(InstallNotice.of(InstallState.Running("v", null)).keepsServiceAlive)
        assertFalse(InstallNotice.of(InstallState.Done("v")).keepsServiceAlive)
        assertFalse(InstallNotice.of(InstallState.Failed("v", InstallError.Network(null))).keepsServiceAlive)
        assertFalse(InstallNotice.of(InstallState.Idle).keepsServiceAlive)
    }

    @Test
    fun finishedInstallsKeepTheirVersion() {
        assertEquals(InstallNotice.Done("1.21.1"), InstallNotice.of(InstallState.Done("1.21.1")))
        assertEquals(InstallNotice.Failed("1.21.1"), InstallNotice.of(InstallState.Failed("1.21.1", InstallError.Network(null))))
    }
}
