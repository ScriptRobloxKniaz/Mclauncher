package com.mclauncher.app.data.net

import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.Collections
import java.util.concurrent.Executors

/**
 * Настоящий HTTP на локальном сервере JDK: проверяется поведение `HttpURLConnection` (без Android), в частности то,
 * что подряд идущие запросы к одному узлу идут по одному соединению. На Android под тем же API работает OkHttp
 * платформы; там это поведение нужно проверить на устройстве.
 */
class UrlConnectionHttpSourceTest {

    private lateinit var server: HttpServer
    private val clientPorts = Collections.synchronizedSet(HashSet<Int>())
    private val userAgents = Collections.synchronizedList(ArrayList<String?>())
    private val encodings = Collections.synchronizedList(ArrayList<String?>())

    private fun base() = "http://${InetAddress.getLoopbackAddress().hostAddress}:${server.address.port}"

    @Before
    fun start() {
        server = HttpServer.create(InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0)
        server.executor = Executors.newCachedThreadPool()
        server.createContext("/file") { ex: HttpExchange ->
            clientPorts += ex.remoteAddress.port
            userAgents += ex.requestHeaders.getFirst("User-Agent")
            encodings += ex.requestHeaders.getFirst("Accept-Encoding")
            val body = "payload-${ex.requestURI.query}".toByteArray()
            ex.sendResponseHeaders(200, body.size.toLong())
            ex.responseBody.use { it.write(body) }
        }
        server.createContext("/missing") { ex: HttpExchange ->
            ex.sendResponseHeaders(404, -1)
            ex.close()
        }
        server.createContext("/boom") { ex: HttpExchange ->
            ex.sendResponseHeaders(503, -1)
            ex.close()
        }
        server.start()
    }

    @After
    fun stop() {
        server.stop(0)
        (server.executor as java.util.concurrent.ExecutorService).shutdownNow()
    }

    private fun source() = UrlConnectionHttpSource(userAgent = "MCLauncher/test", connectTimeoutMs = 3_000, readTimeoutMs = 3_000)

    private suspend fun fetch(source: HttpSource, query: String): String =
        source.get("${base()}/file?$query") { body ->
            assertEquals("payload-$query".length.toLong(), body.contentLength)
            String(body.stream.readBytes())
        }

    @Test
    fun readsTheBodyAndSendsTheExpectedHeaders() = runBlocking {
        val text = fetch(source(), "a")

        assertEquals("payload-a", text)
        assertEquals(listOf<String?>("MCLauncher/test"), userAgents.toList())
        assertEquals(listOf<String?>("identity"), encodings.toList())
    }

    @Test
    fun sequentialRequestsReuseOneConnection() = runBlocking {
        val source = source()

        repeat(12) { assertEquals("payload-$it", fetch(source, "$it")) }

        assertTrue("connections used: ${clientPorts.size}", clientPorts.size <= 2)
    }

    @Test
    fun failedStatusIsReportedWithTheCode() = runBlocking {
        val missing = runCatching { source().get("${base()}/missing") { } }.exceptionOrNull()
        val boom = runCatching { source().get("${base()}/boom") { } }.exceptionOrNull()

        assertEquals(404, (missing as HttpStatusException).status)
        assertEquals(503, (boom as HttpStatusException).status)
    }

    @Test
    fun connectionStillWorksAfterAFailedResponse() = runBlocking {
        val source = source()
        runCatching { source.get("${base()}/missing") { } }

        assertEquals("payload-x", fetch(source, "x"))
    }

    @Test
    fun errorsFromTheConsumerPassThroughUnchanged() = runBlocking {
        val failure = runCatching {
            source().get("${base()}/file?q") { throw IOException("disk full") }
        }.exceptionOrNull()

        assertEquals("disk full", failure?.message)
    }

    @Test
    fun refusedConnectionIsAnIoException() = runBlocking {
        val dead = HttpServer.create(InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0)
        val port = dead.address.port
        dead.stop(0) // порт свободен — соединение будет отклонено

        val failure = runCatching {
            source().get("http://${InetAddress.getLoopbackAddress().hostAddress}:$port/x") { }
        }.exceptionOrNull()

        assertTrue("was $failure", failure is IOException)
    }

    @Test
    fun poolSizeIsRaisedOnlyWhenNotSetAlready() {
        val key = "http.maxConnections"
        val before = System.getProperty(key)
        try {
            System.clearProperty(key)
            assertTrue(UrlConnectionHttpSource.enlargeConnectionPool(40))
            assertEquals("40", System.getProperty(key))

            assertFalse("a value set from outside must stay", UrlConnectionHttpSource.enlargeConnectionPool(7))
            assertEquals("40", System.getProperty(key))

            assertFalse(UrlConnectionHttpSource.enlargeConnectionPool(0))
        } finally {
            if (before == null) System.clearProperty(key) else System.setProperty(key, before)
        }
    }
}
