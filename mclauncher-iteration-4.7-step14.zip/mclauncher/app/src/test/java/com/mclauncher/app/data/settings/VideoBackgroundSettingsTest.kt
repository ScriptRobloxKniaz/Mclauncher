package com.mclauncher.app.data.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoBackgroundSettingsTest {

    @Test
    fun byDefaultTheVideoIsMutedAndThereIsNoVideo() {
        val settings = VideoBackgroundSettings()

        assertTrue(settings.muted)
        assertTrue(settings.enabled)
        assertFalse(settings.hasVideo)
        assertEquals(0f, settings.effectiveVolume, 0f)
    }

    @Test
    fun aMutedVideoIsSilentWhateverTheVolumeIs() {
        val settings = VideoBackgroundSettings(volume = 1f, muted = true)

        assertEquals(0f, settings.effectiveVolume, 0f)
    }

    @Test
    fun anUnmutedVideoPlaysAtTheChosenVolume() {
        val settings = VideoBackgroundSettings(volume = 0.7f, muted = false)

        assertEquals(0.7f, settings.effectiveVolume, 0f)
    }

    @Test
    fun anOutOfRangeVolumeIsClamped() {
        assertEquals(1f, VideoBackgroundSettings(volume = 5f, muted = false).effectiveVolume, 0f)
        assertEquals(0f, VideoBackgroundSettings(volume = -2f, muted = false).effectiveVolume, 0f)
    }

    @Test
    fun aBrokenVolumeFallsBackToTheDefault() {
        assertEquals(VideoBackgroundSettings.DEFAULT_VOLUME, sanitizeVolume(Float.NaN), 0f)
        assertEquals(VideoBackgroundSettings.DEFAULT_VOLUME, VideoBackgroundSettings(volume = Float.NaN, muted = false).effectiveVolume, 0f)
    }

    @Test
    fun sanitizeKeepsValidValuesAndTheEdges() {
        assertEquals(0f, sanitizeVolume(0f), 0f)
        assertEquals(0.25f, sanitizeVolume(0.25f), 0f)
        assertEquals(1f, sanitizeVolume(1f), 0f)
        assertEquals(1f, sanitizeVolume(Float.POSITIVE_INFINITY), 0f)
        assertEquals(0f, sanitizeVolume(Float.NEGATIVE_INFINITY), 0f)
    }

    @Test
    fun theVideoIsActiveOnlyWhenChosenAndEnabled() {
        assertFalse(VideoBackgroundSettings(enabled = true, stamp = null).active)
        assertFalse(VideoBackgroundSettings(enabled = false, stamp = 1L).active)
        assertTrue(VideoBackgroundSettings(enabled = true, stamp = 1L).active)
    }

    @Test
    fun turningTheVideoOffKeepsItChosen() {
        val off = VideoBackgroundSettings(enabled = false, stamp = 42L)

        assertTrue(off.hasVideo)
        assertFalse(off.active)
    }
}
