package com.mclauncher.app.data.versions

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class DownloadScheduleTest {

    private fun task(name: String, size: Long, kind: FileKind = FileKind.LIBRARY) =
        DownloadTask("https://x.test/$name", File("/tmp/$name"), sha1 = null, size = size, kind = kind)

    private fun names(tasks: List<DownloadTask>) = tasks.map { it.target.name }

    @Test
    fun largeFilesGoFirstBiggestToSmallest() {
        val schedule = DownloadSchedule.of(
            listOf(task("a", 1_000), task("jar", 25_000_000), task("b", 2_000_000), task("c", 10)),
            threshold = 1_000_000,
        )

        assertEquals(listOf("jar", "b"), names(schedule.large))
        assertEquals(listOf("a", "c"), names(schedule.small))
    }

    @Test
    fun smallFilesKeepTheirOriginalOrder() {
        val tasks = (1..20).map { task("asset$it", (100 + (it * 37) % 50).toLong()) }

        val schedule = DownloadSchedule.of(tasks, threshold = 10_000)

        assertTrue(schedule.large.isEmpty())
        assertEquals(names(tasks), names(schedule.small))
    }

    @Test
    fun equalSizedLargeFilesKeepTheirOriginalOrder() {
        val schedule = DownloadSchedule.of(
            listOf(task("x", 500), task("y", 500), task("z", 500)),
            threshold = 100,
        )

        assertEquals(listOf("x", "y", "z"), names(schedule.large))
    }

    @Test
    fun theThresholdItselfCountsAsLarge() {
        val schedule = DownloadSchedule.of(listOf(task("edge", 100), task("below", 99)), threshold = 100)

        assertEquals(listOf("edge"), names(schedule.large))
        assertEquals(listOf("below"), names(schedule.small))
    }

    @Test
    fun unknownSizeIsTreatedAsSmall() {
        val schedule = DownloadSchedule.of(listOf(task("none", -1), task("zero", 0)), threshold = 1)

        assertTrue(schedule.large.isEmpty())
        assertEquals(listOf("none", "zero"), names(schedule.small))
    }

    @Test
    fun nothingIsLostOrDuplicated() {
        val tasks = (1..200).map { task("f$it", (it * 7919L) % 3_000_000) }

        val schedule = DownloadSchedule.of(tasks)

        assertEquals(tasks.size, schedule.size)
        assertEquals(names(tasks).sorted(), (names(schedule.large) + names(schedule.small)).sorted())
    }

    @Test
    fun emptyInputGivesEmptyQueues() {
        val schedule = DownloadSchedule.of(emptyList())

        assertEquals(0, schedule.size)
        assertTrue(schedule.large.isEmpty() && schedule.small.isEmpty())
    }

    @Test(expected = IllegalArgumentException::class)
    fun nonPositiveThresholdIsRejected() {
        DownloadSchedule.of(listOf(task("a", 1)), threshold = 0)
    }

    @Test
    fun defaultThresholdSeparatesAJarFromAnAsset() {
        val schedule = DownloadSchedule.of(listOf(task("client.jar", 27_000_000), task("sound.ogg", 40_000)))

        assertEquals(listOf("client.jar"), names(schedule.large))
        assertEquals(listOf("sound.ogg"), names(schedule.small))
    }

    @Test
    fun bufferFollowsTheFileSize() {
        assertEquals(FileDownloader.BUFFER_SIZE, FileDownloader.bufferSizeFor(-1))
        assertEquals(FileDownloader.BUFFER_SIZE, FileDownloader.bufferSizeFor(0))
        assertEquals(4096, FileDownloader.bufferSizeFor(1))
        assertEquals(4096, FileDownloader.bufferSizeFor(4096))
        assertEquals(20_000, FileDownloader.bufferSizeFor(20_000))
        assertEquals(FileDownloader.BUFFER_SIZE, FileDownloader.bufferSizeFor(FileDownloader.BUFFER_SIZE.toLong()))
        assertEquals(FileDownloader.BUFFER_SIZE, FileDownloader.bufferSizeFor(5_000_000_000L))
    }
}
