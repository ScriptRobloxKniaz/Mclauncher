package com.mclauncher.app.data.versions

import com.mclauncher.app.data.net.UrlConnectionHttpSource
import com.mclauncher.app.data.settings.LaunchSettings
import com.mclauncher.app.launch.GameDirectories
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.Collections

/**
 * Установка версии целиком на поддельном «сервере Mojang»: файлы, их хэши и описания согласованы между собой,
 * поэтому проверяется всё — от манифеста до метки установки — без сети.
 */
class VersionInstallerTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val dirs by lazy { GameDirectories(File(tmp.root, ".minecraft")) }
    private val layout by lazy { VersionLayout(dirs) }
    private val env = OsEnvironment.LINUX_ARM64

    /** Одна версия «на сервере»: содержимое файлов, JSON описания и индекса, адреса. */
    private inner class Repo(
        val http: FakeHttpSource,
        val id: String = "1.21.1",
        assetCount: Int = 3,
        val libraryPath: String = "com/example/lib/1.0/lib-1.0.jar",
        inheritsFrom: String? = null,
        virtualAssets: Boolean = false,
    ) {
        val clientJar = "client-jar-bytes".toByteArray()
        val lib = "library-bytes-1".toByteArray()
        val lib2 = "library-bytes-2".toByteArray()
        val log = "<Configuration/>".toByteArray()
        val assets: List<Pair<String, ByteArray>> =
            (1..assetCount).map { "minecraft/sounds/s$it.ogg" to "asset-content-$it".toByteArray() }

        val versionUrl = "https://meta.test/$id.json"
        val indexUrl = "https://meta.test/assets/17.json"
        val clientUrl = "https://dl.test/$id/client.jar"
        val libUrl = "https://libs.test/lib.jar"
        val lib2Url = "https://libs.test/other.jar"
        val logUrl = "https://dl.test/log.xml"
        val windowsOnlyUrl = "https://libs.test/windows-only.jar"
        val nativeUrl = "https://libs.test/lwjgl-natives-linux.jar"

        fun assetUrl(bytes: ByteArray): String {
            val hash = sha1Hex(bytes)
            return "https://resources.download.minecraft.net/${hash.substring(0, 2)}/$hash"
        }

        fun assetFile(bytes: ByteArray): File {
            val hash = sha1Hex(bytes)
            return File(dirs.assets, "objects/${hash.substring(0, 2)}/$hash")
        }

        val indexBytes: ByteArray = buildString {
            append("{\"objects\": {")
            append(
                assets.joinToString(",") { (name, bytes) ->
                    "\"$name\": {\"hash\": \"${sha1Hex(bytes)}\", \"size\": ${bytes.size}}"
                },
            )
            append("}")
            if (virtualAssets) append(", \"virtual\": true")
            append("}")
        }.toByteArray()

        private val inheritsField = if (inheritsFrom != null) ", \"inheritsFrom\": \"$inheritsFrom\"" else ""
        private val fakeHash = "0".repeat(40)

        val versionJson: String = """
            {
              "id": "$id", "type": "release", "mainClass": "net.minecraft.client.main.Main",
              "releaseTime": "2024-08-08T12:00:00+00:00",
              "assets": "17",
              "assetIndex": {"id": "17", "url": "$indexUrl", "sha1": "${sha1Hex(indexBytes)}",
                             "size": ${indexBytes.size}, "totalSize": ${assets.sumOf { it.second.size }}},
              "downloads": {"client": {"url": "$clientUrl", "sha1": "${sha1Hex(clientJar)}", "size": ${clientJar.size}}},
              "javaVersion": {"component": "java-runtime-delta", "majorVersion": 21},
              "arguments": {"game": ["--demo"], "jvm": ["-Xss1M"]},
              "libraries": [
                {"name": "com.example:lib:1.0", "downloads": {"artifact": {"path": "$libraryPath",
                  "url": "$libUrl", "sha1": "${sha1Hex(lib)}", "size": ${lib.size}}}},
                {"name": "com.example:other:2.0", "downloads": {"artifact": {"path": "com/example/other/2.0/other-2.0.jar",
                  "url": "$lib2Url", "sha1": "${sha1Hex(lib2)}", "size": ${lib2.size}}}},
                {"name": "com.example:windows-only:1.0", "rules": [{"action": "allow", "os": {"name": "windows"}}],
                  "downloads": {"artifact": {"path": "com/example/windows-only/1.0/windows-only-1.0.jar",
                  "url": "$windowsOnlyUrl", "sha1": "$fakeHash", "size": 10}}},
                {"name": "org.lwjgl:lwjgl:3.3.3:natives-linux",
                  "downloads": {"artifact": {"path": "org/lwjgl/lwjgl/3.3.3/lwjgl-3.3.3-natives-linux.jar",
                  "url": "$nativeUrl", "sha1": "$fakeHash", "size": 10}}}
              ],
              "logging": {"client": {"argument": "-Dlog4j.configurationFile=${'$'}{path}",
                "file": {"id": "client-1.12.xml", "url": "$logUrl", "sha1": "${sha1Hex(log)}", "size": ${log.size}},
                "type": "log4j2-xml"}}
              $inheritsField
            }
        """.trimIndent()

        val entry = ManifestEntry(
            id = id,
            type = VersionType.RELEASE,
            url = versionUrl,
            sha1 = sha1Hex(versionJson.toByteArray()),
            releaseTime = "2024-08-08T12:00:00+00:00",
        )

        /** Файлы, которые должны быть скачаны: клиент, две библиотеки, конфигурация логов и ассеты. */
        val downloadableCount get() = 4 + assets.size
        val downloadableBytes get() =
            (clientJar.size + lib.size + lib2.size + log.size + assets.sumOf { it.second.size }).toLong()

        fun serveAll() {
            http.serve(versionUrl, versionJson)
            http.serve(indexUrl, indexBytes)
            http.serve(clientUrl, clientJar)
            http.serve(libUrl, lib)
            http.serve(lib2Url, lib2)
            http.serve(logUrl, log)
            assets.forEach { (_, bytes) -> http.serve(assetUrl(bytes), bytes) }
        }
    }

    private fun installer(
        http: FakeHttpSource,
        concurrency: Int = 4,
        largeFileConcurrency: Int = 2,
        largeFileThreshold: Long = DownloadSchedule.DEFAULT_THRESHOLD_BYTES,
        freeSpace: (File) -> Long = { Long.MAX_VALUE },
    ) = VersionInstaller(
        directories = dirs,
        http = http,
        env = env,
        downloader = FileDownloader(http, maxAttempts = 2, retryDelayMs = { 0L }),
        concurrency = concurrency,
        largeFileConcurrency = largeFileConcurrency,
        largeFileThreshold = largeFileThreshold,
        freeSpace = freeSpace,
        progressIntervalMs = 0L,
    )

    private fun failed(result: InstallResult): InstallError =
        (result as? InstallResult.Failed)?.error ?: error("Expected a failure but got $result")

    // ---- Успешная установка ---------------------------------------------------------------

    @Test
    fun installsEverythingAndWritesTheMarkerLast() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http).also { it.serveAll() }
        val events = Collections.synchronizedList(ArrayList<InstallProgress>())

        val result = installer(http).install(repo.entry) { events += it }

        val installed = (result as InstallResult.Installed).version
        assertEquals("1.21.1", installed.id)
        assertEquals("net.minecraft.client.main.Main", installed.mainClass)
        assertEquals("17", installed.assetsId)
        assertEquals(21, installed.javaMajor)

        assertEquals(repo.versionJson, layout.versionJson("1.21.1").readText())
        assertEquals(repo.clientJar.toList(), layout.clientJar("1.21.1").readBytes().toList())
        assertEquals(repo.lib.toList(), File(dirs.libraries, repo.libraryPath).readBytes().toList())
        assertEquals(repo.lib2.toList(), File(dirs.libraries, "com/example/other/2.0/other-2.0.jar").readBytes().toList())
        assertEquals(repo.log.toList(), File(dirs.assets, "log_configs/client-1.12.xml").readBytes().toList())
        assertEquals(repo.indexBytes.toList(), File(dirs.assets, "indexes/17.json").readBytes().toList())
        repo.assets.forEach { (_, bytes) -> assertEquals(bytes.toList(), repo.assetFile(bytes).readBytes().toList()) }

        assertTrue(VersionStore(layout).isInstalled("1.21.1"))
        assertEquals(0, tmp.root.walkTopDown().count { it.name.endsWith(".part") })

        // Чужая платформа и нативные jar на Android не скачиваются.
        assertEquals(0, http.requestCount(repo.windowsOnlyUrl))
        assertEquals(0, http.requestCount(repo.nativeUrl))

        // Итоговый прогресс: всё скачано, стадия — завершение.
        val last = events.last()
        assertEquals(InstallPhase.FINISHING, last.phase)
        assertEquals(repo.downloadableCount, last.filesTotal)
        assertEquals(repo.downloadableCount, last.filesDone)
        assertEquals(repo.downloadableBytes, last.bytesTotal)
        assertEquals(repo.downloadableBytes, last.bytesDone)
        assertEquals(1f, last.fraction!!, 0.0001f)
        assertTrue(events.any { it.phase == InstallPhase.DOWNLOADING })
    }

    @Test
    fun secondRunDownloadsNothing() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http).also { it.serveAll() }
        val installer = installer(http)
        assertTrue(installer.install(repo.entry) is InstallResult.Installed)
        val before = http.totalRequests

        assertTrue(installer.install(repo.entry) is InstallResult.Installed)

        assertEquals(before, http.totalRequests)
    }

    @Test
    fun damagedLibraryAndMissingAssetAreRepaired() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http).also { it.serveAll() }
        val installer = installer(http)
        installer.install(repo.entry)

        File(dirs.libraries, repo.libraryPath).writeText("junk") // другая длина — файл негоден
        val lostAsset = repo.assets[1].second
        assertTrue(repo.assetFile(lostAsset).delete())

        val result = installer.install(repo.entry)

        assertTrue(result is InstallResult.Installed)
        assertEquals(repo.lib.toList(), File(dirs.libraries, repo.libraryPath).readBytes().toList())
        assertEquals(lostAsset.toList(), repo.assetFile(lostAsset).readBytes().toList())
        assertEquals(2, http.requestCount(repo.libUrl))
        assertEquals(2, http.requestCount(repo.assetUrl(lostAsset)))
        assertEquals(1, http.requestCount(repo.clientUrl)) // целые файлы не трогаем
        assertEquals(1, http.requestCount(repo.lib2Url))
    }

    // ---- Прерванная установка -------------------------------------------------------------

    @Test
    fun failedInstallHasNoMarkerAndContinuesWhereItStopped() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http).also { it.serveAll() }
        http.serveSequence(repo.lib2Url, FakeHttpSource.Reply.Status(404))
        val installer = installer(http, concurrency = 1) // по порядку: клиент, библиотека, затем сбой

        val first = installer.install(repo.entry)

        assertEquals(InstallError.Server(404), failed(first))
        assertFalse(layout.marker("1.21.1").exists())
        assertFalse(VersionStore(layout).isInstalled("1.21.1"))

        http.serve(repo.lib2Url, repo.lib2) // сервер «починили»
        val second = installer.install(repo.entry)

        assertTrue(second is InstallResult.Installed)
        assertTrue(VersionStore(layout).isInstalled("1.21.1"))
        assertEquals(1, http.requestCount(repo.clientUrl)) // уже скачанное второй раз не качается
        assertEquals(1, http.requestCount(repo.libUrl))
        assertEquals(2, http.requestCount(repo.lib2Url))
    }

    @Test
    fun cancellationLeavesNoPartialFilesAndNoMarker() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http).also { it.serveAll() }
        http.serveSequence(repo.clientUrl, FakeHttpSource.Reply.Slow(chunks = 5000, chunkSize = 64, pauseMs = 2))
        val started = CompletableDeferred<Unit>()

        val job = launch(Dispatchers.Default) {
            installer(http).install(repo.entry) { progress ->
                if (progress.phase == InstallPhase.DOWNLOADING && progress.bytesDone > 0 && !started.isCompleted) {
                    started.complete(Unit)
                }
            }
        }
        withTimeout(15_000) { started.await() }
        job.cancelAndJoin()

        assertTrue(job.isCancelled)
        assertEquals(0, tmp.root.walkTopDown().count { it.name.endsWith(".part") })
        assertFalse(layout.marker("1.21.1").exists())
        assertFalse(layout.clientJar("1.21.1").exists())
    }

    // ---- Ошибки ---------------------------------------------------------------------------

    @Test
    fun networkFailureIsReportedAsNetworkError() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http)
        http.serveSequence(repo.versionUrl, FakeHttpSource.Reply.Fail("no route to host"))

        val error = failed(installer(http).install(repo.entry))

        assertTrue(error is InstallError.Network)
        assertEquals(2, http.requestCount(repo.versionUrl)) // сбой сети повторяется
        assertFalse(layout.marker("1.21.1").exists())
    }

    @Test
    fun versionDescriptionWithWrongHashIsRejected() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http).also { it.serveAll() }
        http.serve(repo.versionUrl, repo.versionJson + " ") // не тот файл, что в манифесте

        val error = failed(installer(http).install(repo.entry))

        assertTrue(error is InstallError.BadData)
        assertEquals(0, http.requestCount(repo.clientUrl))
    }

    @Test
    fun descriptionThatIsNotAVersionIsBadData() = runBlocking {
        val http = FakeHttpSource()
        val text = "[]"
        val entry = ManifestEntry("1.0", VersionType.RELEASE, "https://meta.test/1.0.json", sha1Hex(text.toByteArray()), null)
        http.serve(entry.url, text)

        assertTrue(failed(installer(http).install(entry)) is InstallError.BadData)
    }

    @Test
    fun clientJarWithWrongHashIsBadData() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http).also { it.serveAll() }
        http.serve(repo.clientUrl, "tampered-jar-bytes!") // другая длина и хэш

        val error = failed(installer(http).install(repo.entry))

        assertTrue(error is InstallError.BadData)
        assertFalse(layout.clientJar("1.21.1").exists())
        assertFalse(layout.marker("1.21.1").exists())
    }

    @Test
    fun notEnoughSpaceStopsBeforeBigDownloads() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http).also { it.serveAll() }

        val error = failed(installer(http, freeSpace = { 10L }).install(repo.entry))

        assertTrue(error is InstallError.NotEnoughSpace)
        error as InstallError.NotEnoughSpace
        assertEquals(10L, error.freeBytes)
        assertTrue(error.neededBytes > repo.downloadableBytes)
        assertEquals(0, http.requestCount(repo.clientUrl))
        assertEquals(0, http.requestCount(repo.libUrl))
    }

    @Test
    fun modLoaderProfilesAreNotInstalledYet() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http, id = "fabric-loader-0.16-1.21.1", inheritsFrom = "1.21.1").also { it.serveAll() }

        val error = failed(installer(http).install(repo.entry))

        assertEquals(InstallError.Unsupported(UnsupportedReason.MOD_LOADER_PROFILE), error)
        assertEquals(0, http.requestCount(repo.indexUrl))
    }

    @Test
    fun legacyAssetLayoutIsNotSupportedYet() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http, virtualAssets = true).also { it.serveAll() }

        val error = failed(installer(http).install(repo.entry))

        assertEquals(InstallError.Unsupported(UnsupportedReason.LEGACY_ASSETS), error)
        assertEquals(0, http.requestCount(repo.clientUrl))
    }

    @Test
    fun libraryPathLeavingTheLibrariesFolderIsRejected() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http, libraryPath = "../evil.jar").also { it.serveAll() }

        val error = failed(installer(http).install(repo.entry))

        assertTrue(error is InstallError.BadData)
        assertFalse(File(dirs.root, "evil.jar").exists())
        assertEquals(0, http.requestCount(repo.libUrl))
    }

    @Test
    fun unsafeVersionIdIsRejectedBeforeAnyRequest() = runBlocking {
        val http = FakeHttpSource()
        val entry = ManifestEntry("../escape", VersionType.RELEASE, "https://meta.test/x.json", null, null)

        val error = failed(installer(http).install(entry))

        assertTrue(error is InstallError.BadData)
        assertEquals(0, http.totalRequests)
    }

    // ---- Параллелизм ----------------------------------------------------------------------

    @Test
    fun parallelismIsBoundedByTheLimit() = runBlocking {
        val http = FakeHttpSource(latencyMs = 15)
        val repo = Repo(http, assetCount = 30).also { it.serveAll() }

        val result = installer(http, concurrency = 3).install(repo.entry)

        assertTrue(result is InstallResult.Installed)
        assertTrue("max in flight was ${http.maxInFlight}", http.maxInFlight in 2..3)
    }

    @Test
    fun largeFilesHaveTheirOwnLimit() = runBlocking {
        val http = FakeHttpSource(latencyMs = 15)
        val repo = Repo(http, assetCount = 30).also { it.serveAll() }

        // Порог 1 байт: все файлы «большие», значит работает только очередь больших (лимит 2), а не мелких (лимит 8).
        val result = installer(http, concurrency = 8, largeFileConcurrency = 2, largeFileThreshold = 1).install(repo.entry)

        assertTrue(result is InstallResult.Installed)
        assertTrue("max in flight was ${http.maxInFlight}", http.maxInFlight in 2..2)
        assertTrue(VersionStore(layout).isInstalled("1.21.1"))
    }

    @Test
    fun smallAndLargeQueuesRunAtTheSameTime() = runBlocking {
        val http = FakeHttpSource(latencyMs = 15)
        val repo = Repo(http, assetCount = 30).also { it.serveAll() }

        // Порог 16 байт делит набор на 23 «больших» (клиент, лог, ассеты 10–30) и 11 «мелких» (две библиотеки, ассеты 1–9).
        val result = installer(http, concurrency = 3, largeFileConcurrency = 2, largeFileThreshold = 16).install(repo.entry)

        assertTrue(result is InstallResult.Installed)
        assertTrue("max in flight was ${http.maxInFlight}", http.maxInFlight in 4..5)
    }

    @Test
    fun everyFileIsDownloadedExactlyOnceWhateverTheSplit() = runBlocking {
        for (threshold in listOf(1L, 16L, 1_000_000L)) {
            val http = FakeHttpSource()
            val repo = Repo(http, assetCount = 12).also { it.serveAll() }

            val result = installer(http, largeFileThreshold = threshold).install(repo.entry)

            assertTrue("threshold $threshold", result is InstallResult.Installed)
            val files = listOf(repo.clientUrl, repo.libUrl, repo.lib2Url, repo.logUrl) + repo.assets.map { repo.assetUrl(it.second) }
            files.forEach { assertEquals("$it with threshold $threshold", 1, http.requestCount(it)) }

            // Чистим для следующего круга: каждый раз установка с нуля.
            dirs.root.deleteRecursively()
        }
    }

    @Test
    fun aFailureInOneQueueStopsTheOtherAndLeavesNoMarker() = runBlocking {
        val http = FakeHttpSource(latencyMs = 10)
        val repo = Repo(http, assetCount = 20).also { it.serveAll() }
        http.serveSequence(repo.assetUrl(repo.assets[0].second), FakeHttpSource.Reply.Status(404))

        // Порог 1: клиент, библиотеки, лог и все ассеты идут через очередь больших — отказ одного файла останавливает остальные.
        val result = installer(http, concurrency = 4, largeFileConcurrency = 2, largeFileThreshold = 1).install(repo.entry)

        assertEquals(InstallError.Server(404), failed(result))
        assertFalse(layout.marker("1.21.1").exists())
    }

    @Test(expected = IllegalArgumentException::class)
    fun largeFileLimitMustBePositive() {
        installer(FakeHttpSource(), largeFileConcurrency = 0)
    }

    @Test
    fun defaultsAreTheTunedValues() {
        assertEquals(64, VersionInstaller.DEFAULT_CONCURRENCY)
        assertEquals(4, VersionInstaller.DEFAULT_LARGE_FILE_CONCURRENCY)
        assertEquals(5, VersionInstaller.DEFAULT_ATTEMPTS)
    }

    @Test
    fun theConnectionPoolFitsEveryParallelDownload() {
        val parallel = LaunchSettings.MAX_PARALLEL_CONNECTIONS // самое большее, что можно выбрать в настройках
        assertTrue(parallel >= VersionInstaller.DEFAULT_CONCURRENCY + VersionInstaller.DEFAULT_LARGE_FILE_CONCURRENCY)
        assertTrue(
            "pool ${UrlConnectionHttpSource.POOL_SIZE} must hold $parallel connections",
            UrlConnectionHttpSource.POOL_SIZE >= parallel,
        )
    }

    @Test
    fun downloadSpeedIsReportedOnlyWhileDownloading() = runBlocking {
        val http = FakeHttpSource()
        val repo = Repo(http, assetCount = 6).also { it.serveAll() }
        var now = 0L
        val progress = Collections.synchronizedList(ArrayList<InstallProgress>())
        val installer = VersionInstaller(
            directories = dirs,
            http = http,
            env = env,
            downloader = FileDownloader(http, maxAttempts = 2, retryDelayMs = { 0L }),
            concurrency = 1,
            largeFileConcurrency = 1,
            freeSpace = { Long.MAX_VALUE },
            clock = { now += 300L; now },
            progressIntervalMs = 0L,
        )

        val result = installer.install(repo.entry) { progress += it }

        assertTrue(result is InstallResult.Installed)
        val downloading = progress.filter { it.phase == InstallPhase.DOWNLOADING }
        assertTrue("some sample must carry a speed", downloading.any { it.bytesPerSecond > 0 })
        assertTrue(progress.filter { it.phase != InstallPhase.DOWNLOADING }.all { it.bytesPerSecond == 0L })
        assertEquals(0L, downloading.first().bytesPerSecond) // замер ещё не начался
    }
}
