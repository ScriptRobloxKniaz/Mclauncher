package com.mclauncher.app.ui.components

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoPlaybackPolicyTest {

    @Test
    fun visibleVideoPlays() {
        assertEquals(VideoPlayback.PLAYING, VideoPlaybackPolicy.stateFor(visible = true, hiddenForMs = 0))
    }

    @Test
    fun visibleVideoPlaysEvenIfTheCounterIsStale() {
        assertEquals(VideoPlayback.PLAYING, VideoPlaybackPolicy.stateFor(visible = true, hiddenForMs = 10_000_000))
    }

    @Test
    fun justHiddenVideoIsPausedNotReleased() {
        assertEquals(VideoPlayback.PAUSED, VideoPlaybackPolicy.stateFor(visible = false, hiddenForMs = 0))
        assertEquals(VideoPlayback.PAUSED, VideoPlaybackPolicy.stateFor(visible = false, hiddenForMs = 1_000))
    }

    @Test
    fun longHiddenVideoIsReleased() {
        val limit = VideoPlaybackPolicy.RELEASE_AFTER_MS
        assertEquals(VideoPlayback.PAUSED, VideoPlaybackPolicy.stateFor(visible = false, hiddenForMs = limit - 1))
        assertEquals(VideoPlayback.RELEASED, VideoPlaybackPolicy.stateFor(visible = false, hiddenForMs = limit))
        assertEquals(VideoPlayback.RELEASED, VideoPlaybackPolicy.stateFor(visible = false, hiddenForMs = limit * 10))
    }

    @Test
    fun releaseDelayIsReasonable() {
        // Меньше нескольких секунд — плеер пересоздавался бы при каждом заходе в настройки; больше минуты — зря держит ресурсы.
        assertTrue(VideoPlaybackPolicy.RELEASE_AFTER_MS in 3_000L..60_000L)
    }
}
