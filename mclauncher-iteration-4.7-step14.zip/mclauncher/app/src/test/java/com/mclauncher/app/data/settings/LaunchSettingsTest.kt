package com.mclauncher.app.data.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LaunchSettingsTest {

    private fun mb(gb: Double) = (gb * 1024).toLong()

    @Test
    fun theSliderMaximumIsSeventyPercentOfTheDeviceSteppedAndNeverBelowTheMinimum() {
        assertEquals(1408, LaunchSettings.maxRamMb(2048)) // 1433 → ближайший шаг вниз
        assertEquals(2048, LaunchSettings.maxRamMb(3072))
        assertEquals(2816, LaunchSettings.maxRamMb(4096))
        assertEquals(5632, LaunchSettings.maxRamMb(mb(8.0)))
        assertEquals(LaunchSettings.MIN_RAM_MB, LaunchSettings.maxRamMb(512))
        assertEquals(LaunchSettings.MIN_RAM_MB, LaunchSettings.maxRamMb(100))
    }

    @Test
    fun anUnknownDeviceSizeFallsBackToFourGigabytes() {
        assertEquals(LaunchSettings.maxRamMb(4096), LaunchSettings.maxRamMb(0))
        assertEquals(LaunchSettings.maxRamMb(4096), LaunchSettings.maxRamMb(-5))
    }

    @Test
    fun maximumsAreAlwaysWholeSteps() {
        for (total in listOf(1500L, 2900L, 3700L, 5100L, 6800L, 11900L)) {
            assertEquals("total=$total", 0, LaunchSettings.maxRamMb(total) % LaunchSettings.RAM_STEP_MB)
        }
    }

    @Test
    fun automaticMemoryIsTwoGigabytesOrLessOnSmallDevices() {
        assertEquals(2048, LaunchSettings().effectiveRamMb(mb(8.0)))
        assertEquals(2048, LaunchSettings().effectiveRamMb(4096))
        assertEquals(1408, LaunchSettings().effectiveRamMb(2048))
    }

    @Test
    fun aChosenValueIsKeptWhenItFitsAndClampedWhenItDoesNot() {
        assertEquals(3072, LaunchSettings(ramMb = 3072).effectiveRamMb(mb(8.0)))
        // Устройство сменили (или память освободили): прежнее значение не должно превысить предел.
        assertEquals(1408, LaunchSettings(ramMb = 6144).effectiveRamMb(2048))
        assertEquals(LaunchSettings.MIN_RAM_MB, LaunchSettings(ramMb = 100).effectiveRamMb(mb(8.0)))
    }

    @Test
    fun storedValuesAreRepairedOnRead() {
        val s = LaunchSettings.fromStored(ramMb = 50, jvmArguments = null, downloadThreads = 100_000)
        assertEquals(null, s.ramMb)
        assertEquals("", s.jvmArguments)
        assertEquals(LaunchSettings.MAX_DOWNLOAD_THREADS, s.downloadThreads)

        val d = LaunchSettings.fromStored(ramMb = null, jvmArguments = "-Dx=1", downloadThreads = null)
        assertEquals(LaunchSettings.DEFAULT_DOWNLOAD_THREADS, d.downloadThreads)
        assertEquals("-Dx=1", d.jvmArguments)

        assertEquals(LaunchSettings.MIN_DOWNLOAD_THREADS, LaunchSettings.fromStored(null, null, -3).downloadThreads)
    }

    @Test
    fun anOverlongStoredArgumentsTextIsCut() {
        val s = LaunchSettings.fromStored(null, "x".repeat(10_000), null)
        assertEquals(JvmArguments.MAX_TEXT_LENGTH, s.jvmArguments.length)
    }

    @Test
    fun largeFileConcurrencyGrowsSlowlyAndStaysInRange() {
        assertEquals(2, LaunchSettings.largeFileConcurrency(8))
        assertEquals(2, LaunchSettings.largeFileConcurrency(16))
        assertEquals(4, LaunchSettings.largeFileConcurrency(64))
        assertEquals(6, LaunchSettings.largeFileConcurrency(128))
        assertEquals(6, LaunchSettings.largeFileConcurrency(10_000))
        assertEquals(2, LaunchSettings.largeFileConcurrency(-1))
    }

    @Test
    fun defaultsMatchTheInstallerDefaults() {
        assertEquals(64, LaunchSettings.DEFAULT_DOWNLOAD_THREADS)
        assertEquals(LaunchSettings.DEFAULT_DOWNLOAD_THREADS / 16, LaunchSettings.largeFileConcurrency(LaunchSettings.DEFAULT_DOWNLOAD_THREADS))
        assertTrue(LaunchSettings.MIN_DOWNLOAD_THREADS < LaunchSettings.DEFAULT_DOWNLOAD_THREADS)
        assertTrue(LaunchSettings.DEFAULT_DOWNLOAD_THREADS < LaunchSettings.MAX_DOWNLOAD_THREADS)
    }

    @Test
    fun theSafeThreadCountNeverLeavesTheRange() {
        assertEquals(LaunchSettings.MAX_DOWNLOAD_THREADS, LaunchSettings(downloadThreads = 9999).safeDownloadThreads)
        assertEquals(LaunchSettings.MIN_DOWNLOAD_THREADS, LaunchSettings(downloadThreads = 0).safeDownloadThreads)
    }
}
