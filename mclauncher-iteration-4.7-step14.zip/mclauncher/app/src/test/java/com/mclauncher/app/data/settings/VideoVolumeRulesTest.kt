package com.mclauncher.app.data.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoVolumeRulesTest {

    // ---------------------------------------------------------------- подпись у ползунка

    @Test
    fun percentIsAWholeNumberFromZeroToHundred() {
        assertEquals(0, volumePercent(0f))
        assertEquals(50, volumePercent(0.5f))
        assertEquals(100, volumePercent(1f))
    }

    @Test
    fun percentRoundsToTheNearestWholeNumber() {
        assertEquals(33, volumePercent(0.334f))
        assertEquals(67, volumePercent(0.666f))
    }

    @Test
    fun percentOfABrokenVolumeStaysInRange() {
        assertEquals(0, volumePercent(-3f))
        assertEquals(100, volumePercent(7f))
        // «Не число» заменяется громкостью по умолчанию, а не показывается как 0.
        assertEquals(50, volumePercent(Float.NaN))
    }

    // ---------------------------------------------------------------- автоматическое включение звука

    @Test
    fun draggingUpWhileMutedTurnsTheSoundOn() {
        assertTrue(shouldUnmuteOnVolumeChange(muted = true, newVolume = 0.3f))
        assertTrue(shouldUnmuteOnVolumeChange(muted = true, newVolume = 1f))
    }

    @Test
    fun draggingToZeroWhileMutedKeepsItMuted() {
        assertFalse(shouldUnmuteOnVolumeChange(muted = true, newVolume = 0f))
        assertFalse(shouldUnmuteOnVolumeChange(muted = true, newVolume = -1f))
    }

    @Test
    fun nothingToDoWhenTheSoundIsAlreadyOn() {
        assertFalse(shouldUnmuteOnVolumeChange(muted = false, newVolume = 0.3f))
        assertFalse(shouldUnmuteOnVolumeChange(muted = false, newVolume = 0f))
    }

    @Test
    fun aBrokenVolumeFromTheSliderUsesTheDefaultAndSoUnmutes() {
        // Значение по умолчанию больше нуля, поэтому «не число» не оставляет звук выключенным без причины.
        assertTrue(shouldUnmuteOnVolumeChange(muted = true, newVolume = Float.NaN))
    }
}
