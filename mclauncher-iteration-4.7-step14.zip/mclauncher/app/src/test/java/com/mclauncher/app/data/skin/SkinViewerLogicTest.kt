package com.mclauncher.app.data.skin

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Логика 3D-просмотра скина вокруг рисовальщика: готовые ракурсы, размер кадра и обзор «со всех сторон». */
class SkinViewerLogicTest {

    private fun texture(): IntArray = IntArray(64 * 64) { 0xFF000000.toInt() or 0x4080C0 }

    // ---- Готовые ракурсы -----------------------------------------------------------------------

    @Test
    fun `front and back presets look at the character from opposite sides`() {
        assertEquals(0f, ViewAngles.FRONT.yaw, 0f)
        assertEquals(0f, ViewAngles.FRONT.pitch, 0f)
        assertEquals(180f, ViewAngles.BACK.yaw, 0f)
        assertEquals(0f, ViewAngles.BACK.pitch, 0f)
    }

    @Test
    fun `back preset stays put when rotated by nothing`() {
        // Явно проверяем границу диапазона: 180° не должно превращаться в −180° при нормализации.
        assertEquals(ViewAngles.BACK, ViewAngles.BACK.rotatedBy(0f, 0f))
        assertEquals(ViewAngles.FRONT, ViewAngles.FRONT.rotatedBy(0f, 0f))
    }

    @Test
    fun `front and back presets render different pictures`() {
        val scene = SkinScene.of(IntArray(64 * 64) { i -> (0xFF shl 24) or ((i % 64 * 4) shl 16) or ((i / 64 * 4) shl 8) }, SkinModel.WIDE)
        val front = SkinRenderer.render(scene, ViewAngles.FRONT.yaw, ViewAngles.FRONT.pitch, 200, 300, shaded = false)
        val back = SkinRenderer.render(scene, ViewAngles.BACK.yaw, ViewAngles.BACK.pitch, 200, 300, shaded = false)
        assertTrue(front.any { it ushr 24 == 255 })
        assertTrue(back.any { it ushr 24 == 255 })
        assertNotEquals(front.toList(), back.toList())
    }

    @Test
    fun `default angles show some depth`() {
        assertNotEquals(0f, ViewAngles().yaw)
        assertNotEquals(0f, ViewAngles().pitch)
    }

    // ---- Размер кадра --------------------------------------------------------------------------

    @Test
    fun `small window is rendered at its own size`() {
        assertEquals(300 to 200, SkinFrame.fit(300, 200))
        assertEquals(400 to 400, SkinFrame.fit(400, 400))
    }

    @Test
    fun `large window is scaled down by its longest side and keeps proportions`() {
        assertEquals(400 to 300, SkinFrame.fit(1600, 1200))
        assertEquals(266 to 400, SkinFrame.fit(800, 1200))
        assertEquals(200 to 200, SkinFrame.fit(2000, 2000, maxSide = 200))
    }

    @Test
    fun `frame size is never zero`() {
        assertEquals(1 to 1, SkinFrame.fit(0, 0))
        assertEquals(1 to 3, SkinFrame.fit(-5, 3))
        val (w, h) = SkinFrame.fit(4000, 3)
        assertEquals(400, w)
        assertEquals(1, h)
    }

    @Test(expected = IllegalArgumentException::class)
    fun `frame limit must be positive`() {
        SkinFrame.fit(100, 100, maxSide = 0)
    }

    // ---- Обзор со всех сторон ------------------------------------------------------------------

    @Test
    fun `character is visible and inside the frame from every direction`() {
        val scene = SkinScene.of(texture(), SkinModel.SLIM)
        for ((windowW, windowH) in listOf(1200 to 800, 500 to 900, 300 to 300)) {
            val (w, h) = SkinFrame.fit(windowW, windowH)
            var yaw = -180f
            while (yaw <= 180f) {
                var pitch = -90f
                while (pitch <= 90f) {
                    val p = SkinRenderer.render(scene, yaw, pitch, w, h)
                    val label = "window ${windowW}x$windowH yaw=$yaw pitch=$pitch"
                    assertTrue("nothing drawn: $label", p.any { it ushr 24 != 0 })
                    for (x in 0 until w) {
                        assertEquals("top row: $label", 0, p[x])
                        assertEquals("bottom row: $label", 0, p[(h - 1) * w + x])
                    }
                    for (y in 0 until h) {
                        assertEquals("left col: $label", 0, p[y * w])
                        assertEquals("right col: $label", 0, p[y * w + w - 1])
                    }
                    pitch += 30f
                }
                yaw += 30f
            }
        }
    }

    @Test
    fun `swiping in any direction never leaves the valid range`() {
        var angles = ViewAngles()
        val swipes = listOf(37f to 11f, -250f to -400f, 900f to 3f, 0f to 1000f, -1234f to -77f)
        repeat(50) { i ->
            val (dx, dy) = swipes[i % swipes.size]
            angles = angles.rotatedBy(dx, dy)
            assertTrue("yaw ${angles.yaw}", angles.yaw > -180f && angles.yaw <= 180f)
            assertTrue("pitch ${angles.pitch}", angles.pitch >= -ViewAngles.MAX_PITCH && angles.pitch <= ViewAngles.MAX_PITCH)
        }
    }

    @Test
    fun `mannequin is drawn in a single color when there is no skin`() {
        val scene = SkinScene.of(SkinScene.mannequinTexture(SkinModel.WIDE), SkinModel.WIDE)
        val p = SkinRenderer.render(scene, ViewAngles.FRONT.yaw, ViewAngles.FRONT.pitch, 200, 300, shaded = false)
        val colors = p.filter { it ushr 24 == 255 }.toSet()
        assertEquals(setOf(SkinScene.MANNEQUIN_COLOR), colors)
    }
}
