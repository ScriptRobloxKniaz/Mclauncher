package com.mclauncher.app.launch

import com.mclauncher.app.data.settings.GraphicsSettings
import com.mclauncher.app.data.settings.OpenGlVersion
import com.mclauncher.app.data.settings.Renderer
import com.mclauncher.engine.launch.RendererProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RendererSelectionTest {

    @Test
    fun everyRendererInTheSettingsHasItsOwnProfile() {
        val profiles = Renderer.entries.map { it.toProfile() }

        assertEquals(Renderer.entries.size, profiles.toSet().size)
        assertEquals(RendererProfile.ALL.toSet(), profiles.toSet())
    }

    @Test
    fun eachChoiceMapsToTheExpectedProfile() {
        assertEquals(RendererProfile.GL4ES, Renderer.GL4ES.toProfile())
        assertEquals(RendererProfile.KRYPTON, Renderer.KRYPTON.toProfile())
        assertEquals(RendererProfile.MOBILEGLUES, Renderer.MOBILEGLUES.toProfile())
        assertEquals(RendererProfile.ZINK, Renderer.ZINK.toProfile())
    }

    @Test
    fun theDefaultSettingsLaunchWithGl4esAndNoExtraVariables() {
        assertEquals(RendererProfile.GL4ES, GraphicsSettings().toRendererProfile())
    }

    @Test
    fun theOpenGlVersionIsPassedToGl4esOnlyWhenChosen() {
        val gl30 = GraphicsSettings().withGlVersion(OpenGlVersion.GL_3_0).toRendererProfile()

        assertEquals("30", gl30.environment("/c")["LIBGL_GL"])
        assertNull(GraphicsSettings().toRendererProfile().environment("/c")["LIBGL_GL"])
    }

    @Test
    fun theOpenGlVersionNeverReachesTheOtherRenderers() {
        for (renderer in listOf(Renderer.KRYPTON, Renderer.MOBILEGLUES, Renderer.ZINK)) {
            val settings = GraphicsSettings().withRenderer(renderer).withGlVersion(OpenGlVersion.GL_3_2)

            assertEquals(renderer.name, renderer.toProfile(), settings.toRendererProfile())
        }
    }

    @Test
    fun theZinkSwitchAloneIsEnoughToLaunchWithZink() {
        assertEquals(RendererProfile.ZINK, GraphicsSettings().withUseZink(true).toRendererProfile())
        assertTrue(GraphicsSettings().withUseZink(true).toRendererProfile().mesaBased)
    }
}
