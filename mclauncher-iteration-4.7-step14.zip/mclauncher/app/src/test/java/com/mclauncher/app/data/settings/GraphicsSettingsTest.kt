package com.mclauncher.app.data.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GraphicsSettingsTest {

    @Test
    fun savedIdsNeverChange() {
        // Эти строки лежат в файлах настроек пользователей: переименование сломает сохранённый выбор.
        assertEquals(listOf("gl4es", "krypton", "mobileglues", "zink"), Renderer.entries.map { it.id })
        assertEquals(listOf("auto", "2.1", "3.0", "3.2"), OpenGlVersion.entries.map { it.id })
    }

    @Test
    fun theRenderersRemovedInStep12FallBackToTheDefault() {
        // virgl и opengl до игры не доходили; у кого они сохранены, получает рендерер по умолчанию, а не сбой.
        assertEquals(Renderer.Default, Renderer.fromId("virgl"))
        assertEquals(Renderer.Default, Renderer.fromId("opengl"))
        assertEquals(GraphicsSettings(), GraphicsSettings.fromStored("virgl", "auto", false))
    }

    @Test
    fun idsAreUnique() {
        assertEquals(Renderer.entries.size, Renderer.entries.map { it.id }.toSet().size)
        assertEquals(OpenGlVersion.entries.size, OpenGlVersion.entries.map { it.id }.toSet().size)
    }

    @Test
    fun defaultsAreCompatibleChoices() {
        val defaults = GraphicsSettings()
        assertEquals(Renderer.GL4ES, defaults.renderer)
        assertEquals(OpenGlVersion.AUTO, defaults.glVersion)
        assertFalse(defaults.useZink)
        assertEquals(Renderer.GL4ES, defaults.effectiveRenderer)
    }

    @Test
    fun unknownIdsFallBackToDefaults() {
        assertEquals(Renderer.GL4ES, Renderer.fromId(null))
        assertEquals(Renderer.GL4ES, Renderer.fromId("vulkan-ultra"))
        assertEquals(OpenGlVersion.AUTO, OpenGlVersion.fromId(null))
        assertEquals(OpenGlVersion.AUTO, OpenGlVersion.fromId("9.9"))
    }

    @Test
    fun onlyZinkNeedsVulkan() {
        assertEquals(listOf(Renderer.ZINK), Renderer.entries.filter { it.needsVulkan })
    }

    @Test
    fun choosingZinkInTheListTurnsTheSwitchOn() {
        val result = GraphicsSettings().withRenderer(Renderer.ZINK)
        assertEquals(Renderer.ZINK, result.renderer)
        assertTrue(result.useZink)
        assertEquals(Renderer.ZINK, result.effectiveRenderer)
    }

    @Test
    fun choosingAnotherRendererTurnsTheSwitchOff() {
        val result = GraphicsSettings().withRenderer(Renderer.ZINK).withRenderer(Renderer.MOBILEGLUES)
        assertEquals(Renderer.MOBILEGLUES, result.renderer)
        assertFalse(result.useZink)
        assertEquals(Renderer.MOBILEGLUES, result.effectiveRenderer)
    }

    @Test
    fun switchingZinkOnSelectsItInTheList() {
        val result = GraphicsSettings(renderer = Renderer.MOBILEGLUES).withUseZink(true)
        assertEquals(Renderer.ZINK, result.renderer)
        assertTrue(result.useZink)
    }

    @Test
    fun switchingZinkOffFromZinkReturnsTheDefaultRenderer() {
        val result = GraphicsSettings().withUseZink(true).withUseZink(false)
        assertEquals(Renderer.Default, result.renderer)
        assertFalse(result.useZink)
    }

    @Test
    fun switchingZinkOffKeepsOtherChoices() {
        val result = GraphicsSettings(renderer = Renderer.KRYPTON).withUseZink(false)
        assertEquals(Renderer.KRYPTON, result.renderer)
        assertFalse(result.useZink)
    }

    @Test
    fun theTwoControlsCanNeverDisagree() {
        // Перебираем все пути изменения настроек: «Zink в списке» всегда равно «переключатель включён».
        var states = setOf(GraphicsSettings())
        repeat(3) {
            states = states + states.flatMap { s ->
                Renderer.entries.map { s.withRenderer(it) } + listOf(s.withUseZink(true), s.withUseZink(false))
            }
        }
        assertTrue(states.isNotEmpty())
        for (s in states) {
            assertEquals("$s", s.renderer == Renderer.ZINK, s.useZink)
            assertEquals("$s", s.useZink, s.effectiveRenderer == Renderer.ZINK)
        }
    }

    @Test
    fun glVersionAppliesOnlyToGl4es() {
        assertTrue(GraphicsSettings().glVersionApplies)
        assertTrue(GraphicsSettings().withRenderer(Renderer.GL4ES).glVersionApplies)
        assertFalse(GraphicsSettings().withRenderer(Renderer.ZINK).glVersionApplies)
        assertFalse(GraphicsSettings().withRenderer(Renderer.MOBILEGLUES).glVersionApplies)
        assertFalse(GraphicsSettings().withRenderer(Renderer.KRYPTON).glVersionApplies)
    }

    @Test
    fun glVersionIsRememberedWhileAnotherRendererIsChosen() {
        val result = GraphicsSettings()
            .withGlVersion(OpenGlVersion.GL_3_2)
            .withRenderer(Renderer.ZINK)
            .withRenderer(Renderer.GL4ES)
        assertEquals(OpenGlVersion.GL_3_2, result.glVersion)
    }

    @Test
    fun libglValueIsTheGl4esNotationAndMissingOnlyForAuto() {
        assertNull(OpenGlVersion.AUTO.libglValue)
        assertEquals("21", OpenGlVersion.GL_2_1.libglValue)
        assertEquals("30", OpenGlVersion.GL_3_0.libglValue)
        assertEquals("32", OpenGlVersion.GL_3_2.libglValue)
    }

    @Test
    fun numberLabelIsMissingOnlyForAuto() {
        assertNull(OpenGlVersion.AUTO.numberLabel)
        assertEquals("2.1", OpenGlVersion.GL_2_1.numberLabel)
        assertEquals("3.2", OpenGlVersion.GL_3_2.numberLabel)
    }

    @Test
    fun storedValuesAreReadBack() {
        val result = GraphicsSettings.fromStored("mobileglues", "3.0", false)
        assertEquals(GraphicsSettings(Renderer.MOBILEGLUES, OpenGlVersion.GL_3_0, false), result)
    }

    @Test
    fun emptyStoreGivesDefaults() {
        assertEquals(GraphicsSettings(), GraphicsSettings.fromStored(null, null, null))
    }

    @Test
    fun damagedStoreGivesDefaults() {
        assertEquals(GraphicsSettings(), GraphicsSettings.fromStored("???", "x", false))
    }

    @Test
    fun storedContradictionsAreResolvedTowardsZink() {
        // Переключатель включён, а в списке другой рендерер — побеждает Zink: пользователь его явно просил.
        val a = GraphicsSettings.fromStored("mobileglues", "auto", true)
        assertEquals(Renderer.ZINK, a.renderer)
        assertTrue(a.useZink)
        // Zink в списке, а переключатель выключен — тоже Zink.
        val b = GraphicsSettings.fromStored("zink", "auto", false)
        assertEquals(Renderer.ZINK, b.renderer)
        assertTrue(b.useZink)
        val c = GraphicsSettings.fromStored("zink", "auto", null)
        assertTrue(c.useZink)
    }

    @Test
    fun storedGlVersionSurvivesZinkContradictionFix() {
        val result = GraphicsSettings.fromStored("mobileglues", "3.2", true)
        assertEquals(OpenGlVersion.GL_3_2, result.glVersion)
    }
}
