package com.mclauncher.app.launch

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class GameLogDiagnosisTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun log(text: String): File = tmp.newFile().apply { writeText(text) }

    @Test
    fun theTailKeepsTheLastLinesInOrder() {
        val file = log((1..100).joinToString("\n") { "line $it" } + "\n")

        val tail = GameLogDiagnosis.tail(file, maxLines = 3)

        assertEquals("line 98\nline 99\nline 100", tail)
    }

    @Test
    fun aShortFileIsReturnedWholeWithoutTrailingBlankLines() {
        assertEquals("a\nb", GameLogDiagnosis.tail(log("a\nb\n\n\n")))
    }

    @Test
    fun aMissingEmptyOrBlankLogHasNoTail() {
        assertNull(GameLogDiagnosis.tail(null))
        assertNull(GameLogDiagnosis.tail(File(tmp.root, "none.log")))
        assertNull(GameLogDiagnosis.tail(log("")))
        assertNull(GameLogDiagnosis.tail(log("\n\n  \n")))
        assertNull(GameLogDiagnosis.tail(tmp.root)) // папка, а не файл
    }

    @Test
    fun onlyTheLastBytesAreReadAndABrokenFirstLineIsDropped() {
        val file = log("x".repeat(50_000) + "\nfirst whole line\nlast line\n")

        val tail = GameLogDiagnosis.tail(file, maxLines = 10, maxBytes = 1024)

        assertEquals("first whole line\nlast line", tail)
    }

    @Test
    fun aWindowThatCutsInsideTheOnlyLineGivesNothingInsteadOfGarbage() {
        assertNull(GameLogDiagnosis.tail(log("y".repeat(5000)), maxBytes = 100))
    }

    @Test
    fun nonPositiveLimitsGiveNothing() {
        assertNull(GameLogDiagnosis.tail(log("a\n"), maxLines = 0))
        assertNull(GameLogDiagnosis.tail(log("a\n"), maxBytes = 0))
    }

    @Test
    fun memoryProblemsAreRecognised() {
        for (text in listOf(
            "java.lang.OutOfMemoryError: Java heap space",
            "Error occurred during initialization of VM\nCould not reserve enough space for 2097152KB object heap",
            "There is insufficient memory for the Java Runtime Environment to continue.",
        )) {
            assertEquals(text, listOf(LogHint.MEMORY), GameLogDiagnosis.hints(text))
        }
    }

    @Test
    fun aWrongJavaVersionIsRecognised() {
        val text = "java.lang.UnsupportedClassVersionError: net/minecraft/client/main/Main has been compiled by a more recent version of the Java Runtime"

        assertEquals(listOf(LogHint.JAVA_VERSION), GameLogDiagnosis.hints(text))
    }

    @Test
    fun aMissingNativeLibraryIsRecognised() {
        assertEquals(listOf(LogHint.NATIVE_LIBRARY), GameLogDiagnosis.hints("java.lang.UnsatisfiedLinkError: no lwjgl in java.library.path"))
    }

    @Test
    fun graphicsErrorsAreRecognised() {
        for (text in listOf("GLFW error 65543: EGL: Failed to create context", "Failed to create the GLFW window", "Unable to create OpenGL context")) {
            assertEquals(text, listOf(LogHint.GRAPHICS), GameLogDiagnosis.hints(text))
        }
    }

    @Test
    fun severalSignsGiveSeveralHintsInAStableOrderWithoutRepeats() {
        val text = "UnsatisfiedLinkError\nGLFW error 1\nOutOfMemoryError\nOutOfMemoryError\nGLFW error 2"

        assertEquals(listOf(LogHint.MEMORY, LogHint.NATIVE_LIBRARY, LogHint.GRAPHICS), GameLogDiagnosis.hints(text))
    }

    @Test
    fun anOrdinaryLogHasNoHints() {
        assertTrue(GameLogDiagnosis.hints(null).isEmpty())
        assertTrue(GameLogDiagnosis.hints("").isEmpty())
        assertFalse(GameLogDiagnosis.hints("[Render thread/INFO]: Setting user: Steve").isNotEmpty())
    }
}
