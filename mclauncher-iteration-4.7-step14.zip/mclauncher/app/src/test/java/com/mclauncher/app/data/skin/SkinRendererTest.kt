package com.mclauncher.app.data.skin

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Проверка 3D-рисовальщика скина. Текстура здесь «кодированная»: цвет каждого пикселя хранит его собственные
 * координаты (красный = x·4, зелёный = y·4), поэтому по цвету пикселя на экране видно, какой именно пиксель скина
 * на него попал. Освещение в этих тестах выключено, чтобы цвета не искажались.
 */
class SkinRendererTest {

    private val w = 400
    private val h = 600

    private fun decode(color: Int): Pair<Int, Int>? =
        if ((color ushr 24) == 0) null else ((color shr 16) and 0xFF) / 4 to ((color shr 8) and 0xFF) / 4

    /** Текстура с координатами в цвете; второй слой прозрачный (или непрозрачный, если [overlayOpaque]). */
    private fun coded(model: SkinModel, overlayOpaque: Boolean = false): IntArray {
        val t = IntArray(64 * 64) { i -> (0xFF shl 24) or ((i % 64 * 4) shl 16) or ((i / 64 * 4) shl 8) or 0x80 }
        if (!overlayOpaque) {
            val overlays = listOf(
                SkinLayout.HAT, SkinLayout.JACKET, SkinLayout.RIGHT_PANTS, SkinLayout.LEFT_PANTS,
                SkinLayout.rightSleeve(model), SkinLayout.leftSleeve(model),
            )
            for (box in overlays) for (r in box.faces) fill(t, r) { it and 0x00FFFFFF }
        }
        return t
    }

    private fun fill(t: IntArray, r: PixelRect, f: (Int) -> Int) {
        for (y in r.y until r.bottom) for (x in r.x until r.right) t[y * 64 + x] = f(t[y * 64 + x])
    }

    private fun render(
        texture: IntArray,
        model: SkinModel = SkinModel.WIDE,
        yaw: Float = 0f,
        pitch: Float = 0f,
        width: Int = w,
        height: Int = h,
        shaded: Boolean = false,
    ): IntArray = SkinRenderer.render(SkinScene.of(texture, model), yaw, pitch, width, height, shaded)

    /** Цвет пикселя экрана, в который проецируется точка модели. */
    private fun at(pixels: IntArray, yaw: Float, pitch: Float, x: Float, y: Float, z: Float, width: Int = w, height: Int = h): Int {
        val (sx, sy) = SkinCamera(width, height, yaw, pitch).project(x, y, z)
        return pixels[sy.toInt() * width + sx.toInt()]
    }

    private fun texelAt(
        model: SkinModel, yaw: Float, pitch: Float, x: Float, y: Float, z: Float,
        texture: IntArray = coded(model),
    ): Pair<Int, Int>? = decode(at(render(texture, model, yaw, pitch), yaw, pitch, x, y, z))

    // ---- Что видно спереди ---------------------------------------------------------------------

    @Test
    fun `front view shows the front faces at the right texture pixels`() {
        val m = SkinModel.WIDE
        assertEquals(12 to 12, texelAt(m, 0f, 0f, 0.5f, 27.5f, 4f)) // голова
        assertEquals(20 to 20, texelAt(m, 0f, 0f, -3.5f, 23.5f, 2f)) // тело, левый верх на экране
        assertEquals(27 to 31, texelAt(m, 0f, 0f, 3.5f, 12.5f, 2f)) // тело, правый низ на экране
        assertEquals(44 to 20, texelAt(m, 0f, 0f, -7.5f, 23.5f, 2f)) // правая рука персонажа — слева от зрителя
        assertEquals(36 to 52, texelAt(m, 0f, 0f, 4.5f, 23.5f, 2f)) // левая рука — справа от зрителя
        assertEquals(4 to 20, texelAt(m, 0f, 0f, -3.5f, 11.5f, 2f)) // правая нога
        assertEquals(20 to 52, texelAt(m, 0f, 0f, 0.5f, 11.5f, 2f)) // левая нога
    }

    @Test
    fun `back view shows the back faces mirrored left to right`() {
        val m = SkinModel.WIDE
        assertEquals(28 to 12, texelAt(m, 180f, 0f, -0.5f, 27.5f, -4f)) // голова
        assertEquals(32 to 20, texelAt(m, 180f, 0f, 3.5f, 23.5f, -2f)) // тело: у спины крайний левый пиксель на экране — это +x
    }

    @Test
    fun `side views show the character's right and left sides`() {
        val m = SkinModel.WIDE
        // yaw +90: лицо ушло вправо, зрителю виден правый бок персонажа (грань RIGHT), лицо — справа на экране
        assertEquals(4 to 12, texelAt(m, 90f, 0f, -4f, 27.5f, 0.5f))
        // yaw -90: виден левый бок
        assertEquals(20 to 12, texelAt(m, -90f, 0f, 4f, 27.5f, -0.5f))
    }

    @Test
    fun `top and bottom views show the head top and the feet soles`() {
        val m = SkinModel.WIDE
        assertEquals(12 to 4, texelAt(m, 0f, 90f, 0.5f, 32f, 0.5f)) // сверху: макушка
        assertEquals(10 to 17, texelAt(m, 0f, -90f, -1.5f, 0f, 0.5f)) // снизу: подошва правой ноги
    }

    @Test
    fun `hidden faces are not drawn through the front ones`() {
        // Пока смотрим спереди, на месте головы не должно быть пикселей задней грани (x = 24..31).
        val pixels = render(coded(SkinModel.WIDE))
        val seen = decode(at(pixels, 0f, 0f, 0.5f, 27.5f, 4f))!!
        assertTrue("back face leaked: $seen", seen.first < 24)
    }

    // ---- Тонкие руки ---------------------------------------------------------------------------

    @Test
    fun `slim arms are three pixels wide and wide arms are four`() {
        val slim = SkinModel.SLIM
        assertEquals(44 to 20, texelAt(slim, 0f, 0f, -6.5f, 23.5f, 2f))
        assertNull(texelAt(slim, 0f, 0f, -7.5f, 23.5f, 2f)) // за пределами тонкой руки пусто
        assertEquals(36 to 52, texelAt(slim, 0f, 0f, 4.5f, 23.5f, 2f))
        assertNull(texelAt(slim, 0f, 0f, 7.5f, 23.5f, 2f))

        val wide = SkinModel.WIDE
        assertEquals(44 to 20, texelAt(wide, 0f, 0f, -7.5f, 23.5f, 2f))
        assertEquals(39 to 52, texelAt(wide, 0f, 0f, 7.5f, 23.5f, 2f)) // четвёртый пиксель широкой руки: у тонкой его нет
    }

    // ---- Второй слой ---------------------------------------------------------------------------

    @Test
    fun `opaque hat covers the head and a transparent hat shows the head`() {
        val m = SkinModel.WIDE
        val red = 0xFFFF0000.toInt()
        val opaque = coded(m)
        fill(opaque, SkinLayout.HAT.face(Face.FRONT)) { red }
        assertEquals(red, at(render(opaque, m), 0f, 0f, 0.5f, 27.5f, 4.6f))

        val transparent = coded(m)
        assertEquals(12 to 12, decode(at(render(transparent, m), 0f, 0f, 0.5f, 27.5f, 4f)))
    }

    @Test
    fun `half transparent overlay is blended with what is under it`() {
        val m = SkinModel.WIDE
        val t = coded(m)
        fill(t, SkinLayout.HAT.face(Face.FRONT)) { 0x80FF0000.toInt() }
        val color = at(render(t, m), 0f, 0f, 0.5f, 27.5f, 4.6f)
        assertEquals(255, color ushr 24)
        val red = (color shr 16) and 0xFF
        val baseRed = 12 * 4 // красная составляющая кодированного пикселя головы
        assertTrue("red=$red", red > baseRed && red < 255)
    }

    // ---- Общее поведение -----------------------------------------------------------------------

    @Test
    fun `area outside the character is fully transparent`() {
        val pixels = render(coded(SkinModel.WIDE), yaw = 28f, pitch = 10f)
        assertEquals(0, pixels[0])
        assertEquals(0, pixels[pixels.size - 1])
        assertTrue(pixels.any { it ushr 24 == 255 })
    }

    @Test
    fun `the character is centered and fits the window at every angle`() {
        val (cx, cy) = SkinCamera(w, h, 0f, 0f).project(0f, 16f, 0f)
        assertEquals(w / 2f, cx, 0.01f)
        assertEquals(h / 2f, cy, 0.01f)

        val texture = coded(SkinModel.WIDE, overlayOpaque = true)
        for ((width, height) in listOf(400 to 600, 600 to 300, 200 to 200)) {
            for (yaw in listOf(0f, 45f, 90f, 135f, 180f)) {
                for (pitch in listOf(-90f, -45f, 0f, 45f, 90f)) {
                    val p = render(texture, SkinModel.WIDE, yaw, pitch, width, height)
                    for (x in 0 until width) {
                        assertEquals("top row ${width}x$height yaw=$yaw pitch=$pitch", 0, p[x])
                        assertEquals("bottom row ${width}x$height yaw=$yaw pitch=$pitch", 0, p[(height - 1) * width + x])
                    }
                    for (y in 0 until height) {
                        assertEquals("left col ${width}x$height yaw=$yaw pitch=$pitch", 0, p[y * width])
                        assertEquals("right col ${width}x$height yaw=$yaw pitch=$pitch", 0, p[y * width + width - 1])
                    }
                }
            }
        }
    }

    @Test
    fun `shading depends on the face direction and not on the view`() {
        val white = IntArray(64 * 64) { -1 }
        // Грань, повёрнутая прямо к камере, освещена одинаково с какой бы стороны мы на неё ни смотрели.
        val front = at(render(white, shaded = true), 0f, 0f, 0f, 18f, 2f) and 0xFF
        val back = at(render(white, yaw = 180f, shaded = true), 180f, 0f, 0f, 18f, -2f) and 0xFF
        val top = at(render(white, pitch = 90f, shaded = true), 0f, 90f, 0f, 32f, 0f) and 0xFF
        assertEquals(224f, front.toFloat(), 1f)
        assertEquals(front, back)
        assertEquals(front, top)

        // А вот боковая грань при взгляде «в три четверти» темнее передней.
        val oblique = render(white, yaw = 28f, pitch = 10f, shaded = true)
        val frontFace = at(oblique, 28f, 10f, 0f, 18f, 2f) and 0xFF
        val sideFace = at(oblique, 28f, 10f, -8f, 18f, 0f) and 0xFF // внешний бок правой руки
        assertNotEquals(frontFace, sideFace)
    }

    @Test
    fun `model has twelve boxes of six faces and half of them are overlay`() {
        val quads = PlayerMesh.build(SkinModel.WIDE)
        assertEquals(72, quads.size)
        assertEquals(36, quads.count { it.overlay })
    }

    @Test
    fun `mannequin texture colors the first layer only`() {
        for (model in SkinModel.entries) {
            val t = SkinScene.mannequinTexture(model)
            for (box in listOf(SkinLayout.HEAD, SkinLayout.BODY, SkinLayout.rightArm(model), SkinLayout.leftArm(model))) {
                for (r in box.faces) assertEquals(SkinScene.MANNEQUIN_COLOR, t[r.y * 64 + r.x])
            }
            for (r in SkinLayout.HAT.faces) assertEquals(0, t[r.y * 64 + r.x])
        }
        val pixels = render(SkinScene.mannequinTexture(SkinModel.WIDE), yaw = 28f, pitch = 10f, shaded = true)
        assertTrue(pixels.any { it ushr 24 == 255 })
    }

    @Test(expected = IllegalArgumentException::class)
    fun `empty window is rejected`() {
        render(coded(SkinModel.WIDE), width = 0, height = 10)
    }

    // ---- Ракурс --------------------------------------------------------------------------------

    @Test
    fun `dragging right turns the face to the right and dragging down looks from above`() {
        val turned = ViewAngles(0f, 0f).rotatedBy(dxPx = 20f, dyPx = 0f)
        assertEquals(10f, turned.yaw, 0.001f)
        assertEquals(0f, turned.pitch, 0.001f)
        assertEquals(10f, ViewAngles(0f, 0f).rotatedBy(0f, 20f).pitch, 0.001f)
    }

    @Test
    fun `pitch is clamped and yaw wraps around`() {
        assertEquals(90f, ViewAngles(0f, 85f).rotatedBy(0f, 100f).pitch, 0.001f)
        assertEquals(-90f, ViewAngles(0f, -85f).rotatedBy(0f, -100f).pitch, 0.001f)
        assertEquals(-170f, ViewAngles(170f, 0f).rotatedBy(40f, 0f).yaw, 0.001f)
        assertEquals(170f, ViewAngles(-170f, 0f).rotatedBy(-40f, 0f).yaw, 0.001f)
        val spun = ViewAngles(0f, 0f).rotatedBy(1440f, 0f) // два полных оборота
        assertTrue(spun.yaw > -180f && spun.yaw <= 180f)
        assertEquals(0f, spun.yaw, 0.001f)
    }
}
