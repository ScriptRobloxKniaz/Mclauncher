package com.mclauncher.app.core

import com.mclauncher.engine.install.ComponentState
import com.mclauncher.engine.install.CoreInstallException

/*
 * Состояние «игрового ядра» для экрана: что из компонентов установлено и идёт ли установка. Только логика, без
 * Android-классов — поэтому проверяется JVM-тестами. Сборка состояния из диска и WorkManager — в CoreInstallManager.
 */

/** Почему установка не удалась. Тексты на ru/en подбирает экран. */
enum class CoreFailure {
    /** В этой сборке нет файлов ядра: CI собрал приложение без шага `fetch_core.py --install`. */
    NOT_BUNDLED,
    NO_SPACE,

    /** Файл из ассетов не совпал с манифестом: приложение собрано или скопировано с повреждением. */
    CORRUPT,
    OTHER,
}

fun CoreInstallException.toFailure(): CoreFailure = when (this) {
    is CoreInstallException.AssetMissing -> CoreFailure.NOT_BUNDLED
    is CoreInstallException.NoSpace -> CoreFailure.NO_SPACE
    is CoreInstallException.Corrupt -> CoreFailure.CORRUPT
    is CoreInstallException.UnknownComponent, is CoreInstallException.Failed -> CoreFailure.OTHER
}

/** Разбор кода из данных WorkManager; незнакомое значение — [CoreFailure.OTHER], а не падение. */
fun failureFromCode(code: String?): CoreFailure = CoreFailure.entries.firstOrNull { it.name == code } ?: CoreFailure.OTHER

/** Один компонент ядра и его состояние на диске. [bytes] — размер файлов в ассетах (до распаковки). */
data class CoreComponentInfo(val id: String, val state: ComponentState, val bytes: Long)

/** Что известно о ядре по диску и манифесту. */
sealed interface CoreDisk {
    /** Манифеста нет в ассетах: приложение собрано без ядра. */
    data object NotBundled : CoreDisk

    /** Процессор устройства не поддерживается ядром или не совпадает с тем, для чего собраны файлы. */
    data class UnsupportedDevice(val deviceAbi: String?, val coreAbi: String) : CoreDisk

    data class Known(val components: List<CoreComponentInfo>) : CoreDisk
}

enum class WorkPhase { NONE, QUEUED, RUNNING, SUCCEEDED, FAILED, CANCELLED }

/** Снимок фоновой установки (WorkManager). Числа — прогресс, пока [phase] = RUNNING; [failure] — при FAILED. */
data class CoreWork(
    val phase: WorkPhase = WorkPhase.NONE,
    val doneBytes: Long = 0,
    val totalBytes: Long = 0,
    val label: String = "",
    val failure: CoreFailure? = null,
    val detail: String? = null,
)

enum class CorePhase { CHECKING, NOT_BUNDLED, UNSUPPORTED, NEEDS_INSTALL, QUEUED, INSTALLING, READY, FAILED }

data class CoreUiState(
    val phase: CorePhase = CorePhase.CHECKING,
    val components: List<CoreComponentInfo> = emptyList(),
    /** 0..1, только при INSTALLING. */
    val progress: Float = 0f,
    val label: String = "",
    val failure: CoreFailure? = null,
    val detail: String? = null,
) {
    val installedCount: Int get() = components.count { it.state == ComponentState.INSTALLED }

    /** Сколько ещё нужно поставить: размер файлов недостающих компонентов в ассетах (на диске будет больше). */
    val missingBytes: Long get() = components.filter { it.state != ComponentState.INSTALLED }.sumOf { it.bytes }

    val canInstall: Boolean get() = phase == CorePhase.NEEDS_INSTALL || phase == CorePhase.FAILED
    val canCancel: Boolean get() = phase == CorePhase.QUEUED || phase == CorePhase.INSTALLING
}

/**
 * Состояние экрана из диска и фоновой работы. Правила:
 *  - идёт или ждёт установка — показываем её, диск не важен;
 *  - иначе решает диск: нет файлов в сборке / чужой процессор / всё установлено;
 *  - если не всё установлено и последняя установка закончилась ошибкой — показываем ошибку (её можно повторить);
 *  - остальное — «нужна установка».
 */
fun reduceCoreState(disk: CoreDisk?, work: CoreWork): CoreUiState {
    val components = (disk as? CoreDisk.Known)?.components.orEmpty()
    return when {
        work.phase == WorkPhase.RUNNING -> CoreUiState(
            phase = CorePhase.INSTALLING,
            components = components,
            progress = if (work.totalBytes > 0) (work.doneBytes.toFloat() / work.totalBytes).coerceIn(0f, 1f) else 0f,
            label = work.label,
        )
        work.phase == WorkPhase.QUEUED -> CoreUiState(CorePhase.QUEUED, components)
        disk == null -> CoreUiState(CorePhase.CHECKING)
        disk is CoreDisk.NotBundled -> CoreUiState(CorePhase.NOT_BUNDLED)
        disk is CoreDisk.UnsupportedDevice -> CoreUiState(CorePhase.UNSUPPORTED, detail = disk.deviceAbi)
        components.all { it.state == ComponentState.INSTALLED } -> CoreUiState(CorePhase.READY, components)
        work.phase == WorkPhase.FAILED -> CoreUiState(
            phase = CorePhase.FAILED,
            components = components,
            failure = work.failure ?: CoreFailure.OTHER,
            detail = work.detail,
        )
        else -> CoreUiState(CorePhase.NEEDS_INSTALL, components)
    }
}
