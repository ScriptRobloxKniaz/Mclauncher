package com.mclauncher.app.data.skin

/**
 * Одна грань коробки модели игрока, готовая к рисованию. Координаты — в «пикселях скина»: 1 единица = 1 пиксель
 * текстуры, персонаж стоит ногами на y = 0 и имеет рост 32. Ось x направлена вправо от зрителя, который смотрит
 * персонажу в лицо, ось y — вверх, ось z — от спины к лицу.
 *
 * [px]/[py]/[pz] — четыре угла по кругу, [tu]/[tv] — их координаты на текстуре (в пикселях, дробные).
 * Нормаль ([nx], [ny], [nz]) смотрит наружу; по ней отсекаются обращённые от зрителя грани и считается освещение.
 * [face] — прямоугольник грани на текстуре: за его пределы выборка не выходит, чтобы на стыках не «просачивался»
 * соседний кусок. [overlay] — второй слой (шляпа, куртка, рукава, штаны): он может быть прозрачным.
 */
class SkinQuad(
    val px: FloatArray,
    val py: FloatArray,
    val pz: FloatArray,
    val tu: FloatArray,
    val tv: FloatArray,
    val nx: Float,
    val ny: Float,
    val nz: Float,
    val face: PixelRect,
    val overlay: Boolean,
)

/** Всё, что нужно для рисования персонажа: грани модели и текстура 64×64 (ARGB, по строкам). */
class SkinScene(
    val quads: List<SkinQuad>,
    val texture: IntArray,
) {
    init {
        require(texture.size >= SkinLayout.TEXTURE_WIDTH * SkinLayout.TEXTURE_HEIGHT) { "Texture must be 64x64" }
    }

    companion object {
        /** Цвет «манекена»: им рисуется персонаж, пока скин не выбран. Это нейтральный цвет, а не чей-то скин. */
        const val MANNEQUIN_COLOR = 0xFF8C84C4.toInt()

        fun of(texture: IntArray, model: SkinModel): SkinScene = SkinScene(PlayerMesh.build(model), texture)

        /** Текстура-манекен: все грани первого слоя залиты одним цветом, второй слой прозрачный. */
        fun mannequinTexture(model: SkinModel): IntArray {
            val pixels = IntArray(SkinLayout.TEXTURE_WIDTH * SkinLayout.TEXTURE_HEIGHT)
            val boxes = listOf(
                SkinLayout.HEAD, SkinLayout.BODY, SkinLayout.RIGHT_LEG, SkinLayout.LEFT_LEG,
                SkinLayout.rightArm(model), SkinLayout.leftArm(model),
            )
            for (box in boxes) {
                for (rect in box.faces) {
                    for (y in rect.y until rect.bottom) {
                        for (x in rect.x until rect.right) pixels[y * SkinLayout.TEXTURE_WIDTH + x] = MANNEQUIN_COLOR
                    }
                }
            }
            return pixels
        }
    }
}

/**
 * Модель игрока из коробок, как в игре: голова, тело, две руки, две ноги и поверх них второй слой чуть крупнее
 * (шляпа +0,5, остальное +0,25 с каждой стороны). Развёртка каждой коробки берётся из [SkinBox], то есть из той же
 * раскладки, по которой работает плоское превью, — так 3D и 2D не могут разойтись.
 *
 * Как грани лежат на текстуре (для зрителя, смотрящего на грань снаружи):
 *  - FRONT (+z): рисунок идёт вправо по +x;
 *  - BACK (−z): вправо по −x;
 *  - RIGHT (−x, правый бок персонажа, слева от зрителя спереди): вправо по +z;
 *  - LEFT (+x): вправо по −z;
 *  - TOP (+y): вправо по +x, вниз — к лицу (+z);
 *  - BOTTOM (−y): вправо по +x, вниз — к спине (−z): как если бы низ раскрыли вниз от лица.
 */
object PlayerMesh {
    private const val HAT_INFLATE = 0.5f
    private const val LAYER_INFLATE = 0.25f

    private class Part(
        val box: SkinBox,
        val minX: Float,
        val minY: Float,
        val minZ: Float,
        val inflate: Float,
        val overlay: Boolean,
    )

    fun build(model: SkinModel): List<SkinQuad> {
        val armW = SkinLayout.armWidth(model).toFloat()
        val rightArmX = -4f - armW
        val parts = listOf(
            // Первый слой
            Part(SkinLayout.HEAD, -4f, 24f, -4f, 0f, overlay = false),
            Part(SkinLayout.BODY, -4f, 12f, -2f, 0f, overlay = false),
            Part(SkinLayout.rightArm(model), rightArmX, 12f, -2f, 0f, overlay = false),
            Part(SkinLayout.leftArm(model), 4f, 12f, -2f, 0f, overlay = false),
            Part(SkinLayout.RIGHT_LEG, -4f, 0f, -2f, 0f, overlay = false),
            Part(SkinLayout.LEFT_LEG, 0f, 0f, -2f, 0f, overlay = false),
            // Второй слой
            Part(SkinLayout.HAT, -4f, 24f, -4f, HAT_INFLATE, overlay = true),
            Part(SkinLayout.JACKET, -4f, 12f, -2f, LAYER_INFLATE, overlay = true),
            Part(SkinLayout.rightSleeve(model), rightArmX, 12f, -2f, LAYER_INFLATE, overlay = true),
            Part(SkinLayout.leftSleeve(model), 4f, 12f, -2f, LAYER_INFLATE, overlay = true),
            Part(SkinLayout.RIGHT_PANTS, -4f, 0f, -2f, LAYER_INFLATE, overlay = true),
            Part(SkinLayout.LEFT_PANTS, 0f, 0f, -2f, LAYER_INFLATE, overlay = true),
        )
        val quads = ArrayList<SkinQuad>(parts.size * Face.entries.size)
        for (part in parts) {
            for (face in Face.entries) quads += quad(part, face)
        }
        return quads
    }

    private fun quad(part: Part, face: Face): SkinQuad {
        val box = part.box
        val inflate = part.inflate
        val x0 = part.minX - inflate
        val y0 = part.minY - inflate
        val z0 = part.minZ - inflate
        val x1 = part.minX + box.width + inflate
        val y1 = part.minY + box.height + inflate
        val z1 = part.minZ + box.depth + inflate
        val w = x1 - x0
        val h = y1 - y0
        val d = z1 - z0

        // Левый верхний угол грани на текстуре (p0), направления «вправо» (a) и «вниз» (b) на текстуре и нормаль.
        val p0: FloatArray
        val a: FloatArray
        val b: FloatArray
        val n: FloatArray
        when (face) {
            Face.FRONT -> { p0 = floatArrayOf(x0, y1, z1); a = floatArrayOf(w, 0f, 0f); b = floatArrayOf(0f, -h, 0f); n = floatArrayOf(0f, 0f, 1f) }
            Face.BACK -> { p0 = floatArrayOf(x1, y1, z0); a = floatArrayOf(-w, 0f, 0f); b = floatArrayOf(0f, -h, 0f); n = floatArrayOf(0f, 0f, -1f) }
            Face.RIGHT -> { p0 = floatArrayOf(x0, y1, z0); a = floatArrayOf(0f, 0f, d); b = floatArrayOf(0f, -h, 0f); n = floatArrayOf(-1f, 0f, 0f) }
            Face.LEFT -> { p0 = floatArrayOf(x1, y1, z1); a = floatArrayOf(0f, 0f, -d); b = floatArrayOf(0f, -h, 0f); n = floatArrayOf(1f, 0f, 0f) }
            Face.TOP -> { p0 = floatArrayOf(x0, y1, z0); a = floatArrayOf(w, 0f, 0f); b = floatArrayOf(0f, 0f, d); n = floatArrayOf(0f, 1f, 0f) }
            Face.BOTTOM -> { p0 = floatArrayOf(x0, y0, z1); a = floatArrayOf(w, 0f, 0f); b = floatArrayOf(0f, 0f, -d); n = floatArrayOf(0f, -1f, 0f) }
        }

        val rect = box.face(face)
        val px = FloatArray(4)
        val py = FloatArray(4)
        val pz = FloatArray(4)
        val tu = FloatArray(4)
        val tv = FloatArray(4)
        // Углы по кругу: левый верхний, правый верхний, правый нижний, левый нижний (на текстуре).
        val corners = arrayOf(intArrayOf(0, 0), intArrayOf(1, 0), intArrayOf(1, 1), intArrayOf(0, 1))
        for (i in 0 until 4) {
            val s = corners[i][0].toFloat()
            val t = corners[i][1].toFloat()
            px[i] = p0[0] + s * a[0] + t * b[0]
            py[i] = p0[1] + s * a[1] + t * b[1]
            pz[i] = p0[2] + s * a[2] + t * b[2]
            tu[i] = rect.x + s * rect.width
            tv[i] = rect.y + t * rect.height
        }
        return SkinQuad(px, py, pz, tu, tv, n[0], n[1], n[2], rect, part.overlay)
    }
}
