package com.mclauncher.app.ui.play

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.versions.VersionLibraryState
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.components.NeonSecondaryButton
import com.mclauncher.app.ui.home.VersionGrid
import com.mclauncher.app.ui.home.rememberPlayAction
import com.mclauncher.app.ui.navigation.Destination

/**
 * Вкладка «Играть»: все установленные версии карточками, у каждой своя кнопка «Играть». Нажатие на карточку выбирает
 * версию для главной кнопки. Установка и удаление версий — на экране «Версии», его открывает кнопка сверху.
 */
@Composable
fun PlayScreen(
    activeAccount: ActiveAccountState,
    library: VersionLibraryState?,
    launchPhase: LaunchPhase,
    onPlay: (versionId: String?) -> Unit,
    onSelectVersion: (String) -> Unit,
    onNavigate: (Destination) -> Unit,
    modifier: Modifier = Modifier,
) {
    val play = rememberPlayAction(activeAccount, library, onPlay, onNavigate)
    val installed = remember(library) { library?.installed.orEmpty() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = stringResource(R.string.nav_play),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
            )
            NeonSecondaryButton(
                text = stringResource(R.string.play_manage_versions),
                onClick = { onNavigate(Destination.Versions) },
                icon = LauncherIcons.Download,
                height = 38.dp,
            )
        }
        VersionGrid(
            installed = installed,
            selectedId = library?.selectedId,
            loaded = library != null,
            canLaunch = launchPhase == LaunchPhase.IDLE,
            onSelect = onSelectVersion,
            onLaunch = { versionId -> play(versionId) },
            onOpenVersions = { onNavigate(Destination.Versions) },
            modifier = Modifier.weight(1f),
        )
    }
}
