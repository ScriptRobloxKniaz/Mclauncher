package com.mclauncher.app.core

import android.content.Context
import android.util.Log
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.install.CoreAssets
import com.mclauncher.engine.install.CoreInstallException
import com.mclauncher.engine.install.CoreInstaller
import com.mclauncher.engine.install.CoreManifest
import com.mclauncher.engine.install.CoreProgress
import com.mclauncher.engine.install.ManifestException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * Игровое ядро на устройстве: что поставлено, запуск и отмена фоновой установки.
 *
 * Сама установка — [CoreInstaller] из `:engine`; здесь к ней добавлены только Android-детали: чтение манифеста из
 * ассетов APK, `libunpack200.so` и WorkManager (установка идёт службой переднего плана с уведомлением и переживает
 * уход с экрана). Манифест читается один раз и только на фоновом потоке.
 */
class CoreInstallManager(
    private val context: Context,
    /** `null`, если процессор устройства ядро не поддерживает. */
    private val layout: EngineLayout?,
    private val deviceAbi: String?,
    private val nativeLibraryDir: File,
) {
    private sealed interface Loaded {
        data object NotBundled : Loaded
        data class Unsupported(val coreAbi: String) : Loaded
        data class Ready(val manifest: CoreManifest, val installer: CoreInstaller) : Loaded
    }

    private val loaded: Loaded by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { load() }
    private val refreshTick = MutableStateFlow(0)
    private val workManager: WorkManager by lazy { WorkManager.getInstance(context) }

    private fun load(): Loaded {
        val assets = context.assets
        val text = try {
            assets.open(CoreManifest.ASSET_NAME).bufferedReader().use { it.readText() }
        } catch (_: IOException) {
            // Нет файла — приложение собрано без ядра (шаг scripts/fetch_core.py --install не выполнялся).
            return Loaded.NotBundled
        }
        val manifest = try {
            CoreManifest.parse(text)
        } catch (e: ManifestException) {
            Log.e(TAG, "The core manifest in the APK is unusable: ${e.message}")
            return Loaded.NotBundled
        }
        val engineLayout = layout
        if (engineLayout == null || engineLayout.abi != manifest.abi) return Loaded.Unsupported(manifest.abi)
        val installer = CoreInstaller(
            layout = engineLayout,
            manifest = manifest,
            assets = CoreAssets { path -> assets.open(path) },
            unpack200 = NativeUnpack200(nativeLibraryDir),
        )
        return Loaded.Ready(manifest, installer)
    }

    /** Состояние компонентов на диске. Читает файлы — вызывать вне главного потока. */
    suspend fun disk(): CoreDisk = withContext(Dispatchers.IO) {
        when (val l = loaded) {
            Loaded.NotBundled -> CoreDisk.NotBundled
            is Loaded.Unsupported -> CoreDisk.UnsupportedDevice(deviceAbi, l.coreAbi)
            is Loaded.Ready -> CoreDisk.Known(
                l.manifest.components.map { CoreComponentInfo(it.id, l.installer.state(it), it.totalBytes) },
            )
        }
    }

    /** Состояние для экрана: диск + фоновая работа. Диск не перечитывается на каждый шаг прогресса. */
    val state: Flow<CoreUiState> = flow {
        var lastDisk: CoreDisk? = null
        emitAll(
            combine(refreshTick, workFlow()) { _, work ->
                val busy = work.phase == WorkPhase.RUNNING || work.phase == WorkPhase.QUEUED
                if (!busy || lastDisk == null) lastDisk = disk()
                reduceCoreState(lastDisk, work)
            },
        )
    }

    /** Перечитать диск (например, после возвращения на экран). */
    fun refresh() {
        refreshTick.update { it + 1 }
    }

    /** Поставить в очередь установку всех недостающих компонентов. Повторный вызов при идущей установке ничего не делает. */
    fun start() {
        val request = OneTimeWorkRequest.Builder(CoreInstallWorker::class.java).build()
        workManager.enqueueUniqueWork(UNIQUE_NAME, ExistingWorkPolicy.KEEP, request)
    }

    fun cancel() {
        workManager.cancelUniqueWork(UNIQUE_NAME)
    }

    /**
     * Ставит всё, чего не хватает; блокирует поток, поэтому вызывается из фоновой работы. Бросает
     * [CoreInstallException] (нет ядра в сборке — [CoreInstallException.AssetMissing]).
     */
    fun installAllBlocking(progress: (CoreProgress) -> Unit) {
        val l = loaded
        if (l !is Loaded.Ready) throw CoreInstallException.AssetMissing(CoreManifest.ASSET_NAME)
        l.installer.install(l.manifest.components.map { it.id }, progress)
    }

    private fun workFlow(): Flow<CoreWork> =
        workManager.getWorkInfosForUniqueWorkFlow(UNIQUE_NAME).map { infos ->
            // Работа с этим именем одна; завершённые копятся до очистки, поэтому активная важнее.
            (infos.firstOrNull { !it.state.isFinished } ?: infos.lastOrNull())?.toCoreWork() ?: CoreWork()
        }

    private fun WorkInfo.toCoreWork(): CoreWork = when (this.state) {
        WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED -> CoreWork(WorkPhase.QUEUED)
        WorkInfo.State.RUNNING -> CoreWork(
            phase = WorkPhase.RUNNING,
            doneBytes = progress.getLong(KEY_DONE, 0),
            totalBytes = progress.getLong(KEY_TOTAL, 0),
            label = progress.getString(KEY_LABEL).orEmpty(),
        )
        WorkInfo.State.SUCCEEDED -> CoreWork(WorkPhase.SUCCEEDED)
        WorkInfo.State.FAILED -> CoreWork(
            phase = WorkPhase.FAILED,
            failure = failureFromCode(outputData.getString(KEY_FAILURE)),
            detail = outputData.getString(KEY_DETAIL),
        )
        WorkInfo.State.CANCELLED -> CoreWork(WorkPhase.CANCELLED)
    }

    companion object {
        private const val TAG = "CoreInstall"
        const val UNIQUE_NAME = "core-install"

        // Ключи данных WorkManager: прогресс (setProgress) и итог (Result.failure).
        const val KEY_DONE = "done"
        const val KEY_TOTAL = "total"
        const val KEY_LABEL = "label"
        const val KEY_FAILURE = "failure"
        const val KEY_DETAIL = "detail"
    }
}
