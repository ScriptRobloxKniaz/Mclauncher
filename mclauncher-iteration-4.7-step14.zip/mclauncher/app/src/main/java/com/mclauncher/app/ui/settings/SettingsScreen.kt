package com.mclauncher.app.ui.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.VideoBackgroundSettings
import com.mclauncher.app.data.settings.volumePercent
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.components.NeonButton
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.components.NeonSecondaryButton

/**
 * Всё, что нужно экранам для работы с видео-фоном: текущие настройки и действия над ними.
 * Собирается один раз в корне UI, чтобы не тащить через навигацию по семь параметров.
 */
@Immutable
data class VideoControls(
    val settings: VideoBackgroundSettings,
    /** Видео выбрано в системном окне (SAF): его нужно скопировать и сделать фоном. */
    val onPick: (Uri) -> Unit,
    val onEnabledChange: (Boolean) -> Unit,
    val onMutedChange: (Boolean) -> Unit,
    /** Ползунок двигают: громкость меняется сразу, но на диск ещё не пишется. */
    val onVolumePreview: (Float) -> Unit,
    /** Ползунок отпустили: громкость запоминается. */
    val onVolumeCommit: (Float) -> Unit,
    val onRemove: () -> Unit,
)

/**
 * Экран «Настройки». Разделы: «Графика и рендеры» (рендерер, версия OpenGL, Zink), видео-фон (переключатель, выбор и
 * удаление видео, громкость, «Выключить звук»; по умолчанию видео играет без звука) и «Игровое ядро» (установка
 * рантаймов Java и компонентов запуска) и «Запуск и загрузка» (память игры, аргументы Java, потоки загрузки).
 */
@Composable
fun SettingsScreen(
    video: VideoControls,
    core: CoreControls,
    graphics: GraphicsControls,
    launch: LaunchControls,
    modifier: Modifier = Modifier,
) {
    val settings = video.settings
    val colors = MaterialTheme.colorScheme

    // SAF: системный выбор видео. Копирование в хранилище приложения делает ViewModel.
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) video.onPick(uri)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = stringResource(R.string.nav_settings),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = colors.onSurface,
        )

        // Порядок важен: сначала предел ширины, потом заполнение.
        GraphicsSection(graphics = graphics, modifier = Modifier.widthIn(max = 640.dp).fillMaxWidth())

        LaunchSection(controls = launch, modifier = Modifier.widthIn(max = 640.dp).fillMaxWidth())

        NeonCard(modifier = Modifier.widthIn(max = 640.dp).fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                VideoHeader(settings = settings, onEnabledChange = video.onEnabledChange)

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NeonButton(
                        text = stringResource(if (settings.hasVideo) R.string.settings_video_replace else R.string.settings_video_pick),
                        onClick = { videoPicker.launch(arrayOf("video/*")) },
                        icon = LauncherIcons.Video,
                    )
                    NeonSecondaryButton(
                        text = stringResource(R.string.settings_video_remove),
                        onClick = video.onRemove,
                        icon = Icons.Filled.Delete,
                        enabled = settings.hasVideo,
                        danger = true,
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(colors.outlineVariant),
                )

                VolumeSection(settings = settings, video = video)
            }
        }

        CoreSection(core = core, modifier = Modifier.widthIn(max = 640.dp).fillMaxWidth())
    }
}

/** Заголовок раздела с пояснением и переключателем «Видео-фон». Без выбранного видео переключатель недоступен. */
@Composable
private fun VideoHeader(
    settings: VideoBackgroundSettings,
    onEnabledChange: (Boolean) -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val switchLabel = stringResource(R.string.settings_video_switch)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(
            imageVector = LauncherIcons.Video,
            contentDescription = null,
            tint = colors.primary,
            modifier = Modifier.size(24.dp),
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.settings_video_title),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = colors.onSurface,
            )
            Text(
                text = stringResource(if (settings.hasVideo) R.string.settings_video_hint else R.string.settings_video_none),
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
            )
        }
        Switch(
            checked = settings.active,
            onCheckedChange = onEnabledChange,
            enabled = settings.hasVideo,
            modifier = Modifier.semantics { contentDescription = switchLabel },
        )
    }
}

/** Ползунок громкости, подпись с процентами и кнопка «Выключить звук» / «Включить звук». */
@Composable
private fun VolumeSection(
    settings: VideoBackgroundSettings,
    video: VideoControls,
) {
    val colors = MaterialTheme.colorScheme

    // Положение ползунка, пока его тянут. Сброс — когда сохранённая громкость обновилась и сравнялась с ним.
    var dragValue by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(settings.volume) { dragValue = null }
    val shown = dragValue ?: settings.volume

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = stringResource(R.string.settings_video_volume),
            style = MaterialTheme.typography.labelLarge,
            color = colors.onSurface,
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(
                imageVector = if (settings.muted) LauncherIcons.VolumeOff else LauncherIcons.VolumeOn,
                contentDescription = null,
                tint = if (settings.hasVideo) colors.onSurfaceVariant else colors.outline,
                modifier = Modifier.size(22.dp),
            )
            Slider(
                value = shown,
                onValueChange = { value ->
                    dragValue = value
                    video.onVolumePreview(value)
                },
                onValueChangeFinished = {
                    dragValue?.let(video.onVolumeCommit)
                },
                valueRange = 0f..1f,
                enabled = settings.hasVideo,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = stringResource(R.string.settings_video_volume_value, volumePercent(shown)),
                style = MaterialTheme.typography.labelLarge,
                color = colors.onSurfaceVariant,
                textAlign = TextAlign.End,
                modifier = Modifier.width(48.dp),
            )
        }
    }

    NeonSecondaryButton(
        text = stringResource(if (settings.muted) R.string.settings_video_unmute else R.string.settings_video_mute),
        onClick = { video.onMutedChange(!settings.muted) },
        icon = if (settings.muted) LauncherIcons.VolumeOn else LauncherIcons.VolumeOff,
        enabled = settings.hasVideo,
    )

    if (settings.hasVideo && settings.muted) {
        Text(
            text = stringResource(R.string.settings_video_muted_note),
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant,
        )
    }
}
