package com.mclauncher.app.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import com.mclauncher.app.MainActivity
import com.mclauncher.app.R
import com.mclauncher.engine.install.CoreProgress
import java.util.UUID

/** Уведомление службы переднего плана при установке ядра: прогресс и кнопка «Отмена». */
internal class CoreNotifier(private val context: Context, private val workId: UUID) {

    private val manager = context.getSystemService(NotificationManager::class.java)

    fun foregroundInfo(progress: CoreProgress?): ForegroundInfo {
        val notification = build(progress)
        // Тип службы обязателен с Android 14 (targetSdk 34+): установка — это передача данных (dataSync).
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    /** Обновляет то же уведомление: id один, поэтому служба не перезапускается. */
    fun update(progress: CoreProgress) {
        manager.notify(NOTIFICATION_ID, build(progress))
    }

    private fun build(progress: CoreProgress?): android.app.Notification {
        ensureChannel()
        val open = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val cancel = WorkManager.getInstance(context).createCancelPendingIntent(workId)
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(context.getString(R.string.core_notif_title))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .addAction(0, context.getString(R.string.core_notif_cancel), cancel)
        if (progress == null || progress.totalBytes <= 0) {
            builder.setContentText(context.getString(R.string.core_notif_preparing))
            builder.setProgress(0, 0, true)
        } else {
            val percent = (progress.fraction * 100).toInt().coerceIn(0, 100)
            builder.setContentText(context.getString(R.string.core_notif_progress, percent))
            builder.setProgress(100, percent, false)
        }
        return builder.build()
    }

    private fun ensureChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.core_notif_channel),
            NotificationManager.IMPORTANCE_LOW,
        )
        manager.createNotificationChannel(channel) // повторный вызов безопасен
    }

    private companion object {
        const val CHANNEL_ID = "core_install"
        const val NOTIFICATION_ID = 7101
    }
}
