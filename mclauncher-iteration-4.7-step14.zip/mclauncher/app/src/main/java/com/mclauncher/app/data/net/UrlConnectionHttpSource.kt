package com.mclauncher.app.data.net

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * [HttpSource] на стандартном `HttpURLConnection`: без внешних зависимостей. На Android он работает поверх OkHttp
 * платформы и сам обрабатывает HTTPS и перенаправления внутри одного протокола.
 *
 * Сжатие отключено (`Accept-Encoding: identity`): файлы игры уже сжаты, а так длина тела совпадает с длиной на сервере.
 * Отмену корутины блокирующее чтение само не замечает — потребитель проверяет её между порциями данных,
 * поэтому задержка отмены не больше [readTimeoutMs].
 *
 * Соединения: после полностью прочитанного ответа `disconnect()` уже ничего не рвёт — соединение возвращается в пул
 * платформы (на JDK это проверяет тест, на Android `disconnect()` по документации лишь освобождает ресурсы). Вероятное
 * узкое место — другое: пул по умолчанию держит всего 5 неактивных соединений на узел (так в OkHttp платформы; на
 * устройстве не измерено), а загрузок идёт больше, поэтому лишние соединения закрывались и открывались заново.
 * Размер пула увеличивает [enlargeConnectionPool].
 */
class UrlConnectionHttpSource(
    private val userAgent: String,
    private val connectTimeoutMs: Int = 15_000,
    private val readTimeoutMs: Int = 20_000,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) : HttpSource {

    override suspend fun <T> get(url: String, consume: suspend (HttpBody) -> T): T =
        withContext(ioDispatcher) {
            val connection = URL(url).openConnection() as? HttpURLConnection
                ?: throw IOException("Not an HTTP(S) URL: $url")
            try {
                connection.requestMethod = "GET"
                connection.connectTimeout = connectTimeoutMs
                connection.readTimeout = readTimeoutMs
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", userAgent)
                connection.setRequestProperty("Accept-Encoding", "identity")

                val status = connection.responseCode
                if (status !in 200..299) throw HttpStatusException(status, url)
                connection.inputStream.use { stream ->
                    consume(HttpBody(connection.contentLengthLong, stream))
                }
            } finally {
                connection.disconnect()
            }
        }

    companion object {
        /** Сколько неактивных соединений держать на узел: больше, чем одновременных загрузок, иначе пул не поможет. */
        const val POOL_SIZE = 144

        private const val POOL_PROPERTY = "http.maxConnections"

        /**
         * Увеличивает пул соединений платформы (по умолчанию — 5 на узел). Свойство читается один раз, при первом
         * сетевом запросе процесса, поэтому вызывать надо до него (из `Application.onCreate`). Если значение уже
         * задано снаружи, оно остаётся как есть. Возвращает `true`, если свойство установлено этим вызовом.
         */
        fun enlargeConnectionPool(size: Int = POOL_SIZE): Boolean {
            if (size < 1) return false
            return try {
                if (System.getProperty(POOL_PROPERTY) != null) {
                    false
                } else {
                    System.setProperty(POOL_PROPERTY, size.toString())
                    true
                }
            } catch (e: SecurityException) {
                false
            }
        }
    }
}
