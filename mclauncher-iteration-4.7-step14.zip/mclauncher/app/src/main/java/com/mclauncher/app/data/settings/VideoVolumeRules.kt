package com.mclauncher.app.data.settings

import kotlin.math.roundToInt

/** Громкость в процентах для подписи у ползунка: 0..100, всегда целое. */
fun volumePercent(volume: Float): Int = (sanitizeVolume(volume) * 100f).roundToInt()

/**
 * Нужно ли включить звук, когда пользователь двигает ползунок громкости.
 *
 * Звук выключен по умолчанию, но если человек тянет ползунок вверх, он хочет слышать видео, поэтому звук включается
 * сам. Если ползунок утащили в ноль, звук остаётся как был: незачем включать «тишину».
 */
fun shouldUnmuteOnVolumeChange(muted: Boolean, newVolume: Float): Boolean = muted && sanitizeVolume(newVolume) > 0f
