package com.mclauncher.app.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.ui.accounts.AccountAvatar
import com.mclauncher.app.ui.accounts.labelRes
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.components.NeonButton
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.components.NeonChip
import com.mclauncher.app.ui.skins.rememberSkinBitmap
import com.mclauncher.app.ui.theme.NeonColors

/**
 * Карточка профиля вверху правой колонки: голова скина, ник с короной, тип аккаунта и стрелка. Нажатие открывает экран
 * аккаунтов. Если аккаунта нет — вместо профиля кнопка «Добавить аккаунт».
 *
 * Корона — часть оформления: отдельного платного статуса в лаунчере нет.
 */
@Composable
fun ProfileCard(
    account: ActiveAccountState,
    onOpenAccounts: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    NeonCard(modifier = modifier.fillMaxWidth(), onClick = onOpenAccounts) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            when (account) {
                // Место резервируем, чтобы карточка не «прыгала», когда база ответит.
                ActiveAccountState.Loading -> Box(Modifier.size(width = 1.dp, height = 40.dp))

                ActiveAccountState.None -> {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = null,
                        tint = colors.primary,
                        modifier = Modifier.size(24.dp),
                    )
                    Text(
                        text = stringResource(R.string.home_add_account),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.onSurface,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                is ActiveAccountState.Selected -> {
                    val selected = account.account
                    AccountAvatar(
                        username = selected.username,
                        type = selected.type,
                        size = 40.dp,
                        skin = rememberSkinBitmap(selected),
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(
                                text = selected.username,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = colors.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false),
                            )
                            Icon(
                                imageVector = LauncherIcons.Crown,
                                contentDescription = null,
                                tint = NeonColors.Gold,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                        ) {
                            Icon(
                                imageVector = LauncherIcons.Gem,
                                contentDescription = null,
                                tint = NeonColors.Accent,
                                modifier = Modifier.size(13.dp),
                            )
                            Text(
                                text = stringResource(selected.type.labelRes),
                                style = MaterialTheme.typography.bodySmall,
                                color = NeonColors.Accent,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
            Icon(
                imageVector = LauncherIcons.ChevronRight,
                contentDescription = null,
                tint = colors.onSurfaceVariant,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

/** Карточка «ИИ-помощник» (Beta): подпись, пояснение, кнопка «Открыть чат» и рисованный робот справа. */
@Composable
fun AssistantCard(
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    NeonCard(modifier = modifier.fillMaxWidth(), highlight = true) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = stringResource(R.string.assistant_title),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    NeonChip(text = stringResource(R.string.badge_beta))
                }
                Text(
                    text = stringResource(R.string.home_assistant_text),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
                NeonButton(
                    text = stringResource(R.string.home_open_chat),
                    onClick = onOpen,
                    icon = LauncherIcons.Chat,
                    trailingIcon = LauncherIcons.ChevronRight,
                    height = 34.dp,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            RobotArt(modifier = Modifier.size(width = 52.dp, height = 64.dp))
        }
    }
}

/** Карточка «Premium-доступ» внизу правой колонки. Оформление: платных функций пока нет, нажатие объясняет это. */
@Composable
fun PremiumCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    NeonCard(modifier = modifier.fillMaxWidth(), highlight = true, onClick = onClick) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(NeonColors.gradient),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = LauncherIcons.Crown,
                    contentDescription = null,
                    tint = NeonColors.Gold,
                    modifier = Modifier.size(20.dp),
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.home_premium_title),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = stringResource(R.string.home_premium_text),
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Icon(
                imageVector = LauncherIcons.ChevronRight,
                contentDescription = null,
                tint = colors.onSurfaceVariant,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

/** Маленький робот-помощник: голова с антенной и светящимися глазами. Нарисован кодом, оригинальный. */
@Composable
private fun RobotArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        // свечение за роботом
        drawCircle(
            brush = Brush.radialGradient(listOf(Color(0x668B5CFF), Color(0x008B5CFF))),
            radius = w * 0.9f,
            center = Offset(w * 0.5f, h * 0.55f),
        )
        // антенна
        drawRect(Color(0xFFB79CFF), Offset(w * 0.47f, h * 0.06f), Size(w * 0.06f, h * 0.14f))
        drawCircle(Color(0xFFE6DCFF), radius = w * 0.07f, center = Offset(w * 0.5f, h * 0.06f))
        // голова
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFEDE7FF), Color(0xFFB9AAF0))),
            topLeft = Offset(w * 0.08f, h * 0.2f),
            size = Size(w * 0.84f, h * 0.42f),
            cornerRadius = CornerRadius(w * 0.2f),
        )
        // экран-лицо
        drawRoundRect(
            color = Color(0xFF1A1245),
            topLeft = Offset(w * 0.17f, h * 0.27f),
            size = Size(w * 0.66f, h * 0.28f),
            cornerRadius = CornerRadius(w * 0.12f),
        )
        // глаза
        drawCircle(Color(0xFF8BE9FF), radius = w * 0.075f, center = Offset(w * 0.36f, h * 0.41f))
        drawCircle(Color(0xFF8BE9FF), radius = w * 0.075f, center = Offset(w * 0.64f, h * 0.41f))
        // тело
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFCFC3FA), Color(0xFF8E7BE0))),
            topLeft = Offset(w * 0.22f, h * 0.66f),
            size = Size(w * 0.56f, h * 0.3f),
            cornerRadius = CornerRadius(w * 0.14f),
        )
        // «уши»
        drawRoundRect(
            color = Color(0xFF7B5CFF),
            topLeft = Offset(0f, h * 0.32f),
            size = Size(w * 0.09f, h * 0.18f),
            cornerRadius = CornerRadius(w * 0.04f),
        )
        drawRoundRect(
            color = Color(0xFF7B5CFF),
            topLeft = Offset(w * 0.91f, h * 0.32f),
            size = Size(w * 0.09f, h * 0.18f),
            cornerRadius = CornerRadius(w * 0.04f),
        )
    }
}
