package com.mclauncher.app.ui.about

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.components.NeonChip
import com.mclauncher.app.ui.components.NeonSecondaryButton

/** Публичный репозиторий проекта: исходный код открыт (условие GPL-3.0). */
private const val SOURCE_URL = "https://github.com/ScriptRobloxKniaz/Mclauncher"

/**
 * Экран «О лаунчере»: версия, лицензия, на чём построен код и оговорка про торговую марку Minecraft.
 * Нужен не только для красоты: лицензия Zalith (GPL-3.0, раздел 7) требует не прятать уведомления об авторских правах
 * и называть программу неофициальной модифицированной версией.
 */
@Composable
fun AboutScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val versionName = remember(context) { context.appVersionName() }
    val openFailed = stringResource(R.string.about_open_failed)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = stringResource(R.string.about_title),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
        )

        // Порядок важен: сначала предел ширины, потом заполнение.
        val cardModifier = Modifier.widthIn(max = 640.dp).fillMaxWidth()

        NeonCard(modifier = cardModifier, highlight = true) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Icon(
                    imageVector = LauncherIcons.Cube,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(44.dp),
                )
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = stringResource(R.string.about_version, versionName ?: "?"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    NeonChip(text = stringResource(R.string.about_unofficial_chip))
                }
            }
        }

        AboutSection(
            title = stringResource(R.string.about_license_title),
            modifier = cardModifier,
        ) {
            AboutText(stringResource(R.string.about_license_text))
            NeonSecondaryButton(
                text = stringResource(R.string.about_source),
                onClick = {
                    try {
                        uriHandler.openUri(SOURCE_URL)
                    } catch (e: IllegalArgumentException) {
                        // Нет приложения, которое умеет открывать ссылки.
                        Toast.makeText(context, openFailed, Toast.LENGTH_SHORT).show()
                    }
                },
                icon = LauncherIcons.ChevronRight,
            )
        }

        AboutSection(
            title = stringResource(R.string.about_origin_title),
            modifier = cardModifier,
        ) {
            AboutText(stringResource(R.string.about_origin_zalith))
            AboutText(stringResource(R.string.about_origin_pojav))
            AboutText(stringResource(R.string.about_origin_note))
        }

        AboutSection(
            title = stringResource(R.string.about_trademark_title),
            modifier = cardModifier,
        ) {
            AboutText(stringResource(R.string.about_trademark_text))
        }
    }
}

@Composable
private fun AboutSection(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    NeonCard(modifier = modifier) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
            )
            content()
        }
    }
}

@Composable
private fun AboutText(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

/** Имя версии из манифеста приложения; `null`, если система его не отдала. */
@Suppress("DEPRECATION")
private fun Context.appVersionName(): String? = try {
    val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
    } else {
        packageManager.getPackageInfo(packageName, 0)
    }
    info.versionName
} catch (e: PackageManager.NameNotFoundException) {
    null
}
