package com.mclauncher.app.data.settings

/**
 * Графический рендерер игры. Выбор действует со следующего запуска: [com.mclauncher.app.launch.toRendererProfile]
 * превращает его в профиль ядра (библиотека и переменные окружения).
 *
 * [id] попадает в файл настроек, поэтому **менять уже выданные значения нельзя**: у пользователей они сохранены.
 * В шаге 12 убраны `virgl` и `opengl`: до игры они не доходили (ядро их не запускало), а сохранённое значение,
 * которого больше нет, заменяется рендерером по умолчанию ([fromId]).
 */
enum class Renderer(val id: String) {
    /** OpenGL → OpenGL ES (GL4ES). Самый совместимый вариант, поэтому он по умолчанию; для версий примерно до 1.21.4. */
    GL4ES("gl4es"),

    /** Krypton Wrapper (NG-GL4ES): развитие GL4ES на OpenGL ES 3, показывает игре OpenGL 3.1. */
    KRYPTON("krypton"),

    /** MobileGlues: OpenGL 4.x поверх OpenGL ES 3, для Minecraft от 1.17. */
    MOBILEGLUES("mobileglues"),

    /** Vulkan-слой: OpenGL поверх Vulkan (Zink, Kopper). Нужен телефон с Vulkan 1.1+. */
    ZINK("zink");

    /** Рендереру нужна поддержка Vulkan на устройстве. */
    val needsVulkan: Boolean get() = this == ZINK

    companion object {
        val Default = GL4ES

        fun fromId(id: String?): Renderer = entries.firstOrNull { it.id == id } ?: Default
    }
}

/**
 * Версия OpenGL, которую GL4ES показывает игре. [AUTO] — пусть решает сама библиотека (переменная не задаётся).
 * Остальные значения уходят в `LIBGL_GL` (в формате GL4ES: `21`, `30`, `32`). Действует ли каждое из них на нашей сборке
 * `libgl4es_114.so`, на устройстве ещё не проверено.
 */
enum class OpenGlVersion(val id: String) {
    AUTO("auto"),
    GL_2_1("2.1"),
    GL_3_0("3.0"),
    GL_3_2("3.2");

    /** Подпись для чисел (`2.1`); у [AUTO] подписи нет — её берут из строковых ресурсов. */
    val numberLabel: String? get() = if (this == AUTO) null else id

    /** Значение `LIBGL_GL`: `2.1` → `21`; `null` у [AUTO] — переменную не задавать. */
    val libglValue: String? get() = if (this == AUTO) null else id.replace(".", "")

    companion object {
        val Default = AUTO

        fun fromId(id: String?): OpenGlVersion = entries.firstOrNull { it.id == id } ?: Default
    }
}

/**
 * Настройки графики. Выпадающий список рендеров и переключатель «Использовать Zink» — два способа выбрать одно и то же,
 * поэтому они всегда согласованы: Zink выбран в списке ⇔ переключатель включён. Менять настройки нужно только
 * через [withRenderer] и [withUseZink], а читать сохранённое — через [fromStored].
 */
data class GraphicsSettings(
    val renderer: Renderer = Renderer.Default,
    val glVersion: OpenGlVersion = OpenGlVersion.Default,
    val useZink: Boolean = false,
) {
    /** Рендерер, который будет передан ядру. */
    val effectiveRenderer: Renderer get() = if (useZink) Renderer.ZINK else renderer

    /** Версия OpenGL имеет смысл только для GL4ES. */
    val glVersionApplies: Boolean get() = effectiveRenderer == Renderer.GL4ES

    /** Выбор в списке рендеров. Выбор Zink включает переключатель, любой другой — выключает. */
    fun withRenderer(value: Renderer): GraphicsSettings = copy(renderer = value, useZink = value == Renderer.ZINK)

    /**
     * Переключатель «Использовать Zink». Включение выбирает Zink в списке; выключение возвращает рендерер по
     * умолчанию, если в списке стоял Zink, и не трогает остальное.
     */
    fun withUseZink(enabled: Boolean): GraphicsSettings = when {
        enabled -> copy(renderer = Renderer.ZINK, useZink = true)
        renderer == Renderer.ZINK -> copy(renderer = Renderer.Default, useZink = false)
        else -> copy(useZink = false)
    }

    fun withGlVersion(value: OpenGlVersion): GraphicsSettings = copy(glVersion = value)

    companion object {
        /**
         * Собирает настройки из сохранённых значений. Неизвестные и повреждённые значения заменяются на значения
         * по умолчанию, а противоречия («Zink» в списке при выключенном переключателе) устраняются.
         */
        fun fromStored(rendererId: String?, glVersionId: String?, useZink: Boolean?): GraphicsSettings {
            val renderer = Renderer.fromId(rendererId)
            val zink = renderer == Renderer.ZINK || useZink == true
            return GraphicsSettings(
                renderer = if (zink) Renderer.ZINK else renderer,
                glVersion = OpenGlVersion.fromId(glVersionId),
                useZink = zink,
            )
        }
    }
}
