package com.mclauncher.app.ui.launch

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.launch.LaunchFailure
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.launch.LaunchResult
import com.mclauncher.app.launch.LogHint
import com.mclauncher.engine.launch.GameExitReport

/** Подпись на кнопке «Играть» в зависимости от стадии запуска. */
@get:StringRes
val LaunchPhase.playLabelRes: Int
    get() = when (this) {
        LaunchPhase.IDLE -> R.string.play
        LaunchPhase.PREPARING -> R.string.play_busy_preparing
        LaunchPhase.LAUNCHING -> R.string.play_busy_launching
    }

/** Понятное пользователю объяснение причины. */
@get:StringRes
private val LaunchFailure.messageRes: Int
    get() = when (this) {
        LaunchFailure.NoAccount -> R.string.launch_error_no_account
        LaunchFailure.NoVersion -> R.string.launch_error_no_version
        is LaunchFailure.VersionNotInstalled -> R.string.launch_error_version_missing
        is LaunchFailure.GameDirUnavailable -> R.string.launch_error_game_dir
        LaunchFailure.EngineUnavailable -> R.string.launch_error_engine_unavailable
        LaunchFailure.AlreadyLaunching -> R.string.launch_error_already
        is LaunchFailure.EngineError -> R.string.launch_error_engine
        is LaunchFailure.CoreNotReady -> R.string.launch_error_core_not_ready
        is LaunchFailure.GameExited ->
            if (exitCode == GameExitReport.CRASH_EXIT_CODE) R.string.launch_error_app_crashed else R.string.launch_error_game_exited
    }

@get:StringRes
private val LogHint.messageRes: Int
    get() = when (this) {
        LogHint.MEMORY -> R.string.launch_hint_memory
        LogHint.JAVA_VERSION -> R.string.launch_hint_java
        LogHint.NATIVE_LIBRARY -> R.string.launch_hint_native
        LogHint.GRAPHICS -> R.string.launch_hint_graphics
    }

/** Всё, что нужно приложить к просьбе о помощи: причина, технические детали и конец журнала игры. */
private fun reportText(detail: String?, logTail: String?): String = buildString {
    if (!detail.isNullOrBlank()) appendLine(detail)
    if (!logTail.isNullOrBlank()) {
        if (isNotEmpty()) appendLine()
        append(logTail)
    }
}.trim()

private fun copyToClipboard(context: Context, text: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
    manager.setPrimaryClip(ClipData.newPlainText("MCLauncher report", text))
    Toast.makeText(context, R.string.launch_report_copied, Toast.LENGTH_SHORT).show()
}

/** Техническая деталь для поддержки (если есть). Показывается мелким текстом. */
private val LaunchFailure.technicalDetail: String?
    get() {
        val raw = when (this) {
            is LaunchFailure.GameDirUnavailable -> detail
            is LaunchFailure.EngineError -> detail
            is LaunchFailure.VersionNotInstalled -> versionId
            is LaunchFailure.CoreNotReady -> missing
            is LaunchFailure.GameExited -> buildString {
                append("exit code ").append(exitCode)
                if (isSignal) append(" (signal)")
                if (!detail.isNullOrBlank()) append("; ").append(detail)
            }
            else -> null
        }
        return raw?.takeIf { it.isNotBlank() }
    }

/**
 * Итог запуска: либо ошибка с причиной (в том числе вылет игры, о котором узнали при возвращении в лаунчер), либо
 * честное сообщение, что это заглушка (игра не стартовала).
 */
@Composable
fun LaunchResultDialog(
    result: LaunchResult,
    onDismiss: () -> Unit,
) {
    val titleRes: Int
    val messageRes: Int
    val detail: String?
    when (result) {
        is LaunchResult.Started -> {
            titleRes = R.string.launch_stub_title
            messageRes = R.string.launch_stub_message
            detail = result.note?.takeIf { it.isNotBlank() }
        }

        is LaunchResult.Failed -> {
            val failure = result.failure
            titleRes = when {
                failure is LaunchFailure.GameExited && failure.exitCode == GameExitReport.CRASH_EXIT_CODE -> R.string.launch_app_crashed_title
                failure is LaunchFailure.GameExited -> R.string.launch_crashed_title
                else -> R.string.launch_failed_title
            }
            messageRes = result.failure.messageRes
            detail = result.failure.technicalDetail
        }
    }
    // Подсказки и конец журнала есть только у вылета игры (см. LauncherViewModel.checkGameExit).
    val exited = ((result as? LaunchResult.Failed)?.failure) as? LaunchFailure.GameExited
    val hints: List<LogHint> = exited?.hints.orEmpty()
    val logTail: String? = exited?.logTail?.takeIf { it.isNotBlank() }
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(titleRes)) },
        text = {
            // Подробности бывают длинными (причина вылета с трассировкой): окно прокручивается, текст можно выделить и скопировать.
            Column(
                modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(stringResource(messageRes))
                if (hints.isNotEmpty()) {
                    Text(stringResource(R.string.launch_hint_title), style = MaterialTheme.typography.titleSmall)
                    for (hint in hints) Text(stringResource(hint.messageRes), style = MaterialTheme.typography.bodyMedium)
                }
                if (detail != null) {
                    SelectionContainer {
                        Text(
                            text = stringResource(R.string.launch_details, detail),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                if (logTail != null) {
                    Text(stringResource(R.string.launch_log_title), style = MaterialTheme.typography.titleSmall)
                    SelectionContainer {
                        Text(
                            text = logTail,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        },
        dismissButton = {
            // Копировать есть что только при подробностях или журнале; иначе кнопки нет.
            if (detail != null || logTail != null) {
                TextButton(onClick = { copyToClipboard(context, reportText(detail, logTail)) }) {
                    Text(stringResource(R.string.launch_copy_report))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_ok)) }
        },
    )
}
