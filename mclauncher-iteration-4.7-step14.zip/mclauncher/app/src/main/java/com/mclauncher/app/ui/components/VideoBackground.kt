package com.mclauncher.app.ui.components

import android.net.Uri
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.mclauncher.app.data.settings.sanitizeVolume
import kotlinx.coroutines.delay

/**
 * Видео на заднем плане: заполняет экран с обрезкой по краям, играет по кругу и по умолчанию без звука.
 *
 * Видео играет, только пока оно видно ([visible]: открыт главный экран и приложение на переднем плане).
 * Правило — в [VideoPlaybackPolicy]:
 *  - сразу после ухода с главного — пауза: плеер и последний кадр остаются, возврат мгновенный;
 *  - через [VideoPlaybackPolicy.RELEASE_AFTER_MS] плеер освобождается целиком (декодер, память, батарея),
 *    при возврате создаётся заново;
 *  - если видео не играется (повреждён файл, неподдерживаемый кодек), вызывается [onError], а вызывающий код
 *    выключает видео-фон — под ним остаётся обычный фон;
 *  - громкость меняется на лету, без перезапуска видео ([volume] от 0 до 1).
 *
 * Аннотация Suppress: часть классов Media3 помечена как нестабильные. Это проверяет только lint, компилятору всё равно.
 */
@Suppress("UnsafeOptInUsageError")
@Composable
fun VideoBackground(
    video: BackgroundVideo,
    volume: Float,
    visible: Boolean,
    onError: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val playback by rememberVideoPlayback(visible)
    // RELEASED: плеера в композиции нет вовсе — его освободил DisposableEffect внутри rememberExoPlayer.
    if (playback == VideoPlayback.RELEASED) return

    val player = rememberExoPlayer(video = video, volume = volume, onError = onError)

    // Пауза при скрытии и продолжение при возвращении. Само освобождение — в rememberExoPlayer.
    LaunchedEffect(player, playback) {
        if (playback == VideoPlayback.PLAYING) player?.play() else player?.pause()
    }

    AndroidView(
        factory = { viewContext ->
            PlayerView(viewContext).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                // Пока нет первого кадра, не закрывать фон чёрным.
                setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
            }
        },
        update = { view -> if (view.player !== player) view.player = player },
        onRelease = { view -> view.player = null },
        modifier = modifier.fillMaxSize(),
    )
}

/**
 * Состояние видео по [VideoPlaybackPolicy]: «играет» пока оно [visible]; после скрытия — «пауза», а ещё через
 * [VideoPlaybackPolicy.RELEASE_AFTER_MS] — «освобождено».
 */
@Composable
private fun rememberVideoPlayback(visible: Boolean): State<VideoPlayback> =
    produceState(
        initialValue = VideoPlaybackPolicy.stateFor(visible = visible, hiddenForMs = 0),
        visible,
    ) {
        value = VideoPlaybackPolicy.stateFor(visible = visible, hiddenForMs = 0)
        if (!visible) {
            delay(VideoPlaybackPolicy.RELEASE_AFTER_MS)
            value = VideoPlaybackPolicy.stateFor(visible = false, hiddenForMs = VideoPlaybackPolicy.RELEASE_AFTER_MS)
        }
    }

/**
 * Плеер для видео-фона. Создаётся при входе в композицию и **гарантированно освобождается** при выходе из неё или
 * при смене видео — иначе декодер остался бы занят и жёг батарею. Возвращает `null` в первый кадр, пока плеер
 * создаётся, и никогда не возвращает уже освобождённый плеер.
 *
 *  - громкость задаётся до начала воспроизведения (при выключенном звуке не мелькнёт звук) и меняется на лету;
 *  - пока звук выключен, звуковая дорожка отключается совсем, и аудио-декодер не работает;
 *  - видео крутится по кругу; плеер не берёт аудиофокус, поэтому чужая музыка не прерывается.
 *
 * Название повторяет привычное имя из Compose-примеров; в самой Media3 такой функции нет — она написана здесь.
 */
@Suppress("UnsafeOptInUsageError")
@Composable
fun rememberExoPlayer(
    video: BackgroundVideo,
    volume: Float,
    onError: () -> Unit,
): ExoPlayer? {
    val context = LocalContext.current
    val currentOnError by rememberUpdatedState(onError)
    val startVolume = sanitizeVolume(volume)
    var player by remember(video.file.path, video.stamp) { mutableStateOf<ExoPlayer?>(null) }

    DisposableEffect(video.file.path, video.stamp) {
        val created = ExoPlayer.Builder(context.applicationContext).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            this.volume = startVolume
            applyAudioTrack(enabled = startVolume > 0f)
            addListener(
                object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        currentOnError()
                    }
                },
            )
            setMediaItem(MediaItem.fromUri(Uri.fromFile(video.file)))
            playWhenReady = false // запускает LaunchedEffect в VideoBackground, когда видео видно
            prepare()
        }
        player = created
        onDispose {
            player = null
            created.release()
        }
    }

    LaunchedEffect(player, volume) {
        val current = player ?: return@LaunchedEffect
        val value = sanitizeVolume(volume)
        current.volume = value
        current.applyAudioTrack(enabled = value > 0f)
    }

    return player
}

/** Включает или отключает звуковую дорожку: без звука аудио-декодер не нужен. */
@Suppress("UnsafeOptInUsageError")
private fun ExoPlayer.applyAudioTrack(enabled: Boolean) {
    trackSelectionParameters = trackSelectionParameters
        .buildUpon()
        .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, !enabled)
        .build()
}
