package com.mclauncher.app.core

import com.mclauncher.engine.install.Unpack200
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Распаковка `.pack` (Java 8) программой `libunpack200.so` из папки нативных библиотек приложения. Это исполняемый
 * файл под видом библиотеки: запускать файлы из внутреннего хранилища Android не даёт, а из папки нативных библиотек —
 * даёт (поэтому в `:app` включена `useLegacyPackaging`). Так делает и ZalithLauncher 2 (RuntimesManager.unpack200).
 * Ключ `-r` удаляет исходный `.pack` после распаковки.
 *
 * НЕ ПРОВЕРЕНО на устройстве: на этой машине нет Android. Если запуск не удастся, установка Java 8 завершится ошибкой
 * с текстом вывода программы, остальные рантаймы (17 и 21) это не затрагивает.
 */
class NativeUnpack200(private val nativeLibraryDir: File) : Unpack200 {

    override fun unpack(pack: File, output: File) {
        val executable = File(nativeLibraryDir, EXECUTABLE)
        if (!executable.isFile) throw IOException("$EXECUTABLE is missing in ${nativeLibraryDir.path}")

        val process = ProcessBuilder(executable.path, "-r", pack.path, output.path)
            .directory(nativeLibraryDir)
            .redirectErrorStream(true)
            .start()
        try {
            // Вывод читаем сразу, иначе заполненный буфер может подвесить программу.
            val text = process.inputStream.bufferedReader().use { it.readText() }
            if (!process.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
                throw IOException("unpack200 did not finish for ${pack.name} in $TIMEOUT_SECONDS s")
            }
            val code = process.exitValue()
            if (code != 0) throw IOException("unpack200 failed for ${pack.name} (exit $code): ${text.take(300)}")
        } finally {
            process.destroy()
        }
    }

    private companion object {
        const val EXECUTABLE = "libunpack200.so"
        const val TIMEOUT_SECONDS = 120L
    }
}
