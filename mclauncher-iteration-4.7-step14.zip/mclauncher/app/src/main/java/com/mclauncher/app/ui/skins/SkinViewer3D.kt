package com.mclauncher.app.ui.skins

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntSize
import com.mclauncher.app.data.skin.SkinFrame
import com.mclauncher.app.data.skin.SkinModel
import com.mclauncher.app.data.skin.SkinRenderer
import com.mclauncher.app.data.skin.SkinScene
import com.mclauncher.app.data.skin.ViewAngles
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.withContext

/** Сохранение ракурса при пересоздании экрана (поворот телефона, смена темы). */
val ViewAnglesSaver: Saver<ViewAngles, Any> = Saver(
    save = { listOf(it.yaw, it.pitch) },
    restore = { saved ->
        @Suppress("UNCHECKED_CAST")
        val values = saved as List<Float>
        ViewAngles(values[0], values[1])
    },
)

/**
 * Объёмный просмотр скина: персонаж вращается пальцем по любой оси, можно рассмотреть его со всех сторон, сверху и
 * снизу. Двойное касание сбрасывает ракурс ([onReset]).
 *
 * Картинку рисует программный рисовальщик [SkinRenderer] (без OpenGL и графического процессора), поэтому кадр считается
 * вне главного потока, в уменьшенном размере ([SkinFrame.fit]), и растягивается на всё окно. Пока рисовальщик занят,
 * новые повороты не копятся в очередь: после кадра он берёт самый свежий ракурс.
 *
 * [texture] — скин 64×64 (ARGB по строкам). Если его нет (`null`), рисуется нейтральный «манекен» с учётом [model].
 */
@Composable
fun SkinViewer3D(
    texture: IntArray?,
    model: SkinModel,
    angles: ViewAngles,
    onRotate: (dxPx: Float, dyPx: Float) -> Unit,
    onReset: () -> Unit,
    description: String,
    modifier: Modifier = Modifier,
) {
    var windowSize by remember { mutableStateOf(IntSize.Zero) }
    var frame by remember { mutableStateOf<ImageBitmap?>(null) }
    val scene = remember(texture, model) { SkinScene.of(texture ?: SkinScene.mannequinTexture(model), model) }

    // Жесты запускаются один раз, а ракурс и действия меняются: читаем их через «обновляемое» состояние.
    val latestAngles by rememberUpdatedState(angles)
    val latestOnRotate by rememberUpdatedState(onRotate)
    val latestOnReset by rememberUpdatedState(onReset)

    LaunchedEffect(scene, windowSize) {
        if (windowSize.width <= 0 || windowSize.height <= 0) return@LaunchedEffect
        val (frameWidth, frameHeight) = SkinFrame.fit(windowSize.width, windowSize.height)
        snapshotFlow { latestAngles }
            .conflate() // пока кадр считается, остаётся только самый свежий ракурс
            .collect { current ->
                frame = withContext(Dispatchers.Default) {
                    val pixels = SkinRenderer.render(scene, current.yaw, current.pitch, frameWidth, frameHeight)
                    Bitmap.createBitmap(pixels, frameWidth, frameHeight, Bitmap.Config.ARGB_8888).asImageBitmap()
                }
            }
    }

    Box(
        modifier = modifier
            .onSizeChanged { windowSize = it }
            .semantics { contentDescription = description }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    latestOnRotate(dragAmount.x, dragAmount.y)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { latestOnReset() })
            },
    ) {
        frame?.let { image ->
            Image(
                bitmap = image,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds,
                filterQuality = FilterQuality.Low, // кадр меньше окна: растягиваем плавно, без «лесенки»
            )
        }
    }
}
