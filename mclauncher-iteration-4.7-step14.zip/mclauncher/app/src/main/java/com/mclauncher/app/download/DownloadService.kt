package com.mclauncher.app.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.mclauncher.app.LauncherApp
import com.mclauncher.app.MainActivity
import com.mclauncher.app.R
import com.mclauncher.app.data.versions.InstallNotice
import com.mclauncher.app.data.versions.InstallState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Служба переднего плана на время установки версии игры: с ней система не усыпляет и не убивает процесс, когда
 * лаунчер свёрнут, а в шторке виден прогресс с кнопкой «Отмена». Саму загрузку она не выполняет: её ведёт
 * `InstallManager` в процессе приложения, служба только следит за его состоянием ([InstallNotice]) и держит процесс.
 *
 * Запускается автоматически, когда установка начинается ([watch]), и останавливается сама, когда она заканчивается:
 * тогда вместо прогресса остаётся уведомление с итогом. Если запустить службу система не даёт (фон, ограничения
 * производителя), установка идёт как раньше, просто без защиты от усыпления.
 *
 * Тип службы — `dataSync` (передача данных): он обязателен с Android 14 и объявлен в манифесте.
 * Проверено только чтением кода: на устройстве служба ещё не запускалась.
 */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var manager: NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        manager = getSystemService(NotificationManager::class.java)
        ensureChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as? LauncherApp
        if (app == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_CANCEL) {
            // Установка остановится, состояние станет «покой», и коллектор ниже сам закроет службу.
            app.installManager.cancel()
            if (job == null) stopSelf()
            return START_NOT_STICKY
        }

        // Уведомление нужно показать сразу: система даёт на это несколько секунд после startForegroundService.
        val first = InstallNotice.of(app.installManager.state.value)
        startForegroundCompat(buildRunning(first as? InstallNotice.Running))
        acquireWakeLock()

        // Следим заново при каждом запуске: так устаревший наблюдатель прошлой установки не снимет новое уведомление.
        job?.cancel()
        job = scope.launch {
            app.installManager.state.collect { state -> onNotice(InstallNotice.of(state)) }
        }
        // Если процесс всё же убьют, воскрешать службу не нужно: установка без процесса всё равно не идёт.
        return START_NOT_STICKY
    }

    private fun onNotice(notice: InstallNotice) {
        when (notice) {
            is InstallNotice.Running -> manager.notify(FOREGROUND_ID, buildRunning(notice))

            is InstallNotice.Done -> finish(buildFinished(notice.versionId, ok = true))
            is InstallNotice.Failed -> finish(buildFinished(notice.versionId, ok = false))
            InstallNotice.None -> finish(null)
        }
    }

    /** Установка закончилась: убираем прогресс, оставляем итог (если он есть) и закрываем службу. */
    private fun finish(summary: Notification?) {
        job?.cancel()
        job = null
        stopForegroundCompat()
        if (summary != null) manager.notify(FINISHED_ID, summary)
        stopSelf()
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        releaseWakeLock()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- уведомления

    private fun buildRunning(notice: InstallNotice.Running?): Notification {
        val builder = baseBuilder()
            .setContentTitle(
                if (notice != null) getString(R.string.download_notif_title, notice.versionId) else getString(R.string.download_notif_title_unknown),
            )
            .setOngoing(true)
            .addAction(0, getString(R.string.download_notif_cancel), cancelIntent())
        val percent = notice?.percent
        if (notice == null || percent == null) {
            builder.setContentText(getString(R.string.download_notif_preparing))
            builder.setProgress(0, 0, true)
        } else {
            builder.setContentText(
                if (notice.bytesPerSecond > 0) {
                    val speed = String.format(Locale.getDefault(), "%.1f", notice.bytesPerSecond / BYTES_PER_MEGABYTE)
                    getString(R.string.download_notif_progress_speed, percent, speed)
                } else {
                    getString(R.string.download_notif_progress, percent)
                },
            )
            builder.setProgress(100, percent, false)
        }
        return builder.build()
    }

    private fun buildFinished(versionId: String, ok: Boolean): Notification =
        baseBuilder()
            .setSmallIcon(if (ok) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setContentTitle(getString(if (ok) R.string.download_notif_done else R.string.download_notif_failed, versionId))
            .setContentText(getString(if (ok) R.string.download_notif_done_text else R.string.download_notif_failed_text))
            .setOngoing(false)
            .setAutoCancel(true)
            .build()

    private fun baseBuilder(): NotificationCompat.Builder =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentIntent(openLauncherIntent())
            .setOnlyAlertOnce(true)
            .setSilent(true)

    private fun openLauncherIntent(): PendingIntent = PendingIntent.getActivity(
        this,
        0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun cancelIntent(): PendingIntent = PendingIntent.getService(
        this,
        1,
        Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun ensureChannel() {
        val channel = NotificationChannel(CHANNEL_ID, getString(R.string.download_notif_channel), NotificationManager.IMPORTANCE_LOW)
        manager.createNotificationChannel(channel) // повторный вызов безопасен
    }

    private fun startForegroundCompat(notification: Notification) {
        // Тип службы обязателен с Android 14: установка — это передача данных (dataSync).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(FOREGROUND_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(FOREGROUND_ID, notification)
        }
    }

    @Suppress("DEPRECATION") // STOP_FOREGROUND_REMOVE есть только с API 24, а старый вариант с Boolean — на всех
    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
    }

    // ---------------------------------------------------------------- не засыпать, пока качаем

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        try {
            val power = getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
            wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MCLauncher:download").apply {
                setReferenceCounted(false)
                acquire(WAKE_LOCK_TIMEOUT_MS) // с запасом: служба сама отпустит замок, а этот срок — страховка
            }
        } catch (e: SecurityException) {
            // Разрешения нет или его отозвали — загрузка идёт и без замка.
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.takeIf { it.isHeld }?.release()
        } catch (e: RuntimeException) {
            // Замок уже отпущен по таймауту.
        }
        wakeLock = null
    }

    companion object {
        private const val ACTION_CANCEL = "com.mclauncher.app.download.CANCEL"
        private const val CHANNEL_ID = "version_download"
        private const val FOREGROUND_ID = 7201
        private const val FINISHED_ID = 7202
        private const val BYTES_PER_MEGABYTE = 1024.0 * 1024.0
        private const val WAKE_LOCK_TIMEOUT_MS = 3L * 60L * 60L * 1000L

        /** Запускает службу. Если система не разрешает (фон, ограничения), ничего не делает: установка идёт и так. */
        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, DownloadService::class.java))
            } catch (e: IllegalStateException) {
                // ForegroundServiceStartNotAllowedException (Android 12+) — подкласс IllegalStateException.
            } catch (e: SecurityException) {
                // Нет разрешения на службу переднего плана.
            }
        }

        /**
         * Следит за установкой: когда она начинается, запускает службу. Вызывать один раз при старте процесса лаунчера
         * (в процессе игры не нужно).
         */
        fun watch(context: Context, state: StateFlow<InstallState>, scope: CoroutineScope) {
            val appContext = context.applicationContext
            scope.launch {
                state.map { InstallNotice.of(it).keepsServiceAlive }.distinctUntilChanged().collect { running ->
                    if (running) start(appContext)
                }
            }
        }
    }
}
