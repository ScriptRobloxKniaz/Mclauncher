package com.mclauncher.app.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Иконки, которых нет в material-icons-core. Нарисованы вручную,
 * чтобы не тащить тяжёлый material-icons-extended.
 */
object LauncherIcons {

    /** Четырёхлучевая «искра» — значок ИИ-помощника. */
    val Sparkle: ImageVector by lazy {
        ImageVector.Builder(
            name = "Sparkle",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f)
                lineTo(14.4f, 9.6f)
                lineTo(22f, 12f)
                lineTo(14.4f, 14.4f)
                lineTo(12f, 22f)
                lineTo(9.6f, 14.4f)
                lineTo(2f, 12f)
                lineTo(9.6f, 9.6f)
                close()
            }
        }.build()
    }

    /** Рамка с горами — «выбрать картинку/фон». */
    val Image: ImageVector by lazy {
        ImageVector.Builder(
            name = "Image",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            // Рамка: внешний прямоугольник минус внутренний (even-odd).
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
                moveTo(3f, 4f)
                lineTo(21f, 4f)
                lineTo(21f, 20f)
                lineTo(3f, 20f)
                close()
                moveTo(5f, 6f)
                lineTo(5f, 18f)
                lineTo(19f, 18f)
                lineTo(19f, 6f)
                close()
            }
            // Горы
            path(fill = SolidColor(Color.Black)) {
                moveTo(6.5f, 16.5f)
                lineTo(10f, 11f)
                lineTo(12.8f, 14.6f)
                lineTo(14.8f, 12.2f)
                lineTo(17.5f, 16.5f)
                close()
            }
        }.build()
    }

    /** Три строки с маркерами — список версий игры. */
    val Versions: ImageVector by lazy {
        ImageVector.Builder(
            name = "Versions",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(fill = SolidColor(Color.Black)) {
                for (top in listOf(4f, 10f, 16f)) {
                    // маркер
                    moveTo(3f, top)
                    lineTo(7f, top)
                    lineTo(7f, top + 4f)
                    lineTo(3f, top + 4f)
                    close()
                    // строка
                    moveTo(9f, top)
                    lineTo(21f, top)
                    lineTo(21f, top + 4f)
                    lineTo(9f, top + 4f)
                    close()
                }
            }
        }.build()
    }

    /** Блок (изометрический куб) — значок версии игры. Три грани разной яркости дают объём. */
    val Cube: ImageVector by lazy {
        ImageVector.Builder(
            name = "Cube",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            // верхняя грань
            path(fill = SolidColor(Color.Black), fillAlpha = 1f) {
                moveTo(12f, 2f); lineTo(21f, 7f); lineTo(12f, 12f); lineTo(3f, 7f); close()
            }
            // левая грань
            path(fill = SolidColor(Color.Black), fillAlpha = 0.62f) {
                moveTo(3f, 7f); lineTo(12f, 12f); lineTo(12f, 22f); lineTo(3f, 17f); close()
            }
            // правая грань
            path(fill = SolidColor(Color.Black), fillAlpha = 0.8f) {
                moveTo(12f, 12f); lineTo(21f, 7f); lineTo(21f, 17f); lineTo(12f, 22f); close()
            }
        }.build()
    }

    /** Рамка с треугольником «играть» — видео. */
    val Video: ImageVector by lazy {
        ImageVector.Builder(
            name = "Video",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            // Рамка: внешний прямоугольник минус внутренний (even-odd).
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
                moveTo(3f, 5f); lineTo(21f, 5f); lineTo(21f, 19f); lineTo(3f, 19f); close()
                moveTo(5f, 7f); lineTo(5f, 17f); lineTo(19f, 17f); lineTo(19f, 7f); close()
            }
            path(fill = SolidColor(Color.Black)) {
                moveTo(10f, 9f); lineTo(15.5f, 12f); lineTo(10f, 15f); close()
            }
        }.build()
    }

    /** Динамик с двумя дугами — звук включён. */
    val VolumeOn: ImageVector by lazy {
        ImageVector.Builder(
            name = "VolumeOn",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 9f); lineTo(7f, 9f); lineTo(12f, 4f); lineTo(12f, 20f); lineTo(7f, 15f); lineTo(3f, 15f); close()
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
            ) {
                moveTo(15.5f, 9f); quadTo(17.5f, 12f, 15.5f, 15f)
                moveTo(18.2f, 6.5f); quadTo(22.2f, 12f, 18.2f, 17.5f)
            }
        }.build()
    }

    /** Динамик с крестиком — звук выключен. */
    val VolumeOff: ImageVector by lazy {
        ImageVector.Builder(
            name = "VolumeOff",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 9f); lineTo(7f, 9f); lineTo(12f, 4f); lineTo(12f, 20f); lineTo(7f, 15f); lineTo(3f, 15f); close()
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
            ) {
                moveTo(16f, 9.5f); lineTo(21f, 14.5f)
                moveTo(21f, 9.5f); lineTo(16f, 14.5f)
            }
        }.build()
    }

    // --- Значки интерфейса «фиолетовый неон»: боковое меню, карточки главного экрана ---

    /** Штриховая линия для значков: скруглённые концы и углы. */
    private fun ImageVector.Builder.line(width: Float = 2f, block: PathBuilder.() -> Unit) {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = width,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
            pathBuilder = block,
        )
    }

    private fun icon(name: String, block: ImageVector.Builder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply(block).build()

    /** Стрелка вправо «>» — переход, подробнее. */
    val ChevronRight: ImageVector by lazy {
        icon("ChevronRight") {
            line(2.4f) { moveTo(9f, 5f); lineTo(16f, 12f); lineTo(9f, 19f) }
        }
    }

    /** Стрелка вниз — выпадающий список. */
    val ChevronDown: ImageVector by lazy {
        icon("ChevronDown") {
            line(2.4f) { moveTo(5f, 9f); lineTo(12f, 16f); lineTo(19f, 9f) }
        }
    }

    /** Блок с двумя выступами — «Моды». */
    val Puzzle: ImageVector by lazy {
        icon("Puzzle") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 7f); lineTo(8f, 7f); lineTo(8f, 3f); lineTo(12f, 3f); lineTo(12f, 7f)
                lineTo(17f, 7f); lineTo(17f, 12f); lineTo(21f, 12f); lineTo(21f, 16f); lineTo(17f, 16f)
                lineTo(17f, 21f); lineTo(3f, 21f); close()
            }
        }
    }

    /** Три листа друг на друге — «Ресурспаки». */
    val Layers: ImageVector by lazy {
        icon("Layers") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 3f); lineTo(21f, 8f); lineTo(12f, 13f); lineTo(3f, 8f); close()
            }
            line { moveTo(3f, 12.5f); lineTo(12f, 17.5f); lineTo(21f, 12.5f) }
            line { moveTo(3f, 16.5f); lineTo(12f, 21.5f); lineTo(21f, 16.5f) }
        }
    }

    /** Солнце с лучами — «Шейдеры». */
    val Sun: ImageVector by lazy {
        icon("Sun") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 8f); lineTo(14.83f, 9.17f); lineTo(16f, 12f); lineTo(14.83f, 14.83f)
                lineTo(12f, 16f); lineTo(9.17f, 14.83f); lineTo(8f, 12f); lineTo(9.17f, 9.17f); close()
            }
            line {
                moveTo(18.5f, 12f); lineTo(21f, 12f)
                moveTo(16.6f, 7.4f); lineTo(18.4f, 5.6f)
                moveTo(12f, 5.5f); lineTo(12f, 3f)
                moveTo(7.4f, 7.4f); lineTo(5.6f, 5.6f)
                moveTo(5.5f, 12f); lineTo(3f, 12f)
                moveTo(7.4f, 16.6f); lineTo(5.6f, 18.4f)
                moveTo(12f, 18.5f); lineTo(12f, 21f)
                moveTo(16.6f, 16.6f); lineTo(18.4f, 18.4f)
            }
        }
    }

    /** Корона. */
    val Crown: ImageVector by lazy {
        icon("Crown") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 17f); lineTo(3f, 7f); lineTo(8.5f, 11.5f); lineTo(12f, 4f); lineTo(15.5f, 11.5f)
                lineTo(21f, 7f); lineTo(21f, 17f); close()
            }
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 19f); lineTo(21f, 19f); lineTo(21f, 21.5f); lineTo(3f, 21.5f); close()
            }
        }
    }

    /** Огранённый камень — метка «Premium». */
    val Gem: ImageVector by lazy {
        icon("Gem") {
            line(1.8f) {
                moveTo(7f, 3f); lineTo(17f, 3f); lineTo(22f, 9f); lineTo(12f, 21f); lineTo(2f, 9f); close()
                moveTo(2f, 9f); lineTo(22f, 9f)
                moveTo(9f, 9f); lineTo(12f, 21f)
                moveTo(15f, 9f); lineTo(12f, 21f)
                moveTo(7f, 3f); lineTo(9f, 9f)
                moveTo(17f, 3f); lineTo(15f, 9f)
            }
        }
    }

    /** Облачко сообщения — «Открыть чат». */
    val Chat: ImageVector by lazy {
        icon("Chat") {
            line {
                moveTo(4f, 5f); lineTo(20f, 5f); lineTo(20f, 16f); lineTo(11f, 16f); lineTo(7f, 20f)
                lineTo(7f, 16f); lineTo(4f, 16f); close()
            }
        }
    }

    /** Стрелка вниз над лотком — «Скачать», «Установить». */
    val Download: ImageVector by lazy {
        icon("Download") {
            line {
                moveTo(12f, 4f); lineTo(12f, 15f)
                moveTo(7f, 11f); lineTo(12f, 16f); lineTo(17f, 11f)
                moveTo(5f, 20f); lineTo(19f, 20f)
            }
        }
    }
}
