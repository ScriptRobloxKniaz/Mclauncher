package com.mclauncher.app.game

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.os.SystemClock
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.mclauncher.app.R
import com.mclauncher.engine.launch.GameExitReport
import com.mclauncher.engine.launch.GameRunner
import com.mclauncher.engine.launch.NativeLaunchPlan
import com.movtery.zalithlauncher.bridge.ZLBridge
import com.movtery.zalithlauncher.bridge.ZLNativeInvoker
import org.lwjgl.glfw.CallbackBridge
import java.io.File

/**
 * Экран игры. Работает в отдельном процессе `:game` (см. манифест): JVM игры живёт в нём и вместе с ним завершается,
 * а лаунчер остаётся целым и после вылета игры показывает его причину ([GameExitReport]).
 *
 * Последовательность: лаунчер кладёт [NativeLaunchPlan] в Intent → здесь создаётся `TextureView` → когда его
 * поверхность готова, в фоновом потоке запускается `GameRunner` → JVM рисует в эту поверхность через `libpojavexec`.
 * Поверхность может пересоздаваться (свернули и вернулись): тогда окну игры отдаётся новая, а JVM продолжает работать.
 *
 * Управление пока самое грубое — только чтобы проверить, что игра рисует и реагирует (полноценные сенсорные
 * элементы управления — этап 4.7c): палец — это мышь (в меню — щелчок, в мире — поворот камеры), а двойное «Назад»
 * закрывает игру. Всё, что здесь написано, проверено только чтением кода: на устройстве экран ещё не запускался.
 */
class GameActivity : ComponentActivity(), TextureView.SurfaceTextureListener, ZLNativeInvoker.Host {

    private var plan: NativeLaunchPlan? = null
    private var textureView: TextureView? = null
    private var surface: Surface? = null

    /** JVM уже запущена в этом процессе. Вторую в нём создать нельзя, поэтому запуск делается ровно один раз. */
    private var gameThreadStarted = false

    /** Игра начала выводить кадры: до этого касания ей не отправляем. */
    @Volatile
    private var rendering = false

    private var lastBackMillis = 0L

    // Касание → мышь
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var touchClicking = false

    @Suppress("DEPRECATION") // типизированный getSerializableExtra есть только с API 33, а minSdk 26
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val received = intent?.getSerializableExtra(EXTRA_PLAN) as? NativeLaunchPlan
        if (received == null) {
            // Экран открыли без плана (например, система восстановила его после смерти процесса): играть нечем.
            finish()
            return
        }
        plan = received
        // Метка «игра запущена» — до всего остального: если процесс упадёт раньше, чем дойдёт до JVM, лаунчер всё равно
        // узнает об этом и покажет диалог (иначе вылет в самом начале не оставлял бы никакого следа).
        try {
            GameExitReport.markSessionStarted(File(received.reportDir), System.currentTimeMillis())
            GameExitReport.noteStage(File(received.reportDir), "game screen created")
        } catch (e: Exception) {
            // Не получилось записать — не повод не запускать игру.
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.BLACK))
        enterImmersiveMode()

        val view = TextureView(this).apply {
            isOpaque = true
            surfaceTextureListener = this@GameActivity
            setOnTouchListener { v, event -> handleTouch(v, event) }
        }
        textureView = view
        setContentView(
            FrameLayout(this).apply {
                setBackgroundColor(Color.BLACK)
                addView(view, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            },
        )

        // Без сенсорных элементов управления у игрока нет другого способа выйти, кроме двойного «Назад».
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastBackMillis <= BACK_CONFIRM_MS) {
                        closeByPlayer()
                    } else {
                        lastBackMillis = now
                        Toast.makeText(this@GameActivity, R.string.game_back_again, Toast.LENGTH_SHORT).show()
                    }
                }
            },
        )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    private fun enterImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ---------------------------------------------------------------- поверхность

    override fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int) {
        val current = plan ?: return
        // Буфер всегда размера окна игры, а не размера вида: игра рисует в нём, а система масштабирует на экран.
        texture.setDefaultBufferSize(current.windowWidth, current.windowHeight)
        val newSurface = Surface(texture)
        surface = newSurface

        if (gameThreadStarted) {
            // Поверхность пересоздана, JVM продолжает работать: отдаём окну игры новую.
            ZLBridge.setupBridgeWindow(newSurface)
            CallbackBridge.sendUpdateWindowSize(current.windowWidth, current.windowHeight)
            return
        }
        gameThreadStarted = true
        val appContext = applicationContext
        Thread({ runGame(appContext, current, newSurface) }, "MCLauncher-game").start()
    }

    override fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int) {
        val current = plan ?: return
        texture.setDefaultBufferSize(current.windowWidth, current.windowHeight)
    }

    override fun onSurfaceTextureDestroyed(texture: SurfaceTexture): Boolean {
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(texture: SurfaceTexture) = Unit

    /** Поток игры. Блокируется до выхода JVM, а обычно и не возвращается: процесс завершает нативный код. */
    private fun runGame(appContext: Context, current: NativeLaunchPlan, gameSurface: Surface) {
        GameRunner.run(appContext, current, this, gameSurface) { rendering = true }
        // Сюда попадаем, только если JVM не запустилась или вернула управление сама. Отчёт уже записан.
        runOnUiThread { finishAndEndProcess() }
    }

    // ---------------------------------------------------------------- касания → мышь

    private fun handleTouch(view: View, event: MotionEvent): Boolean {
        val current = plan ?: return false
        if (!rendering || view.width <= 0 || view.height <= 0) return true
        val x = event.x * current.windowWidth / view.width
        val y = event.y * current.windowHeight / view.height
        val grabbing = CallbackBridge.isGrabbing()
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = x
                lastTouchY = y
                if (!grabbing) {
                    CallbackBridge.sendCursorPos(x, y)
                    CallbackBridge.sendMouseButton(CallbackBridge.GLFW_MOUSE_BUTTON_LEFT, true)
                    touchClicking = true
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (grabbing) {
                    // Мышь захвачена игрой: палец двигает камеру, значит, нужен сдвиг, а не положение.
                    CallbackBridge.sendCursorPos(CallbackBridge.mouseX + (x - lastTouchX), CallbackBridge.mouseY + (y - lastTouchY))
                } else {
                    CallbackBridge.sendCursorPos(x, y)
                }
                lastTouchX = x
                lastTouchY = y
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (touchClicking) {
                    CallbackBridge.sendCursorPos(x, y)
                    CallbackBridge.sendMouseButton(CallbackBridge.GLFW_MOUSE_BUTTON_LEFT, false)
                    touchClicking = false
                }
            }
        }
        return true
    }

    // ---------------------------------------------------------------- выход

    /** Игрок закрыл игру сам: пишем нормальный итог, чтобы лаунчер не принял это за вылет. */
    private fun closeByPlayer() {
        plan?.let { current ->
            GameRunner.recordExit(
                File(current.reportDir),
                GameExitReport(exitCode = 0, isSignal = false, message = "Closed by the player", logFile = current.logFile, timeMillis = System.currentTimeMillis()),
            )
        }
        finishAndEndProcess()
    }

    private fun finishAndEndProcess() {
        finish()
        // JVM нельзя создать заново в том же процессе, поэтому процесс игры не оставляем: следующий запуск получит чистый.
        Process.killProcess(Process.myPid())
    }

    override fun onDestroy() {
        super.onDestroy()
        // Экран игры закрыт (в том числе системой): без него игре некуда рисовать. Итог — либо уже записанный
        // нормальный, либо его нет, и тогда лаунчер сообщит о вылете.
        if (plan != null) Process.killProcess(Process.myPid())
    }

    // ---------------------------------------------------------------- ZLNativeInvoker.Host (вызывается из нативного кода)

    override fun onJvmExit(exitCode: Int, isSignal: Boolean) {
        // После возврата отсюда нативный код вызывает System.exit(0): всё нужное записываем сейчас и синхронно.
        val current = plan ?: return
        GameRunner.recordExit(
            File(current.reportDir),
            GameExitReport(exitCode, isSignal, logFile = current.logFile, timeMillis = System.currentTimeMillis()),
        )
    }

    override fun openLink(link: String?) {
        val uri = link?.let { runCatching { Uri.parse(it) }.getOrNull() } ?: return
        // Игра присылает ссылки из чата и меню: открываем только веб-адреса, чтобы файлы и intent: не уходили в систему.
        if (uri.scheme != "http" && uri.scheme != "https") return
        runOnUiThread {
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    override fun querySystemClipboard() {
        val text = readClipboardText() ?: return
        ZLBridge.clipboardReceived(text, "plain")
    }

    override fun putClipboardData(data: String?, mimeType: String?) {
        if (data != null) writeClipboardText(data)
    }

    override fun accessClipboard(type: Int, text: String?): String? = when (type) {
        CallbackBridge.CLIPBOARD_COPY -> {
            writeClipboardText(text ?: "")
            null
        }

        CallbackBridge.CLIPBOARD_PASTE -> readClipboardText().orEmpty()
        else -> null
    }

    private fun clipboard(): ClipboardManager? = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager

    private fun readClipboardText(): String? = runCatching {
        val clip = clipboard()?.primaryClip
        if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this)?.toString() else null
    }.getOrNull()

    private fun writeClipboardText(text: String) {
        runCatching { clipboard()?.setPrimaryClip(ClipData.newPlainText("Minecraft", text)) }
    }

    companion object {
        const val EXTRA_PLAN = "com.mclauncher.app.game.PLAN"

        /** Двойное «Назад» в пределах этого времени закрывает игру. */
        private const val BACK_CONFIRM_MS = 2_000L

        fun intent(context: Context, plan: NativeLaunchPlan): Intent =
            Intent(context, GameActivity::class.java)
                .putExtra(EXTRA_PLAN, plan)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
