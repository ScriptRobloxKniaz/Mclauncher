package com.mclauncher.app.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mclauncher.app.LauncherApp
import com.mclauncher.app.core.CoreUiState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

/** Состояние раздела «Игровое ядро»: сама установка идёт в WorkManager, ViewModel только показывает и запускает. */
class CoreViewModel(application: Application) : AndroidViewModel(application) {

    private val manager = (application as LauncherApp).coreManager

    val state: StateFlow<CoreUiState> = manager.state.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = CoreUiState(),
    )

    fun install() = manager.start()

    fun cancel() = manager.cancel()

    /** Перечитать диск: например, если пользователь вернулся на экран. */
    fun refresh() = manager.refresh()
}
