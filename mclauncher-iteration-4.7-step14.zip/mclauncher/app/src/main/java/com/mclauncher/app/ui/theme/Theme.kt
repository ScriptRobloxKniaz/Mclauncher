package com.mclauncher.app.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

/**
 * Цвета, которых нет в схеме Material: градиенты кнопок, «стекло» карточек и свечение. Остальное берётся из
 * [MaterialTheme]. Палитра — фиолетово-синий неон: почти чёрный фиолетовый фон, полупрозрачные карточки с тонкой
 * светлой рамкой и яркий фиолетово-синий акцент.
 *
 * Кисти ([gradient], [glassFill] и другие) созданы один раз: они неизменяемы, и их можно безопасно использовать
 * в любом месте без пересоздания при каждой перерисовке.
 */
object NeonColors {
    /** Начало и конец градиента главной кнопки и выбранного пункта меню. */
    val GradientStart = Color(0xFF8B5CFF)
    val GradientEnd = Color(0xFF5B5CF0)

    /** Градиент нажатой кнопки: темнее. */
    val PressedStart = Color(0xFF6A3FDB)
    val PressedEnd = Color(0xFF4545C6)

    /** Свечение вокруг главных кнопок и подсветка выбранных элементов. */
    val Glow = Color(0xFF8B5CFF)

    /** Заливка и содержимое недоступной кнопки. */
    val DisabledFill = Color(0xFF1B1636)
    val DisabledContent = Color(0xFF675F8F)

    /** Текст и значки на градиенте. */
    val OnGradient = Color.White

    /** Акцент для надписи «Beta» и мелких меток. */
    val Accent = Color(0xFFB79CFF)

    /** Положительная метка («Выбрана», «В сети»). */
    val Success = Color(0xFF5BE49B)
    val SuccessContainer = Color(0x3322C55E)

    /** Корона и «премиальные» детали. */
    val Gold = Color(0xFFFFC857)

    // «Стекло»: полупрозрачная тёмно-фиолетовая заливка, светлая тонкая рамка сверху и почти невидимая снизу.
    private val GlassTop = Color(0xCC1B1442)
    private val GlassBottom = Color(0xB30E0A26)
    private val GlassSelectedTop = Color(0xE62B1F66)
    private val GlassSelectedBottom = Color(0xD9161040)
    private val GlassBorderTop = Color(0x668F7BFF)
    private val GlassBorderBottom = Color(0x2A5F55C0)
    private val HighlightTop = Color(0xD94B30B8)
    private val HighlightBottom = Color(0xCC1D1558)
    private val HighlightBorderTop = Color(0xCCA58BFF)
    private val HighlightBorderBottom = Color(0x665B52D0)

    val gradient: Brush = Brush.horizontalGradient(listOf(GradientStart, GradientEnd))
    val pressedGradient: Brush = Brush.horizontalGradient(listOf(PressedStart, PressedEnd))

    val glassFill: Brush = Brush.verticalGradient(listOf(GlassTop, GlassBottom))
    val glassSelectedFill: Brush = Brush.verticalGradient(listOf(GlassSelectedTop, GlassSelectedBottom))
    val glassBorder: Brush = Brush.verticalGradient(listOf(GlassBorderTop, GlassBorderBottom))
    val glassSelectedBorder: Brush = Brush.verticalGradient(listOf(GradientStart, GradientEnd))

    /** Яркая фиолетовая карточка («ИИ-помощник», «Premium»). */
    val highlightFill: Brush = Brush.linearGradient(listOf(HighlightTop, HighlightBottom))
    val highlightBorder: Brush = Brush.verticalGradient(listOf(HighlightBorderTop, HighlightBorderBottom))

    /** Заливка выбранного пункта бокового меню. */
    val sidebarSelected: Brush = Brush.horizontalGradient(listOf(Color(0xFF7248F0), Color(0xFF4E4AE2)))
}

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9171FF),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFF4B33C9),
    onPrimaryContainer = Color(0xFFE8E2FF),
    inversePrimary = Color(0xFF5B3FE0),
    secondary = Color(0xFF7C9BFF),
    onSecondary = Color(0xFF0A1740),
    secondaryContainer = Color(0xFF1D2560),
    onSecondaryContainer = Color(0xFFDCE4FF),
    tertiary = Color(0xFFC4A3FF),
    onTertiary = Color(0xFF2A0E5A),
    tertiaryContainer = Color(0xFF3A2780),
    onTertiaryContainer = Color(0xFFEBE0FF),
    background = Color(0xFF07050F),
    onBackground = Color(0xFFECE8FF),
    surface = Color(0xFF0D0A1F),
    onSurface = Color(0xFFECE8FF),
    surfaceVariant = Color(0xFF1A1438),
    onSurfaceVariant = Color(0xFFB1A8DC),
    surfaceTint = Color(0xFF9171FF),
    inverseSurface = Color(0xFFECE8FF),
    inverseOnSurface = Color(0xFF0D0A1F),
    error = Color(0xFFFF5468),
    onError = Color(0xFF3B0008),
    errorContainer = Color(0xFF5A1020),
    onErrorContainer = Color(0xFFFFD9DE),
    outline = Color(0xFF4B4182),
    outlineVariant = Color(0xFF2B2358),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFF2A2058),
    surfaceDim = Color(0xFF07050F),
    surfaceContainerLowest = Color(0xFF07050F),
    surfaceContainerLow = Color(0xFF0D0A1F),
    surfaceContainer = Color(0xFF120E2A),
    surfaceContainerHigh = Color(0xFF191338),
    surfaceContainerHighest = Color(0xFF221A4A),
)

// Светлая схема пока не используется (тема всегда тёмная, см. MainActivity); она тоже фиолетовая, чтобы не осталось
// чужих цветов, когда выбор темы появится в настройках (итерация 8).
private val LightColors = lightColorScheme(
    primary = Color(0xFF5B3FE0),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE5DEFF),
    onPrimaryContainer = Color(0xFF1B0A5C),
    secondary = Color(0xFF55509A),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE4DFFF),
    onSecondaryContainer = Color(0xFF14104A),
    tertiary = Color(0xFF7B46D6),
    background = Color(0xFFF8F6FF),
    onBackground = Color(0xFF120E2E),
    surface = Color(0xFFF8F6FF),
    onSurface = Color(0xFF120E2E),
    surfaceVariant = Color(0xFFE6E1F7),
    onSurfaceVariant = Color(0xFF494368),
)

@Composable
fun MCLauncherTheme(
    // Пока всегда тёмная (см. MainActivity).
    darkTheme: Boolean = true,
    // По умолчанию выключено, чтобы сохранить собственную палитру лаунчера.
    // Позже можно вынести в настройки.
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content,
    )
}
