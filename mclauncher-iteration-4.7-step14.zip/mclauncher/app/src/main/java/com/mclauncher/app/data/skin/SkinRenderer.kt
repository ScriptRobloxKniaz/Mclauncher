package com.mclauncher.app.data.skin

import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Ракурс, с которого виден персонаж. [yaw] — поворот вокруг вертикали в градусах (0 — лицом к зрителю, положительный —
 * лицо уходит вправо), [pitch] — наклон: положительный — смотрим сверху, отрицательный — снизу, ±90 — строго
 * сверху/снизу. Чистые данные: сохраняются и меняются без Android.
 */
data class ViewAngles(val yaw: Float = DEFAULT_YAW, val pitch: Float = DEFAULT_PITCH) {

    /** Поворот на [dxPx] и [dyPx] пикселей перетаскивания; тангаж ограничен ±90°, рыскание остаётся в (−180; 180]. */
    fun rotatedBy(dxPx: Float, dyPx: Float): ViewAngles {
        var newYaw = (yaw + dxPx * DEGREES_PER_PIXEL) % 360f
        if (newYaw > 180f) newYaw -= 360f
        if (newYaw <= -180f) newYaw += 360f
        return ViewAngles(newYaw, (pitch + dyPx * DEGREES_PER_PIXEL).coerceIn(-MAX_PITCH, MAX_PITCH))
    }

    companion object {
        /** Начальный ракурс: чуть повёрнут и чуть сверху, чтобы с первого взгляда было видно, что это объём. */
        const val DEFAULT_YAW = 28f
        const val DEFAULT_PITCH = 10f
        const val MAX_PITCH = 90f
        const val DEGREES_PER_PIXEL = 0.5f

        /** Строго спереди, на уровне глаз. */
        val FRONT = ViewAngles(yaw = 0f, pitch = 0f)

        /** Строго сзади (поворот на 180°, не на −180°: так остаётся в диапазоне (−180; 180]). */
        val BACK = ViewAngles(yaw = 180f, pitch = 0f)
    }
}

/**
 * Размер кадра 3D-превью. Программный рисовальщик считает каждый пиксель сам, поэтому кадр рисуется не в полный размер
 * окна, а уменьшенным так, чтобы длинная сторона не превышала [MAX_SIDE]; на экран он растягивается. Это держит
 * перетаскивание плавным даже на слабых телефонах.
 */
object SkinFrame {
    const val MAX_SIDE = 400

    /** Размер кадра для окна [width]×[height] пикселей: пропорции сохраняются, стороны не меньше 1. */
    fun fit(width: Int, height: Int, maxSide: Int = MAX_SIDE): Pair<Int, Int> {
        require(maxSide > 0) { "maxSide must be positive: $maxSide" }
        val w = width.coerceAtLeast(1)
        val h = height.coerceAtLeast(1)
        val longest = max(w, h)
        if (longest <= maxSide) return w to h
        // Целочисленно, без дробных: результат не зависит от округления float.
        return (w.toLong() * maxSide / longest).toInt().coerceAtLeast(1) to
            (h.toLong() * maxSide / longest).toInt().coerceAtLeast(1)
    }
}

/**
 * Камера: персонаж поворачивается вокруг своей середины (y = 16), камера смотрит на него с расстояния [DISTANCE].
 * Масштаб подбирается так, чтобы персонаж целиком помещался в окно [width]×[height] с небольшим запасом.
 */
class SkinCamera(val width: Int, val height: Int, yawDeg: Float, pitchDeg: Float) {
    private val cosYaw = cos(Math.toRadians(yawDeg.toDouble())).toFloat()
    private val sinYaw = sin(Math.toRadians(yawDeg.toDouble())).toFloat()
    private val cosPitch = cos(Math.toRadians(pitchDeg.toDouble())).toFloat()
    private val sinPitch = sin(Math.toRadians(pitchDeg.toDouble())).toFloat()

    private val centerX = width / 2f
    private val centerY = height / 2f

    /** Фокусное расстояние в экранных пикселях: на глубине [DISTANCE] одна единица модели занимает `focal / DISTANCE` пикселей. */
    private val focal: Float = FILL * min(height / FIT_HEIGHT, width / FIT_WIDTH) * DISTANCE

    /**
     * Переводит точку модели в систему камеры: `out[0]` — вправо, `out[1]` — вверх, `out[2]` — к зрителю
     * (камера стоит в точке z = [DISTANCE]).
     */
    fun toCamera(x: Float, y: Float, z: Float, out: FloatArray) {
        val ry = y - CENTER_Y
        val x1 = x * cosYaw + z * sinYaw
        val z1 = -x * sinYaw + z * cosYaw
        out[0] = x1
        out[1] = ry * cosPitch - z1 * sinPitch
        out[2] = ry * sinPitch + z1 * cosPitch
    }

    /** То же для направления (нормали): без сдвига к центру. */
    fun rotateDirection(x: Float, y: Float, z: Float, out: FloatArray) {
        val x1 = x * cosYaw + z * sinYaw
        val z1 = -x * sinYaw + z * cosYaw
        out[0] = x1
        out[1] = y * cosPitch - z1 * sinPitch
        out[2] = y * sinPitch + z1 * cosPitch
    }

    /** Экранный x точки в системе камеры; [depth] = расстояние до камеры вдоль её взгляда. */
    fun screenX(camX: Float, depth: Float): Float = centerX + focal * camX / depth

    fun screenY(camY: Float, depth: Float): Float = centerY - focal * camY / depth

    /** Экранная точка для точки модели — для тестов и подсказок. Возвращает (x, y) в пикселях окна. */
    fun project(x: Float, y: Float, z: Float): Pair<Float, Float> {
        val c = FloatArray(3)
        toCamera(x, y, z, c)
        val depth = DISTANCE - c[2]
        return screenX(c[0], depth) to screenY(c[1], depth)
    }

    companion object {
        const val CENTER_Y = 16f
        const val DISTANCE = 75f

        /** Размеры, которые должны поместиться: рост 32 и ширина с руками 16, плюс поля. */
        private const val FIT_HEIGHT = 34f
        private const val FIT_WIDTH = 22f

        /**
         * Доля окна, которую занимает персонаж в «лицевом» положении. Не 1: при повороте ближние части становятся крупнее
         * из-за перспективы, и без запаса голова или ноги упирались бы в край (проверяет тест на всех ракурсах).
         */
        private const val FILL = 0.86f
    }
}

/**
 * Программный рисовальщик 3D-модели игрока: перспектива, буфер глубины, перспективно-верная выборка текстуры
 * «ближайшим соседом» (пиксели скина остаются чёткими), отсечение обращённых назад граней, простое освещение.
 * Работает на обычных массивах, без Android и без графического процессора: поэтому его можно проверить JVM-тестами,
 * а на телефоне он рисует кадр за единицы миллисекунд и запускается только когда ракурс меняется.
 */
object SkinRenderer {

    /** Свет падает сверху-справа-спереди (в системе камеры); [AMBIENT] — доля света в тени. */
    private const val LIGHT_X = 0.35f
    private const val LIGHT_Y = 0.65f
    private const val LIGHT_Z = 0.68f
    private const val AMBIENT = 0.62f

    /** Пиксели второго слоя прозрачнее этого порога не рисуются совсем. */
    private const val MIN_OVERLAY_ALPHA = 8

    /** Допуск при проверке «пиксель внутри треугольника»: закрывает щели на рёбрах между гранями. */
    private const val EDGE_EPSILON = -0.001f

    /**
     * Рисует персонажа в массив [width]×[height] (ARGB по строкам; вне фигуры — полностью прозрачный пиксель).
     * [shaded] = false отключает освещение — цвета пикселей тогда в точности равны цветам текстуры.
     */
    fun render(
        scene: SkinScene,
        yawDeg: Float,
        pitchDeg: Float,
        width: Int,
        height: Int,
        shaded: Boolean = true,
    ): IntArray {
        require(width > 0 && height > 0) { "Size must be positive: ${width}x$height" }
        val out = IntArray(width * height)
        val depthBuffer = FloatArray(width * height) // хранит 1/глубину: больше — ближе
        val camera = SkinCamera(width, height, yawDeg, pitchDeg.coerceIn(-ViewAngles.MAX_PITCH, ViewAngles.MAX_PITCH))

        val c = FloatArray(3)
        val n = FloatArray(3)
        val sx = FloatArray(4)
        val sy = FloatArray(4)
        val sw = FloatArray(4) // 1 / глубина вершины
        val lightLength = kotlin.math.sqrt(LIGHT_X * LIGHT_X + LIGHT_Y * LIGHT_Y + LIGHT_Z * LIGHT_Z)

        // Сначала первый слой, потом второй: полупрозрачные пиксели второго слоя смешиваются с тем, что под ними.
        for (overlayPass in 0..1) {
            val wantOverlay = overlayPass == 1
            for (quad in scene.quads) {
                if (quad.overlay != wantOverlay) continue

                camera.rotateDirection(quad.nx, quad.ny, quad.nz, n)
                camera.toCamera(quad.px[0], quad.py[0], quad.pz[0], c)
                // Грань видна, если нормаль смотрит в сторону камеры (камера в точке (0, 0, DISTANCE)).
                val facing = n[0] * (0f - c[0]) + n[1] * (0f - c[1]) + n[2] * (SkinCamera.DISTANCE - c[2])
                if (facing <= 0f) continue

                for (i in 0 until 4) {
                    camera.toCamera(quad.px[i], quad.py[i], quad.pz[i], c)
                    val depth = SkinCamera.DISTANCE - c[2]
                    sx[i] = camera.screenX(c[0], depth)
                    sy[i] = camera.screenY(c[1], depth)
                    sw[i] = 1f / depth
                }

                val light = if (shaded) {
                    val lit = max(0f, (n[0] * LIGHT_X + n[1] * LIGHT_Y + n[2] * LIGHT_Z) / lightLength)
                    AMBIENT + (1f - AMBIENT) * lit
                } else {
                    1f
                }

                triangle(scene, quad, 0, 1, 2, sx, sy, sw, light, out, depthBuffer, width, height)
                triangle(scene, quad, 0, 2, 3, sx, sy, sw, light, out, depthBuffer, width, height)
            }
        }
        return out
    }

    private fun triangle(
        scene: SkinScene,
        quad: SkinQuad,
        i0: Int,
        i1: Int,
        i2: Int,
        sx: FloatArray,
        sy: FloatArray,
        sw: FloatArray,
        light: Float,
        out: IntArray,
        depthBuffer: FloatArray,
        width: Int,
        height: Int,
    ) {
        val x0 = sx[i0]; val y0 = sy[i0]
        val x1 = sx[i1]; val y1 = sy[i1]
        val x2 = sx[i2]; val y2 = sy[i2]

        val area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)
        if (area > -1e-6f && area < 1e-6f) return
        val invArea = 1f / area

        val minX = max(0, floor(min(x0, min(x1, x2))).toInt())
        val maxX = min(width - 1, floor(max(x0, max(x1, x2))).toInt())
        val minY = max(0, floor(min(y0, min(y1, y2))).toInt())
        val maxY = min(height - 1, floor(max(y0, max(y1, y2))).toInt())
        if (minX > maxX || minY > maxY) return

        val w0 = sw[i0]; val w1 = sw[i1]; val w2 = sw[i2]
        // Текстурные координаты, умноженные на 1/глубину: их можно линейно интерполировать по экрану.
        val u0 = quad.tu[i0] * w0; val u1 = quad.tu[i1] * w1; val u2 = quad.tu[i2] * w2
        val v0 = quad.tv[i0] * w0; val v1 = quad.tv[i1] * w1; val v2 = quad.tv[i2] * w2

        val face = quad.face
        val texture = scene.texture
        val overlay = quad.overlay

        for (y in minY..maxY) {
            val py = y + 0.5f
            val rowStart = y * width
            for (x in minX..maxX) {
                val px = x + 0.5f
                // Барицентрические координаты точки относительно вершин (не зависят от обхода по/против часовой).
                val b0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) * invArea
                val b1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) * invArea
                val b2 = 1f - b0 - b1
                if (b0 < EDGE_EPSILON || b1 < EDGE_EPSILON || b2 < EDGE_EPSILON) continue

                val w = b0 * w0 + b1 * w1 + b2 * w2
                val index = rowStart + x
                if (w <= depthBuffer[index]) continue

                val u = (b0 * u0 + b1 * u1 + b2 * u2) / w
                val v = (b0 * v0 + b1 * v1 + b2 * v2) / w
                val tx = floor(u).toInt().coerceIn(face.x, face.right - 1)
                val ty = floor(v).toInt().coerceIn(face.y, face.bottom - 1)
                val texel = texture[ty * SkinLayout.TEXTURE_WIDTH + tx]

                val alpha = if (overlay) texel ushr 24 else 255 // первый слой игра рисует непрозрачным
                if (alpha < MIN_OVERLAY_ALPHA) continue

                val r = shade((texel shr 16) and 0xFF, light)
                val g = shade((texel shr 8) and 0xFF, light)
                val b = shade(texel and 0xFF, light)

                val under = out[index]
                out[index] = if (alpha == 255) {
                    depthBuffer[index] = w
                    (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                } else if ((under ushr 24) == 0) {
                    // Под полупрозрачным пикселем пусто: остаётся полупрозрачным.
                    (alpha shl 24) or (r shl 16) or (g shl 8) or b
                } else {
                    val inv = 255 - alpha
                    val mr = (r * alpha + ((under shr 16) and 0xFF) * inv) / 255
                    val mg = (g * alpha + ((under shr 8) and 0xFF) * inv) / 255
                    val mb = (b * alpha + (under and 0xFF) * inv) / 255
                    (0xFF shl 24) or (mr shl 16) or (mg shl 8) or mb
                }
            }
        }
    }

    private fun shade(channel: Int, light: Float): Int = (channel * light + 0.5f).toInt().coerceIn(0, 255)
}
