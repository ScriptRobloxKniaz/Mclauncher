package com.mclauncher.app.launch

import com.mclauncher.app.data.settings.GraphicsSettings
import com.mclauncher.app.data.settings.Renderer
import com.mclauncher.engine.launch.RendererProfile

/** Профиль ядра для рендерера из настроек (какую библиотеку подгружать и с какими переменными окружения). */
fun Renderer.toProfile(): RendererProfile = when (this) {
    Renderer.GL4ES -> RendererProfile.GL4ES
    Renderer.KRYPTON -> RendererProfile.KRYPTON
    Renderer.MOBILEGLUES -> RendererProfile.MOBILEGLUES
    Renderer.ZINK -> RendererProfile.ZINK
}

/**
 * Что из «Графики и рендеров» уходит в запуск. Версия OpenGL ([GraphicsSettings.glVersion]) добавляется только к GL4ES
 * и только если выбрана не «Авто»: остальные рендереры версию задают сами, и лишняя переменная могла бы им помешать.
 */
fun GraphicsSettings.toRendererProfile(): RendererProfile {
    val profile = effectiveRenderer.toProfile()
    val version = glVersion.libglValue
    return if (glVersionApplies && version != null) profile.withEnv("LIBGL_GL" to version) else profile
}
