package com.mclauncher.app.ui.components

import androidx.compose.ui.graphics.ImageBitmap
import com.mclauncher.app.data.settings.BackgroundPreset
import java.io.File

/**
 * Видео, которое играет поверх обычного фона. [stamp] — момент импорта: новое видео пересоздаёт плеер,
 * даже если файл лежит по тому же пути. Громкость сюда не входит: она меняется на лету без перезапуска видео.
 */
data class BackgroundVideo(val file: File, val stamp: Long)

/** То, что реально рисуется на заднем плане (результат разбора [com.mclauncher.app.data.settings.BackgroundSelection]). */
sealed interface BackgroundContent {

    data class Preset(val preset: BackgroundPreset) : BackgroundContent

    /** Загруженная картинка пользователя. Сравнивается по ссылке на bitmap. */
    data class Image(val bitmap: ImageBitmap) : BackgroundContent
}
