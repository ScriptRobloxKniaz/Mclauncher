package com.mclauncher.app.ui.assistant

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.mclauncher.app.R
import com.mclauncher.app.ui.navigation.Destination
import com.mclauncher.app.ui.placeholder.PlaceholderScreen

/**
 * Заглушка ИИ-помощника сборок (Beta). Он открывается из бокового меню, поэтому кнопки «назад» здесь нет.
 * Настоящий чат и подбор модов появятся отдельной итерацией после импорта модов и сборок (итерация 7).
 */
@Composable
fun AssistantScreen(modifier: Modifier = Modifier) {
    PlaceholderScreen(
        destination = Destination.Assistant,
        message = stringResource(R.string.placeholder_assistant),
        modifier = modifier,
    )
}
