package com.mclauncher.app.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.mclauncher.app.R
import com.mclauncher.app.data.versions.InstalledVersion
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.components.NeonSecondaryButton
import com.mclauncher.app.ui.versions.labelRes
import com.mclauncher.app.ui.versions.releaseDate

/**
 * Окно «Выбрать версию»: установленные версии списком, выбранная отмечена галочкой. Список ленивый, и у каждой строки
 * есть ключ (идентификатор версии), поэтому при выборе перерисовывается только затронутая строка.
 */
@Composable
fun VersionPickerDialog(
    installed: List<InstalledVersion>,
    selectedId: String?,
    onSelect: (String) -> Unit,
    onInstallMore: () -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        NeonCard(
            modifier = Modifier
                .widthIn(max = 380.dp)
                .fillMaxWidth(0.9f)
                .heightIn(max = 320.dp),
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = stringResource(R.string.home_choose_version),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                if (installed.isEmpty()) {
                    Text(
                        text = stringResource(R.string.home_no_versions_message),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        items(installed, key = { it.id }, contentType = { PICKER_ROW }) { version ->
                            PickerRow(
                                version = version,
                                selected = version.id == selectedId,
                                onClick = {
                                    onSelect(version.id)
                                    onDismiss()
                                },
                            )
                        }
                    }
                }
                NeonSecondaryButton(
                    text = stringResource(R.string.home_install_version),
                    onClick = {
                        onDismiss()
                        onInstallMore()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    height = 38.dp,
                )
            }
        }
    }
}

private const val PICKER_ROW = "picker-row"

@Composable
private fun PickerRow(
    version: InstalledVersion,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val typeLabel = stringResource(version.type.labelRes)
    // Подпись строки собирается заново только при смене версии, а не при каждой прокрутке списка.
    val subtitle = remember(version.releaseTime, typeLabel) {
        listOfNotNull(typeLabel, releaseDate(version.releaseTime)).joinToString(" · ")
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        VersionBlock(size = 28.dp)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = version.id,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = colors.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (selected) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = stringResource(R.string.versions_selected),
                tint = colors.primary,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}
