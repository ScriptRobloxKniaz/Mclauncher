package com.mclauncher.app.ui.home

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import com.mclauncher.app.R
import com.mclauncher.app.data.versions.VersionLibraryState
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.navigation.Destination

/**
 * Общее действие всех кнопок «Играть» (главная и вкладка «Играть»): сначала проверяет аккаунт и версию
 * ([decidePlay]) и либо запускает игру, либо объясняет, чего не хватает, и ведёт на нужный экран.
 * Аргумент действия — версия, чья кнопка нажата; `null` — выбранная.
 *
 * Возвращаемая функция пересоздаётся только при смене аккаунта или списка версий, а не при каждой перекомпоновке,
 * поэтому карточки, которым её передали, не перерисовываются зря.
 */
@Composable
fun rememberPlayAction(
    activeAccount: ActiveAccountState,
    library: VersionLibraryState?,
    onPlay: (versionId: String?) -> Unit,
    onNavigate: (Destination) -> Unit,
): (String?) -> Unit {
    val context = LocalContext.current
    val currentOnPlay by rememberUpdatedState(onPlay)
    val currentOnNavigate by rememberUpdatedState(onNavigate)
    return remember(activeAccount, library, context) {
        val action: (String?) -> Unit = { versionId ->
            when (decidePlay(activeAccount, library, versionId)) {
                PlayDecision.LAUNCH -> currentOnPlay(versionId)

                PlayDecision.NEED_ACCOUNT -> {
                    Toast.makeText(context, R.string.play_need_account, Toast.LENGTH_SHORT).show()
                    currentOnNavigate(Destination.Accounts)
                }

                PlayDecision.NEED_VERSION -> {
                    Toast.makeText(context, R.string.play_need_version, Toast.LENGTH_SHORT).show()
                    currentOnNavigate(Destination.Versions)
                }

                PlayDecision.PICK_VERSION ->
                    Toast.makeText(context, R.string.play_pick_version, Toast.LENGTH_SHORT).show()

                PlayDecision.WAIT -> Unit
            }
        }
        action
    }
}
