package com.mclauncher.app.game

import android.os.Process
import com.mclauncher.engine.launch.GameExitReport
import java.io.File
import kotlin.system.exitProcess

/**
 * Записывает причину любого необработанного исключения в `logs/game-exit.txt`, прежде чем система закроет процесс.
 * Работает в обоих процессах приложения (лаунчер и `:game`): при следующем показе лаунчера [GameExitReport.consume]
 * отдаёт запись, и игрок видит диалог с причиной вместо молчаливого вылета.
 *
 * Обработчик ничего не «глотает»: после записи вызывается прежний, и система делает то же, что и без него.
 * Нативные падения (сигналы) он не видит — для них есть метка сессии и «последний шаг» ([GameExitReport.noteStage]).
 */
object CrashRecorder {

    /**
     * @param label `launcher` или `game` — попадёт в сообщение, чтобы было видно, в каком процессе это произошло
     * @param reportDir папка отчётов (`logs`); вычисляется в момент падения
     */
    fun install(label: String, reportDir: () -> File) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                GameExitReport.write(
                    reportDir(),
                    GameExitReport.crash(label, thread.name, error, timeMillis = System.currentTimeMillis()),
                )
            } catch (ignored: Throwable) {
                // Записать не вышло — не мешаем системе закрыть процесс.
            }
            if (previous != null) {
                previous.uncaughtException(thread, error)
            } else {
                Process.killProcess(Process.myPid())
                exitProcess(10)
            }
        }
    }
}
