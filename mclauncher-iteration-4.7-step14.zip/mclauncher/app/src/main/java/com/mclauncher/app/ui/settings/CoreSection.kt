package com.mclauncher.app.ui.settings

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.mclauncher.app.R
import com.mclauncher.app.core.CoreFailure
import com.mclauncher.app.core.CorePhase
import com.mclauncher.app.core.CoreUiState
import com.mclauncher.app.ui.components.NeonButton
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.components.NeonSecondaryButton
import com.mclauncher.engine.install.ComponentState

/** Состояние раздела «Игровое ядро» и его действия. */
@Immutable
data class CoreControls(
    val state: CoreUiState,
    val onInstall: () -> Unit,
    val onCancel: () -> Unit,
    val onRefresh: () -> Unit,
)

/**
 * Раздел «Игровое ядро»: сколько компонентов (рантаймы Java, LWJGL, компоненты запуска) установлено, кнопка установки с
 * прогрессом и отмена. Сама установка идёт в фоне (служба с уведомлением), экран можно закрыть.
 */
@Composable
fun CoreSection(core: CoreControls, modifier: Modifier = Modifier) {
    val state = core.state
    val colors = MaterialTheme.colorScheme
    val context = LocalContext.current

    // Каждый раз, когда экран открывается, перечитываем диск: установка могла завершиться, пока его не было.
    LaunchedEffect(Unit) { core.onRefresh() }

    // С Android 13 уведомление службы показывается только с разрешением. Отказ установке не мешает: она идёт и так.
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        core.onInstall()
    }
    val install = {
        val needsAsk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needsAsk) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS) else core.onInstall()
    }

    NeonCard(modifier = modifier) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Build,
                    contentDescription = null,
                    tint = colors.primary,
                    modifier = Modifier.size(24.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.core_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.onSurface,
                    )
                    Text(
                        text = stringResource(R.string.core_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                    )
                }
            }

            Text(
                text = statusText(state, context),
                style = MaterialTheme.typography.bodyMedium,
                color = if (state.phase == CorePhase.FAILED) colors.error else colors.onSurface,
            )

            if (state.phase == CorePhase.INSTALLING) {
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                if (state.label.isNotEmpty()) {
                    Text(
                        text = state.label,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                        maxLines = 1,
                    )
                }
            } else if (state.phase == CorePhase.QUEUED) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            if (state.components.isNotEmpty()) {
                Text(
                    text = state.components.joinToString("   ") { c ->
                        (if (c.state == ComponentState.INSTALLED) "✓ " else "○ ") + c.id
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant,
                )
            }

            if (state.phase == CorePhase.FAILED && !state.detail.isNullOrBlank()) {
                Text(
                    text = state.detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant,
                    maxLines = 4,
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (state.canInstall) {
                    NeonButton(
                        text = stringResource(if (state.phase == CorePhase.FAILED) R.string.core_retry else R.string.core_install),
                        onClick = install,
                        icon = Icons.Filled.Add,
                    )
                }
                if (state.canCancel) {
                    NeonSecondaryButton(
                        text = stringResource(R.string.core_cancel),
                        onClick = core.onCancel,
                        icon = Icons.Filled.Close,
                        danger = true,
                    )
                }
                if (state.phase == CorePhase.READY || state.phase == CorePhase.NEEDS_INSTALL || state.phase == CorePhase.NOT_BUNDLED) {
                    NeonSecondaryButton(
                        text = stringResource(R.string.core_recheck),
                        onClick = core.onRefresh,
                        icon = Icons.Filled.Refresh,
                    )
                }
            }
        }
    }
}

@Composable
private fun statusText(state: CoreUiState, context: android.content.Context): String = when (state.phase) {
    CorePhase.CHECKING -> stringResource(R.string.core_status_checking)
    CorePhase.NOT_BUNDLED -> stringResource(R.string.core_status_not_bundled)
    CorePhase.UNSUPPORTED -> stringResource(R.string.core_status_unsupported, state.detail ?: "?")
    CorePhase.NEEDS_INSTALL -> stringResource(
        R.string.core_status_needs,
        state.installedCount,
        state.components.size,
        Formatter.formatShortFileSize(context, state.missingBytes),
    )
    CorePhase.QUEUED -> stringResource(R.string.core_status_queued)
    CorePhase.INSTALLING -> stringResource(R.string.core_status_installing, (state.progress * 100).toInt())
    CorePhase.READY -> stringResource(R.string.core_status_ready, state.components.size)
    CorePhase.FAILED -> stringResource(
        when (state.failure) {
            CoreFailure.NOT_BUNDLED -> R.string.core_failure_not_bundled
            CoreFailure.NO_SPACE -> R.string.core_failure_no_space
            CoreFailure.CORRUPT -> R.string.core_failure_corrupt
            CoreFailure.OTHER, null -> R.string.core_failure_other
        },
    )
}
