package com.mclauncher.app.launch

import com.mclauncher.app.data.account.Account
import com.mclauncher.engine.launch.RendererProfile

const val DEFAULT_RAM_MB = 2048

/** Всё, что нужно движку, чтобы запустить игру. */
data class LaunchRequest(
    val account: Account,
    /** Идентификатор установленной версии из `.minecraft/versions` (её устанавливает и выбирает экран «Версии»). */
    val versionId: String,
    val ramMb: Int,
    val directories: GameDirectories,
    /** Аргументы Java из настроек, уже проверенные ([com.mclauncher.app.data.settings.JvmArguments]): идут после аргументов версии. */
    val extraJvmArgs: List<String> = emptyList(),
    /** Рендерер из настроек «Графика и рендеры» (см. [toRendererProfile]); по умолчанию GL4ES. */
    val renderer: RendererProfile = RendererProfile.GL4ES,
)

/** Почему запуск не удался. Тексты для пользователя подбирает UI-слой (строки ru/en). */
sealed interface LaunchFailure {
    /** Нет активного аккаунта. */
    data object NoAccount : LaunchFailure

    /** Ни одна версия не выбрана (или ещё ни одна не установлена). */
    data object NoVersion : LaunchFailure

    /** Версия выбрана, но на диске её нет или установка не была завершена: нужно установить заново. */
    data class VersionNotInstalled(val versionId: String) : LaunchFailure

    /** Не удалось создать папку игры или записать в неё. [detail] — для логов и поддержки. */
    data class GameDirUnavailable(val detail: String?) : LaunchFailure

    /** Движок недоступен: нет нативных библиотек или среды Java. */
    data object EngineUnavailable : LaunchFailure

    /** Предыдущий запуск ещё идёт. */
    data object AlreadyLaunching : LaunchFailure

    /**
     * Ядро игры не готово: на устройстве нет нужных файлов (сборка без ядра, установка ядра не завершена).
     * [missing] — что именно не найдено, для логов и поддержки.
     */
    data class CoreNotReady(val missing: String?) : LaunchFailure

    /**
     * Игра была запущена, но завершилась с ошибкой (или упала). Узнаём об этом при возвращении в лаунчер.
     * [detail] — пояснение и путь к журналу игры; для логов и поддержки. [logTail] — конец журнала игры, [hints] —
     * вероятные причины по нему (см. [GameLogDiagnosis]).
     */
    data class GameExited(
        val exitCode: Int,
        val isSignal: Boolean,
        val detail: String?,
        val logTail: String? = null,
        val hints: List<LogHint> = emptyList(),
    ) : LaunchFailure

    /** Движок сообщил об ошибке. */
    data class EngineError(val detail: String?) : LaunchFailure
}

sealed interface LaunchResult {

    /**
     * Игра запущена: открыт экран игры, который идёт в отдельном процессе. [placeholder] = true означает заглушку
     * ([StubGameEngine]): игра на самом деле НЕ стартовала. [note] — пояснение для поддержки (например, путь к журналу).
     */
    data class Started(val placeholder: Boolean, val note: String? = null) : LaunchResult

    data class Failed(val failure: LaunchFailure) : LaunchResult
}

/** Стадия запуска для индикатора на кнопке «Играть». */
enum class LaunchPhase { IDLE, PREPARING, LAUNCHING }
