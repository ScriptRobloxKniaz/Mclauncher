package com.mclauncher.app.launch

import android.app.ActivityManager
import android.content.Context

/** Объём оперативной памяти устройства — от него зависит верхняя граница ползунка «Память игры». */
object DeviceMemory {

    /** Всего памяти, МБ; 0, если система не ответила (тогда настройки берут запасное значение). */
    fun totalMb(context: Context): Long = try {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager?.getMemoryInfo(info)
        info.totalMem / (1024L * 1024L)
    } catch (e: RuntimeException) {
        0L
    }
}
