package com.mclauncher.app.data.settings

/**
 * Настройки запуска и загрузки: память игры, свои аргументы Java, число одновременных загрузок.
 *
 * [ramMb] = `null` — «автоматически»: значение выбирается по памяти устройства ([autoRamMb]) и пересчитывается при
 * каждом запуске. Свои значения хранятся как есть, а применяются через [effectiveRamMb] с поправкой на устройство.
 */
data class LaunchSettings(
    val ramMb: Int? = null,
    val jvmArguments: String = "",
    val downloadThreads: Int = DEFAULT_DOWNLOAD_THREADS,
) {
    /** Память, которую получит игра на устройстве с [deviceTotalMb] МБ. */
    fun effectiveRamMb(deviceTotalMb: Long): Int = ramMb?.let { clampRam(it, deviceTotalMb) } ?: autoRamMb(deviceTotalMb)

    fun parsedJvmArguments(): JvmArguments = JvmArguments.parse(jvmArguments)

    /** Значение для установщика: всегда в допустимых границах, даже если в файле настроек оказалось лишнее. */
    val safeDownloadThreads: Int get() = clampThreads(downloadThreads)

    companion object {
        const val MIN_RAM_MB = 512
        const val RAM_STEP_MB = 128

        /** Столько получает игра, если памяти устройства хватает: так было и до появления настройки. */
        const val AUTO_RAM_TARGET_MB = 2048

        /** Не больше этой доли памяти устройства: остальное нужно самой Android и лаунчеру, иначе систему убьёт процесс игры. */
        private const val MAX_SHARE_PERCENT = 70

        /** Если Android не сообщил объём памяти (не бывает на практике), считаем устройство «4 ГБ». */
        private const val FALLBACK_TOTAL_MB = 4096L

        const val MIN_DOWNLOAD_THREADS = 8
        const val MAX_DOWNLOAD_THREADS = 128
        const val DOWNLOAD_THREADS_STEP = 8
        const val DEFAULT_DOWNLOAD_THREADS = 64

        /** Верхняя граница ползунка памяти для устройства; не меньше [MIN_RAM_MB]. */
        fun maxRamMb(deviceTotalMb: Long): Int {
            val total = if (deviceTotalMb > 0) deviceTotalMb else FALLBACK_TOTAL_MB
            val share = total * MAX_SHARE_PERCENT / 100
            val stepped = (share / RAM_STEP_MB) * RAM_STEP_MB
            return stepped.coerceIn(MIN_RAM_MB.toLong(), Int.MAX_VALUE.toLong()).toInt()
        }

        fun autoRamMb(deviceTotalMb: Long): Int = minOf(AUTO_RAM_TARGET_MB, maxRamMb(deviceTotalMb))

        fun clampRam(value: Int, deviceTotalMb: Long): Int = value.coerceIn(MIN_RAM_MB, maxRamMb(deviceTotalMb))

        fun clampThreads(value: Int): Int = value.coerceIn(MIN_DOWNLOAD_THREADS, MAX_DOWNLOAD_THREADS)

        /**
         * Сколько больших файлов качать одновременно при [threads] потоках: их время определяет канал, поэтому растёт
         * медленно (64 → 4). Всегда в пределах 2–6.
         */
        fun largeFileConcurrency(threads: Int): Int = (clampThreads(threads) / 16).coerceIn(2, 6)

        /** Сколько соединений должен вмещать пул платформы: все загрузки при максимальных настройках с запасом. */
        const val MAX_PARALLEL_CONNECTIONS = MAX_DOWNLOAD_THREADS + 6

        /** Читает сохранённое: неверные и пропавшие значения заменяются значениями по умолчанию. */
        fun fromStored(ramMb: Int?, jvmArguments: String?, downloadThreads: Int?) = LaunchSettings(
            ramMb = ramMb?.takeIf { it >= MIN_RAM_MB },
            jvmArguments = jvmArguments.orEmpty().take(JvmArguments.MAX_TEXT_LENGTH),
            downloadThreads = clampThreads(downloadThreads ?: DEFAULT_DOWNLOAD_THREADS),
        )
    }
}
