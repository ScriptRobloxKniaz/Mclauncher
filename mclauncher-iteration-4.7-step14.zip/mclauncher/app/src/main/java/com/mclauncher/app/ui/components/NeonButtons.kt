package com.mclauncher.app.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mclauncher.app.ui.theme.NeonColors

private val ButtonShape = RoundedCornerShape(12.dp)

private val SoftWhiteBorder = Color(0x40FFFFFF)
private val FocusWhiteBorder = Color(0xCCFFFFFF)

/**
 * Свечение вокруг кнопки: два тонких полупрозрачных ореола, нарисованных за кнопкой. Раньше здесь была тень
 * `Modifier.shadow` с цветом — на каждой кнопке сетки версий она пересчитывалась при прокрутке и заметно тормозила;
 * ореолы — это два прямоугольника на кнопку, их цена почти нулевая.
 */
private fun Modifier.neonGlow(visible: Boolean): Modifier =
    if (!visible) {
        this
    } else {
        drawBehind {
            val radius = 12.dp.toPx()
            for ((spread, alpha) in GlowLayers) {
                val grow = spread.dp.toPx()
                drawRoundRect(
                    color = NeonColors.Glow.copy(alpha = alpha),
                    topLeft = Offset(-grow, -grow + 1.dp.toPx()),
                    size = Size(size.width + grow * 2, size.height + grow * 2),
                    cornerRadius = CornerRadius(radius + grow),
                )
            }
        }
    }

private val GlowLayers = listOf(6f to 0.07f, 3f to 0.12f)

/**
 * Главная кнопка: фиолетово-синий градиент со свечением. Компактная — по умолчанию 40 dp высотой.
 * [busy] — вместо значка крутится индикатор, нажатия игнорируются, но вид остаётся «живым».
 * [trailingIcon] — значок справа от подписи (например, стрелка «>»).
 */
@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    busy: Boolean = false,
    height: Dp = 40.dp,
    trailingIcon: ImageVector? = null,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val focused by interactionSource.collectIsFocusedAsState()
    val active = enabled && !busy
    val scale by animateFloatAsState(
        targetValue = if (pressed && active) 0.97f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "neonButtonScale",
    )
    val contentColor = if (enabled) NeonColors.OnGradient else NeonColors.DisabledContent
    val borderColor = when {
        focused -> FocusWhiteBorder
        enabled -> SoftWhiteBorder
        else -> Color(0x1AFFFFFF)
    }

    Box(
        modifier = modifier
            .height(height)
            // Масштаб читается в фазе рисования (лямбда graphicsLayer), поэтому анимация не вызывает перекомпоновку.
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .neonGlow(visible = enabled && !pressed)
            .clip(ButtonShape)
            .background(
                when {
                    !enabled -> SolidColor(NeonColors.DisabledFill)
                    pressed -> NeonColors.pressedGradient
                    else -> NeonColors.gradient
                },
            )
            .border(1.dp, borderColor, ButtonShape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = Color.White),
                enabled = active,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (busy) {
                CircularProgressIndicator(
                    color = contentColor,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(18.dp),
                )
            } else if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(20.dp),
                )
            }
            Text(
                text = text,
                color = contentColor,
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (trailingIcon != null && !busy) {
                Icon(
                    imageVector = trailingIcon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(16.dp),
                )
            }
        }
    }
}

/**
 * Вторичная кнопка в стиле «стекло»: тёмная полупрозрачная заливка и тонкая рамка; при нажатии или фокусе рамка
 * загорается акцентным цветом. [danger] — красная рамка и значок, для «Удалить».
 */
@Composable
fun NeonSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    danger: Boolean = false,
    height: Dp = 40.dp,
    trailingIcon: ImageVector? = null,
) {
    val colors = MaterialTheme.colorScheme
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val focused by interactionSource.collectIsFocusedAsState()
    val accent = if (danger) colors.error else colors.primary
    val borderColor = when {
        !enabled -> colors.outlineVariant.copy(alpha = 0.5f)
        pressed || focused -> accent
        danger -> colors.error.copy(alpha = 0.7f)
        else -> colors.outline
    }
    val contentColor = when {
        !enabled -> NeonColors.DisabledContent
        danger -> colors.error
        else -> colors.onSurface
    }

    Box(
        modifier = modifier
            .height(height)
            .clip(ButtonShape)
            .background(if (pressed && enabled) NeonColors.glassSelectedFill else NeonColors.glassFill)
            .border(1.dp, borderColor, ButtonShape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = accent),
                enabled = enabled,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(20.dp),
                )
            }
            Text(
                text = text,
                color = contentColor,
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Medium),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (trailingIcon != null) {
                Icon(
                    imageVector = trailingIcon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(16.dp),
                )
            }
        }
    }
}

/** Квадратная кнопка с одним значком. [contentDescription] нужен для озвучки. */
@Composable
fun NeonIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 36.dp,
) {
    val colors = MaterialTheme.colorScheme
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val focused by interactionSource.collectIsFocusedAsState()

    Box(
        modifier = modifier
            .size(size)
            .clip(ButtonShape)
            .background(NeonColors.glassFill)
            .border(1.dp, if (pressed || focused) colors.primary else colors.outline, ButtonShape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = colors.primary),
                role = Role.Button,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = colors.onSurface,
            modifier = Modifier.size(18.dp),
        )
    }
}
