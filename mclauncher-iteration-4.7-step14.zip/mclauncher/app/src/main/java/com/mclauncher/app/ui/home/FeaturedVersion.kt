package com.mclauncher.app.ui.home

import com.mclauncher.app.data.versions.InstalledVersion

/**
 * Версия для карточки «Последние версии» на главном экране: выбранная игроком, а если ничего не выбрано — самая новая из
 * установленных (по дате выхода, при равенстве — по времени установки). `null`, если версий нет.
 * Чистая логика без Android: проверяется JVM-тестами.
 */
fun pickFeaturedVersion(installed: List<InstalledVersion>, selectedId: String?): InstalledVersion? {
    if (installed.isEmpty()) return null
    installed.firstOrNull { it.id == selectedId }?.let { return it }
    return installed.maxWithOrNull(
        compareBy<InstalledVersion> { it.releaseTime.orEmpty() }.thenBy { it.installedAt },
    )
}
