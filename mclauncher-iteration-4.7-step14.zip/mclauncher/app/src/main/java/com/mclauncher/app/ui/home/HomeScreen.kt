package com.mclauncher.app.ui.home

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.BackgroundPreset
import com.mclauncher.app.data.settings.BackgroundSelection
import com.mclauncher.app.data.versions.VersionLibraryState
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.navigation.Destination

/**
 * Главный экран в альбомной ориентации из двух колонок:
 *  - центр: заголовок «MCLauncher», кнопки «Играть» и «Выбрать версию», карточки «Последние версии» и «Новости»;
 *  - справа: профиль, карточка ИИ-помощника и внизу «Premium-доступ». Карточки «Быстрые действия» нет — она не нужна.
 *
 * Стадии запуска показывают сами кнопки, итог — диалог в корне UI. Под девизом всегда видна пометка
 * «неофициальная модифицированная версия»: её требует лицензия ZalithLauncher 2.
 *
 * Если окно вдруг узкое (разделённый экран), колонки ставятся друг под другом и экран прокручивается.
 */
@Composable
fun HomeScreen(
    activeAccount: ActiveAccountState,
    library: VersionLibraryState?,
    launchPhase: LaunchPhase,
    /** `null` — запустить выбранную версию, иначе — именно эту (её сначала выбирают). */
    onPlay: (versionId: String?) -> Unit,
    onSelectVersion: (String) -> Unit,
    backgroundSelection: BackgroundSelection,
    customBackgroundPreview: ImageBitmap?,
    /** Сейчас на заднем плане играет видео: в окне выбора фона отмечается оно, а не картинка или пресет. */
    videoActive: Boolean,
    onSelectPreset: (BackgroundPreset) -> Unit,
    onPickCustomBackground: (Uri) -> Unit,
    onPickCustomVideo: (Uri) -> Unit,
    onNavigate: (Destination) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var showBackgroundSheet by rememberSaveable { mutableStateOf(false) }
    var showVersionPicker by rememberSaveable { mutableStateOf(false) }

    // SAF: системный выбор картинки. Права на чтение действуют на один этот вызов — этого достаточно,
    // потому что картинка сразу копируется в хранилище приложения. С видео то же самое.
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            showBackgroundSheet = false
            onPickCustomBackground(uri)
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            showBackgroundSheet = false
            onPickCustomVideo(uri)
        }
    }

    // Общая проверка для всех кнопок «Играть»: аккаунт и версия должны быть, иначе объясняем и ведём куда нужно.
    val play = rememberPlayAction(activeAccount, library, onPlay, onNavigate)

    // Что показывать — считается один раз на смену списка версий, а не на каждую перекомпоновку.
    val installed = remember(library) { library?.installed.orEmpty() }
    val featured = remember(library) { pickFeaturedVersion(installed, library?.selectedId) }
    val canLaunch = launchPhase == LaunchPhase.IDLE

    val center: @Composable () -> Unit = {
        HomeHero(onChangeBackground = { showBackgroundSheet = true })
        HomeActions(
            version = library?.selected,
            launchPhase = launchPhase,
            onPlay = { play(null) },
            onPickVersion = { showVersionPicker = true },
        )
        LatestVersionsCard(
            version = featured,
            selected = featured != null && featured.id == library?.selectedId,
            loaded = library != null,
            canLaunch = canLaunch,
            onPlay = { versionId -> play(versionId) },
            onOpenVersions = { onNavigate(Destination.Versions) },
            onOpenAll = { onNavigate(Destination.Play) },
        )
        NewsCard()
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        // Размеры берём в локальные переменные: внутри вложенных лямбд так надёжнее, чем обращаться к scope.
        val availableWidth = maxWidth
        val availableHeight = maxHeight
        // Две колонки, пока окно шире, чем выше (альбомная ориентация закреплена в манифесте). Друг под другом их ставим
        // только в «высоком» или совсем узком окне — например, в разделённом экране.
        val narrow = availableWidth < availableHeight || availableWidth < 560.dp
        val sideWidth: Dp = when {
            availableWidth > 900.dp -> 280.dp
            availableWidth >= 680.dp -> 252.dp
            else -> 232.dp
        }

        if (narrow) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                center()
                HomeSideColumn(
                    account = activeAccount,
                    onOpenAccounts = { onNavigate(Destination.Accounts) },
                    onOpenAssistant = { onNavigate(Destination.Assistant) },
                    onPremium = { Toast.makeText(context, R.string.home_premium_soon, Toast.LENGTH_SHORT).show() },
                    pinPremiumToBottom = false,
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                // Центр прокручивается: на низком экране карточки «Новости» может не хватить места.
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    center()
                }
                HomeSideColumn(
                    account = activeAccount,
                    onOpenAccounts = { onNavigate(Destination.Accounts) },
                    onOpenAssistant = { onNavigate(Destination.Assistant) },
                    onPremium = { Toast.makeText(context, R.string.home_premium_soon, Toast.LENGTH_SHORT).show() },
                    pinPremiumToBottom = true,
                    modifier = Modifier
                        .width(sideWidth)
                        .fillMaxHeight(),
                )
            }
        }
    }

    if (showVersionPicker) {
        VersionPickerDialog(
            installed = installed,
            selectedId = library?.selectedId,
            onSelect = onSelectVersion,
            onInstallMore = { onNavigate(Destination.Versions) },
            onDismiss = { showVersionPicker = false },
        )
    }

    if (showBackgroundSheet) {
        BackgroundSheet(
            selection = backgroundSelection,
            customPreview = customBackgroundPreview,
            videoActive = videoActive,
            onSelectPreset = onSelectPreset,
            onPickFromGallery = { imagePicker.launch(arrayOf("image/*")) },
            onPickVideo = { videoPicker.launch(arrayOf("video/*")) },
            onDismiss = { showBackgroundSheet = false },
        )
    }
}

/**
 * Правая колонка: профиль, ИИ-помощник и «Premium-доступ». С [pinPremiumToBottom] последняя карточка прижата к низу
 * экрана, а верхние прокручиваются, если не помещаются; в узком окне все карточки идут подряд.
 */
@Composable
private fun HomeSideColumn(
    account: ActiveAccountState,
    onOpenAccounts: () -> Unit,
    onOpenAssistant: () -> Unit,
    onPremium: () -> Unit,
    pinPremiumToBottom: Boolean,
    modifier: Modifier = Modifier,
) {
    if (pinPremiumToBottom) {
        Box(modifier = modifier) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    // Запас под закреплённую карточку «Premium», чтобы она не закрывала нижнюю карточку колонки.
                    .padding(bottom = PremiumReserve),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ProfileCard(account = account, onOpenAccounts = onOpenAccounts)
                AssistantCard(onOpen = onOpenAssistant)
            }
            PremiumCard(
                onClick = onPremium,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    } else {
        Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ProfileCard(account = account, onOpenAccounts = onOpenAccounts)
            AssistantCard(onOpen = onOpenAssistant)
            PremiumCard(onClick = onPremium)
        }
    }
}

/** Высота карточки «Premium» вместе с промежутком над ней. */
private val PremiumReserve = 66.dp
