package com.mclauncher.app.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.mclauncher.app.R
import com.mclauncher.app.ui.components.LauncherIcons

/** Как экран связан с боковым меню. */
enum class Placement {
    /** Есть пункт в боковом меню: он подсвечивается, пока экран открыт. */
    SIDEBAR,

    /** Меню видно, но подсвеченного пункта нет (аккаунты, скины — их открывают с главной). */
    SECONDARY,

    /** Полноэкранный: меню скрыто, назад — кнопка или жест. */
    FULLSCREEN,
}

/** Все экраны приложения. Порядок пунктов с [Placement.SIDEBAR] задаёт порядок в меню и направление анимации. */
enum class Destination(
    val route: String,
    @StringRes val labelRes: Int,
    val icon: ImageVector,
    val placement: Placement,
) {
    Home("home", R.string.nav_home, Icons.Filled.Home, Placement.SIDEBAR),
    Play("play", R.string.nav_play, Icons.Filled.PlayArrow, Placement.SIDEBAR),
    Mods("mods", R.string.nav_mods, LauncherIcons.Puzzle, Placement.SIDEBAR),
    ResourcePacks("resourcepacks", R.string.nav_resourcepacks, LauncherIcons.Layers, Placement.SIDEBAR),
    Shaders("shaders", R.string.nav_shaders, LauncherIcons.Sun, Placement.SIDEBAR),
    Settings("settings", R.string.nav_settings, Icons.Filled.Settings, Placement.SIDEBAR),

    /** ИИ-помощник сборок (Beta): в боковом меню выделен отдельной карточкой под основными пунктами. */
    Assistant("assistant", R.string.assistant_title, LauncherIcons.Sparkle, Placement.SIDEBAR),

    /** «О лаунчере»: версия, лицензия, происхождение кода. В меню — внизу. */
    About("about", R.string.nav_about, Icons.Filled.Info, Placement.SIDEBAR),

    Accounts("accounts", R.string.nav_accounts, Icons.Filled.Person, Placement.SECONDARY),
    Skins("skins", R.string.nav_skins, Icons.Filled.Face, Placement.SECONDARY),

    /** Версии игры: установка, выбор, удаление. Полноэкранный, открывается с вкладки «Играть». */
    Versions("versions", R.string.versions_title, LauncherIcons.Versions, Placement.FULLSCREEN);

    /** Показывать ли боковое меню (или нижнюю панель) на этом экране. */
    val showsNavigation: Boolean get() = placement != Placement.FULLSCREEN

    companion object {
        /** Основные пункты меню, сверху вниз (без ИИ-помощника и «О лаунчере» — они рисуются отдельно). */
        val sidebarMain: List<Destination> = listOf(Home, Play, Mods, ResourcePacks, Shaders, Settings)

        /** Пункты нижней панели узкого экрана: на ней помещается только пять. */
        val compactTabs: List<Destination> = listOf(Home, Play, Mods, Assistant, Settings)

        fun fromRoute(route: String?): Destination? = entries.firstOrNull { it.route == route }
    }
}
