package com.mclauncher.app.launch

import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.versions.Argument
import com.mclauncher.app.data.versions.GameVersion
import com.mclauncher.app.data.versions.InstallPlanner
import com.mclauncher.app.data.versions.Library
import com.mclauncher.app.data.versions.OsEnvironment
import com.mclauncher.app.data.versions.RuleEvaluator
import com.mclauncher.app.data.versions.VersionLayout
import com.mclauncher.engine.EngineLaunchSpec
import com.mclauncher.engine.detectLwjglRequirement

/**
 * Превращает описание версии Mojang, аккаунт и папки в [EngineLaunchSpec] — то, что понимает ядро.
 *
 * Здесь вся «Mojang-часть» запуска: какие библиотеки идут в classpath (тот же отбор, что при установке — установленное
 * и запускаемое не разойдутся), какие аргументы подходят этой системе и чем заполняются шаблоны аккаунта и папок.
 * Всё, что относится к Pojav/Zalith (LWJGL ядра, нативы, флаги JVM), решает [com.mclauncher.engine.LaunchCommandBuilder].
 *
 * Чистый Kotlin без Android; читает с диска только проверку «есть ли файл настроек логов».
 */
class LaunchSpecFactory(
    private val layout: VersionLayout,
    private val env: OsEnvironment,
    private val planner: InstallPlanner,
    private val launcherName: String,
    private val launcherVersion: String,
) {

    /**
     * @param extraJvmArgs пользовательские аргументы Java из настроек: добавляются **последними**, чтобы при одинаковых
     * `-D…` победило значение игрока (JVM берёт последнее). Проверка (память, classpath и т. п.) — на стороне вызова.
     */
    fun create(
        version: GameVersion,
        account: Account,
        directories: GameDirectories,
        ramMb: Int,
        extraJvmArgs: List<String> = emptyList(),
    ): EngineLaunchSpec {
        val clientJar = layout.clientJar(version.id).path

        val jvmArgs = ArrayList<String>()
        jvmArgs += "-Dminecraft.client.jar=$clientJar"
        val fromVersion = version.arguments.jvm.resolve()
        // Старые версии не знают, кто их запустил; новые уже просят подставить эти значения.
        if (fromVersion.none { it.startsWith("-Dminecraft.launcher.brand=") }) jvmArgs += "-Dminecraft.launcher.brand=\${launcher_name}"
        if (fromVersion.none { it.startsWith("-Dminecraft.launcher.version=") }) jvmArgs += "-Dminecraft.launcher.version=\${launcher_version}"
        loggingArgument(version)?.let { jvmArgs += it }
        jvmArgs += fromVersion
        jvmArgs += extraJvmArgs

        return EngineLaunchSpec(
            versionId = version.id,
            javaMajor = version.java.majorVersion,
            mainClass = version.mainClass,
            clientJar = clientJar,
            libraryJars = libraryJars(version),
            // LWJGL определяется по полному списку: сами его jar'ы в classpath не попадают (приложение их не отбирает).
            lwjgl = detectLwjglRequirement(version.libraries.map { it.name }),
            jvmArgs = jvmArgs,
            gameArgs = version.arguments.game.resolve(),
            variables = variables(version, account, directories),
            ramMb = ramMb,
            newArgumentFormat = !version.arguments.legacy,
        )
    }

    /** Библиотеки версии по тому же отбору, что и установка, как абсолютные пути; небезопасные пути отбрасываются. */
    private fun libraryJars(version: GameVersion): List<String> {
        val selected = planner.selectLibraries(version)
        // Если есть современный `asm`, устаревший `asm-all` в classpath не нужен (так же делает апстрим).
        val hasAsm = selected.any { it.name.startsWith("org.ow2.asm:asm:") }
        return selected
            .filterNot { hasAsm && it.name.startsWith("org.ow2.asm:asm-all:") }
            .mapNotNull(::jarPath)
            .distinct()
    }

    private fun jarPath(library: Library): String? =
        library.artifact?.path?.let { layout.library(it) }?.path

    /** Аргументы, правила которых разрешают их на этой системе (функции вроде демо-режима и Quick Play не включены). */
    private fun List<Argument>.resolve(): List<String> =
        filter { RuleEvaluator.isAllowed(it.rules, env) }.flatMap { it.values }

    /** Аргумент настройки логов из описания версии, если файл настройки скачан; иначе `null`. */
    private fun loggingArgument(version: GameVersion): String? {
        val config = version.logging ?: return null
        val file = layout.logConfig(config.fileId)?.takeIf { it.isFile } ?: return null
        return config.argument.replace("\${path}", file.path)
    }

    private fun variables(version: GameVersion, account: Account, directories: GameDirectories): Map<String, String> {
        val assets = directories.assets.path
        return linkedMapOf(
            // Оффлайн-аккаунт: токена нет, Mojang-серверы его не проверяют. Настоящий токен придёт с 4.5 (Microsoft).
            "auth_player_name" to account.username,
            "auth_uuid" to account.uuid.replace("-", ""),
            "auth_access_token" to OFFLINE_TOKEN,
            "auth_session" to OFFLINE_TOKEN,
            "auth_xuid" to "",
            "clientid" to "",
            // Как у апстрима: тип пользователя всегда `msa`, иначе новые версии отказываются стартовать.
            "user_type" to "msa",
            "user_properties" to "{}",
            "game_directory" to directories.root.path,
            "assets_root" to assets,
            "game_assets" to assets,
            "assets_index_name" to version.assetIndex.id,
            "library_directory" to directories.libraries.path,
            "version_name" to version.id,
            "version_type" to version.type.id.ifEmpty { "release" },
            "launcher_name" to launcherName,
            "launcher_version" to launcherVersion,
        )
    }

    private companion object {
        const val OFFLINE_TOKEN = "0"
    }
}
