package com.mclauncher.app.data.versions

/**
 * Раскладка файлов установки по двум независимым очередям.
 *
 * Время установки определяют два разных предела. У тысяч мелких файлов (ассеты) — задержка: рукопожатие и ожидание
 * ответа на каждый, поэтому помогает много одновременных загрузок. У нескольких больших файлов (клиентский jar,
 * крупные библиотеки) — пропускная способность канала: их много параллельно не нужно, но начинать надо с самых
 * больших, иначе один большой файл, начатый последним, растягивает хвост всей установки.
 *
 * Поэтому: [large] — файлы от [threshold] байт, от самого большого к меньшему; [small] — остальные и файлы с неизвестным
 * размером, в исходном порядке. У очередей свои ограничения параллелизма, и работают они одновременно.
 */
class DownloadSchedule private constructor(
    val large: List<DownloadTask>,
    val small: List<DownloadTask>,
) {
    val size: Int get() = large.size + small.size

    companion object {
        /** Порог по умолчанию: клиентский jar и крупные библиотеки — «большие», ассеты и мелкие библиотеки — «мелкие». */
        const val DEFAULT_THRESHOLD_BYTES = 512L * 1024

        fun of(tasks: List<DownloadTask>, threshold: Long = DEFAULT_THRESHOLD_BYTES): DownloadSchedule {
            require(threshold > 0) { "threshold must be positive" }
            val large = ArrayList<DownloadTask>()
            val small = ArrayList<DownloadTask>(tasks.size)
            for (task in tasks) {
                if (task.size >= threshold) large += task else small += task
            }
            // Сортировка устойчивая: файлы одного размера остаются в исходном порядке.
            large.sortByDescending { it.size }
            return DownloadSchedule(large, small)
        }
    }
}
