package com.mclauncher.app.launch

import com.mclauncher.app.data.account.Account
import com.mclauncher.engine.launch.RendererProfile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * Оркестратор запуска: проверки перед стартом → подготовка папок → вызов [GameEngine].
 *
 * Никогда не бросает исключения наружу (кроме отмены корутины): любой сбой превращается
 * в [LaunchResult.Failed] с понятной причиной, которую UI показывает пользователю.
 */
class GameLauncher(
    private val engine: GameEngine,
    private val directories: GameDirectories,
    /** Проверка «версия установлена целиком». Читает диск, поэтому вызывается на [ioDispatcher]. */
    private val isVersionInstalled: (String) -> Boolean,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) {
    private val mutex = Mutex()
    private val _phase = MutableStateFlow(LaunchPhase.IDLE)

    /** Текущая стадия — чтобы кнопка «Играть» показывала прогресс и не принимала повторные нажатия. */
    val phase: StateFlow<LaunchPhase> = _phase.asStateFlow()

    suspend fun launch(
        account: Account?,
        versionId: String?,
        ramMb: Int = DEFAULT_RAM_MB,
        extraJvmArgs: List<String> = emptyList(),
        renderer: RendererProfile = RendererProfile.GL4ES,
    ): LaunchResult {
        if (account == null) return LaunchResult.Failed(LaunchFailure.NoAccount)
        if (versionId == null) return LaunchResult.Failed(LaunchFailure.NoVersion)
        // Второй запуск параллельно не стартуем: игра — один процесс на всех.
        if (!mutex.tryLock()) return LaunchResult.Failed(LaunchFailure.AlreadyLaunching)

        try {
            _phase.value = LaunchPhase.PREPARING
            val dirFailure = prepareDirectories()
            if (dirFailure != null) return LaunchResult.Failed(dirFailure)

            if (!withContext(ioDispatcher) { isVersionInstalled(versionId) }) {
                return LaunchResult.Failed(LaunchFailure.VersionNotInstalled(versionId))
            }

            _phase.value = LaunchPhase.LAUNCHING
            return runEngine(LaunchRequest(account, versionId, ramMb, directories, extraJvmArgs, renderer))
        } finally {
            _phase.value = LaunchPhase.IDLE
            mutex.unlock()
        }
    }

    private suspend fun prepareDirectories(): LaunchFailure? = try {
        withContext(ioDispatcher) { directories.ensureCreated() }
        null
    } catch (e: IOException) {
        LaunchFailure.GameDirUnavailable(e.message)
    } catch (e: SecurityException) {
        LaunchFailure.GameDirUnavailable(e.message)
    }

    private suspend fun runEngine(request: LaunchRequest): LaunchResult = try {
        engine.launch(request)
    } catch (e: CancellationException) {
        throw e
    } catch (e: UnsatisfiedLinkError) {
        // Типичная картина, когда нативные библиотеки ядра не загрузились.
        LaunchResult.Failed(LaunchFailure.EngineUnavailable)
    } catch (e: Exception) {
        LaunchResult.Failed(LaunchFailure.EngineError(e.message))
    }
}
