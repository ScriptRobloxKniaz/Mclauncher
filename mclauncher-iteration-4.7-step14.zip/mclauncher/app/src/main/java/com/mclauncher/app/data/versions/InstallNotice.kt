package com.mclauncher.app.data.versions

/**
 * Что показать в уведомлении о загрузке версии. Чистая модель поверх [InstallState]: слова и числа превращает
 * в текст служба, поэтому логика проверяется обычными тестами.
 */
sealed interface InstallNotice {

    /** Сообщать не о чем: установка не идёт и итога нет (или её отменили). */
    data object None : InstallNotice

    /** Идёт установка. [percent] — `null`, пока размер неизвестен (подготовка); [bytesPerSecond] = 0 — скорость не измерена. */
    data class Running(val versionId: String, val percent: Int?, val bytesPerSecond: Long) : InstallNotice

    data class Done(val versionId: String) : InstallNotice

    data class Failed(val versionId: String) : InstallNotice

    /** Службе переднего плана нужно жить, пока установка идёт, и только пока она идёт. */
    val keepsServiceAlive: Boolean get() = this is Running

    companion object {
        fun of(state: InstallState): InstallNotice = when (state) {
            InstallState.Idle -> None
            is InstallState.Running -> Running(
                versionId = state.versionId,
                percent = state.progress?.fraction?.let { (it * 100).toInt().coerceIn(0, 100) },
                bytesPerSecond = state.progress?.bytesPerSecond?.coerceAtLeast(0) ?: 0L,
            )
            is InstallState.Done -> Done(state.versionId)
            is InstallState.Failed -> Failed(state.versionId)
        }
    }
}
