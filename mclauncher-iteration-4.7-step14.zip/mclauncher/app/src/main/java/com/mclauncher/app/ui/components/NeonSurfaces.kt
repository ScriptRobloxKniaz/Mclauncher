package com.mclauncher.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mclauncher.app.ui.theme.NeonColors

/** Скругление карточек по умолчанию. */
val NeonCardShape = RoundedCornerShape(16.dp)

/**
 * Карточка в стиле «стекло»: полупрозрачная тёмно-фиолетовая заливка с вертикальным градиентом и тонкая светлая рамка
 * (сверху ярче, снизу почти не видна). Реального размытия фона нет — оно на каждом кадре стоило бы заметного
 * времени GPU, особенно поверх видео, — вместо него прозрачность и градиент.
 *
 *  - [selected] — выбранная карточка: ярче заливка и фиолетово-синяя рамка;
 *  - [highlight] — яркая фиолетовая карточка для акцентных блоков («ИИ-помощник», «Premium»);
 *  - если задан [onClick], вся карточка нажимается.
 */
@Composable
fun NeonCard(
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    highlight: Boolean = false,
    onClick: (() -> Unit)? = null,
    shape: Shape = NeonCardShape,
    content: @Composable ColumnScope.() -> Unit,
) {
    val fill = when {
        highlight -> NeonColors.highlightFill
        selected -> NeonColors.glassSelectedFill
        else -> NeonColors.glassFill
    }
    val border = when {
        highlight -> NeonColors.highlightBorder
        selected -> NeonColors.glassSelectedBorder
        else -> NeonColors.glassBorder
    }
    Column(
        modifier = modifier
            .clip(shape)
            .background(fill)
            .border(if (selected) 1.5.dp else 1.dp, border, shape)
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier),
        content = content,
    )
}

/**
 * Маленькая метка-«таблетка»: «Beta», «Выбрана». По умолчанию фиолетовая; [success] — зелёная.
 */
@Composable
fun NeonChip(
    text: String,
    modifier: Modifier = Modifier,
    success: Boolean = false,
) {
    val container = if (success) NeonColors.SuccessContainer else Color(0x668B5CFF)
    val content = if (success) NeonColors.Success else Color(0xFFE6DCFF)
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(container)
            .padding(horizontal = 8.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = content,
            fontSize = 10.sp,
            lineHeight = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}

/**
 * Выпадающий список в стиле лаунчера: «стеклянное» поле с подписью выбранного пункта и стрелкой; по нажатию
 * открывается меню, выбранный пункт отмечен галочкой. [optionLabel] — подпись пункта (из строковых ресурсов).
 */
@Composable
fun <T> NeonDropdown(
    options: List<T>,
    selected: T,
    optionLabel: @Composable (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: ImageVector? = null,
) {
    val colors = MaterialTheme.colorScheme
    var expanded by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    val contentColor = if (enabled) colors.onSurface else NeonColors.DisabledContent

    Box(modifier = modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(42.dp)
                .clip(shape)
                .background(NeonColors.glassFill)
                .border(1.dp, NeonColors.glassBorder, shape)
                .clickable(enabled = enabled, role = Role.DropdownList) { expanded = true }
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (leadingIcon != null) {
                Icon(
                    imageVector = leadingIcon,
                    contentDescription = null,
                    tint = if (enabled) colors.primary else NeonColors.DisabledContent,
                    modifier = Modifier.size(18.dp),
                )
            }
            Text(
                text = optionLabel(selected),
                color = contentColor,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Icon(
                imageVector = LauncherIcons.ChevronDown,
                contentDescription = null,
                tint = if (enabled) colors.onSurfaceVariant else NeonColors.DisabledContent,
                modifier = Modifier.size(16.dp),
            )
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(optionLabel(option)) },
                    onClick = {
                        expanded = false
                        onSelect(option)
                    },
                    trailingIcon = {
                        if (option == selected) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = null,
                                tint = colors.primary,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    },
                )
            }
        }
    }
}
