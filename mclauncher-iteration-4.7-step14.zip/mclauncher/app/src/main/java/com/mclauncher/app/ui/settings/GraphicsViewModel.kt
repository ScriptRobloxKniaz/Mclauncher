package com.mclauncher.app.ui.settings

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mclauncher.app.LauncherApp
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.GraphicsSettings
import com.mclauncher.app.data.settings.OpenGlVersion
import com.mclauncher.app.data.settings.Renderer
import com.mclauncher.app.ui.common.UiEvent
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.IOException

/**
 * Раздел «Графика и рендеры». Значения только сохраняются в DataStore; передать их ядру в аргументах запуска —
 * задача 4.7b. Живёт только пока открыт экран «Настройки».
 */
class GraphicsViewModel(application: Application) : AndroidViewModel(application) {

    private val settings = (application as LauncherApp).settings

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events: Flow<UiEvent> = _events.receiveAsFlow()

    val state: StateFlow<GraphicsSettings> = settings.graphics.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = GraphicsSettings(),
    )

    fun setRenderer(renderer: Renderer) = save { it.withRenderer(renderer) }

    fun setUseZink(enabled: Boolean) = save { it.withUseZink(enabled) }

    fun setGlVersion(version: OpenGlVersion) = save { it.withGlVersion(version) }

    private fun save(transform: (GraphicsSettings) -> GraphicsSettings) {
        viewModelScope.launch {
            try {
                settings.updateGraphics(transform)
            } catch (e: IOException) {
                Log.w(TAG, "Failed to save graphics settings", e)
                _events.trySend(UiEvent(R.string.error_settings_save))
            }
        }
    }

    private companion object {
        const val TAG = "GraphicsViewModel"
    }
}
