package com.mclauncher.app.data.background

import java.io.IOException
import java.util.Locale

/** Почему видео не удалось взять в фон. От причины зависит сообщение пользователю. */
enum class VideoImportReason {
    /** Это не видеофайл или в нём нет видеодорожки. */
    NOT_VIDEO,

    /** Файл больше [VideoImportPolicy.MAX_BYTES]. */
    TOO_LARGE,

    /** Не хватает места на устройстве для копии. */
    NO_SPACE,

    /** Файл не читается (удалён, нет доступа, оборвалось чтение). */
    UNREADABLE,
}

class VideoImportException(val reason: VideoImportReason, message: String? = null) : IOException(message ?: reason.name)

/**
 * Правила приёма видео для фона. Чистая логика без Android: проверяется JVM-тестами.
 *
 * Видео копируется в приватное хранилище целиком (как и картинка), поэтому у размера есть предел:
 * фон не должен незаметно съесть память телефона.
 */
object VideoImportPolicy {

    const val MAX_BYTES: Long = 256L * 1024 * 1024

    /** Запас свободного места, который не трогаем при копировании. */
    const val SPACE_RESERVE_BYTES: Long = 64L * 1024 * 1024

    private val knownExtensions = setOf("mp4", "m4v", "mov", "webm", "mkv", "3gp")

    /**
     * Годится ли файл с таким типом и именем. Любой видеотип (`video/mp4`, `video/webm` и т. д.) принимается сразу;
     * если провайдер файлов не знает типа (или отдаёт `application/octet-stream`), решает расширение.
     * Окончательная проверка — позже, по самому файлу.
     */
    fun isAcceptable(mimeType: String?, displayName: String?): Boolean {
        val mime = mimeType?.trim()?.lowercase(Locale.ROOT)
        if (mime != null && mime.startsWith("video/")) return true

        val unknownType = mime == null || mime.isEmpty() || mime == "application/octet-stream"
        if (!unknownType) return false

        val extension = displayName?.substringAfterLast('.', missingDelimiterValue = "")?.lowercase(Locale.ROOT).orEmpty()
        return extension in knownExtensions
    }

    fun isTooLarge(bytes: Long): Boolean = bytes > MAX_BYTES

    /** Хватит ли места под копию размером [needed] байт, если свободно [usable] и нужно оставить запас. */
    fun hasEnoughSpace(needed: Long, usable: Long): Boolean = usable - SPACE_RESERVE_BYTES >= needed
}
