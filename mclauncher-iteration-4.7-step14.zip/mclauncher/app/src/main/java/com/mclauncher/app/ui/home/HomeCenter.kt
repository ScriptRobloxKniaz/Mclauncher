package com.mclauncher.app.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mclauncher.app.R
import com.mclauncher.app.data.versions.InstalledVersion
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.components.NeonButton
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.components.NeonChip
import com.mclauncher.app.ui.components.NeonIconButton
import com.mclauncher.app.ui.components.NeonSecondaryButton
import com.mclauncher.app.ui.launch.playLabelRes
import com.mclauncher.app.ui.theme.NeonColors
import com.mclauncher.app.ui.versions.labelRes
import com.mclauncher.app.ui.versions.releaseDate

private val TitleShadow = Shadow(color = Color(0xB3000000), offset = Offset(0f, 3f), blurRadius = 12f)
private val SubtitleShadow = Shadow(color = Color(0xB3000000), offset = Offset(0f, 2f), blurRadius = 8f)

/**
 * Центр главного экрана: большой заголовок «MCLauncher» с девизом, кнопки «Играть» и «Выбрать версию»,
 * карточка «Последние версии» и карточка «Новости». Под девизом всегда видна пометка «неофициальная модифицированная
 * версия» — её требует лицензия ZalithLauncher 2.
 */
@Composable
fun HomeHero(
    onChangeBackground: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val name = stringResource(R.string.app_name)
    // «MC» заливается градиентом, остальное — белое, как в макете.
    val title = remember(name) {
        val split = if (name.startsWith("MC")) 2 else 0
        buildAnnotatedString {
            if (split > 0) {
                withStyle(SpanStyle(brush = Brush.horizontalGradient(listOf(Color(0xFFB794FF), Color(0xFF7C6CFF))))) {
                    append(name.substring(0, split))
                }
            }
            withStyle(SpanStyle(color = Color.White)) { append(name.substring(split)) }
        }
    }
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.displaySmall.copy(
                    fontSize = 34.sp,
                    lineHeight = 38.sp,
                    fontWeight = FontWeight.ExtraBold,
                    shadow = TitleShadow,
                ),
                maxLines = 1,
            )
            Text(
                text = stringResource(R.string.home_tagline),
                style = MaterialTheme.typography.titleSmall.copy(
                    color = Color(0xFFCFC6FF),
                    fontWeight = FontWeight.Medium,
                    shadow = SubtitleShadow,
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = stringResource(R.string.home_unofficial),
                style = MaterialTheme.typography.labelSmall.copy(
                    color = Color(0xB3FFFFFF),
                    shadow = SubtitleShadow,
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        NeonIconButton(
            icon = LauncherIcons.Image,
            contentDescription = stringResource(R.string.background_change),
            onClick = onChangeBackground,
        )
    }
}

/** Ряд главных кнопок: «Играть» с градиентом и «Выбрать версию» в стекле. Кнопки компактные, не на всю ширину. */
@Composable
fun HomeActions(
    version: InstalledVersion?,
    launchPhase: LaunchPhase,
    onPlay: () -> Unit,
    onPickVersion: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NeonButton(
            text = stringResource(launchPhase.playLabelRes),
            onClick = onPlay,
            modifier = Modifier.width(168.dp),
            icon = Icons.Filled.PlayArrow,
            trailingIcon = LauncherIcons.ChevronRight,
            busy = launchPhase != LaunchPhase.IDLE,
            height = 44.dp,
        )
        NeonSecondaryButton(
            text = version?.id ?: stringResource(R.string.home_choose_version),
            onClick = onPickVersion,
            icon = LauncherIcons.Cube,
            trailingIcon = LauncherIcons.ChevronDown,
            height = 44.dp,
        )
    }
}

/**
 * Карточка «Последние версии»: выбранная (или самая новая из установленных) версия, метка и кнопка «Играть».
 * Если ничего не установлено — подсказка и кнопка установки.
 */
@Composable
fun LatestVersionsCard(
    version: InstalledVersion?,
    selected: Boolean,
    loaded: Boolean,
    canLaunch: Boolean,
    onPlay: (String) -> Unit,
    onOpenVersions: () -> Unit,
    onOpenAll: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    NeonCard(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = LauncherIcons.Cube,
                    contentDescription = null,
                    tint = colors.primary,
                    modifier = Modifier.size(20.dp),
                )
                Text(
                    text = stringResource(R.string.home_latest_title),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.onSurface,
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp),
                )
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(role = Role.Button, onClick = onOpenAll)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = stringResource(R.string.home_all_versions),
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.onSurfaceVariant,
                    )
                    Icon(
                        imageVector = LauncherIcons.ChevronRight,
                        contentDescription = null,
                        tint = colors.onSurfaceVariant,
                        modifier = Modifier.size(14.dp),
                    )
                }
            }

            when {
                // Пока список читается с диска, место просто занято: карточка не «прыгает».
                !loaded -> Box(Modifier.size(width = 1.dp, height = 44.dp))

                version == null -> Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = stringResource(R.string.home_no_versions_message),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    NeonButton(
                        text = stringResource(R.string.home_install_version),
                        onClick = onOpenVersions,
                        icon = Icons.Filled.Add,
                        height = 36.dp,
                    )
                }

                else -> VersionRow(
                    version = version,
                    selected = selected,
                    canLaunch = canLaunch,
                    onPlay = { onPlay(version.id) },
                )
            }
        }
    }
}

@Composable
private fun VersionRow(
    version: InstalledVersion,
    selected: Boolean,
    canLaunch: Boolean,
    onPlay: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val typeLabel = stringResource(version.type.labelRes)
    val releasePrefix = stringResource(R.string.home_released)
    // Подпись собирается только при смене версии, а не при каждой перекомпоновке.
    val subtitle = remember(version.releaseTime, typeLabel, releasePrefix) {
        releaseDate(version.releaseTime)?.let { "$releasePrefix: $it" } ?: typeLabel
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        VersionBlock(size = 40.dp)
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = version.id,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                NeonChip(
                    text = stringResource(if (selected) R.string.home_chip_selected else R.string.home_chip_installed),
                    success = true,
                )
            }
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        NeonButton(
            text = stringResource(R.string.play),
            onClick = onPlay,
            icon = Icons.Filled.PlayArrow,
            enabled = canLaunch,
            height = 36.dp,
        )
    }
}

/**
 * Значок версии: плоский изометрический блок «трава сверху, земля по бокам», нарисованный тремя многоугольниками.
 * Это обобщённый рисунок без текстур игры.
 */
@Composable
fun VersionBlock(size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        fun face(color: Color, vararg points: Pair<Float, Float>) {
            val path = Path().apply {
                moveTo(points[0].first * w, points[0].second * h)
                for (i in 1 until points.size) lineTo(points[i].first * w, points[i].second * h)
                close()
            }
            drawPath(path, color)
        }
        // верх, левая и правая грани
        face(Color(0xFF6BBF4E), 0.5f to 0.04f, 0.94f to 0.28f, 0.5f to 0.52f, 0.06f to 0.28f)
        face(Color(0xFF8A5A3B), 0.06f to 0.28f, 0.5f to 0.52f, 0.5f to 0.98f, 0.06f to 0.74f)
        face(Color(0xFF6E452D), 0.5f to 0.52f, 0.94f to 0.28f, 0.94f to 0.74f, 0.5f to 0.98f)
        // «шапка» травы на боковых гранях
        face(Color(0xFF58A63F), 0.06f to 0.28f, 0.5f to 0.52f, 0.5f to 0.64f, 0.06f to 0.4f)
        face(Color(0xFF4B9235), 0.5f to 0.52f, 0.94f to 0.28f, 0.94f to 0.4f, 0.5f to 0.64f)
    }
}

/** Карточка «Новости»: приветствие для новых пользователей. Содержимое пока зашито в приложение — ленты новостей нет. */
@Composable
fun NewsCard(modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    NeonCard(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = LauncherIcons.Versions,
                    contentDescription = null,
                    tint = colors.primary,
                    modifier = Modifier.size(20.dp),
                )
                Text(
                    text = stringResource(R.string.home_news_title),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.onSurface,
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                NewsArt(modifier = Modifier.size(width = 76.dp, height = 52.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.home_news_welcome_title),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = colors.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = stringResource(R.string.home_news_welcome_text),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

/** Картинка новости: фиолетовое небо, луна и силуэт башен — рисуется кодом, файлов с картинками в приложении нет. */
@Composable
private fun NewsArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.clip(RoundedCornerShape(10.dp))) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF2C1B6B), Color(0xFF8F5BD6))))
        drawCircle(Color(0xFFF0E6FF), radius = size.height * 0.12f, center = Offset(size.width * 0.74f, size.height * 0.26f))
        val tower = Color(0xFF140C33)
        fun rect(x: Float, y: Float, w: Float, h: Float) =
            drawRect(tower, Offset(size.width * x, size.height * y), Size(size.width * w, size.height * h))
        rect(0.00f, 0.72f, 1.00f, 0.28f)
        rect(0.14f, 0.46f, 0.12f, 0.30f)
        rect(0.18f, 0.36f, 0.04f, 0.12f)
        rect(0.34f, 0.56f, 0.10f, 0.20f)
        rect(0.52f, 0.40f, 0.14f, 0.36f)
        rect(0.56f, 0.28f, 0.06f, 0.14f)
        rect(0.76f, 0.58f, 0.12f, 0.18f)
    }
}
