package com.mclauncher.app.ui.components

/** Что делать с плеером видео-фона. */
enum class VideoPlayback {
    /** Видео на виду: играет. */
    PLAYING,

    /** Видео ненадолго скрыто: пауза, плеер и последний кадр остаются — возврат мгновенный. */
    PAUSED,

    /** Видео скрыто давно: плеер освобождён (декодер, память, батарея), при возврате создаётся заново. */
    RELEASED,
}

/**
 * Правило для видео-фона: оно играет только пока видно — то есть открыт главный экран и приложение на переднем плане.
 * Уйти в «Настройки» и сразу вернуться дёшево (пауза), а надолго — освободить плеер целиком.
 * Чистая логика без Android: проверяется JVM-тестами.
 */
object VideoPlaybackPolicy {

    /** Через сколько после скрытия видео плеер освобождается. */
    const val RELEASE_AFTER_MS: Long = 15_000L

    /** [hiddenForMs] — сколько видео уже скрыто (для видимого не используется). */
    fun stateFor(visible: Boolean, hiddenForMs: Long): VideoPlayback = when {
        visible -> VideoPlayback.PLAYING
        hiddenForMs >= RELEASE_AFTER_MS -> VideoPlayback.RELEASED
        else -> VideoPlayback.PAUSED
    }
}
