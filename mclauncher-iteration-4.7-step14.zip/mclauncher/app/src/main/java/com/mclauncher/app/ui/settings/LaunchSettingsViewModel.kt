package com.mclauncher.app.ui.settings

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mclauncher.app.LauncherApp
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.JvmArguments
import com.mclauncher.app.data.settings.LaunchSettings
import com.mclauncher.app.launch.DeviceMemory
import com.mclauncher.app.ui.common.UiEvent
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.IOException

/**
 * Раздел «Запуск и загрузка»: память игры, аргументы Java, число потоков загрузки. Значения сохраняются в DataStore;
 * запуск игры и установщик читают их при каждом запуске/установке (см. `LauncherViewModel.launchGame` и `LauncherApp`).
 */
class LaunchSettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val settings = (application as LauncherApp).settings

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events: Flow<UiEvent> = _events.receiveAsFlow()

    /** Память устройства, МБ: не меняется, пока приложение запущено. */
    val deviceTotalMb: Long = DeviceMemory.totalMb(application)

    val state: StateFlow<LaunchSettings> = settings.launch.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = LaunchSettings(),
    )

    fun setRamMb(value: Int) = save { it.copy(ramMb = LaunchSettings.clampRam(value, deviceTotalMb)) }

    fun setRamAuto() = save { it.copy(ramMb = null) }

    fun setJvmArguments(text: String) = save { it.copy(jvmArguments = text.take(JvmArguments.MAX_TEXT_LENGTH)) }

    fun setDownloadThreads(value: Int) = save { it.copy(downloadThreads = LaunchSettings.clampThreads(value)) }

    private fun save(transform: (LaunchSettings) -> LaunchSettings) {
        viewModelScope.launch {
            try {
                settings.updateLaunch(transform)
            } catch (e: IOException) {
                Log.w(TAG, "Failed to save launch settings", e)
                _events.trySend(UiEvent(R.string.error_settings_save))
            }
        }
    }

    private companion object {
        const val TAG = "LaunchSettingsVM"
    }
}
