package com.mclauncher.app.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Кнопка «Играть» на всю ширину панели: тот же синий градиент, что и у остальных главных кнопок,
 * но чуть выше (48 dp), потому что это главное действие экрана.
 */
@Composable
fun PlayButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    /** Идёт подготовка/запуск: вместо стрелки крутится индикатор, нажатия игнорируются. */
    busy: Boolean = false,
    enabled: Boolean = true,
) {
    NeonButton(
        text = label,
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        icon = Icons.Filled.PlayArrow,
        enabled = enabled,
        busy = busy,
        height = height,
    )
}
