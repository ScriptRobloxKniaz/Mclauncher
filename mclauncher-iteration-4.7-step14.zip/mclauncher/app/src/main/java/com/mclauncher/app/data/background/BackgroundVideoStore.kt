package com.mclauncher.app.data.background

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Видео-фон пользователя.
 *
 * Как и картинку, видео из галереи (SAF) один раз копируем в приватную папку приложения: не нужны постоянные
 * разрешения на чтение, фон не пропадёт, если файл удалят из галереи, и плеер читает обычный файл.
 * Копия идёт блоками и **прерывается вместе с корутиной**; во время копирования файл лежит под временным именем и
 * заменяет прежний видео-фон только целиком, поэтому оборванный импорт ничего не портит.
 *
 * Все методы работают на Dispatchers.IO. Ожидаемые сбои — [VideoImportException] с причиной.
 */
class BackgroundVideoStore(context: Context) {

    private val appContext = context.applicationContext
    private val dir get() = File(appContext.filesDir, "backgrounds")
    private val file get() = File(dir, FILE_NAME)

    /** Сохранённый файл или `null`, если его нет. Быстрая проверка наличия; вызывать не из главного потока. */
    fun fileOrNull(): File? = file.takeIf { it.isFile && it.length() > 0 }

    suspend fun importFrom(uri: Uri) {
        withContext(Dispatchers.IO) {
            val resolver = appContext.contentResolver
            val info = queryInfo(uri)
            if (!VideoImportPolicy.isAcceptable(resolver.getType(uri), info.name)) {
                throw VideoImportException(VideoImportReason.NOT_VIDEO, "Not a video: ${info.name}")
            }
            val declaredSize = info.size
            if (declaredSize != null && VideoImportPolicy.isTooLarge(declaredSize)) {
                throw VideoImportException(VideoImportReason.TOO_LARGE, "Declared size $declaredSize")
            }

            dir.mkdirs()
            if (declaredSize != null && !VideoImportPolicy.hasEnoughSpace(declaredSize, dir.usableSpace)) {
                throw VideoImportException(VideoImportReason.NO_SPACE, "Free space ${dir.usableSpace}")
            }

            val tmp = File(dir, "$FILE_NAME.tmp")
            try {
                val input = resolver.openInputStream(uri) ?: throw FileNotFoundException(uri.toString())
                input.use { source ->
                    tmp.outputStream().use { target ->
                        val buffer = ByteArray(BUFFER_BYTES)
                        var total = 0L
                        while (true) {
                            ensureActive() // отмена импорта (уход с экрана, новый выбор) останавливает копирование
                            val read = source.read(buffer)
                            if (read < 0) break
                            total += read
                            // Размер из провайдера бывает неизвестен или неверен, поэтому предел держим и при копировании.
                            if (VideoImportPolicy.isTooLarge(total)) {
                                throw VideoImportException(VideoImportReason.TOO_LARGE, "Copied more than the limit")
                            }
                            target.write(buffer, 0, read)
                        }
                    }
                }
                requireVideoTrack(tmp)
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
            } catch (e: VideoImportException) {
                tmp.delete()
                throw e
            } catch (e: IOException) {
                tmp.delete()
                throw if (e.isOutOfSpace()) VideoImportException(VideoImportReason.NO_SPACE, e.message) else e
            } catch (e: Throwable) {
                // Отмена корутины и прочее: временный файл не оставляем.
                tmp.delete()
                throw e
            }
        }
    }

    suspend fun delete() {
        withContext(Dispatchers.IO) {
            file.delete()
            File(dir, "$FILE_NAME.tmp").delete()
        }
    }

    /** В файле должна быть видеодорожка: так отсеиваются битые файлы и «видео» без картинки, пока они не стали фоном. */
    private fun requireVideoTrack(target: File) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(target.path)
            if (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) != "yes") {
                throw VideoImportException(VideoImportReason.NOT_VIDEO, "No video track")
            }
        } catch (e: VideoImportException) {
            throw e
        } catch (e: RuntimeException) {
            // Системный разборщик бросает RuntimeException на файлах, которые не умеет читать.
            throw VideoImportException(VideoImportReason.NOT_VIDEO, e.message)
        } finally {
            retriever.release()
        }
    }

    private class FileInfo(val name: String?, val size: Long?)

    private fun queryInfo(uri: Uri): FileInfo {
        val projection = arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        appContext.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                val name = if (nameIndex >= 0 && !cursor.isNull(nameIndex)) cursor.getString(nameIndex) else null
                val size = if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) cursor.getLong(sizeIndex) else null
                return FileInfo(name, size)
            }
        }
        return FileInfo(null, null)
    }

    private fun IOException.isOutOfSpace(): Boolean {
        val text = message.orEmpty()
        return text.contains("ENOSPC") || text.contains("No space left", ignoreCase = true)
    }

    private companion object {
        const val FILE_NAME = "custom_video.mp4"
        const val BUFFER_BYTES = 64 * 1024
    }
}
