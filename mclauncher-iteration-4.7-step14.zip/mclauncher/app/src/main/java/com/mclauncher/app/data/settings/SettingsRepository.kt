package com.mclauncher.app.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.mclauncher.app.data.versions.SelectedVersionSetting
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "launcher_settings")

/**
 * Настройки лаунчера в DataStore: выбор фона (картинка или видео, звук видео), графика (рендерер, версия OpenGL)
 * и выбранная версия игры; RAM, версия Java и прочее добавятся в итерации 8.
 *
 * Запись может бросить [IOException] — вызывающий код обязан её обработать.
 */
class SettingsRepository(context: Context) : SelectedVersionSetting {

    private val dataStore = context.applicationContext.settingsDataStore

    val background: Flow<BackgroundSelection> = dataStore.data
        .catch { e ->
            // Повреждённый файл настроек не должен ронять приложение: читаем значения по умолчанию.
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs -> prefs.toBackgroundSelection() }
        .distinctUntilChanged()

    suspend fun setBackgroundPreset(preset: BackgroundPreset) {
        dataStore.edit { prefs ->
            prefs[Keys.BackgroundType] = TYPE_PRESET
            prefs[Keys.BackgroundPreset] = preset.id
            prefs.remove(Keys.BackgroundStamp)
        }
    }

    suspend fun setBackgroundCustom(stamp: Long) {
        dataStore.edit { prefs ->
            prefs[Keys.BackgroundType] = TYPE_CUSTOM
            prefs[Keys.BackgroundStamp] = stamp
        }
    }

    // --- Видео-фон ---

    val videoBackground: Flow<VideoBackgroundSettings> = dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs -> prefs.toVideoSettings() }
        .distinctUntilChanged()

    /** Новое видео импортировано: запоминаем момент и сразу включаем видео-фон. Звук и громкость не трогаем. */
    suspend fun setVideoImported(stamp: Long) {
        dataStore.edit { prefs ->
            prefs[Keys.VideoStamp] = stamp
            prefs[Keys.VideoEnabled] = true
        }
    }

    /** Видео убрано: файл больше не нужен. Остальные настройки (звук, громкость) сохраняются для следующего видео. */
    suspend fun clearVideo() {
        dataStore.edit { prefs -> prefs.remove(Keys.VideoStamp) }
    }

    suspend fun setVideoEnabled(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[Keys.VideoEnabled] = enabled }
    }

    suspend fun setVideoMuted(muted: Boolean) {
        dataStore.edit { prefs -> prefs[Keys.VideoMuted] = muted }
    }

    suspend fun setVideoVolume(volume: Float) {
        dataStore.edit { prefs -> prefs[Keys.VideoVolume] = sanitizeVolume(volume) }
    }

    // --- Графика и рендеры ---

    val graphics: Flow<GraphicsSettings> = dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs -> prefs.toGraphics() }
        .distinctUntilChanged()

    /**
     * Меняет настройки графики одним действием: чтение, [transform] и запись идут внутри одной транзакции DataStore,
     * поэтому список рендеров, переключатель Zink и версия OpenGL не расходятся даже при быстрых нажатиях.
     */
    suspend fun updateGraphics(transform: (GraphicsSettings) -> GraphicsSettings) {
        dataStore.edit { prefs ->
            val next = transform(prefs.toGraphics())
            prefs[Keys.GraphicsRenderer] = next.renderer.id
            prefs[Keys.GraphicsGlVersion] = next.glVersion.id
            prefs[Keys.GraphicsUseZink] = next.useZink
        }
    }

    // --- Запуск и загрузка ---

    val launch: Flow<LaunchSettings> = dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs -> prefs.toLaunch() }
        .distinctUntilChanged()

    /** Меняет настройки запуска одной транзакцией DataStore: чтение, [transform] и запись не разъезжаются. */
    suspend fun updateLaunch(transform: (LaunchSettings) -> LaunchSettings) {
        dataStore.edit { prefs ->
            val next = transform(prefs.toLaunch())
            val ram = next.ramMb
            if (ram == null) prefs.remove(Keys.LaunchRamMb) else prefs[Keys.LaunchRamMb] = ram
            prefs[Keys.LaunchJvmArguments] = next.jvmArguments.take(JvmArguments.MAX_TEXT_LENGTH)
            prefs[Keys.DownloadThreads] = LaunchSettings.clampThreads(next.downloadThreads)
        }
    }

    override val selectedId: Flow<String?> = dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs -> prefs[Keys.SelectedVersion] }
        .distinctUntilChanged()

    override suspend fun setSelectedId(id: String?) {
        dataStore.edit { prefs ->
            if (id == null) prefs.remove(Keys.SelectedVersion) else prefs[Keys.SelectedVersion] = id
        }
    }

    private fun Preferences.toBackgroundSelection(): BackgroundSelection {
        val stamp = this[Keys.BackgroundStamp]
        return if (this[Keys.BackgroundType] == TYPE_CUSTOM && stamp != null) {
            BackgroundSelection.Custom(stamp)
        } else {
            BackgroundSelection.Preset(BackgroundPreset.fromId(this[Keys.BackgroundPreset]))
        }
    }

    /** По умолчанию видео включено, но **без звука**: так оно не раздражает при первом запуске. */
    private fun Preferences.toVideoSettings() = VideoBackgroundSettings(
        enabled = this[Keys.VideoEnabled] ?: true,
        volume = sanitizeVolume(this[Keys.VideoVolume] ?: VideoBackgroundSettings.DEFAULT_VOLUME),
        muted = this[Keys.VideoMuted] ?: true,
        stamp = this[Keys.VideoStamp],
    )

    private fun Preferences.toGraphics() = GraphicsSettings.fromStored(
        rendererId = this[Keys.GraphicsRenderer],
        glVersionId = this[Keys.GraphicsGlVersion],
        useZink = this[Keys.GraphicsUseZink],
    )

    private fun Preferences.toLaunch() = LaunchSettings.fromStored(
        ramMb = this[Keys.LaunchRamMb],
        jvmArguments = this[Keys.LaunchJvmArguments],
        downloadThreads = this[Keys.DownloadThreads],
    )

    private object Keys {
        val LaunchRamMb = intPreferencesKey("launch_ram_mb")
        val LaunchJvmArguments = stringPreferencesKey("launch_jvm_arguments")
        val DownloadThreads = intPreferencesKey("download_threads")
        val GraphicsRenderer = stringPreferencesKey("graphics_renderer")
        val GraphicsGlVersion = stringPreferencesKey("graphics_gl_version")
        val GraphicsUseZink = booleanPreferencesKey("graphics_use_zink")
        val BackgroundType = stringPreferencesKey("background_type")
        val BackgroundPreset = stringPreferencesKey("background_preset")
        val BackgroundStamp = longPreferencesKey("background_stamp")
        val SelectedVersion = stringPreferencesKey("selected_version_id")
        val VideoEnabled = booleanPreferencesKey("video_enabled")
        val VideoMuted = booleanPreferencesKey("video_muted")
        val VideoVolume = floatPreferencesKey("video_volume")
        val VideoStamp = longPreferencesKey("video_stamp")
    }

    private companion object {
        const val TYPE_PRESET = "preset"
        const val TYPE_CUSTOM = "custom"
    }
}
