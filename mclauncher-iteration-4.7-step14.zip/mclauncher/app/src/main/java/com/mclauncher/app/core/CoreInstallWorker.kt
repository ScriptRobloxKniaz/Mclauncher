package com.mclauncher.app.core

import android.content.Context
import android.os.SystemClock
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.mclauncher.app.LauncherApp
import com.mclauncher.engine.install.CoreInstallException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/**
 * Фоновая установка игрового ядра: служба переднего плана (тип dataSync) с уведомлением и кнопкой «Отмена».
 * Работа живёт в WorkManager, поэтому не обрывается при уходе с экрана и после перезапуска процесса начинается заново
 * (установленные компоненты пропускаются, недоделанные ставятся с нуля: временные папки удаляются).
 */
class CoreInstallWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val manager = (applicationContext as LauncherApp).coreManager
        val notifier = CoreNotifier(applicationContext, id)

        // С Android 12 службу переднего плана нельзя запускать из фона; установка стартует по нажатию кнопки,
        // так что обычно всё в порядке. Если система отказала — работаем как обычная фоновая работа.
        try {
            setForeground(notifier.foregroundInfo(null))
        } catch (e: Exception) {
            Log.w(TAG, "Cannot start the foreground service, continuing in the background: ${e.message}")
        }

        return withContext(Dispatchers.IO) {
            try {
                var lastUpdate = 0L
                manager.installAllBlocking { progress ->
                    ensureActive() // отмена пользователем: исключение прервёт установку, установщик уберёт временные папки
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastUpdate >= UPDATE_INTERVAL_MS || progress.doneBytes >= progress.totalBytes) {
                        lastUpdate = now
                        setProgressAsync(
                            workDataOf(
                                CoreInstallManager.KEY_DONE to progress.doneBytes,
                                CoreInstallManager.KEY_TOTAL to progress.totalBytes,
                                CoreInstallManager.KEY_LABEL to progress.label,
                            ),
                        )
                        notifier.update(progress)
                    }
                }
                manager.refresh()
                Result.success()
            } catch (e: CancellationException) {
                throw e
            } catch (e: CoreInstallException) {
                Log.e(TAG, "Core installation failed: ${e.message}", e)
                failure(e.toFailure(), e.message)
            } catch (e: Exception) {
                Log.e(TAG, "Core installation crashed", e)
                failure(CoreFailure.OTHER, e.message)
            }
        }
    }

    private fun failure(kind: CoreFailure, detail: String?): Result = Result.failure(
        workDataOf(
            CoreInstallManager.KEY_FAILURE to kind.name,
            CoreInstallManager.KEY_DETAIL to detail.orEmpty().take(MAX_DETAIL),
        ),
    )

    private companion object {
        const val TAG = "CoreInstallWorker"
        const val UPDATE_INTERVAL_MS = 300L
        const val MAX_DETAIL = 500 // данные WorkManager ограничены 10 КБ
    }
}
