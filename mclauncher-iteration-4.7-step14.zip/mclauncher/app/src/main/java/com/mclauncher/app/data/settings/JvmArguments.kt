package com.mclauncher.app.data.settings

/** Почему аргумент из поля «Аргументы Java» не будет передан игре. Тексты подбирает UI-слой. */
enum class RejectReason {
    /** Слово без «-» в начале. JVM приняла бы его за имя главного класса и запустила бы не игру. */
    NOT_AN_OPTION,

    /** Память: её задаёт ползунок «Память игры», два источника дали бы неопределённость. */
    MEMORY,

    /** Лаунчер задаёт это сам (classpath, пути к библиотекам, рендерер) или аргумент мешает запуску (`-version`). */
    MANAGED,

    /** Шаблон `${…}`: подставляет только лаунчер, а в пользовательском тексте он остался бы нераскрытым. */
    TEMPLATE,
}

data class RejectedArgument(val argument: String, val reason: RejectReason)

/**
 * Разбор строки «Аргументы Java» из настроек: делит её на аргументы и отсеивает те, что сломали бы запуск.
 * Отсев — не цензура: у каждого отклонённого есть причина, которую видит игрок.
 *
 * Разделитель — пробел; аргумент с пробелом внутри можно взять в двойные кавычки (`"-Dname=a b"`), сами кавычки
 * в аргумент не попадают. Экранирования нет.
 */
class JvmArguments private constructor(
    val accepted: List<String>,
    val rejected: List<RejectedArgument>,
) {
    companion object {
        /** Сколько символов принимает поле: хватает на десяток флагов, а файл настроек не раздувается. */
        const val MAX_TEXT_LENGTH = 2000

        fun parse(text: String): JvmArguments {
            val accepted = ArrayList<String>()
            val rejected = ArrayList<RejectedArgument>()
            for (token in tokenize(text.take(MAX_TEXT_LENGTH))) {
                val reason = rejectionOf(token)
                if (reason == null) accepted += token else rejected += RejectedArgument(token, reason)
            }
            return JvmArguments(accepted, rejected)
        }

        fun tokenize(text: String): List<String> {
            val result = ArrayList<String>()
            val current = StringBuilder()
            var inQuotes = false
            var hasToken = false
            for (ch in text) {
                when {
                    ch == '"' -> {
                        inQuotes = !inQuotes
                        hasToken = true
                    }
                    ch.isWhitespace() && !inQuotes -> {
                        if (hasToken) result += current.toString()
                        current.setLength(0)
                        hasToken = false
                    }
                    else -> {
                        current.append(ch)
                        hasToken = true
                    }
                }
            }
            if (hasToken) result += current.toString()
            return result.filter { it.isNotEmpty() }
        }

        private fun rejectionOf(token: String): RejectReason? = when {
            token.contains("\${") -> RejectReason.TEMPLATE
            !token.startsWith("-") -> RejectReason.NOT_AN_OPTION
            MEMORY_PREFIXES.any { token.startsWith(it) } -> RejectReason.MEMORY
            token in MANAGED_EXACT || MANAGED_PREFIXES.any { token.startsWith(it) } -> RejectReason.MANAGED
            else -> null
        }

        private val MEMORY_PREFIXES = listOf("-Xmx", "-Xms", "-XX:MaxHeapSize", "-XX:InitialHeapSize")

        private val MANAGED_EXACT = setOf(
            "-cp", "-classpath", "--class-path", "-jar",
            "-version", "--version", "-showversion", "--show-version", "-help", "--help", "-h", "-?", "-X",
        )

        private val MANAGED_PREFIXES = listOf(
            "--class-path=",
            "-Djava.library.path",
            "-Dorg.lwjgl.librarypath",
            "-Dorg.lwjgl.opengl.libname",
            "-Dminecraft.client.jar",
        )
    }
}
