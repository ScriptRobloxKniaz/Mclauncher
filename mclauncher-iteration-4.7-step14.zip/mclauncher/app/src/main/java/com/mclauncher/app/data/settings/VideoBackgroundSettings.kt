package com.mclauncher.app.data.settings

/**
 * Настройки видео-фона.
 *
 * Видео по умолчанию идёт **без звука**: [muted] включён с самого начала, звук появляется только после явного
 * действия пользователя в «Настройках». Сам файл лежит в приватной папке приложения
 * (см. [com.mclauncher.app.data.background.BackgroundVideoStore]), а [stamp] — момент его импорта: он меняется при
 * каждом новом видео и заставляет плеер начать заново. `null` — видео не выбрано.
 */
data class VideoBackgroundSettings(
    /** Переключатель «Видео-фон». Выключенное видео не воспроизводится, но остаётся выбранным. */
    val enabled: Boolean = true,
    /** Громкость от 0 до 1, когда звук включён. */
    val volume: Float = DEFAULT_VOLUME,
    val muted: Boolean = true,
    val stamp: Long? = null,
) {
    val hasVideo: Boolean get() = stamp != null

    /** Видео нужно показывать прямо сейчас: оно выбрано и не выключено. */
    val active: Boolean get() = enabled && hasVideo

    /** Громкость, с которой реально играет плеер: при выключенном звуке — всегда 0. */
    val effectiveVolume: Float get() = if (muted) 0f else sanitizeVolume(volume)

    companion object {
        const val DEFAULT_VOLUME = 0.5f
    }
}

/** Приводит громкость к диапазону 0..1; «не число» из повреждённых настроек заменяется значением по умолчанию. */
fun sanitizeVolume(value: Float): Float = when {
    value.isNaN() -> VideoBackgroundSettings.DEFAULT_VOLUME
    value < 0f -> 0f
    value > 1f -> 1f
    else -> value
}
