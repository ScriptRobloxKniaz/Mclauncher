package com.mclauncher.app.ui.settings

import android.content.pm.PackageManager
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.GraphicsSettings
import com.mclauncher.app.data.settings.OpenGlVersion
import com.mclauncher.app.data.settings.Renderer
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.components.NeonDropdown

/** Состояние раздела «Графика и рендеры» и его действия. */
@Immutable
data class GraphicsControls(
    val settings: GraphicsSettings,
    val onRendererChange: (Renderer) -> Unit,
    val onUseZinkChange: (Boolean) -> Unit,
    val onGlVersionChange: (OpenGlVersion) -> Unit,
)

@get:StringRes
private val Renderer.labelRes: Int
    get() = when (this) {
        Renderer.GL4ES -> R.string.graphics_renderer_gl4es
        Renderer.KRYPTON -> R.string.graphics_renderer_krypton
        Renderer.MOBILEGLUES -> R.string.graphics_renderer_mobileglues
        Renderer.ZINK -> R.string.graphics_renderer_zink
    }

/** Короткая справка о рендерере: для каких версий игры он годится. */
@get:StringRes
private val Renderer.noteRes: Int
    get() = when (this) {
        Renderer.GL4ES -> R.string.graphics_note_gl4es
        Renderer.KRYPTON -> R.string.graphics_note_krypton
        Renderer.MOBILEGLUES -> R.string.graphics_note_mobileglues
        Renderer.ZINK -> R.string.graphics_note_zink
    }

/** Vulkan 1.1 в кодировке Android: major 1, minor 1. Именно с него Zink работает на телефонах. */
private const val VULKAN_1_1 = 0x00401000

/**
 * Раздел «Графика и рендеры» (как в PojavLauncher): выбор рендерера, версия OpenGL для GL4ES и переключатель
 * «Использовать Zink». Список и переключатель всегда согласованы (см. [GraphicsSettings]). Выбор действует со
 * следующего запуска игры (см. `toRendererProfile`).
 */
@Composable
fun GraphicsSection(graphics: GraphicsControls, modifier: Modifier = Modifier) {
    val settings = graphics.settings
    val colors = MaterialTheme.colorScheme
    val context = LocalContext.current
    // Проверка Vulkan не меняется, пока экран открыт, — считаем один раз.
    val vulkanSupported = remember(context) {
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_VERSION, VULKAN_1_1)
    }
    val zinkSwitchLabel = stringResource(R.string.graphics_zink_switch)

    NeonCard(modifier = modifier) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = LauncherIcons.Sun,
                    contentDescription = null,
                    tint = colors.primary,
                    modifier = Modifier.size(24.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.graphics_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.onSurface,
                    )
                    Text(
                        text = stringResource(R.string.graphics_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                    )
                }
            }

            LabeledField(label = stringResource(R.string.graphics_renderer)) {
                NeonDropdown(
                    options = Renderer.entries,
                    selected = settings.renderer,
                    optionLabel = { renderer -> stringResource(renderer.labelRes) },
                    onSelect = graphics.onRendererChange,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    text = stringResource(settings.renderer.noteRes),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant,
                )
            }

            LabeledField(label = stringResource(R.string.graphics_gl_version)) {
                NeonDropdown(
                    options = OpenGlVersion.entries,
                    selected = settings.glVersion,
                    optionLabel = { version ->
                        version.numberLabel ?: stringResource(R.string.graphics_gl_auto)
                    },
                    onSelect = graphics.onGlVersionChange,
                    enabled = settings.glVersionApplies,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (!settings.glVersionApplies) {
                    Text(
                        text = stringResource(R.string.graphics_gl_version_note),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.graphics_zink),
                        style = MaterialTheme.typography.labelLarge,
                        color = colors.onSurface,
                    )
                    Text(
                        text = stringResource(R.string.graphics_zink_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = settings.useZink,
                    onCheckedChange = graphics.onUseZinkChange,
                    modifier = Modifier.semantics { contentDescription = zinkSwitchLabel },
                )
            }

            if (settings.effectiveRenderer.needsVulkan && !vulkanSupported) {
                Text(
                    text = stringResource(R.string.graphics_no_vulkan),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.error,
                )
            }

            Text(
                text = stringResource(R.string.graphics_saved_note),
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
            )
        }
    }
}

/** Подпись над полем ввода/списка и само поле под ней. */
@Composable
private fun LabeledField(label: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )
        content()
    }
}
