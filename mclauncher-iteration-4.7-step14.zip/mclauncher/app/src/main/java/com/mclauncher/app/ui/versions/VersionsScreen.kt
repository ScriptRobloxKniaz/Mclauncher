package com.mclauncher.app.ui.versions

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mclauncher.app.R
import com.mclauncher.app.data.versions.InstallError
import com.mclauncher.app.data.versions.InstallState
import com.mclauncher.app.data.versions.InstalledVersion
import com.mclauncher.app.data.versions.ManifestEntry
import com.mclauncher.app.data.versions.VersionFilter
import com.mclauncher.app.ui.common.CollectUiEvents
import com.mclauncher.app.ui.common.rememberNotificationPermissionGate

/**
 * Экран «Версии»: установка версий Mojang на устройство, выбор версии для кнопки «Играть» и удаление.
 * Установка продолжается, если уйти с экрана: ею управляет менеджер уровня приложения.
 */
@Composable
fun VersionsScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: VersionsViewModel = viewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()
    CollectUiEvents(viewModel.events)
    // Перед установкой спрашиваем про уведомления: с ними загрузка в фоне показывает прогресс в шторке.
    val withNotificationPermission = rememberNotificationPermissionGate()

    // Храним только id: по нему диалог сам закроется, если версия пропала из списка.
    var pendingDeleteId by rememberSaveable { mutableStateOf<String?>(null) }
    val pendingDelete = state.listing.installed.firstOrNull { it.id == pendingDeleteId }

    val running = state.install as? InstallState.Running
    val failed = state.install as? InstallState.Failed

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .widthIn(max = 640.dp)
                .fillMaxHeight(),
        ) {
            VersionsTopBar(refreshing = state.refreshing, onBack = onBack, onRefresh = viewModel::reload)

            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (failed != null) {
                    item(key = "install-error") {
                        InstallErrorCard(
                            versionId = failed.versionId,
                            error = failed.error,
                            onDismiss = viewModel::dismissInstallError,
                        )
                    }
                }

                val catalog = state.catalog
                if (catalog is CatalogUi.Loaded && catalog.fromCache) {
                    item(key = "offline") { InfoCard(text = stringResource(R.string.versions_offline_banner)) }
                }

                item(key = "search") {
                    OutlinedTextField(
                        value = query,
                        onValueChange = viewModel::setQuery,
                        singleLine = true,
                        label = { Text(stringResource(R.string.versions_search)) },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setQuery("") }) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = stringResource(R.string.versions_search_clear),
                                    )
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                item(key = "filters") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VersionFilter.entries.forEach { option ->
                            FilterChip(
                                selected = state.filter == option,
                                onClick = { viewModel.setFilter(option) },
                                label = { Text(stringResource(option.labelRes)) },
                            )
                        }
                    }
                }

                if (state.filter == VersionFilter.OLD) {
                    item(key = "old-hint") { InfoCard(text = stringResource(R.string.versions_old_hint)) }
                }

                if (state.listing.installed.isNotEmpty()) {
                    item(key = "installed-header") { SectionTitle(stringResource(R.string.versions_section_installed)) }
                    items(state.listing.installed, key = { "installed:${it.id}" }) { version ->
                        InstalledCard(
                            version = version,
                            selected = version.id == state.selectedId,
                            onSelect = { viewModel.select(version.id) },
                            onDelete = { pendingDeleteId = version.id },
                        )
                    }
                }

                item(key = "available-header") { SectionTitle(stringResource(R.string.versions_section_available)) }
                when (val catalogState = state.catalog) {
                    CatalogUi.Loading -> item(key = "loading") { LoadingBlock() }

                    is CatalogUi.Failed -> item(key = "load-failed") {
                        LoadFailedCard(error = catalogState.error, onRetry = viewModel::reload)
                    }

                    is CatalogUi.Loaded -> {
                        if (state.listing.available.isEmpty()) {
                            item(key = "empty") {
                                Text(
                                    text = stringResource(R.string.versions_empty_available),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 16.dp),
                                )
                            }
                        } else {
                            items(state.listing.available, key = { "available:${it.id}" }) { entry ->
                                AvailableCard(
                                    entry = entry,
                                    isLatest = entry.id == state.latestRelease,
                                    running = running?.takeIf { it.versionId == entry.id },
                                    canInstall = running == null,
                                    onInstall = { withNotificationPermission { viewModel.install(entry) } },
                                    onCancel = viewModel::cancelInstall,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    pendingDelete?.let { version ->
        AlertDialog(
            onDismissRequest = { pendingDeleteId = null },
            title = { Text(stringResource(R.string.versions_delete_title)) },
            text = { Text(stringResource(R.string.versions_delete_message, version.id)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        pendingDeleteId = null
                        viewModel.delete(version.id)
                    },
                ) { Text(stringResource(R.string.delete_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteId = null }) { Text(stringResource(R.string.action_cancel)) }
            },
        )
    }
}

@Composable
private fun VersionsTopBar(
    refreshing: Boolean,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = stringResource(R.string.action_back),
            )
        }
        Text(
            text = stringResource(R.string.versions_title),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f),
        )
        // Рамка одного размера, чтобы заголовок не дёргался, когда кнопка меняется на индикатор.
        Box(modifier = Modifier.size(48.dp), contentAlignment = Alignment.Center) {
            if (refreshing) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
            } else {
                IconButton(onClick = onRefresh) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = stringResource(R.string.versions_refresh),
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 6.dp),
    )
}

@Composable
private fun LoadingBlock() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
        contentAlignment = Alignment.Center,
    ) {
        CircularProgressIndicator()
    }
}

@Composable
private fun InfoCard(text: String, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f),
        modifier = modifier.fillMaxWidth(),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(12.dp),
        )
    }
}

@Composable
private fun InstallErrorCard(
    versionId: String,
    error: InstallError,
    onDismiss: () -> Unit,
) {
    val detail = installErrorDetail(error)
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.errorContainer,
        contentColor = MaterialTheme.colorScheme.onErrorContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(start = 14.dp, top = 12.dp, end = 8.dp, bottom = 4.dp)) {
            Text(
                text = stringResource(R.string.install_error_title, versionId),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = installErrorMessage(error),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp),
            )
            if (detail != null) {
                Text(
                    text = stringResource(R.string.launch_details, detail),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_ok)) }
            }
        }
    }
}

@Composable
private fun LoadFailedCard(
    error: InstallError,
    onRetry: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.92f),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = stringResource(R.string.versions_load_failed_title),
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
            )
            Text(
                text = catalogErrorMessage(error),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Button(onClick = onRetry) { Text(stringResource(R.string.versions_retry)) }
        }
    }
}

@Composable
private fun InstalledCard(
    version: InstalledVersion,
    selected: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val date = releaseDate(version.releaseTime)
    Card(
        onClick = onSelect,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) colors.primaryContainer.copy(alpha = 0.95f) else colors.surface.copy(alpha = 0.90f),
            contentColor = if (selected) colors.onPrimaryContainer else colors.onSurface,
        ),
        border = if (selected) BorderStroke(2.dp, colors.primary) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    ) {
        Row(
            modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = version.id,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = listOfNotNull(stringResource(version.type.labelRes), date).joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            if (selected) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text(
                        text = stringResource(R.string.versions_selected),
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
            } else {
                TextButton(onClick = onSelect) { Text(stringResource(R.string.versions_select)) }
            }
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = stringResource(R.string.versions_delete_cd, version.id),
                )
            }
        }
    }
}

@Composable
private fun AvailableCard(
    entry: ManifestEntry,
    isLatest: Boolean,
    running: InstallState.Running?,
    canInstall: Boolean,
    onInstall: () -> Unit,
    onCancel: () -> Unit,
) {
    val date = releaseDate(entry.releaseTime)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.90f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            text = entry.id,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        if (isLatest) LatestBadge()
                    }
                    Text(
                        text = listOfNotNull(stringResource(entry.type.labelRes), date).joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (running == null) {
                    FilledTonalButton(onClick = onInstall, enabled = canInstall) {
                        Text(stringResource(R.string.versions_install))
                    }
                } else {
                    TextButton(onClick = onCancel) { Text(stringResource(R.string.action_cancel)) }
                }
            }
            if (running != null) {
                val fraction = running.progress?.fraction
                Column(
                    modifier = Modifier.padding(top = 8.dp, end = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    if (fraction == null) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    } else {
                        LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
                    }
                    Text(
                        text = installPhaseLabel(running.progress),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun LatestBadge() {
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.tertiaryContainer,
        contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
    ) {
        Text(
            text = stringResource(R.string.versions_latest),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
        )
    }
}

@Composable
private fun catalogErrorMessage(error: InstallError): String = when (error) {
    is InstallError.Network -> stringResource(R.string.versions_load_error_network)
    is InstallError.Server -> stringResource(R.string.install_error_server, error.status)
    is InstallError.BadData -> stringResource(R.string.versions_load_error_bad)
    else -> stringResource(R.string.versions_load_error_other)
}
