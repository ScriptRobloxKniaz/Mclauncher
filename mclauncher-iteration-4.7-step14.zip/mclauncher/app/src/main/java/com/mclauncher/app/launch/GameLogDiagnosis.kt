package com.mclauncher.app.launch

import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

/** Вероятная причина, которую можно подсказать по журналу игры. */
enum class LogHint {
    /** Не хватило памяти или система не смогла выделить столько, сколько запросили. */
    MEMORY,

    /** Версия Java не подходит версии игры. */
    JAVA_VERSION,

    /** Не загрузилась нативная библиотека. */
    NATIVE_LIBRARY,

    /** Ошибка графики: окно или контекст OpenGL не создались. */
    GRAPHICS,
}

/**
 * Разбор журнала игры (`logs/latest.log`) после вылета: хвост журнала для показа и подсказки по известным признакам.
 * Признаки — устойчивые сообщения самой Java и LWJGL/GLFW; подсказка лишь предположение, поэтому формулируется осторожно.
 */
object GameLogDiagnosis {

    const val DEFAULT_MAX_LINES = 40
    const val DEFAULT_MAX_BYTES = 24 * 1024

    /**
     * Последние [maxLines] строк файла (читаются не больше [maxBytes] с конца) или `null`, если файла нет, он пуст или
     * не читается. Работа с диском: вызывать вне главного потока.
     */
    fun tail(file: File?, maxLines: Int = DEFAULT_MAX_LINES, maxBytes: Int = DEFAULT_MAX_BYTES): String? {
        if (file == null || maxLines <= 0 || maxBytes <= 0) return null
        return try {
            if (!file.isFile) return null
            RandomAccessFile(file, "r").use { raf ->
                val length = raf.length()
                if (length <= 0L) return null
                val start = (length - maxBytes).coerceAtLeast(0L)
                val bytes = ByteArray((length - start).toInt())
                raf.seek(start)
                raf.readFully(bytes)
                var text = String(bytes, Charsets.UTF_8)
                // Начало могло оказаться посреди строки (или посреди символа): неполную первую строку отбрасываем.
                if (start > 0L) text = text.substringAfter('\n', missingDelimiterValue = "")
                val lines = text.trimEnd().lines()
                lines.takeLast(maxLines).joinToString("\n").ifBlank { null }
            }
        } catch (e: IOException) {
            null
        }
    }

    /** Подсказки по тексту журнала; порядок стабильный, без повторов. */
    fun hints(text: String?): List<LogHint> {
        if (text.isNullOrBlank()) return emptyList()
        val lower = text.lowercase()
        val result = ArrayList<LogHint>()
        if ("outofmemoryerror" in lower || "could not reserve enough space" in lower ||
            "insufficient memory for the java runtime" in lower || "cannot allocate memory" in lower
        ) {
            result += LogHint.MEMORY
        }
        if ("unsupportedclassversionerror" in lower || "more recent version of the java runtime" in lower) {
            result += LogHint.JAVA_VERSION
        }
        if ("unsatisfiedlinkerror" in lower) result += LogHint.NATIVE_LIBRARY
        if ("glfw error" in lower || "failed to create the glfw window" in lower || "unable to create opengl" in lower ||
            "failed to create window" in lower
        ) {
            result += LogHint.GRAPHICS
        }
        return result
    }
}
