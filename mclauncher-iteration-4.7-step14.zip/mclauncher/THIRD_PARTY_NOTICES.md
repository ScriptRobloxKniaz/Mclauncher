# Сторонний код и компоненты

Приложение распространяется под **GPL-3.0** (файл [LICENSE](LICENSE)). Этот файл перечисляет то, что
взято у других проектов. Он ведётся по факту: что реально есть в репозитории — в разделе 1; что будет
включается в APK, когда перед сборкой выполнен `scripts/fetch_core.py --install` (этап 4.7b-1), — в разделе 2.
Файлы ядра в репозиторий не копируются. Я не юрист: это перечень источников, а не юридическое заключение.

## 1. Код, портированный в этот репозиторий (с этапа 4.7a)

### ZalithLauncher 2

- Проект: <https://github.com/ZalithLauncher/ZalithLauncher2>
- Лицензия: **GPL-3.0** с дополнительными условиями по разделу 7 (см. ниже).
- Авторские права: Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors.
- Ревизия, по которой написан порт: `144767e74d26a3fd9c378b8cb13a7a92684c8635` (закреплена в `engine/UPSTREAM`).

Что взято — не копированием файлов, а переписыванием логики на Kotlin под наши типы. Источник каждого правила
указан комментарием в коде:

| Где у нас | Откуда (файл апстрима) | Что |
|---|---|---|
| `engine/…/LwjglVersion.kt` | `game/launch/LaunchArgs.kt` | выбор набора LWJGL по версии игры, порядок jar'ов в classpath |
| `engine/…/LaunchCommandBuilder.kt` | `game/launch/LaunchArgs.kt`, `game/launch/Launcher.kt` | сборка команды запуска JVM: подмена `-Djava.library.path`, свойства окружения Android, память, `mio.Wrapper`, `--add-exports` |
| `engine/…/EngineLayout.kt` | `components/Components.kt`, `path/LibPath.kt` | имена папок и файлов компонентов ядра |
| `app/…/data/versions/EngineLibraryPolicy.kt` | `game/version/download/_LibraryReplacement.kt` | какие библиотеки не нужны, три замены (JNA, OSHI, asm-all) с их SHA-1 и размерами |
| `app/…/launch/LaunchSpecFactory.kt` | `game/launch/LaunchArgs.kt`, `game/launch/LibSortFix.kt` | значения шаблонов аккаунта и папок, правило про asm-all |
| `engine/…/launch/NativeLaunchPlanner.kt` | `game/launch/Launcher.kt` | пути поиска библиотек JVM, переменные окружения, порядок `dlopen` рантайма |
| `engine/…/launch/RendererProfile.kt` | `game/renderer/renderers/{GL4ES,NGGL4ES,MobileGlues,KopperZink}Renderer.kt`, `game/launch/GameLauncher.kt` | идентификаторы, библиотеки и переменные окружения четырёх рендереров (GL4ES, Krypton, MobileGlues, Zink) |
| `engine/…/launch/GameRunner.kt` | `game/launch/Launcher.kt` (`launchJvm`) | порядок шагов запуска JVM в процессе игры |
| `engine/src/main/java/com/movtery/zalithlauncher/bridge/{ZLBridge,LoggerBridge,NativeLibraryLoader}.java`, `…/org/lwjgl/glfw/GraphicOutputListener.java` | одноимённые файлы апстрима | **копии без изменений** (GPL-заголовки сохранены); имена вшиты в нативный код |
| `engine/src/main/java/com/oracle/dalvik/VMLauncher.java` | одноимённый файл апстрима | копия с пометкой происхождения |
| `engine/src/main/java/com/movtery/zalithlauncher/bridge/ZLNativeInvoker.java`, `…/org/lwjgl/glfw/CallbackBridge.java` | одноимённые файлы апстрима | **переписаны**: оставлены только имена и сигнатуры, которые ищет нативный код; логика приложения Zalith (настройки, Compose-состояние) заменена маленьким интерфейсом `Host` |

**Дополнительные условия Zalith (раздел 7 GPLv3), которые нужно выполнять:**

1. Распространяемая изменённая версия не должна называться «ZalithLauncher» или «ZL» и должна на стартовом экране
   или главном интерфейсе явно называться «неофициальной модифицированной версией».
   Наше имя — MCLauncher. Пометка «Неофициальная модифицированная версия» **есть на главном экране** (шапка,
   строка `home_unofficial`) — добавлена до того, как в APK начали попадать файлы Zalith (4.7b-1).
2. Нельзя удалять показываемые программой уведомления об авторских правах. Экран «О лаунчере» (боковое меню) их
   показывает: лицензию приложения, авторские права Zalith, лицензию Pojav, оговорку про торговую марку Minecraft и
   ссылку на исходный код. Полного списка библиотек с текстами лицензий там пока нет — он остаётся на этап 8.

### PojavLauncher

- Проект: <https://github.com/PojavLauncherTeam/PojavLauncher>
- Лицензия: **LGPL-3.0** (по README репозитория).
- Через Zalith 2 в порт попала идея сборки classpath по описанию версии: в исходниках Zalith эти функции помечены
  как «Modified from PojavLauncher» (`Tools.java`). Сам код Pojav напрямую в репозиторий не копировался.

## 1a. Библиотеки, подключённые через Gradle

Подтягиваются при сборке из Google Maven и Maven Central, в репозиторий не копируются; перечень и версии —
`gradle/libs.versions.toml`. **AndroidX Media3** (`media3-exoplayer`, `media3-ui`) проигрывает видео-фон,
**AndroidX WorkManager** запускает установку ядра в фоне. Библиотеки AndroidX, Kotlin, kotlinx.coroutines и
kotlinx.serialization распространяются по лицензии **Apache-2.0** (по их собственным репозиториям).
**Apache Commons Compress** (Apache-2.0) читает tar-архивы рантаймов, **XZ for Java** (`org.tukaani:xz`, по
сведениям проекта — общественное достояние/0BSD) снимает сжатие `.xz`; оба подключены в `:engine`, версии взяты из
каталога Zalith на закреплённой ревизии. Точные тексты лицензий нужно собрать в экран «О приложении» (этап 8).

## 2. Компоненты ядра в APK (этап 4.7b-1 и далее)

С 4.7b-1 скрипт `scripts/fetch_core.py --install` кладёт в `:engine` (а значит, в APK, собранный после него) такие
файлы из закреплённой ревизии Zalith — это **факт**, а не план:

| Что кладётся | Откуда у Zalith | Лицензия по сведениям апстрима |
|---|---|---|
| `launcher/MioLaunchWrapper.jar`, `launcher/MioLibPatcher.jar` | `assets/components/launcher` | **не найдена** (в jar'ах нет файла лицензии; `MioLibPatcher` содержит классы javassist) |
| jar'ы LWJGL 3.3.3 и 3.4.1 (пропатченные) | `assets/app_runtime/lwjgl` | BSD-3-Clause (LWJGL); сами патчи — по лицензии Zalith |
| нативы LWJGL arm64 (`liblwjgl*.so`, `libfreetype.so`, `libshaderc.so`) | AAR `lwjgl-<версия>-natives-release` | BSD-3-Clause и лицензии вложенных библиотек (FreeType, GLFW, shaderc, stb, Khronos и др.); их тексты лежат в `assets/core/licenses/lwjgl-natives-*` |
| `libopenal.so` | AAR `openal-soft-release` | OpenAL Soft (в AAR тексты: LGPL/GPL-2, Apache-2.0 для Oboe, лицензия PFFFT); лежат в `assets/core/licenses/openal-soft` |
| Рантаймы Java 8, 17, 21 (arm64) | `assets/runtimes/jre-*` | OpenJDK, GPLv2 с Classpath Exception (по README Pojav: «GPLv2»; наличие исключения нужно подтвердить по `LICENSE` внутри архивов) |
| `libunpack200.so` | `jniLibs/arm64-v8a` | часть OpenJDK (GPLv2) — уточнить |
| `libgl4es_114.so` (рендерер GL4ES) | `jniLibs/arm64-v8a` | по таблице README апстрима: gl4es_extra_extra / NG-GL4ES — MIT; для именно этого файла **не проверено** |
| `libmobileglues.so` (рендерер MobileGlues) | AAR `MobileGlues-release.aar` | **LGPL-2.1**, «Copyright (c) 2025 MobileGL-Dev»: текст лицензии лежит в самом AAR и копируется в `assets/core/licenses/mobileglues` (подтверждено по содержимому AAR) |
| `libng_gl4es.so` (рендерер Krypton Wrapper, NG-GL4ES) | AAR `NG-GL4ES-release.aar` | по таблице README апстрима NG-GL4ES — MIT; в самом AAR **нет** файла лицензии, для именно этого файла **не проверено** |
| `libglxshim.so`, `libEGL_mesa.so`, `libzink_dri.so`, `libglapi.so`, `libcutils.so` (рендерер Zink/Kopper) | AAR `kopper-zink-release.aar` | в AAR лежит `mesa-licenses.rst` (лицензии Mesa; ядро Mesa — MIT), он копируется в `assets/core/licenses/kopper-zink`. Лицензии `libglxshim.so` и `libcutils.so` по отдельности **не подтверждены** (в таблице README апстрима `libs/kopper-zink` не значится) |
| `libjnidispatch.so` (JNA) | `jniLibs/arm64-v8a` | JNA — LGPL-2.1 или Apache-2.0 (по сведениям проекта JNA); в апстриме не проверялось |
| `LICENSE` Zalith | корень апстрима | GPL-3.0 с условиями по разделу 7 — кладётся рядом как `ZalithLauncher2-LICENSE.txt` |

**Не кладётся** (пока): `authlib-injector.jar` — в самом jar'е лежит **AGPL-3.0** (вместе с лицензиями json-simple,
ASM, nanohttpd), его нужно рассмотреть отдельно до 4.7d; `nide8auth.jar`, caciocavallo, `forge_installer.jar`,
`HMCLTransformerDiscoveryService` — до тех пор, пока не понадобятся и не будет выяснена лицензия.

**До выпуска APK с ядром другим людям** нужно: подтвердить лицензию `MioLaunchWrapper.jar` и `MioLibPatcher.jar`
(спросить авторов Zalith или заменить компоненты своими), проверить Classpath Exception у рантаймов, показать
тексты лицензий в «О приложении». Пока этого нет, APK с ядром — для личной проверки владельцем проекта.

Список ниже составлен по таблице «Open Source Libraries and Licenses» в README Zalith 2 на указанной ревизии и
описывает **весь** состав апстрима — часть этих компонентов (рендереры, SDL, ByteHook) придёт с 4.7b-2/4.7c.

| Компонент | Лицензия по README апстрима |
|---|---|
| LWJGL (jar'ы и нативы набора 3.3.3 и 3.4.1, пропатченные в Zalith) | BSD 3-Clause |
| ANGLE | BSD 3-Clause |
| Mesa 3D (OSMesa) | MIT |
| gl4es_extra_extra, NG-GL4ES | MIT |
| MobileGlues | LGPL-2.1 |
| SimpleFPEWrapper | LGPL-3.0 |
| SDL3, sdl2-compat | Zlib |
| ByteHook | MIT |
| OpenJDK (рантаймы Java 8/17/21/25) | GPLv2 (по README Pojav) — детали Classpath Exception проверить |
| Нативные части PojavLauncher/Zalith (`libpojavexec.so` и др., сборка из `jni/` по `Android.mk`) | LGPL-3.0 / GPL-3.0 (как у апстрима) |

**Лицензии не найдены в таблице апстрима — установить до включения в APK:**
`authlib-injector.jar`, `nide8auth.jar`, `caciocavallo` (AWT-слой для Java), `MioLaunchWrapper.jar`,
`MioLibPatcher.jar`, `HMCLTransformerDiscoveryService`, `forge_installer.jar`, а также файлы в
`assets/runtimes/jna` и `libs/openal-soft`, `libs/kopper-zink`, `libs/spirv-cross-natives`.
Пока лицензия компонента не подтверждена, он не включается в сборку, которую получают другие люди.

## 3. Что не входит в репозиторий

Клиент, библиотеки и ассеты Minecraft — собственность Mojang AB / Microsoft. Они скачиваются на устройство
пользователя с серверов Mojang при установке версии и в репозиторий не попадают. Minecraft — торговая марка
Mojang AB / Microsoft; проект неофициальный.
