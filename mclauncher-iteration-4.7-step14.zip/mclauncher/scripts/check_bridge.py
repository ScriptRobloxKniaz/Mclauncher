#!/usr/bin/env python3
"""Проверка договора между Java-мостом (engine/src/main/java) и нативным кодом (engine/src/main/jni) без NDK и Android.

Нативный код находит Java по строковым именам: C вызывает `FindClass("…")` и `GetStaticMethodID(…, "имя", "сигнатура")`,
а Java объявляет `native`-методы, которые JVM ищет по имени символа `Java_<класс>_<метод>` или по таблице
`RegisterNatives`. Ни компилятор, ни линковщик этого не проверяют: ошибка (переименованный метод, не та сигнатура)
проявляется падением при запуске игры. Скрипт проверяет совпадение имён и сигнатур с двух сторон:

  1. каждый `native`-метод в Java-классах моста имеет C-функцию с правильным символом или запись в таблице
     `RegisterNatives` с той же сигнатурой;
  2. каждое обращение C к классам моста (`FindClass("com/movtery/…")`, `GetStaticMethodID`) находит в Java класс и
     статический метод с тем же именем и дескриптором (список обращений зашит в CALLBACKS: он описывает договор);
  3. каждое такое обращение действительно есть в C-файле (договор не устарел);
  4. каждый Java-класс, который C ищет через `FindClass`, существует, а те, что нужны JNI_OnLoad, не пропущены.

Запуск: python3 -I scripts/check_bridge.py [корень проекта]. Код возврата 0 — всё сходится.
"""
import os
import re
import sys

ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
JAVA = os.path.join(ROOT, "engine", "src", "main", "java")
JNI = os.path.join(ROOT, "engine", "src", "main", "jni")

# Что C вызывает у Java: (файл C, класс, метод, дескриптор, статический?). Это и есть договор; пункты 2 и 3 сверяют его
# с Java и с C. Добавили в C новое обращение к мосту — добавьте строку сюда.
CALLBACKS = [
    # libpojavexec.so: JNI_OnLoad (input_bridge_v3.c) — без любого из этих методов библиотека не загрузится.
    ("input_bridge_v3.c", "org/lwjgl/glfw/CallbackBridge", "accessAndroidClipboard", "(ILjava/lang/String;)Ljava/lang/String;", True),
    ("input_bridge_v3.c", "org/lwjgl/glfw/CallbackBridge", "onGrabStateChanged", "(Z)V", True),
    ("input_bridge_v3.c", "org/lwjgl/glfw/CallbackBridge", "onCursorShapeChanged", "(I)V", True),
    ("input_bridge_v3.c", "org/lwjgl/glfw/CallbackBridge", "onGraphicOutput", "()V", True),
    ("input_bridge_v3.c", "org/lwjgl/glfw/CallbackBridge", "onDirectInputEnable", "()V", True),
    ("input_bridge_v3.c", "org/lwjgl/glfw/CallbackBridge", "notifyLauncher", "(I[I)Z", True),
    # Журнал игры (stdio_is.c)
    ("stdio_is.c", "com/movtery/zalithlauncher/bridge/LoggerBridge$EventLogListener", "onEventLogged", "(Ljava/lang/String;)V", False),
    # Выход JVM (stdio_is.c, setupExitMethod)
    ("stdio_is.c", "com/movtery/zalithlauncher/bridge/ZLNativeInvoker", "jvmExit", "(IZ)V", True),
    # libpojavexec_awt.so (awt_bridge.c, JNI_OnLoad)
    ("awt_bridge.c", "com/movtery/zalithlauncher/bridge/ZLNativeInvoker", "openLink", "(Ljava/lang/String;)V", True),
    ("awt_bridge.c", "com/movtery/zalithlauncher/bridge/ZLNativeInvoker", "querySystemClipboard", "()V", True),
    ("awt_bridge.c", "com/movtery/zalithlauncher/bridge/ZLNativeInvoker", "putClipboardData", "(Ljava/lang/String;Ljava/lang/String;)V", True),
]

# Таблицы RegisterNatives: имя таблицы в C → класс, чьи методы она регистрирует.
REGISTERED_TABLES = {
    "noncritical_fcns": "org/lwjgl/glfw/CallbackBridge",
    "critical_fcns": "org/lwjgl/glfw/CallbackBridge",
}

# Классы, которые C ищет в среде Android и которые обязаны быть в :engine. Остальные FindClass (java/…, org/lwjgl/…,
# классы игровой JVM, Vulkan, SDL) относятся к игровой JVM или к библиотекам, которые мост не загружает.
OWN_PREFIXES = ("com/movtery/zalithlauncher/bridge/", "org/lwjgl/glfw/CallbackBridge", "com/oracle/dalvik/")

PRIMITIVES = {
    "void": "V", "boolean": "Z", "byte": "B", "char": "C", "short": "S", "int": "I", "long": "J", "float": "F", "double": "D",
}
KNOWN_CLASSES = {
    "String": "java/lang/String", "Object": "java/lang/Object", "CharSequence": "java/lang/CharSequence",
    "Context": "android/content/Context", "Surface": "android/view/Surface",
}

errors = []


def err(message):
    errors.append(message)


def read(path):
    with open(path, encoding="utf-8", errors="replace") as handle:
        return handle.read()


def strip_comments(text):
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    return re.sub(r"//[^\n]*", " ", text)


# ---------------------------------------------------------------- Java

class JavaClass:
    def __init__(self, internal, package, imports, body):
        self.internal = internal  # com/pkg/Outer$Inner
        self.package = package
        self.imports = imports
        self.body = body
        self.natives = []  # (имя, дескриптор)
        self.methods = []  # (имя, дескриптор, статический?)


def split_params(text):
    parts, depth, current = [], 0, ""
    for char in text:
        if char in "<(":
            depth += 1
        elif char in ">)":
            depth -= 1
        if char == "," and depth == 0:
            parts.append(current)
            current = ""
        else:
            current += char
    if current.strip():
        parts.append(current)
    return parts


def descriptor_of(type_name, cls, all_classes):
    type_name = re.sub(r"<.*>", "", type_name).strip()
    dims = 0
    if type_name.endswith("..."):
        dims += 1
        type_name = type_name[:-3].strip()
    while type_name.endswith("[]"):
        dims += 1
        type_name = type_name[:-2].strip()
    if type_name in PRIMITIVES:
        base = PRIMITIVES[type_name]
    else:
        base = "L" + resolve_class(type_name, cls, all_classes) + ";"
    return "[" * dims + base


def resolve_class(simple, cls, all_classes):
    if "." in simple:
        return simple.replace(".", "/")
    if simple in KNOWN_CLASSES:
        return KNOWN_CLASSES[simple]
    for imp in cls.imports:
        if imp.endswith("." + simple):
            return imp.replace(".", "/")
    # вложенный класс этого же файла или класс того же пакета
    for other in all_classes.values():
        if other.internal == cls.internal + "$" + simple or other.internal == cls.package + "/" + simple:
            return other.internal
        if other.internal.endswith("$" + simple) and other.internal.startswith(cls.internal.split("$")[0]):
            return other.internal
    err(f"{cls.internal}: не удалось определить класс типа «{simple}» для дескриптора")
    return "UNKNOWN/" + simple


METHOD_RE = re.compile(
    r"(?P<mods>(?:(?:public|private|protected|static|final|native|synchronized|abstract)\s+)*)"
    r"(?P<ret>[\w.\[\]<>]+)\s+(?P<name>\w+)\s*\((?P<params>[^)]*)\)\s*(?:throws[\w\s,.]+)?(?P<end>[;{])"
)
ANNOTATION_RE = re.compile(r"@\w+(?:\([^)]*\))?\s*")


def parse_java(path, all_classes):
    text = strip_comments(read(path))
    package = re.search(r"^\s*package\s+([\w.]+)\s*;", text, re.M)
    package = package.group(1).replace(".", "/") if package else ""
    imports = re.findall(r"^\s*import\s+(?:static\s+)?([\w.]+)\s*;", text, re.M)
    outer = re.search(r"\b(?:class|interface)\s+(\w+)", text)
    if not outer:
        return
    top = f"{package}/{outer.group(1)}" if package else outer.group(1)
    cls = JavaClass(top, package, imports, text)
    all_classes[top] = cls
    # вложенные интерфейсы и классы: ищем объявления после первого
    for match in re.finditer(r"\b(?:class|interface)\s+(\w+)", text):
        if match.group(1) != outer.group(1):
            nested = JavaClass(f"{top}${match.group(1)}", package, imports, text)
            all_classes[nested.internal] = nested


def collect_methods(path, all_classes):
    text = strip_comments(read(path))
    package = re.search(r"^\s*package\s+([\w.]+)\s*;", text, re.M)
    package = package.group(1).replace(".", "/") if package else ""
    outer = re.search(r"\b(?:class|interface)\s+(\w+)", text)
    if not outer:
        return
    top = f"{package}/{outer.group(1)}" if package else outer.group(1)
    cls = all_classes[top]
    # Границы вложенных классов нужны, чтобы метод попал к нужному классу.
    cleaned = ANNOTATION_RE.sub("", text)
    spans = []
    for match in re.finditer(r"\b(class|interface)\s+(\w+)[^{;]*\{", cleaned):
        start = match.end() - 1
        depth, index = 0, start
        while index < len(cleaned):
            if cleaned[index] == "{":
                depth += 1
            elif cleaned[index] == "}":
                depth -= 1
                if depth == 0:
                    break
            index += 1
        spans.append((start, index, match.group(2)))
    for match in METHOD_RE.finditer(cleaned):
        name, ret, mods, params = match.group("name"), match.group("ret"), match.group("mods"), match.group("params")
        # Конструкторы выглядят как «private Имя(…)»: «тип» у них — модификатор.
        if ret in ("new", "return", "else", "throw", "public", "private", "protected", "static", "final") or name in ("if", "for", "while", "switch", "catch", "synchronized"):
            continue
        owner = cls
        best = None
        for start, end, cname in spans:
            if start < match.start() < end and (best is None or start > best[0]):
                best = (start, cname)
        if best and best[1] != outer.group(1):
            owner = all_classes.get(f"{top}${best[1]}", cls)
        types = []
        for param in split_params(params):
            tokens = param.replace("final ", "").strip().rsplit(None, 1)
            if len(tokens) != 2:
                continue
            types.append(descriptor_of(tokens[0], owner, all_classes))
        descriptor = "(" + "".join(types) + ")" + descriptor_of(ret, owner, all_classes)
        if "native" in mods.split():
            owner.natives.append((name, descriptor))
        else:
            owner.methods.append((name, descriptor, "static" in mods.split()))


def load_java():
    all_classes = {}
    files = []
    for dirpath, _dirs, names in os.walk(JAVA):
        for name in names:
            if name.endswith(".java"):
                files.append(os.path.join(dirpath, name))
    for path in sorted(files):
        parse_java(path, all_classes)
    for path in sorted(files):
        collect_methods(path, all_classes)
    return all_classes


# ---------------------------------------------------------------- C

def mangle(text):
    out = ""
    for char in text:
        if char == "_":
            out += "_1"
        elif char == ";":
            out += "_2"
        elif char == "[":
            out += "_3"
        elif char == "/" or char == ".":
            out += "_"
        elif char == "$":
            out += "_00024"
        elif char.isalnum():
            out += char
        else:
            out += "_0%04x" % ord(char)
    return out


def load_c():
    sources = {}
    for dirpath, _dirs, names in os.walk(JNI):
        if os.sep + "GL" in dirpath:
            continue
        for name in names:
            if name.endswith((".c", ".cpp")):
                sources[os.path.relpath(os.path.join(dirpath, name), JNI)] = read(os.path.join(dirpath, name))
    return sources


def registered_methods(c_sources):
    """{таблица: {(имя, сигнатура)}} из `JNINativeMethod name[] = { {"имя", "сигнатура", функция}, … }`."""
    result = {}
    for text in c_sources.values():
        for match in re.finditer(r"JNINativeMethod\s+(\w+)\s*\[\s*\]\s*=\s*\{(.*?)\};", text, re.S):
            entries = set(re.findall(r'\{\s*"(\w+)"\s*,\s*"([^"]+)"', match.group(2)))
            result.setdefault(match.group(1), set()).update(entries)
    return result


def main():
    classes = load_java()
    c_sources = load_c()
    all_c = "\n".join(c_sources.values())
    tables = registered_methods(c_sources)

    # 1. native-методы Java ↔ C
    native_count = 0
    for internal, cls in sorted(classes.items()):
        for name, descriptor in cls.natives:
            native_count += 1
            symbol = f"Java_{mangle(internal)}_{mangle(name)}"
            found_symbol = re.search(r"\b" + re.escape(symbol) + r"\b", all_c) is not None
            registered = any(
                REGISTERED_TABLES.get(table) == internal and (name, descriptor) in entries
                for table, entries in tables.items()
            )
            if not (found_symbol or registered):
                err(f"{internal}.{name}{descriptor}: нет ни C-функции {symbol}, ни записи в таблице RegisterNatives")

    # Таблицы RegisterNatives: каждая запись должна иметь Java-native с той же сигнатурой.
    for table, owner in REGISTERED_TABLES.items():
        if table not in tables:
            err(f"таблица RegisterNatives {table} не найдена в C-коде")
            continue
        cls = classes.get(owner)
        if cls is None:
            err(f"таблица {table}: класса {owner} нет в Java")
            continue
        declared = set(cls.natives)
        for name, sig in sorted(tables[table]):
            if (name, sig) not in declared:
                err(f"таблица {table}: в Java у {owner} нет native-метода {name}{sig}")

    # 2 и 3. Обращения C к Java ↔ Java и C
    for c_file, owner, name, descriptor, static in CALLBACKS:
        cls = classes.get(owner)
        if cls is None:
            err(f"C ({c_file}) ищет класс {owner}, а в Java его нет")
            continue
        if not any(m == (name, descriptor, static) for m in cls.methods):
            kind = "статический " if static else ""
            err(f"C ({c_file}) ищет {kind}метод {owner}.{name}{descriptor}, а в Java такого нет")
        source = c_sources.get(c_file)
        if source is None:
            err(f"договор CALLBACKS ссылается на несуществующий C-файл {c_file}")
        elif f'"{name}"' not in source or descriptor not in source:
            err(f'договор CALLBACKS устарел: в {c_file} нет обращения "{name}", "{descriptor}"')

    # 4. Классы, которые C ищет через FindClass и которые должны быть в :engine
    for c_file, text in sorted(c_sources.items()):
        for internal in re.findall(r'FindClass\s*\([^,]+,\s*"([^"]+)"', text):
            if internal.startswith(OWN_PREFIXES) and internal not in classes:
                err(f'{c_file}: FindClass("{internal}") — такого класса нет в Java')

    # JNI_OnLoad библиотек не должен ссылаться на методы, которых нет в договоре.
    onload = c_sources.get("input_bridge_v3.c", "")
    in_onload = set(re.findall(r'GetStaticMethodID\([^;]*?"(\w+)",\s*"([^"]+)"\)', onload.split("jint JNI_OnLoad")[1].split("hookExec")[0] if "jint JNI_OnLoad" in onload else ""))
    contract = {(name, sig) for f, owner, name, sig, _ in CALLBACKS if owner == "org/lwjgl/glfw/CallbackBridge"}
    for pair in sorted(in_onload - contract):
        err(f"input_bridge_v3.c JNI_OnLoad ищет {pair[0]}{pair[1]}, а в договоре CALLBACKS этого нет")

    if errors:
        print("Ошибки в договоре Java-моста и нативного кода:")
        for message in errors:
            print(" -", message)
        return 1
    print(
        f"OK: классов {len(classes)}, native-методов {native_count}, обращений C к Java {len(CALLBACKS)}; "
        "имена и сигнатуры сходятся"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
