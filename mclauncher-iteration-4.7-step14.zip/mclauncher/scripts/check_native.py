#!/usr/bin/env python3
"""Проверка целостности нативной части ядра (engine/src/main/jni) без NDK.

Компилятора C под Android здесь нет, поэтому проверяется то, что можно проверить статически и что чаще всего ломается
при сокращении апстримного кода:
  * каждый файл из LOCAL_SRC_FILES в Android.mk существует;
  * каждая библиотека из LOCAL_SHARED_LIBRARIES — это модуль из того же Android.mk или bytehook (prefab);
  * каждый .c/.cpp в каталоге входит в какой-нибудь модуль (нет осиротевших файлов после сокращения);
  * каждый #include "..." и #include <...>, который указывает внутрь jni/, находит файл; остальные <...> должны быть
    системными заголовками из списка (так опечатка или удалённый файл не пройдут незамеченными).

Запуск: python3 -I scripts/check_native.py [корень проекта]. Код возврата 0 — всё в порядке.
"""
import os
import re
import sys

ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
JNI = os.path.join(ROOT, "engine", "src", "main", "jni")

# Заголовки платформы и NDK, которых нет в jni/. Список закрытый: незнакомый заголовок — повод посмотреть глазами.
SYSTEM_EXACT = {
    "jni.h", "bytehook.h", "elf.h", "atomic",
    "string.h", "stdlib.h", "stdio.h", "stdbool.h", "stdint.h", "stddef.h", "stdarg.h", "stdatomic.h",
    "dlfcn.h", "unistd.h", "pthread.h", "assert.h", "malloc.h", "fcntl.h", "time.h", "errno.h", "libgen.h",
    "math.h", "sched.h", "signal.h", "limits.h", "ctype.h", "inttypes.h", "locale.h", "link.h", "poll.h",
    "dirent.h", "semaphore.h", "wchar.h", "setjmp.h", "stdnoreturn.h",
}
SYSTEM_PREFIXES = ("android/", "EGL/", "GLES/", "GLES2/", "GLES3/", "KHR/", "vulkan/", "sys/", "linux/", "asm/", "bits/")

INCLUDE_RE = re.compile(r'^\s*#\s*include\s*([<"])([^>"]+)[>"]', re.M)
errors = []
warnings = []


def err(msg):
    errors.append(msg)


def read(path):
    with open(path, encoding="utf-8", errors="replace") as f:
        return f.read()


def parse_android_mk(text):
    """Возвращает {модуль: {'src': [...], 'shared': [...]}}. Понимает переносы строк через обратную косую черту."""
    text = re.sub(r"\\\r?\n", " ", text)
    modules = {}
    current = None
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("include $(CLEAR_VARS)"):
            current = {"name": None, "src": [], "shared": []}
            continue
        m = re.match(r"LOCAL_MODULE\s*:=\s*(\S+)", line)
        if m and current is not None:
            current["name"] = m.group(1)
            modules[m.group(1)] = current
            continue
        if current is None:
            continue
        m = re.match(r"LOCAL_SRC_FILES\s*(\+?=|:=)\s*(.*)", line)
        if m:
            current["src"] += m.group(2).split()
            continue
        m = re.match(r"LOCAL_SHARED_LIBRARIES\s*(\+?=|:=)\s*(.*)", line)
        if m:
            current["shared"] += m.group(2).split()
    return modules


def check_includes(path, rel):
    text = read(path)
    here = os.path.dirname(path)
    for kind, name in INCLUDE_RE.findall(text):
        if kind == '"':
            if os.path.isfile(os.path.join(here, name)) or os.path.isfile(os.path.join(JNI, name)):
                continue
            err(f"{rel}: #include \"{name}\" не найден")
        else:
            norm = name.replace("//", "/")
            if os.path.isfile(os.path.join(JNI, norm)):
                continue
            if norm in SYSTEM_EXACT or norm.startswith(SYSTEM_PREFIXES):
                continue
            err(f"{rel}: #include <{name}> — нет в jni/ и нет в списке системных заголовков")


def main():
    mk_path = os.path.join(JNI, "Android.mk")
    if not os.path.isfile(mk_path):
        print(f"Нет {mk_path}")
        return 1

    modules = parse_android_mk(read(mk_path))
    if not modules:
        err("Android.mk: не найден ни один модуль")

    used = set()
    for name, mod in modules.items():
        if not mod["src"] and name not in ("awt_headless",):
            err(f"Android.mk: у модуля {name} нет LOCAL_SRC_FILES")
        for src in mod["src"]:
            used.add(os.path.normpath(src))
            if not os.path.isfile(os.path.join(JNI, src)):
                err(f"Android.mk: модуль {name}: файла {src} нет")
        for lib in mod["shared"]:
            if lib != "bytehook" and lib not in modules:
                err(f"Android.mk: модуль {name}: LOCAL_SHARED_LIBRARIES содержит неизвестный модуль {lib}")

    if "import-module,prefab/bytehook" not in read(mk_path):
        err("Android.mk: нет import-module для prefab/bytehook, а exithook зависит от него")

    for dirpath, dirnames, filenames in os.walk(JNI):
        for fn in filenames:
            path = os.path.join(dirpath, fn)
            rel = os.path.relpath(path, JNI)
            if rel.startswith("GL" + os.sep):
                continue  # заголовки Khronos/Mesa: проверять их #include незачем
            if fn.endswith((".c", ".cpp")):
                if os.path.normpath(rel) not in used:
                    err(f"{rel}: файл есть, но не входит ни в один модуль Android.mk")
            if fn.endswith((".c", ".cpp", ".h")):
                check_includes(path, rel)

    # Сборочные файлы Gradle: нативная часть должна включаться только по свойству.
    gradle = read(os.path.join(ROOT, "engine", "build.gradle.kts"))
    if "mclauncher.native" not in gradle or "Android.mk" not in gradle:
        err("engine/build.gradle.kts: не найдено условное подключение нативной сборки (mclauncher.native / Android.mk)")
    if "ndkVersion" in gradle:
        m = re.search(r'ndkVersion\s*=\s*"([^"]+)"', gradle)
        if not m or m.group(1) != "25.2.9519653":
            err("engine/build.gradle.kts: ndkVersion должен быть 25.2.9519653 (как в апстриме)")

    for w in warnings:
        print("WARN:", w)
    if errors:
        print("Ошибки в нативной части:")
        for e in errors:
            print(" -", e)
        return 1
    files = sum(len(m["src"]) for m in modules.values())
    print(f"OK: модулей {len(modules)}, исходных файлов {files}, все включения и пути сходятся")
    return 0


if __name__ == "__main__":
    sys.exit(main())
