/*
 * Origin: PojavLauncher (LGPL-3.0), via ZalithLauncher 2 (GPL-3.0) at the revision pinned in engine/UPSTREAM.
 * The package, class and method names are part of the JNI symbol Java_com_oracle_dalvik_VMLauncher_launchJVM in
 * libpojavexec.so and must not be changed. Copied without changes except for this note.
 */

package com.oracle.dalvik;

import androidx.annotation.Keep;

@Keep
public final class VMLauncher {
	private VMLauncher() {
	}
    @Keep public static native int launchJVM(String[] args);
}
