package com.mclauncher.engine.install

import com.mclauncher.engine.EngineLayout
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.CancellationException

/*
 * Установка компонентов ядра из ассетов APK на устройство. Без Android-классов: ассеты приходят через [CoreAssets],
 * распаковщик .pack — через [Unpack200]; поэтому всё проверяется JVM-тестами. Запуск в фоне (WorkManager, уведомление)
 * делает :app.
 *
 * Как устроена установка одного компонента:
 *  1. всё пишется в соседнюю папку `.<имя>.installing`; настоящая папка не трогается, пока всё не готово;
 *  2. каждый файл сверяется по размеру и SHA-256 из манифеста (для архивов — по всему файлу целиком);
 *  3. рантайм после распаковки донастраивается (.pack у Java 8) и проверяется (`bin/java`, `release`, `libjvm.so`);
 *  4. в папку пишется метка с `contentId` из манифеста — по ней компонент считается установленным;
 *  5. старая папка удаляется, новая переименовывается на её место.
 * Если на любом шаге ошибка или отмена, `.installing` удаляется, а прежняя установка остаётся как была.
 */

/** Откуда берутся файлы ядра. [path] — путь в ассетах (`core/…`). Нет файла — [FileNotFoundException]. */
fun interface CoreAssets {
    @Throws(IOException::class)
    fun open(path: String): InputStream
}

enum class ComponentState {
    /** Метки нет: компонент не ставился (или установка оборвалась до конца). */
    MISSING,

    /** Метка есть, но она от другой сборки ядра или файлы повреждены: нужно поставить заново. */
    OUTDATED,

    INSTALLED,
}

/** Прогресс установки нескольких компонентов: [doneBytes] из [totalBytes] — байты файлов из ассетов (до распаковки). */
data class CoreProgress(
    val componentId: String,
    val label: String,
    val doneBytes: Long,
    val totalBytes: Long,
) {
    val fraction: Float get() = if (totalBytes <= 0) 0f else (doneBytes.toFloat() / totalBytes).coerceIn(0f, 1f)
}

sealed class CoreInstallException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class UnknownComponent(val id: String) : CoreInstallException("Unknown core component '$id'")

    /** Файла нет в ассетах: сборка приложения без ядра (CI без шага `fetch_core.py --install`). */
    class AssetMissing(val path: String, cause: Throwable? = null) : CoreInstallException("Asset not found: $path", cause)

    /** Размер или SHA-256 файла из ассетов не совпал с манифестом. */
    class Corrupt(val path: String) : CoreInstallException("The file does not match the manifest: $path")

    class NoSpace(val requiredBytes: Long, val availableBytes: Long) :
        CoreInstallException("Not enough free space: need about $requiredBytes bytes, have $availableBytes")

    class Failed(val componentId: String, cause: Throwable) :
        CoreInstallException("Installing '$componentId' failed: ${cause.message ?: cause.javaClass.simpleName}", cause)
}

class CoreInstaller(
    private val layout: EngineLayout,
    private val manifest: CoreManifest,
    private val assets: CoreAssets,
    private val unpack200: Unpack200,
    private val openXz: (InputStream) -> InputStream = XzStreams::open,
    private val freeSpace: (File) -> Long = { it.usableSpace },
    private val extractor: ArchiveExtractor = ArchiveExtractor(),
) {

    /** Папка компонента на устройстве. Манифест уже проверен: `dest` начинается с `components/` или `runtimes/`. */
    fun targetDir(component: CoreComponent): File = when {
        component.dest.startsWith("components/") -> File(layout.componentsDir, component.dest.removePrefix("components/"))
        component.dest.startsWith("runtimes/") -> File(layout.runtimesDir, component.dest.removePrefix("runtimes/"))
        else -> throw IllegalStateException("Unexpected destination '${component.dest}'")
    }

    fun state(component: CoreComponent): ComponentState {
        val dir = targetDir(component)
        val marker = File(dir, MARKER)
        if (!marker.isFile) return ComponentState.MISSING
        val stored = try {
            marker.readText().trim()
        } catch (_: IOException) {
            return ComponentState.OUTDATED
        }
        if (stored != component.contentId) return ComponentState.OUTDATED
        return if (isIntact(component, dir)) ComponentState.INSTALLED else ComponentState.OUTDATED
    }

    /** Компоненты из [ids], которые ещё не установлены. Неизвестный id — [CoreInstallException.UnknownComponent]. */
    fun pending(ids: Collection<String>): List<CoreComponent> =
        resolve(ids).filter { state(it) != ComponentState.INSTALLED }

    /**
     * Ставит недостающие компоненты из [ids]; готовые пропускает. Работает на вызывающем потоке (блокирует), поэтому
     * вызывать нужно из фона. [progress] может бросить исключение отмены ([CancellationException]) — установка
     * остановится, временные папки удалятся, исключение уйдёт наружу без обёрток.
     */
    fun install(ids: Collection<String>, progress: (CoreProgress) -> Unit = {}) {
        val todo = pending(ids)
        if (todo.isEmpty()) return

        val required = todo.sumOf { estimatedBytes(it) } + SPACE_MARGIN
        val available = freeSpace(nearestExisting(layout.componentsDir)).coerceAtMost(freeSpace(nearestExisting(layout.runtimesDir)))
        if (available < required) throw CoreInstallException.NoSpace(required, available)

        val tracker = Tracker(todo.sumOf { it.totalBytes }, progress)
        for (component in todo) {
            try {
                installOne(component, tracker)
            } catch (e: CancellationException) {
                throw e
            } catch (e: CoreInstallException) {
                throw e
            } catch (e: Exception) {
                throw CoreInstallException.Failed(component.id, e)
            }
        }
    }

    private fun resolve(ids: Collection<String>): List<CoreComponent> =
        ids.distinct().map { manifest.component(it) ?: throw CoreInstallException.UnknownComponent(it) }

    private fun isIntact(component: CoreComponent, dir: File): Boolean = when (component.kind) {
        ComponentKind.DIR -> component.files.all { f -> File(dir, f.path).let { it.isFile && it.length() == f.size } }
        ComponentKind.RUNTIME -> File(dir, "bin/java").isFile
    }

    /** Сколько места нужно под компонент: файлы как есть, а рантайм из архивов занимает в несколько раз больше. */
    private fun estimatedBytes(component: CoreComponent): Long = when (component.kind) {
        ComponentKind.DIR -> component.totalBytes
        ComponentKind.RUNTIME -> component.totalBytes * RUNTIME_EXPANSION
    }

    private fun nearestExisting(dir: File): File =
        generateSequence(dir) { it.parentFile }.firstOrNull { it.exists() } ?: dir

    // ---------------------------------------------------------------- установка одного компонента

    private fun installOne(component: CoreComponent, tracker: Tracker) {
        val target = targetDir(component)
        val parent = target.parentFile ?: throw IOException("No parent folder for ${target.path}")
        if (!parent.isDirectory && !parent.mkdirs()) throw IOException("Cannot create ${parent.path}")
        val staging = File(parent, ".${target.name}.installing")
        RuntimeFiles.deleteTree(staging)
        try {
            if (!staging.mkdirs()) throw IOException("Cannot create ${staging.path}")
            when (component.kind) {
                ComponentKind.DIR -> copyFiles(component, staging, tracker)
                ComponentKind.RUNTIME -> unpackRuntime(component, staging, tracker)
            }
            File(staging, MARKER).writeText(component.contentId)
            RuntimeFiles.deleteTree(target)
            if (!staging.renameTo(target)) throw IOException("Cannot move ${staging.path} to ${target.path}")
        } finally {
            RuntimeFiles.deleteTree(staging)
        }
    }

    private fun openAsset(path: String): InputStream = try {
        assets.open(path)
    } catch (e: FileNotFoundException) {
        throw CoreInstallException.AssetMissing(path, e)
    }

    private fun copyFiles(component: CoreComponent, staging: File, tracker: Tracker) {
        for (file in component.files) {
            val assetPath = component.assetPath(file)
            val out = File(staging, file.path)
            out.parentFile?.mkdirs()
            val stream = HashingStream(openAsset(assetPath)) { tracker.add(component.id, file.path, it) }
            stream.use { input ->
                FileOutputStream(out).use { sink ->
                    val buffer = ByteArray(COPY_BUFFER)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        sink.write(buffer, 0, n)
                    }
                }
            }
            verify(stream, file, assetPath)
        }
    }

    private fun unpackRuntime(component: CoreComponent, staging: File, tracker: Tracker) {
        // Общий архив первым, архив под архитектуру поверх него — как у Zalith (RuntimesManager.installRuntimeBinPack).
        val archives = component.files.sortedBy { if (it.path.startsWith("universal")) 0 else 1 }
        for (file in archives) {
            val assetPath = component.assetPath(file)
            val stream = HashingStream(openAsset(assetPath)) { tracker.add(component.id, file.path, it) }
            stream.use { raw ->
                val xz = openXz(raw)
                extractor.extractTar(xz, staging) { tracker.check() }
                // До конца файла: иначе сумма и размер относились бы только к прочитанному (потоки закроет `use`).
                val scratch = ByteArray(COPY_BUFFER)
                while (xz.read(scratch) >= 0) Unit
                raw.drain()
            }
            verify(stream, file, assetPath)
        }
        tracker.label(component.id, "unpack200")
        RuntimeFiles.unpackPacked(staging, unpack200) { tracker.check() }
        RuntimeFiles.problem(staging)?.let { throw IOException("The ${component.id} runtime is incomplete: $it") }
    }

    private fun verify(stream: HashingStream, file: CoreFile, assetPath: String) {
        if (stream.count != file.size || stream.sha256Hex() != file.sha256) throw CoreInstallException.Corrupt(assetPath)
    }

    /** Складывает байты всех файлов и сообщает прогресс не чаще, чем раз в [REPORT_STEP] байт. */
    private class Tracker(private val total: Long, private val sink: (CoreProgress) -> Unit) {
        private var done = 0L
        private var lastReported = -REPORT_STEP
        private var component = ""
        private var current = ""

        fun add(componentId: String, label: String, bytes: Int) {
            component = componentId
            current = label
            done += bytes
            if (done - lastReported >= REPORT_STEP || done >= total) report()
        }

        fun label(componentId: String, label: String) {
            component = componentId
            current = label
            report()
        }

        /** Точка отмены: сообщает текущее состояние, а исключение бросает вызывающий код приложения. */
        fun check() = report()

        private fun report() {
            lastReported = done
            sink(CoreProgress(component, current, done, total))
        }
    }

    companion object {
        /** Метка установки внутри папки компонента. Имя без расширения: списки jar'ов LWJGL её не видят. */
        const val MARKER = ".mcl-core"

        private const val COPY_BUFFER = 64 * 1024
        private const val REPORT_STEP = 128L * 1024

        /** Рантайм из архивов занимает в 3–5 раз больше (Java 8: 3,3; 17: 4,8; 21: 5,2); берём с запасом. */
        private const val RUNTIME_EXPANSION = 6L
        private const val SPACE_MARGIN = 64L * 1024 * 1024
    }
}
