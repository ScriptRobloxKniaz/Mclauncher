package com.mclauncher.engine.install

import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.File
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.nio.file.Files
import java.security.MessageDigest

/** Распаковщик `.pack` (Java 8 хранит часть jar'ов в формате pack200). На устройстве — `libunpack200.so`. */
fun interface Unpack200 {
    /** Превращает [pack] в [output]; при неудаче бросает [IOException]. */
    @Throws(IOException::class)
    fun unpack(pack: File, output: File)
}

/** Открытие `.xz`: единственное место, где ядро касается библиотеки xz (в JVM-тестах подставляется обычный tar). */
object XzStreams {
    fun open(input: InputStream): InputStream = XZCompressorInputStream(input)
}

/** Что делается с рантаймом Java после распаковки, и проверка, что он целый. */
object RuntimeFiles {

    /** Находит и распаковывает `*.pack` (только Java 8; у остальных их нет). Возвращает число распакованных. */
    fun unpackPacked(root: File, unpack200: Unpack200, checkpoint: () -> Unit = {}): Int {
        val packs = root.walkTopDown()
            .onEnter { !Files.isSymbolicLink(it.toPath()) }
            .filter { it.isFile && !Files.isSymbolicLink(it.toPath()) && it.name.endsWith(".pack") }
            .toList()
        for (pack in packs) {
            checkpoint()
            val output = File(pack.path.removeSuffix(".pack"))
            unpack200.unpack(pack, output)
            if (!output.isFile || output.length() == 0L) {
                throw IOException("unpack200 produced no output for ${pack.name}")
            }
            // `-r` у libunpack200 удаляет исходный .pack; если распаковщик этого не сделал, место не тратим зря.
            if (pack.exists()) pack.delete()
        }
        return packs.size
    }

    /**
     * Минимальная проверка распакованного рантайма: есть `bin/java`, `release` и где-то в `lib/` — `libjvm.so`.
     * Это проверка набора файлов; что JVM действительно стартует, покажет только запуск на устройстве.
     * Возвращает описание проблемы или `null`.
     */
    fun problem(root: File): String? {
        if (!File(root, "bin/java").isFile) return "bin/java is missing"
        if (!File(root, "release").isFile) return "the 'release' file is missing"
        val lib = File(root, "lib")
        val hasJvm = lib.isDirectory && lib.walkTopDown()
            .onEnter { !Files.isSymbolicLink(it.toPath()) }
            .any { it.isFile && it.name == "libjvm.so" }
        if (!hasJvm) return "libjvm.so is missing"
        return null
    }

    /** Удаляет файл или папку; символические ссылки удаляются сами, по ним не ходят. */
    fun deleteTree(file: File) {
        val path = file.toPath()
        if (Files.isSymbolicLink(path)) {
            Files.deleteIfExists(path)
            return
        }
        if (!file.exists()) return
        if (file.isDirectory) file.listFiles()?.forEach { deleteTree(it) }
        if (!file.delete() && file.exists()) throw IOException("Cannot delete ${file.path}")
    }
}

/**
 * Поток, который считает прочитанные байты и сумму SHA-256. `skip` реализован чтением: иначе пропущенные байты не
 * попали бы в сумму и целый файл показался бы повреждённым.
 */
internal class HashingStream(
    input: InputStream,
    private val onBytes: (Int) -> Unit = {},
) : FilterInputStream(input) {
    private val digest = MessageDigest.getInstance("SHA-256")
    var count = 0L
        private set

    override fun read(): Int {
        val b = super.read()
        if (b >= 0) {
            digest.update(b.toByte())
            count++
            onBytes(1)
        }
        return b
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        val n = super.read(buffer, offset, length)
        if (n > 0) {
            digest.update(buffer, offset, n)
            count += n
            onBytes(n)
        }
        return n
    }

    override fun skip(n: Long): Long {
        if (n <= 0) return 0
        val scratch = ByteArray(minOf(n, 8192L).toInt())
        var left = n
        while (left > 0) {
            val read = read(scratch, 0, minOf(left, scratch.size.toLong()).toInt())
            if (read < 0) break
            left -= read
        }
        return n - left
    }

    override fun markSupported(): Boolean = false
    override fun mark(readlimit: Int) = Unit
    override fun reset() = throw IOException("mark/reset is not supported")

    /** Дочитывает поток до конца, чтобы сумма и размер относились ко всему файлу. */
    fun drain() {
        val scratch = ByteArray(8192)
        while (read(scratch) >= 0) Unit
    }

    fun sha256Hex(): String = digest.digest().joinToString("") { "%02x".format(it) }
}
