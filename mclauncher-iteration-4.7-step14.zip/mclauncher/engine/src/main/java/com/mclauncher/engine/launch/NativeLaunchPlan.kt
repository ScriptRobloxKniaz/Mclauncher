package com.mclauncher.engine.launch

import java.io.File
import java.io.Serializable

/**
 * Всё, что процессу игры нужно знать, чтобы запустить JVM: готовый список шагов, без вычислений и без чтения
 * описания версии. Собирается в процессе лаунчера ([NativeLaunchPlanner]), передаётся в процесс `:game` через Intent
 * ([Serializable]) и выполняется там `GameRunner`.
 *
 * Содержит токен доступа (в [argv]): в логи и файлы пишите только [redactedArgv].
 */
class NativeLaunchPlan(
    /** Java и всё, что после неё: флаги JVM, `-cp …`, `mio.Wrapper`, главный класс, аргументы игры. Первый элемент — путь к `java`. */
    val argv: ArrayList<String>,
    /** Рабочая папка игры (`chdir` перед запуском JVM). */
    val workingDir: String,
    /** Пути поиска библиотек для JVM (`ZLBridge.setLdLibraryPath`). */
    val jvmLibraryPath: String,
    /** Переменные окружения процесса; `DALVIK_JAVAVM` и `DALVIK_APPLICATION` добавляются уже в процессе игры. */
    val environment: LinkedHashMap<String, String>,
    /** Библиотеки, которые подгружаются через `dlopen` до старта JVM, по порядку. Отсутствие файла — не ошибка запуска. */
    val dlopenLibraries: ArrayList<String>,
    /** Рендерер: его библиотека подгружается последней, сначала по имени, затем по полному пути. */
    val rendererLibrary: String,
    val rendererLibraryPath: String,
    val rendererName: String,
    /** Размер окна игры в пикселях. */
    val windowWidth: Int,
    val windowHeight: Int,
    /** Новый формат аргументов (`arguments` в описании версии, 1.13+): нативному вводу нужен режим очереди. */
    val useInputStackQueue: Boolean,
    /** Журнал игры: сюда нативный код пишет всё, что игра выводит в консоль. */
    val logFile: String,
    /** Что запускаем — для заголовка журнала и отчёта (`1.21.1`). */
    val versionId: String,
) : Serializable {

    /** Папка отчётов о завершении ([GameExitReport]): та же, где журнал игры. Лаунчер читает отчёты оттуда же. */
    val reportDir: String get() = File(logFile).parent ?: "."

    /** [argv] без значений после `--accessToken` и `--session`: безопасно для журнала. */
    fun redactedArgv(): List<String> {
        val result = ArrayList<String>(argv.size)
        var hide = false
        for (arg in argv) {
            if (hide) {
                result += "********"
                hide = false
            } else {
                result += arg
                hide = arg == "--accessToken" || arg == "--session"
            }
        }
        return result
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
