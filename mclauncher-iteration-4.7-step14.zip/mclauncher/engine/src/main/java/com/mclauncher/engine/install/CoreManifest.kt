package com.mclauncher.engine.install

import com.mclauncher.engine.JavaRuntimes
import com.mclauncher.engine.LwjglRequirement

/*
 * Манифест ядра: что лежит в ассетах APK и как это проверить. Его пишет scripts/fetch_core.py (--install), читает
 * приложение на устройстве. Формат построчный, поля через пробел (имена файлов без пробелов проверяет скрипт):
 *
 *   mcl-core 1
 *   abi arm64-v8a
 *   upstream <40 hex>
 *   component <id> <dir|runtime> <components/…|runtimes/…> <contentId: 64 hex>
 *   file <id> <путь внутри компонента> <размер> <sha256>
 *
 * Строки с `#` и пустые игнорируются. Любое отклонение — ManifestException: лучше отказаться ставить ядро, чем
 * распаковать то, что не понял.
 */

class ManifestException(message: String) : Exception(message)

enum class ComponentKind(val token: String) {
    /** Набор файлов: копируется в папку компонента как есть. */
    DIR("dir"),

    /** Архивы `.tar.xz`: распаковываются по порядку (общий, затем под архитектуру) и донастраиваются. */
    RUNTIME("runtime"),
}

/** Файл ассетов: [path] — путь внутри компонента, [size] и [sha256] — размер и сумма самого файла из ассетов. */
data class CoreFile(val path: String, val size: Long, val sha256: String)

data class CoreComponent(
    val id: String,
    val kind: ComponentKind,
    /** `components/<папка>` или `runtimes/<папка>`; корень задаёт [com.mclauncher.engine.EngineLayout]. */
    val dest: String,
    /** Сумма по составу компонента: меняется, когда меняется любой файл. Записывается меткой после установки. */
    val contentId: String,
    val files: List<CoreFile>,
) {
    val totalBytes: Long get() = files.sumOf { it.size }

    /** Путь файла в ассетах APK. */
    fun assetPath(file: CoreFile): String = "${CoreManifest.ASSETS_ROOT}/$dest/${file.path}"
}

data class CoreManifest(val abi: String, val upstream: String, val components: List<CoreComponent>) {

    fun component(id: String): CoreComponent? = components.firstOrNull { it.id == id }

    companion object {
        const val ASSETS_ROOT = "core"
        const val ASSET_NAME = "$ASSETS_ROOT/core-manifest.txt"
        const val FORMAT = 1

        private val ID_RE = Regex("^[a-z0-9][a-z0-9.\\-]*$")
        private val HEX64 = Regex("^[0-9a-f]{64}$")
        private val SHA1_HEX = Regex("^[0-9a-f]{40}$")
        private val SEGMENT = Regex("^[A-Za-z0-9._+\\-]+$")

        /** Безопасный относительный путь: сегменты без `..`, пробелов и пустых частей. */
        fun isSafeRelativePath(path: String): Boolean {
            if (path.isEmpty() || path.startsWith("/") || path.endsWith("/")) return false
            return path.split('/').all { it != "." && it != ".." && SEGMENT.matches(it) }
        }

        fun parse(text: String): CoreManifest {
            var formatSeen = false
            var abi: String? = null
            var upstream: String? = null
            data class Draft(val id: String, val kind: ComponentKind, val dest: String, val contentId: String) {
                val files = ArrayList<CoreFile>()
            }
            val drafts = LinkedHashMap<String, Draft>()

            text.lineSequence().forEachIndexed { index, raw ->
                val line = raw.trim()
                if (line.isEmpty() || line.startsWith("#")) return@forEachIndexed
                val n = index + 1
                val parts = line.split(' ')
                fun fail(why: String): Nothing = throw ManifestException("core-manifest.txt:$n: $why")

                when (parts[0]) {
                    "mcl-core" -> {
                        if (parts.size != 2 || parts[1] != FORMAT.toString()) fail("unsupported format '${parts.drop(1).joinToString(" ")}'")
                        formatSeen = true
                    }
                    "abi" -> {
                        if (parts.size != 2 || !SEGMENT.matches(parts[1])) fail("bad abi line")
                        abi = parts[1]
                    }
                    "upstream" -> {
                        if (parts.size != 2 || !SHA1_HEX.matches(parts[1])) fail("bad upstream revision")
                        upstream = parts[1]
                    }
                    "component" -> {
                        if (!formatSeen) fail("'mcl-core' header must come first")
                        if (parts.size != 5) fail("a component line needs 4 fields")
                        val (id, kindToken, dest, contentId) = parts.drop(1)
                        if (!ID_RE.matches(id)) fail("bad component id '$id'")
                        if (id in drafts) fail("duplicate component '$id'")
                        val kind = ComponentKind.entries.firstOrNull { it.token == kindToken } ?: fail("unknown kind '$kindToken'")
                        if (!isSafeRelativePath(dest)) fail("unsafe destination '$dest'")
                        val rootOk = when (kind) {
                            ComponentKind.DIR -> dest.startsWith("components/")
                            ComponentKind.RUNTIME -> dest.startsWith("runtimes/")
                        }
                        if (!rootOk || dest.count { it == '/' } < 1) fail("destination '$dest' does not fit kind '$kindToken'")
                        if (!HEX64.matches(contentId)) fail("bad content id")
                        drafts[id] = Draft(id, kind, dest, contentId)
                    }
                    "file" -> {
                        if (parts.size != 5) fail("a file line needs 4 fields")
                        val (id, path, sizeText, sha) = parts.drop(1)
                        val draft = drafts[id] ?: fail("file for unknown component '$id'")
                        if (!isSafeRelativePath(path)) fail("unsafe file path '$path'")
                        val size = sizeText.toLongOrNull()?.takeIf { it >= 0 } ?: fail("bad size '$sizeText'")
                        if (!HEX64.matches(sha)) fail("bad sha256")
                        if (draft.files.any { it.path == path }) fail("duplicate file '$path' in '$id'")
                        draft.files += CoreFile(path, size, sha)
                    }
                    else -> fail("unknown line '${parts[0]}'")
                }
            }

            if (!formatSeen) throw ManifestException("core-manifest.txt: the 'mcl-core' header is missing")
            val abiValue = abi ?: throw ManifestException("core-manifest.txt: 'abi' is missing")
            val upstreamValue = upstream ?: throw ManifestException("core-manifest.txt: 'upstream' is missing")
            val components = drafts.values.map { d ->
                if (d.files.isEmpty()) throw ManifestException("core-manifest.txt: component '${d.id}' has no files")
                if (d.kind == ComponentKind.RUNTIME && d.files.any { !it.path.endsWith(".tar.xz") }) {
                    throw ManifestException("core-manifest.txt: runtime '${d.id}' may only contain .tar.xz archives")
                }
                CoreComponent(d.id, d.kind, d.dest, d.contentId, d.files.toList())
            }
            if (components.isEmpty()) throw ManifestException("core-manifest.txt: no components")
            return CoreManifest(abiValue, upstreamValue, components)
        }
    }
}

/** Какие компоненты нужны для запуска версии. Имена совпадают с теми, что пишет scripts/fetch_core.py. */
object CoreRequirements {
    const val LAUNCHER = "launcher"

    /** `null` — Java новее всех поставляемых рантаймов (см. [JavaRuntimes]). */
    fun idsFor(lwjgl: LwjglRequirement, javaMajor: Int): List<String>? {
        val jre = JavaRuntimes.componentFor(javaMajor) ?: return null
        return listOf(LAUNCHER, "lwjgl-${lwjgl.lwjgl.dirName}", "jre-$jre")
    }
}
