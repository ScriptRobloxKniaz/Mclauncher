package com.mclauncher.engine

import com.mclauncher.engine.launch.RendererProfile
import java.io.File

/**
 * Готово ли ядро к запуску. [missing] — человекочитаемый список того, чего не хватает (по-английски: это текст для
 * лога и поддержки, а не для экрана); пуст, когда всё на месте.
 */
data class CoreStatus(val missing: List<String>) {
    val isReady: Boolean get() = missing.isEmpty()
}

/**
 * Проверка состава ядра на диске: нативные библиотеки приложения, распакованные компоненты и Java-рантайм.
 * Только проверка наличия файлов — работоспособность библиотек подтверждается лишь запуском на устройстве.
 */
object EngineCore {

    /**
     * Что нужно именно для запуска версии с таким [lwjgl] и Java [javaMajor].
     * @param renderer если задан, нужны ещё и библиотеки этого рендерера (`libgl4es_114.so`; у Zink их несколько)
     */
    fun check(
        layout: EngineLayout,
        lwjgl: LwjglRequirement,
        javaMajor: Int,
        renderer: RendererProfile? = null,
    ): CoreStatus {
        val missing = ArrayList<String>()

        fun require(file: File, what: String) {
            if (!file.isFile) missing += "$what (${file.path})"
        }

        // Библиотеки, которые Android кладёт в папку нативных библиотек приложения (jniLibs и AAR).
        require(File(layout.nativeLibraryDir, "libpojavexec.so"), "Pojav bridge library")
        require(File(layout.nativeLibraryDir, "libopenal.so"), "OpenAL library")
        if (renderer != null) {
            for (name in renderer.requiredLibraries) {
                require(File(layout.nativeLibraryDir, name), "${renderer.displayName} renderer library")
            }
        }

        // Компоненты, которые распаковываются из ассетов при первом запуске.
        val lwjglDir = layout.lwjglDir(lwjgl.lwjgl)
        require(File(lwjglDir, "lwjgl.jar"), "LWJGL ${lwjgl.lwjgl.dirName} core jar")
        require(File(layout.lwjglNativesDir(lwjgl.lwjgl), "liblwjgl.so"), "LWJGL ${lwjgl.lwjgl.dirName} natives for ${layout.abi}")
        require(layout.launchWrapperJar, "Launch wrapper")
        require(layout.libPatcherJar, "Library patcher")

        val component = JavaRuntimes.componentFor(javaMajor)
        if (component == null) {
            missing += "Java runtime for Java $javaMajor (the core ships ${JavaRuntimes.AVAILABLE})"
        } else {
            require(layout.javaExecutable(component), "Java $component runtime")
        }
        return CoreStatus(missing)
    }
}
