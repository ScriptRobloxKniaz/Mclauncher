package com.mclauncher.engine.install

import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarConstants
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.Paths

/*
 * Распаковка tar в папку. Сжатие (xz) снимает вызывающий: сюда приходит уже обычный tar-поток, поэтому класс
 * проверяется JVM-тестами на tar, собранных прямо в тесте.
 *
 * Правила (рантайм Java — это сотни файлов из архива, который лежит в APK, но распаковщик не доверяет и ему):
 *  - имя записи не может быть абсолютным и содержать `..`; ведущие `./` отбрасываются (в архивах Zalith они есть);
 *  - ни одна запись не пишется через символическую ссылку наружу: папка назначения проверяется по реальному пути;
 *  - ссылка не может указывать за пределы папки (абсолютный путь и `..` наружу — отказ);
 *  - жёсткая ссылка копирует уже распакованный файл; устройства и каналы — отказ, а не тихий пропуск;
 *  - исполняемый бит сохраняется; ограничены число записей и общий размер.
 * Символические ссылки по логике взяты из RuntimesManager.uncompressTarXZ (ZalithLauncher 2, GPL-3.0): у них
 * Os.symlink, у нас java.nio — он есть с API 26 (minSdk проекта).
 */

/** Архив нарушает правила распаковки; в сообщении — имя записи. */
class UnsafeArchiveException(message: String) : IOException(message)

class ArchiveExtractor(
    private val maxEntries: Int = 200_000,
    private val maxBytes: Long = 4L shl 30,
) {
    class Stats {
        var entries = 0
            internal set
        var files = 0
            internal set
        var symlinks = 0
            internal set
        var bytes = 0L
            internal set
    }

    /**
     * Распаковывает [tar] в [dest] (папка создаётся). Поверх уже распакованного: файлы с тем же именем заменяются —
     * так второй архив рантайма (под архитектуру) ложится на общий.
     *
     * [checkpoint] вызывается на каждой записи и примерно на каждый мегабайт данных; бросив исключение, он
     * останавливает распаковку (так работает отмена). [tar] не закрывается.
     */
    fun extractTar(tar: InputStream, dest: File, checkpoint: () -> Unit = {}): Stats {
        if (!dest.isDirectory && !dest.mkdirs()) throw IOException("Cannot create ${dest.path}")
        val root = dest.canonicalFile
        val rootPath = root.toPath()
        val stats = Stats()
        val input = TarArchiveInputStream(tar)
        val buffer = ByteArray(BUFFER)

        fun ensureInside(file: File, what: String) {
            if (!file.canonicalFile.toPath().startsWith(rootPath)) {
                throw UnsafeArchiveException("$what leaves the destination: ${file.path}")
            }
        }

        while (true) {
            val entry: TarArchiveEntry = input.nextEntry ?: break
            checkpoint()
            if (++stats.entries > maxEntries) throw UnsafeArchiveException("The archive has more than $maxEntries entries")

            val name = normalizeEntryName(entry.name) ?: continue
            val target = File(root, name)
            val parent = target.parentFile ?: root

            when {
                entry.isDirectory -> {
                    if (!target.isDirectory && !target.mkdirs()) throw IOException("Cannot create ${target.path}")
                    ensureInside(target, "directory '$name'")
                }

                entry.isSymbolicLink -> {
                    makeParent(parent)
                    ensureInside(parent, "'$name'")
                    val link = entry.linkName
                    if (link.isEmpty() || link.contains('\u0000') || link.startsWith("/")) {
                        throw UnsafeArchiveException("Unsafe symlink target for '$name': '$link'")
                    }
                    val resolved = parent.canonicalFile.toPath().resolve(link).normalize()
                    if (!resolved.startsWith(rootPath)) {
                        throw UnsafeArchiveException("Symlink '$name' -> '$link' leaves the destination")
                    }
                    removeExisting(target)
                    Files.createSymbolicLink(target.toPath(), Paths.get(link))
                    stats.symlinks++
                }

                entry.isLink -> {
                    // Жёсткая ссылка: в tar это имя уже записанного файла. Копируем его содержимое.
                    makeParent(parent)
                    ensureInside(parent, "'$name'")
                    val sourceName = normalizeEntryName(entry.linkName)
                        ?: throw UnsafeArchiveException("Hard link '$name' has no target")
                    val source = File(root, sourceName)
                    ensureInside(source, "hard link source '$sourceName'")
                    if (!source.isFile) throw UnsafeArchiveException("Hard link '$name' points to a missing file '$sourceName'")
                    removeExisting(target)
                    source.copyTo(target)
                    copyMode(entry, target)
                    stats.files++
                }

                isRegularFile(entry) -> {
                    makeParent(parent)
                    ensureInside(parent, "'$name'")
                    removeExisting(target)
                    var sinceCheckpoint = 0L
                    FileOutputStream(target).use { out ->
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            out.write(buffer, 0, n)
                            stats.bytes += n
                            if (stats.bytes > maxBytes) throw UnsafeArchiveException("The archive unpacks to more than $maxBytes bytes")
                            sinceCheckpoint += n
                            if (sinceCheckpoint >= CHECKPOINT_BYTES) {
                                sinceCheckpoint = 0
                                checkpoint()
                            }
                        }
                    }
                    copyMode(entry, target)
                    stats.files++
                }

                else -> throw UnsafeArchiveException("Unsupported entry type for '$name' (devices and pipes are not allowed)")
            }
        }
        return stats
    }

    /**
     * Обычный файл — только по типу записи. `TarArchiveEntry.isFile` для канала или устройства тоже отвечает «да»
     * (он смотрит на имя), и такая запись молча превратилась бы в пустой файл.
     */
    private fun isRegularFile(entry: TarArchiveEntry): Boolean =
        entry.linkFlag == TarConstants.LF_NORMAL || entry.linkFlag == TarConstants.LF_OLDNORM || entry.linkFlag == TarConstants.LF_CONTIG

    private fun makeParent(parent: File) {
        if (!parent.isDirectory && !parent.mkdirs()) throw IOException("Cannot create ${parent.path}")
    }

    /** Удаляет то, что лежит на месте записи; ссылка удаляется сама, а не файл, на который она указывает. */
    private fun removeExisting(target: File) {
        if (Files.isSymbolicLink(target.toPath())) {
            Files.delete(target.toPath())
        } else if (target.isDirectory) {
            throw UnsafeArchiveException("'${target.name}' is a directory in the destination but a file in the archive")
        } else if (target.exists() && !target.delete()) {
            throw IOException("Cannot replace ${target.path}")
        }
    }

    private fun copyMode(entry: TarArchiveEntry, file: File) {
        // Права архива: нужен только исполняемый бит (для bin/java и т. п.). Остальное задаёт система.
        if (entry.mode and EXEC_BITS != 0) file.setExecutable(true, false)
    }

    companion object {
        private const val BUFFER = 64 * 1024
        private const val CHECKPOINT_BYTES = 1L shl 20
        private const val EXEC_BITS = 0b001_001_001

        /**
         * Имя записи без ведущих `./` и лишних `/`; `null` — запись про сам корень (`./`). Абсолютные имена,
         * `..` и обратная косая черта — [UnsafeArchiveException].
         */
        fun normalizeEntryName(raw: String): String? {
            if (raw.contains('\u0000') || raw.contains('\\') || raw.startsWith("/")) {
                throw UnsafeArchiveException("Unsafe entry name: '$raw'")
            }
            val parts = ArrayList<String>()
            for (segment in raw.split('/')) {
                when (segment) {
                    "", "." -> Unit
                    ".." -> throw UnsafeArchiveException("Unsafe entry name: '$raw'")
                    else -> parts += segment
                }
            }
            return if (parts.isEmpty()) null else parts.joinToString("/")
        }
    }
}
