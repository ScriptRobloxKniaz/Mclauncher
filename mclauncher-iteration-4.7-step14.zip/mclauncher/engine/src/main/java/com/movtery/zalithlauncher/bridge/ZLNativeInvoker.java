/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 *
 * Modified for MCLauncher: reduced to what the native part needs to load and to start the game (no SDL, gamepad,
 * clipboard or UI dependencies of ZalithLauncher 2); the host application plugs in through ZLNativeInvoker.Host.
 * The package, class and method names are part of the JNI symbols of libpojavexec.so and must not be changed.
 */

package com.movtery.zalithlauncher.bridge;

import androidx.annotation.Keep;

/**
 * Вызовы из нативного кода (и из JVM игры через неё) обратно в приложение. Методы вызываются по имени и сигнатуре из
 * {@code stdio_is.c} (jvmExit) и {@code awt_bridge.c} (остальные), поэтому имена нельзя менять.
 *
 * В ZalithLauncher 2 здесь класс на Kotlin, привязанный к его Activity и Launcher. Здесь приложение подключается
 * через {@link Host}: так мост не знает ничего об интерфейсе.
 */
@Keep
public final class ZLNativeInvoker {
    private ZLNativeInvoker() {
    }

    /** Что приложение умеет делать по просьбе нативного кода. Все методы могут вызываться из любого потока. */
    public interface Host {
        void openLink(String link);

        void querySystemClipboard();

        void putClipboardData(String data, String mimeType);

        /**
         * Доступ игры к буферу обмена Android ({@code CallbackBridge.accessAndroidClipboard}).
         * @param type {@code CallbackBridge.CLIPBOARD_COPY}, {@code CLIPBOARD_PASTE} или {@code CLIPBOARD_OPEN}
         * @return текст для {@code CLIPBOARD_PASTE}, иначе {@code null}
         */
        String accessClipboard(int type, String text);

        /**
         * JVM игры завершилась. После возврата из этого метода нативный код вызовет {@code System.exit(0)} и процесс
         * игры завершится, поэтому всё, что нужно сохранить (код выхода, пометку для лаунчера), надо сделать здесь,
         * синхронно.
         */
        void onJvmExit(int exitCode, boolean isSignal);
    }

    private static volatile Host host;

    public static void setHost(Host newHost) {
        host = newHost;
    }

    public static Host getHost() {
        return host;
    }

    @Keep
    public static void openLink(String link) {
        Host h = host;
        if (h == null) return;
        try {
            h.openLink(link);
        } catch (Throwable ignored) {
            // исключение нельзя вернуть в нативный код: там оно останется «висеть» в вызывающем потоке
        }
    }

    @Keep
    public static void querySystemClipboard() {
        Host h = host;
        if (h == null) return;
        try {
            h.querySystemClipboard();
        } catch (Throwable ignored) {
        }
    }

    @Keep
    public static void putClipboardData(String data, String mimeType) {
        Host h = host;
        if (h == null) return;
        try {
            h.putClipboardData(data, mimeType);
        } catch (Throwable ignored) {
        }
    }

    @Keep
    public static void jvmExit(int exitCode, boolean isSignal) {
        Host h = host;
        if (h == null) return;
        try {
            h.onJvmExit(exitCode, isSignal);
        } catch (Throwable ignored) {
            // дальше нативный код всё равно завершит процесс
        }
    }
}
