/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 *
 * Modified for MCLauncher: reduced to what the native part needs to load and to start the game (no SDL, gamepad,
 * clipboard or UI dependencies of ZalithLauncher 2); the host application plugs in through ZLNativeInvoker.Host.
 * The package, class and method names are part of the JNI symbols of libpojavexec.so and must not be changed.
 */

package org.lwjgl.glfw;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.Keep;
import androidx.annotation.Nullable;

import com.movtery.zalithlauncher.bridge.NativeLibraryLoader;
import com.movtery.zalithlauncher.bridge.ZLNativeInvoker;

/**
 * Сторона Android моста ввода и окна между приложением и игрой (сторона JVM — одноимённый класс в jar'ах LWJGL ядра).
 *
 * Нативный код ищет этот класс по имени уже при загрузке {@code libpojavexec.so} ({@code JNI_OnLoad}) и вызывает
 * из него статические методы {@code accessAndroidClipboard}, {@code onGrabStateChanged}, {@code onCursorShapeChanged},
 * {@code onGraphicOutput}, {@code onDirectInputEnable} и {@code notifyLauncher}; девять методов {@code native} ниже он
 * привязывает через {@code RegisterNatives}. Без любого из них библиотека не загрузится, поэтому состав и сигнатуры
 * менять нельзя. Версия {@code @CriticalNative} (быстрее на ~4 раза) не используется: без класса
 * {@code CriticalNativeTest} нативный код выбирает обычные функции.
 *
 * Отправка ввода здесь минимальна — только то, что нужно окну; сенсорное управление появится на этапе 4.7c.
 */
@Keep
public class CallbackBridge {
    public static final int CLIPBOARD_COPY = 2000;
    public static final int CLIPBOARD_PASTE = 2001;
    public static final int CLIPBOARD_OPEN = 2002;

    // Значения из GLFW 3: окно в фокусе / курсор над окном.
    public static final int GLFW_FOCUSED = 0x20001;
    public static final int GLFW_HOVERED = 0x2000B;

    public static final int GLFW_MOUSE_BUTTON_LEFT = 0;
    public static final int GLFW_MOUSE_BUTTON_RIGHT = 1;
    public static final int GLFW_MOUSE_BUTTON_MIDDLE = 2;

    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    public static volatile int windowWidth, windowHeight;
    public static float mouseX, mouseY;

    private static volatile boolean isGrabbing = false;
    private static volatile int cursorShape = 0x36001; // GLFW_ARROW_CURSOR

    /** Кто слушает смену режима курсора (захват мыши игрой). Вызывается в главном потоке. */
    public interface GrabListener {
        void onGrabChanged(boolean grabbing);
    }

    @Nullable
    private static volatile GrabListener sGrabListener;
    private static GraphicOutputListener sGraphicOutputListener;

    public static void setGrabListener(@Nullable GrabListener listener) {
        sGrabListener = listener;
    }

    public static void setGraphicOutputListener(GraphicOutputListener listener) {
        sGraphicOutputListener = listener;
    }

    public static boolean isGrabbing() {
        // Без обращения к JNI на каждый вызов.
        return isGrabbing;
    }

    public static int getCursorShape() {
        return cursorShape;
    }

    // --- Ввод (минимум) ---

    public static void sendUpdateWindowSize(int w, int h) {
        windowWidth = w;
        windowHeight = h;
        nativeSendScreenSize(w, h);
    }

    public static void sendCursorPos(float x, float y) {
        mouseX = x;
        mouseY = y;
        nativeSendCursorPos(x, y);
    }

    public static void sendMouseButton(int button, boolean isDown) {
        nativeSendMouseButton(button, isDown ? 1 : 0, 0);
    }

    public static void sendScroll(double xoffset, double yoffset) {
        nativeSendScroll(xoffset, yoffset);
    }

    public static void resetInputState() {
        nativeResetInputState();
    }

    // --- Вызовы из нативного кода ---

    // Called from JRE side
    @SuppressWarnings("unused")
    @Keep
    public static @Nullable String accessAndroidClipboard(int type, String copy) {
        ZLNativeInvoker.Host host = ZLNativeInvoker.getHost();
        if (host == null) return type == CLIPBOARD_PASTE ? "" : null;
        try {
            return host.accessClipboard(type, copy);
        } catch (Throwable e) {
            return type == CLIPBOARD_PASTE ? "" : null;
        }
    }

    // Called from JRE side
    @SuppressWarnings("unused")
    @Keep
    private static void onGrabStateChanged(final boolean grabbing) {
        isGrabbing = grabbing;
        MAIN_HANDLER.post(() -> {
            // Если захват снова поменялся, пока ждали, это уведомление устарело.
            if (isGrabbing != grabbing) return;
            GrabListener listener = sGrabListener;
            if (listener != null) listener.onGrabChanged(grabbing);
        });
    }

    // Called from JRE side
    @SuppressWarnings("unused")
    @Keep
    private static void onCursorShapeChanged(final int shape) {
        cursorShape = shape;
    }

    // Called from JRE side
    @SuppressWarnings("unused")
    @Keep
    private static void onGraphicOutput() {
        GraphicOutputListener listener = sGraphicOutputListener;
        if (listener != null) listener.onGraphicOutput();
    }

    // Called from JRE side
    @SuppressWarnings("unused")
    @Keep
    private static void onDirectInputEnable() {
        // Прямой ввод геймпада появится вместе с поддержкой геймпадов.
    }

    // Called from JRE side (SDL3 integration of LWJGL 3.4; SDL is not supported yet)
    @SuppressWarnings("unused")
    @Keep
    public static boolean notifyLauncher(int type, int... action) {
        return false;
    }

    // --- Native: имена и сигнатуры зашиты в input_bridge_v3.c (registerFunctions) ---

    @Keep public static native void nativeSetUseInputStackQueue(boolean useInputStackQueue);

    @Keep private static native boolean nativeSendChar(char codepoint);
    @Keep private static native boolean nativeSendCharMods(char codepoint, int mods);
    @Keep private static native void nativeSendKey(int key, int scancode, int action, int mods);
    @Keep private static native void nativeSendCursorPos(float x, float y);
    @Keep private static native void nativeSendMouseButton(int button, int action, int mods);
    @Keep private static native void nativeResetInputState();
    @Keep private static native void nativeSendScroll(double xoffset, double yoffset);
    @Keep private static native void nativeSendScreenSize(int width, int height);

    @Keep public static native void nativeSetWindowAttrib(int attrib, int value);
    @Keep public static native void nativeSetGrabbing(boolean grab);
    @Keep public static native int getCurrentFps();

    static {
        NativeLibraryLoader.loadPojavLib();
    }
}
