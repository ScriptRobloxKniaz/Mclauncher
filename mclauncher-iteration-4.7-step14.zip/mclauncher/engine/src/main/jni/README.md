# Нативная часть игрового ядра (`engine/src/main/jni`)

Исходники на C/C++ — копия `ZalithLauncher/src/main/jni` из **ZalithLauncher 2** (ревизия закреплена в
[`../../../UPSTREAM`](../../../UPSTREAM)), который в свою очередь развивает нативный код **PojavLauncher**.

| | |
|---|---|
| Лицензия | GPL-3.0 (ZalithLauncher 2) с дополнительными условиями раздела 7; код Pojav — LGPL-3.0. Всё приложение MCLauncher распространяется под GPL-3.0, см. `LICENSE` в корне и `THIRD_PARTY_NOTICES.md`. |
| Что изменено | Файлы `*.c`, `*.h`, `*.cpp` не менялись. Убраны каталоги `jsound/`, `flite/`, `awt_xawt/` (звук JRE через OpenAL, озвучка, заглушки AWT) — они не нужны для первого запуска и вернутся при необходимости. `Android.mk` и `Application.mk` сокращены соответственно. |
| Сборка | `ndk-build` через AGP, только при `-Pmclauncher.native=true` (см. `engine/build.gradle.kts`). NDK `25.2.9519653`, как в апстриме. Зависимость `com.bytedance:bytehook` (MIT) подключается как prefab. |

**Нельзя переименовывать Java-классы моста.** Имена `com.movtery.zalithlauncher.bridge.ZLBridge`, `…LoggerBridge`,
`…ZLNativeInvoker`, `org.lwjgl.glfw.CallbackBridge`, `com.oracle.dalvik.VMLauncher` и ещё несколько вшиты в JNI-символы
(`Java_<пакет>_<класс>_<метод>`) и в вызовы `FindClass`. Подробности — `docs/ENGINE.md`, раздел 10.

Не добавляйте сюда собственный код без пометки: этот каталог должен оставаться сверяемым с апстримом.
