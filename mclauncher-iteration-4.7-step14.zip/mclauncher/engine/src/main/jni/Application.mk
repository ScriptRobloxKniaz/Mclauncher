# Параметры ndk-build для нативной части ядра. Как в ZalithLauncher 2; AGP переопределяет APP_PLATFORM значением minSdk.
APP_PLATFORM := android-21
APP_STL := c++_shared
