# Нативная часть игрового ядра MCLauncher (ndk-build). Лицензия: GPL-3.0, происхождение — см. README.md рядом.
#
# Это сокращённая копия jni/Android.mk из ZalithLauncher 2 (ревизия в engine/UPSTREAM). Убрано то, что для запуска
# игры не нужно на этом этапе: jsound (звук JRE через OpenAL), flite (озвучка), awt_headless и awt_xawt (заглушки AWT).
# Всё остальное оставлено как есть: имена модулей и функций зашиты в JNI-символы Java-классов моста (docs/ENGINE.md, раздел 10).
#
# Собирается только при -Pmclauncher.native=true (engine/build.gradle.kts); обычная сборка NDK не требует.

LOCAL_PATH := $(call my-dir)
HERE_PATH := $(LOCAL_PATH)

# bytehook (ByteDance, MIT) приходит как prefab-пакет из com.bytedance:bytehook; нужен для exithook.
$(call import-module,prefab/bytehook)
LOCAL_PATH := $(HERE_PATH)


# --- pojavexec: мост JVM <-> Android (запуск JVM, EGL/GL-мост, ввод, лог) ---
include $(CLEAR_VARS)
LOCAL_LDLIBS := -ldl -llog -landroid
LOCAL_MODULE := pojavexec
LOCAL_SHARED_LIBRARIES := driver_helper
LOCAL_CFLAGS += -rdynamic
LOCAL_SRC_FILES := \
    bigcoreaffinity.c \
    egl_bridge.c \
    ctxbridges/br_loader.c \
    ctxbridges/gl_bridge.c \
    ctxbridges/osm_bridge.c \
    ctxbridges/egl_loader.c \
    ctxbridges/osmesa_loader.c \
    ctxbridges/swap_interval_no_egl.c \
    ctxbridges/virgl_bridge.c \
    environ/environ.c \
    logger/logger.c \
    input_bridge_v3.c \
    jre_launcher.c \
    utils.c \
    stdio_is.c \
    java_exec_hooks.c \
    lwjgl_dlopen_hook.c

ifeq ($(TARGET_ARCH_ABI),arm64-v8a)
LOCAL_CFLAGS += -DADRENO_POSSIBLE
LOCAL_LDLIBS += -lEGL -lGLESv2
endif
include $(BUILD_SHARED_LIBRARY)


# --- vulkan_check: определяет, есть ли у устройства Vulkan (нужно для выбора рендера) ---
include $(CLEAR_VARS)
LOCAL_LDLIBS := -ldl -llog
LOCAL_MODULE := vulkan_check
LOCAL_SHARED_LIBRARIES := driver_helper
LOCAL_SRC_FILES := vulkan_checker.c
include $(BUILD_SHARED_LIBRARY)

ifeq ($(TARGET_ARCH_ABI),arm64-v8a)
LOCAL_CFLAGS += -DADRENO_POSSIBLE
endif


# --- exithook: перехват выхода игры (код завершения возвращается в лаунчер), хуки SDL ---
include $(CLEAR_VARS)
LOCAL_MODULE := exithook
LOCAL_LDLIBS := -ldl -llog
LOCAL_SHARED_LIBRARIES := bytehook pojavexec
LOCAL_SRC_FILES := exit_hook.c \
    sdl_hook.c \
    sdl_dlopen_hook.c
include $(BUILD_SHARED_LIBRARY)


# --- driver_helper: загрузка драйверов GPU в обход ограничений пространства имён линкера ---
include $(CLEAR_VARS)
LOCAL_LDLIBS := -ldl -llog -landroid
LOCAL_MODULE := driver_helper
LOCAL_SRC_FILES := \
    driver_helper/driver_helper.c \
    driver_helper/nsbypass.c
LOCAL_CFLAGS += -g -rdynamic

ifeq ($(TARGET_ARCH_ABI),arm64-v8a)
LOCAL_CFLAGS += -DADRENO_POSSIBLE
LOCAL_LDLIBS += -lEGL -lGLESv2
endif
include $(BUILD_SHARED_LIBRARY)


# --- linkerhook: подмена пространства имён линкера для загружаемых библиотек ---
include $(CLEAR_VARS)
LOCAL_MODULE := linkerhook
LOCAL_SRC_FILES := \
    linkerhook/linkerhook.cpp \
    linkerhook/linkerns.c
LOCAL_LDFLAGS := -z global
include $(BUILD_SHARED_LIBRARY)


# --- pojavexec_awt: мост AWT для Java-кода внутри JVM ---
include $(CLEAR_VARS)
LOCAL_MODULE := pojavexec_awt
LOCAL_SRC_FILES := \
    awt_bridge.c
include $(BUILD_SHARED_LIBRARY)
