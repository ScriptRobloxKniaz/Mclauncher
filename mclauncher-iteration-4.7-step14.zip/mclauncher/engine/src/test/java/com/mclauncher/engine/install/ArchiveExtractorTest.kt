package com.mclauncher.engine.install

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.nio.file.Files
import java.util.concurrent.CancellationException

class ArchiveExtractorTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val dest by lazy { File(tmp.root, "out") }

    private fun extract(tar: ByteArray, extractor: ArchiveExtractor = ArchiveExtractor(), check: () -> Unit = {}) =
        extractor.extractTar(tar.inputStream(), dest, check)

    private fun assertUnsafe(tar: ByteArray, extractor: ArchiveExtractor = ArchiveExtractor()): UnsafeArchiveException {
        try {
            extract(tar, extractor)
        } catch (e: UnsafeArchiveException) {
            return e
        }
        fail("An unsafe archive was extracted")
        throw AssertionError()
    }

    // ---------------------------------------------------------------- обычные записи

    @Test
    fun extractsFilesAndFolders() {
        val tar = TarBuilder().dir("lib").file("lib/a.txt", "alpha").file("b.txt", "beta").build()

        val stats = extract(tar)

        assertEquals("alpha", File(dest, "lib/a.txt").readText())
        assertEquals("beta", File(dest, "b.txt").readText())
        assertEquals(2, stats.files)
        assertEquals(3, stats.entries)
        assertEquals(9L, stats.bytes)
    }

    @Test
    fun theLeadingDotSlashOfRealRuntimeArchivesIsDropped() {
        val tar = TarBuilder().dir("./").dir("./bin").file("./bin/java", "x", mode = 0b111_101_101).file("./release", "r").build()

        extract(tar)

        assertTrue(File(dest, "bin/java").isFile)
        assertEquals("r", File(dest, "release").readText())
    }

    @Test
    fun parentFoldersAreCreatedWhenTheArchiveHasNoFolderEntries() {
        extract(TarBuilder().file("a/b/c.txt", "deep").build())

        assertEquals("deep", File(dest, "a/b/c.txt").readText())
    }

    @Test
    fun theExecutableBitIsKept() {
        extract(TarBuilder().file("bin/java", "x", mode = 0b111_101_101).file("lib/data", "y", mode = 0b110_100_100).build())

        assertTrue(File(dest, "bin/java").canExecute())
        assertFalse(File(dest, "lib/data").canExecute())
    }

    @Test
    fun aLaterArchiveReplacesFilesOfAnEarlierOne() {
        extract(TarBuilder().file("lib/x", "universal").file("only-universal", "u").build())
        extract(TarBuilder().file("lib/x", "arm64").file("only-bin", "b").build())

        assertEquals("arm64", File(dest, "lib/x").readText())
        assertEquals("u", File(dest, "only-universal").readText())
        assertEquals("b", File(dest, "only-bin").readText())
    }

    @Test
    fun aLongNameIsRestored() {
        val name = "legal/" + "d".repeat(80) + "/" + "f".repeat(90) + ".txt"
        extract(TarBuilder().file(name, "long").build())

        assertEquals("long", File(dest, name).readText())
    }

    // ---------------------------------------------------------------- ссылки

    @Test
    fun relativeSymlinksAreCreated() {
        val tar = TarBuilder()
            .file("legal/java.base/LICENSE", "text")
            .symlink("legal/java.net/LICENSE", "../java.base/LICENSE")
            .build()

        val stats = extract(tar)

        val link = File(dest, "legal/java.net/LICENSE")
        assertTrue(Files.isSymbolicLink(link.toPath()))
        assertEquals("text", link.readText())
        assertEquals(1, stats.symlinks)
    }

    @Test
    fun aSymlinkToAnAbsolutePathIsRefused() {
        assertUnsafe(TarBuilder().symlink("evil", "/etc/passwd").build())
    }

    @Test
    fun aSymlinkThatClimbsOutOfTheFolderIsRefused() {
        assertUnsafe(TarBuilder().symlink("evil", "../../outside").build())
        assertUnsafe(TarBuilder().dir("a").symlink("a/evil", "../../outside").build())
    }

    @Test
    fun aSymlinkThatStaysInsideAfterGoingUpIsAllowed() {
        extract(TarBuilder().file("x", "1").dir("a/b").symlink("a/b/link", "../../x").build())

        assertEquals("1", File(dest, "a/b/link").readText())
    }

    @Test
    fun nothingIsWrittenThroughASymlinkToAFolderOutside() {
        // Классическая атака: сначала ссылка на чужую папку, потом файл «через» неё.
        val outside = tmp.newFolder("outside")
        dest.mkdirs()
        Files.createSymbolicLink(File(dest, "link").toPath(), outside.toPath())

        assertUnsafe(TarBuilder().file("link/pwned.txt", "bad").build())
        assertFalse(File(outside, "pwned.txt").exists())
    }

    @Test
    fun aFileDoesNotFollowAnExistingSymlinkOnItsOwnName() {
        val outside = tmp.newFile("victim.txt").apply { writeText("keep") }
        dest.mkdirs()
        Files.createSymbolicLink(File(dest, "f").toPath(), outside.toPath())

        extract(TarBuilder().file("f", "new").build())

        assertEquals("keep", outside.readText())
        assertFalse(Files.isSymbolicLink(File(dest, "f").toPath()))
        assertEquals("new", File(dest, "f").readText())
    }

    @Test
    fun aHardLinkCopiesTheAlreadyExtractedFile() {
        extract(TarBuilder().file("lib/a", "same").hardlink("lib/b", "lib/a").build())

        assertEquals("same", File(dest, "lib/b").readText())
    }

    @Test
    fun aHardLinkToAMissingFileIsRefused() {
        assertUnsafe(TarBuilder().hardlink("b", "missing").build())
    }

    @Test
    fun devicesAndPipesAreRefusedInsteadOfSkipped() {
        assertUnsafe(TarBuilder().fifo("pipe").build())
    }

    // ---------------------------------------------------------------- имена

    @Test
    fun namesWithDotDotAreRefused() {
        assertUnsafe(TarBuilder().file("../evil.txt", "x").build())
        assertUnsafe(TarBuilder().file("a/../../evil.txt", "x").build())
        assertFalse(File(tmp.root, "evil.txt").exists())
    }

    @Test
    fun normalizeEntryNameRules() {
        assertEquals("a/b", ArchiveExtractor.normalizeEntryName("./a//b/"))
        assertEquals("bin/java", ArchiveExtractor.normalizeEntryName("./bin/java"))
        assertNull(ArchiveExtractor.normalizeEntryName("./"))
        assertNull(ArchiveExtractor.normalizeEntryName("."))
        for (bad in listOf("/etc/passwd", "../x", "a/../b", "a\\b", "x\u0000y")) {
            try {
                ArchiveExtractor.normalizeEntryName(bad)
                fail("'$bad' was accepted")
            } catch (_: UnsafeArchiveException) {
            }
        }
    }

    // ---------------------------------------------------------------- пределы и отмена

    @Test
    fun tooManyEntriesAreRefused() {
        val b = TarBuilder()
        repeat(5) { b.file("f$it", "x") }

        assertUnsafe(b.build(), ArchiveExtractor(maxEntries = 4))
    }

    @Test
    fun tooMuchDataIsRefused() {
        assertUnsafe(TarBuilder().file("big", ByteArray(1000)).build(), ArchiveExtractor(maxBytes = 999))
    }

    @Test
    fun theCheckpointCanCancelTheExtraction() {
        val b = TarBuilder()
        repeat(10) { b.file("f$it", "x") }
        var calls = 0

        try {
            extract(b.build()) {
                if (++calls == 4) throw CancellationException("stop")
            }
            fail("The extraction was not cancelled")
        } catch (_: CancellationException) {
        }
        assertTrue(File(dest, "f0").exists())
        assertFalse(File(dest, "f9").exists())
    }
}
