package com.mclauncher.engine.install

import com.mclauncher.engine.LwjglRequirement
import com.mclauncher.engine.LwjglVersion
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class CoreManifestTest {

    private val sha = "a".repeat(64)
    private val rev = "1".repeat(40)

    private fun manifest(vararg extra: String): String = (
        listOf(
            "# комментарий",
            "mcl-core 1",
            "abi arm64-v8a",
            "upstream $rev",
            "component launcher dir components/launcher $sha",
            "file launcher MioLaunchWrapper.jar 2103 $sha",
            "file launcher MioLibPatcher.jar 816423 $sha",
            "component jre-17 runtime runtimes/jre-17 $sha",
            "file jre-17 universal.tar.xz 100 $sha",
            "file jre-17 bin-arm64.tar.xz 50 $sha",
        ) + extra
        ).joinToString("\n")

    private fun assertRejected(text: String, fragment: String) {
        try {
            CoreManifest.parse(text)
            fail("The manifest was accepted, expected an error with '$fragment'")
        } catch (e: ManifestException) {
            assertTrue("'${e.message}' should mention '$fragment'", e.message!!.contains(fragment))
        }
    }

    // ---------------------------------------------------------------- разбор

    @Test
    fun parsesAWellFormedManifest() {
        val m = CoreManifest.parse(manifest())

        assertEquals("arm64-v8a", m.abi)
        assertEquals(rev, m.upstream)
        assertEquals(listOf("launcher", "jre-17"), m.components.map { it.id })
        val launcher = m.component("launcher")!!
        assertEquals(ComponentKind.DIR, launcher.kind)
        assertEquals("components/launcher", launcher.dest)
        assertEquals(2, launcher.files.size)
        assertEquals(2103L + 816423L, launcher.totalBytes)
        assertEquals(ComponentKind.RUNTIME, m.component("jre-17")!!.kind)
        assertNull(m.component("jre-99"))
    }

    @Test
    fun anAssetPathIsBuiltFromTheDestinationAndTheFileName() {
        val launcher = CoreManifest.parse(manifest()).component("launcher")!!

        assertEquals("core/components/launcher/MioLaunchWrapper.jar", launcher.assetPath(launcher.files[0]))
    }

    @Test
    fun theManifestAssetNameMatchesWhatTheScriptWrites() {
        assertEquals("core/core-manifest.txt", CoreManifest.ASSET_NAME)
    }

    @Test
    fun windowsLineEndingsAndBlankLinesAreFine() {
        val text = manifest().replace("\n", "\r\n") + "\r\n\r\n"

        assertEquals(2, CoreManifest.parse(text).components.size)
    }

    // ---------------------------------------------------------------- отказы

    @Test
    fun aMissingHeaderIsRejected() {
        assertRejected(manifest().lines().filter { !it.startsWith("mcl-core") }.joinToString("\n"), "header")
    }

    @Test
    fun anUnknownFormatVersionIsRejected() {
        assertRejected(manifest().replace("mcl-core 1", "mcl-core 2"), "unsupported format")
    }

    @Test
    fun missingAbiOrUpstreamIsRejected() {
        assertRejected(manifest().lines().filter { !it.startsWith("abi") }.joinToString("\n"), "'abi'")
        assertRejected(manifest().lines().filter { !it.startsWith("upstream") }.joinToString("\n"), "'upstream'")
    }

    @Test
    fun anUpstreamThatIsNotAFullShaIsRejected() {
        assertRejected(manifest().replace(rev, "main"), "upstream")
    }

    @Test
    fun unknownLinesAreRejectedRatherThanIgnored() {
        assertRejected(manifest("extra things"), "unknown line")
    }

    @Test
    fun aFileOfAnUnknownComponentIsRejected() {
        assertRejected(manifest("file ghost x.jar 1 $sha"), "unknown component")
    }

    @Test
    fun aDuplicateComponentOrFileIsRejected() {
        assertRejected(manifest("component launcher dir components/other $sha"), "duplicate component")
        assertRejected(manifest("file launcher MioLaunchWrapper.jar 1 $sha"), "duplicate file")
    }

    @Test
    fun unsafePathsAreRejected() {
        for (path in listOf("../x.jar", "a/../b.jar", "/abs.jar", "a//b.jar", "dir/")) {
            assertRejected(manifest("file launcher $path 1 $sha"), "unsafe file path")
        }
        // Пробел в имени — лишнее поле в строке: манифест построчный, скрипт такие имена не пишет.
        assertRejected(manifest("file launcher a b.jar 1 $sha"), "file line")
        assertRejected(manifest().replace("components/launcher", "components/../x"), "unsafe destination")
    }

    @Test
    fun aDestinationOutsideTheKnownRootsIsRejected() {
        assertRejected(manifest().replace("components/launcher", "elsewhere/launcher"), "does not fit")
        // Рантайм нельзя положить в components/, а набор файлов — в runtimes/.
        assertRejected(manifest().replace("runtimes/jre-17", "components/jre-17"), "does not fit")
        assertRejected(manifest().replace("components/launcher", "runtimes/launcher"), "does not fit")
    }

    @Test
    fun badNumbersAndHashesAreRejected() {
        assertRejected(manifest().replace("2103", "-5"), "bad size")
        assertRejected(manifest().replace("2103", "many"), "bad size")
        assertRejected(manifest().replaceFirst(sha, "xyz"), "content id")
    }

    @Test
    fun aComponentWithoutFilesIsRejected() {
        assertRejected(manifest("component empty dir components/empty $sha"), "no files")
    }

    @Test
    fun aRuntimeMayOnlyHoldArchives() {
        assertRejected(manifest("file jre-17 script.sh 1 $sha"), "only contain .tar.xz")
    }

    @Test
    fun anEmptyManifestIsRejected() {
        assertRejected("", "header")
        assertRejected("mcl-core 1\nabi arm64-v8a\nupstream $rev\n", "no components")
    }

    @Test
    fun safeRelativePathRules() {
        assertTrue(CoreManifest.isSafeRelativePath("natives/arm64-v8a/liblwjgl.so"))
        assertTrue(CoreManifest.isSafeRelativePath("lwjgl-3.3.3-merged-modules.jar"))
        assertFalse(CoreManifest.isSafeRelativePath(""))
        assertFalse(CoreManifest.isSafeRelativePath("."))
        assertFalse(CoreManifest.isSafeRelativePath("a/./b"))
        assertFalse(CoreManifest.isSafeRelativePath("a\\b"))
    }

    // ---------------------------------------------------------------- что нужно версии игры

    @Test
    fun requirementsNameTheLauncherTheLwjglSetAndTheRuntime() {
        val ids = CoreRequirements.idsFor(LwjglRequirement(LwjglVersion.V3_4_1, legacyLwjgl2 = false), javaMajor = 21)

        assertEquals(listOf("launcher", "lwjgl-3.4.1", "jre-21"), ids)
    }

    @Test
    fun theRuntimeIsTheNearestNotOlderOne() {
        val ids = CoreRequirements.idsFor(LwjglRequirement.DEFAULT, javaMajor = 16)

        assertEquals(listOf("launcher", "lwjgl-3.3.3", "jre-17"), ids)
    }

    @Test
    fun aJavaNewerThanAnyRuntimeHasNoRequirements() {
        assertNull(CoreRequirements.idsFor(LwjglRequirement.DEFAULT, javaMajor = 99))
    }

    @Test
    fun idsFromRequirementsExistInAManifestBuiltWithTheScriptNaming() {
        val text = manifest(
            "component lwjgl-3.3.3 dir components/lwjgl/3.3.3 $sha",
            "file lwjgl-3.3.3 lwjgl.jar 10 $sha",
            "file lwjgl-3.3.3 natives/arm64-v8a/liblwjgl.so 10 $sha",
        )
        val m = CoreManifest.parse(text)
        val ids = CoreRequirements.idsFor(LwjglRequirement.DEFAULT, javaMajor = 17)!!

        assertTrue(ids.all { m.component(it) != null })
        assertNotNull(m.component("lwjgl-3.3.3"))
    }
}
