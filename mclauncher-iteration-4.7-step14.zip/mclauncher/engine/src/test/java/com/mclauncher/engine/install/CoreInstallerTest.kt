package com.mclauncher.engine.install

import com.mclauncher.engine.EngineLayout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.CancellationException

class CoreInstallerTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private lateinit var layout: EngineLayout

    /** Содержимое «ассетов»: путь → байты. Заполняется фикстурами ниже. */
    private val assets = HashMap<String, ByteArray>()
    private val opened = ArrayList<String>()
    private val manifestLines = ArrayList<String>()
    private val unpacked = ArrayList<String>()

    @Before
    fun setUp() {
        layout = EngineLayout(
            componentsDir = File(tmp.root, "files/components"),
            runtimesDir = File(tmp.root, "files/runtimes"),
            nativeLibraryDir = File(tmp.root, "lib"),
            abi = "arm64-v8a",
        )
        manifestLines += listOf("mcl-core 1", "abi arm64-v8a", "upstream ${"1".repeat(40)}")
    }

    // ---------------------------------------------------------------- фикстуры

    private fun addDir(id: String, dest: String, files: Map<String, String>, contentId: String = sha256Hex(id.toByteArray())) {
        manifestLines += "component $id dir $dest $contentId"
        for ((path, text) in files) {
            val bytes = text.toByteArray()
            assets["core/$dest/$path"] = bytes
            manifestLines += "file $id $path ${bytes.size} ${sha256Hex(bytes)}"
        }
    }

    private fun javaTars(withPacks: Boolean = false): Pair<ByteArray, ByteArray> {
        val universal = TarBuilder().file("release", "JAVA_VERSION=\"17\"").file("lib/modules", "m")
        if (withPacks) universal.file("lib/rt.jar.pack", "packed")
        val bin = TarBuilder().dir("./bin").file("./bin/java", "elf", mode = 0b111_101_101).file("./lib/server/libjvm.so", "jvm")
        return universal.build() to bin.build()
    }

    private fun addRuntime(
        id: String,
        dest: String,
        tars: Pair<ByteArray, ByteArray> = javaTars(),
        contentId: String = sha256Hex(id.toByteArray()),
    ) {
        manifestLines += "component $id runtime $dest $contentId"
        for ((name, bytes) in listOf("universal.tar.xz" to tars.first, "bin-arm64.tar.xz" to tars.second)) {
            assets["core/$dest/$name"] = bytes
            manifestLines += "file $id $name ${bytes.size} ${sha256Hex(bytes)}"
        }
    }

    private fun manifest() = CoreManifest.parse(manifestLines.joinToString("\n"))

    private fun installer(
        freeSpace: (File) -> Long = { Long.MAX_VALUE },
        unpack200: Unpack200 = Unpack200 { pack, out ->
            unpacked += pack.name
            out.writeText("jar of ${pack.name}")
            pack.delete()
        },
    ) = CoreInstaller(
        layout = layout,
        manifest = manifest(),
        assets = CoreAssets { path ->
            opened += path
            val bytes = assets[path] ?: throw FileNotFoundException(path)
            bytes.inputStream()
        },
        unpack200 = unpack200,
        openXz = { it }, // в тестах «xz» — обычный tar: настоящего xz-декодера на JVM-тестах нет
        freeSpace = freeSpace,
    )

    private fun leftovers(): List<String> =
        tmp.root.walkTopDown().filter { it.name.endsWith(".installing") }.map { it.path }.toList()

    // ---------------------------------------------------------------- набор файлов

    @Test
    fun installsADirComponentIntoItsFolder() {
        addDir("launcher", "components/launcher", mapOf("MioLaunchWrapper.jar" to "wrapper", "MioLibPatcher.jar" to "patcher"))

        installer().install(listOf("launcher"))

        assertEquals("wrapper", layout.launchWrapperJar.readText())
        assertEquals("patcher", layout.libPatcherJar.readText())
        assertTrue(File(layout.componentsDir, "launcher/${CoreInstaller.MARKER}").isFile)
        assertEquals(emptyList<String>(), leftovers())
    }

    @Test
    fun filesInSubfoldersKeepTheirPlace() {
        addDir(
            "lwjgl-3.3.3", "components/lwjgl/3.3.3",
            mapOf("lwjgl.jar" to "core", "natives/arm64-v8a/liblwjgl.so" to "native"),
        )

        installer().install(listOf("lwjgl-3.3.3"))

        assertEquals("native", File(layout.lwjglDir(com.mclauncher.engine.LwjglVersion.V3_3_3), "natives/arm64-v8a/liblwjgl.so").readText())
        assertEquals(
            File(layout.componentsDir, "lwjgl/3.3.3/natives/arm64-v8a"),
            layout.lwjglNativesDir(com.mclauncher.engine.LwjglVersion.V3_3_3),
        )
    }

    @Test
    fun theMarkerFileDoesNotAppearInTheLwjglJarList() {
        addDir("lwjgl-3.3.3", "components/lwjgl/3.3.3", mapOf("lwjgl.jar" to "a", "lwjgl-stb.jar" to "b"))

        installer().install(listOf("lwjgl-3.3.3"))

        val jars = layout.lwjglJars(com.mclauncher.engine.LwjglRequirement.DEFAULT).map { it.name }
        assertEquals(listOf("lwjgl.jar", "lwjgl-stb.jar"), jars)
    }

    // ---------------------------------------------------------------- рантайм

    @Test
    fun installsARuntimeFromTwoArchives() {
        addRuntime("jre-17", "runtimes/jre-17")

        installer().install(listOf("jre-17"))

        assertTrue(layout.javaExecutable(17).isFile)
        assertTrue(layout.javaExecutable(17).canExecute())
        assertEquals("m", File(layout.runtimeDir(17), "lib/modules").readText())
        assertTrue(File(layout.runtimeDir(17), "lib/server/libjvm.so").isFile)
        assertEquals(layout.runtimeDir(17), layout.javaHome(17))
        assertEquals(emptyList<String>(), leftovers())
    }

    @Test
    fun theArchiveForTheArchitectureLaysOverTheUniversalOne() {
        val universal = TarBuilder().file("release", "r").file("lib/jvm.cfg", "universal").build()
        val bin = TarBuilder().file("bin/java", "elf").file("lib/server/libjvm.so", "j").file("lib/jvm.cfg", "arm64").build()
        // В манифесте файлы идут по алфавиту (bin-arm64 раньше universal): порядок установки от этого зависеть не должен.
        manifestLines += "component jre-17 runtime runtimes/jre-17 ${sha256Hex("x".toByteArray())}"
        for ((name, b) in listOf("bin-arm64.tar.xz" to bin, "universal.tar.xz" to universal)) {
            assets["core/runtimes/jre-17/$name"] = b
            manifestLines += "file jre-17 $name ${b.size} ${sha256Hex(b)}"
        }

        installer().install(listOf("jre-17"))

        assertEquals("arm64", File(layout.runtimeDir(17), "lib/jvm.cfg").readText())
    }

    @Test
    fun packedJarsOfJavaEightAreUnpackedAndTheRuntimeIsChecked() {
        addRuntime("jre-8", "runtimes/jre-8", javaTars(withPacks = true))

        installer().install(listOf("jre-8"))

        assertEquals(listOf("rt.jar.pack"), unpacked)
        assertEquals("jar of rt.jar.pack", File(layout.runtimeDir(8), "lib/rt.jar").readText())
        assertFalse(File(layout.runtimeDir(8), "lib/rt.jar.pack").exists())
        assertEquals(layout.runtimeDir(8), layout.javaHome(8))
    }

    @Test
    fun aFailingUnpackerFailsTheRuntimeAndLeavesNothingBehind() {
        addRuntime("jre-8", "runtimes/jre-8", javaTars(withPacks = true))

        try {
            installer(unpack200 = Unpack200 { _, _ -> throw IOException("exec failed") }).install(listOf("jre-8"))
            fail("The install should have failed")
        } catch (e: CoreInstallException.Failed) {
            assertEquals("jre-8", e.componentId)
            assertTrue(e.message!!.contains("exec failed"))
        }
        assertFalse(layout.runtimeDir(8).exists())
        assertEquals(emptyList<String>(), leftovers())
    }

    @Test
    fun anIncompleteRuntimeIsNotInstalled() {
        // Нет libjvm.so — JVM не стартует, лучше отказаться сразу.
        val universal = TarBuilder().file("release", "r").build()
        val bin = TarBuilder().file("bin/java", "elf").build()
        addRuntime("jre-21", "runtimes/jre-21", universal to bin)

        try {
            installer().install(listOf("jre-21"))
            fail("An incomplete runtime was installed")
        } catch (e: CoreInstallException.Failed) {
            assertTrue(e.message!!.contains("libjvm.so"))
        }
        assertFalse(layout.runtimeDir(21).exists())
    }

    @Test
    fun anUnsafeArchiveFailsTheComponent() {
        val evil = TarBuilder().file("../escape", "x").build()
        addRuntime("jre-17", "runtimes/jre-17", evil to javaTars().second)

        try {
            installer().install(listOf("jre-17"))
            fail("An unsafe archive was installed")
        } catch (e: CoreInstallException.Failed) {
            assertTrue(e.cause is UnsafeArchiveException)
        }
        assertFalse(File(tmp.root, "files/escape").exists())
        assertFalse(layout.runtimeDir(17).exists())
    }

    // ---------------------------------------------------------------- состояние

    @Test
    fun theStateGoesFromMissingToInstalled() {
        addDir("launcher", "components/launcher", mapOf("MioLaunchWrapper.jar" to "w"))
        val c = manifest().component("launcher")!!
        val installer = installer()

        assertEquals(ComponentState.MISSING, installer.state(c))
        installer.install(listOf("launcher"))
        assertEquals(ComponentState.INSTALLED, installer.state(c))
    }

    @Test
    fun anInstalledComponentIsNotInstalledAgain() {
        addDir("launcher", "components/launcher", mapOf("MioLaunchWrapper.jar" to "w"))
        val installer = installer()
        installer.install(listOf("launcher"))
        opened.clear()

        installer.install(listOf("launcher"))

        assertEquals(emptyList<String>(), opened)
        assertEquals(emptyList<String>(), installer.pending(listOf("launcher")).map { it.id })
    }

    @Test
    fun aMarkerFromAnotherBuildMeansOutdatedAndIsReplaced() {
        addDir("launcher", "components/launcher", mapOf("MioLaunchWrapper.jar" to "old"), contentId = "1".repeat(64))
        installer().install(listOf("launcher"))
        // Новая сборка приложения: тот же компонент, другое содержимое и другой contentId.
        manifestLines.clear()
        manifestLines += listOf("mcl-core 1", "abi arm64-v8a", "upstream ${"1".repeat(40)}")
        addDir("launcher", "components/launcher", mapOf("MioLaunchWrapper.jar" to "new"), contentId = "2".repeat(64))
        val installer = installer()
        val c = manifest().component("launcher")!!

        assertEquals(ComponentState.OUTDATED, installer.state(c))
        installer.install(listOf("launcher"))

        assertEquals("new", layout.launchWrapperJar.readText())
        assertEquals(ComponentState.INSTALLED, installer.state(c))
    }

    @Test
    fun aDamagedFileOfAnInstalledComponentIsRepaired() {
        addDir("launcher", "components/launcher", mapOf("MioLaunchWrapper.jar" to "wrapper!"))
        val installer = installer()
        installer.install(listOf("launcher"))
        layout.launchWrapperJar.writeText("cut") // другой размер

        assertEquals(ComponentState.OUTDATED, installer.state(manifest().component("launcher")!!))
        installer.install(listOf("launcher"))

        assertEquals("wrapper!", layout.launchWrapperJar.readText())
    }

    @Test
    fun aMissingRuntimeBinaryMeansTheRuntimeIsOutdated() {
        addRuntime("jre-17", "runtimes/jre-17")
        val installer = installer()
        installer.install(listOf("jre-17"))
        layout.javaExecutable(17).delete()

        assertEquals(ComponentState.OUTDATED, installer.state(manifest().component("jre-17")!!))
    }

    @Test
    fun onlyMissingComponentsAreInstalled() {
        addDir("launcher", "components/launcher", mapOf("MioLaunchWrapper.jar" to "w"))
        addDir("lwjgl-3.3.3", "components/lwjgl/3.3.3", mapOf("lwjgl.jar" to "l"))
        val installer = installer()
        installer.install(listOf("launcher"))
        opened.clear()

        installer.install(listOf("launcher", "lwjgl-3.3.3"))

        assertEquals(listOf("core/components/lwjgl/3.3.3/lwjgl.jar"), opened)
    }

    // ---------------------------------------------------------------- ошибки

    @Test
    fun anUnknownComponentIsReported() {
        addDir("launcher", "components/launcher", mapOf("a.jar" to "a"))

        try {
            installer().install(listOf("ghost"))
            fail("An unknown component was accepted")
        } catch (e: CoreInstallException.UnknownComponent) {
            assertEquals("ghost", e.id)
        }
    }

    @Test
    fun aFileMissingFromTheAssetsIsReportedAsABuildWithoutTheCore() {
        addDir("launcher", "components/launcher", mapOf("a.jar" to "a"))
        assets.clear()

        try {
            installer().install(listOf("launcher"))
            fail("A missing asset was not reported")
        } catch (e: CoreInstallException.AssetMissing) {
            assertEquals("core/components/launcher/a.jar", e.path)
        }
        assertFalse(File(layout.componentsDir, "launcher").exists())
        assertEquals(emptyList<String>(), leftovers())
    }

    @Test
    fun aCorruptedAssetIsRejectedByItsSha() {
        addDir("launcher", "components/launcher", mapOf("a.jar" to "right"))
        assets["core/components/launcher/a.jar"] = "wrong".toByteArray() // тот же размер, другое содержимое

        try {
            installer().install(listOf("launcher"))
            fail("A corrupted asset was installed")
        } catch (e: CoreInstallException.Corrupt) {
            assertTrue(e.path.endsWith("a.jar"))
        }
        assertFalse(File(layout.componentsDir, "launcher").exists())
    }

    @Test
    fun aTruncatedAssetIsRejectedBySize() {
        addDir("launcher", "components/launcher", mapOf("a.jar" to "complete"))
        assets["core/components/launcher/a.jar"] = "comp".toByteArray()

        try {
            installer().install(listOf("launcher"))
            fail("A truncated asset was installed")
        } catch (_: CoreInstallException.Corrupt) {
        }
    }

    @Test
    fun aCorruptedArchiveIsRejectedAsAWholeFile() {
        addRuntime("jre-17", "runtimes/jre-17")
        // Хвост архива изменён после tar-данных: распаковка пройдёт, а сумма всего файла не совпадёт.
        val key = "core/runtimes/jre-17/bin-arm64.tar.xz"
        assets[key] = assets[key]!!.copyOf().also { it[it.size - 1] = 1 }

        try {
            installer().install(listOf("jre-17"))
            fail("A corrupted archive was installed")
        } catch (e: CoreInstallException.Corrupt) {
            assertTrue(e.path.endsWith("bin-arm64.tar.xz"))
        }
        assertFalse(layout.runtimeDir(17).exists())
    }

    @Test
    fun notEnoughSpaceStopsBeforeAnythingIsWritten() {
        addDir("launcher", "components/launcher", mapOf("a.jar" to "a"))

        try {
            installer(freeSpace = { 1_000 }).install(listOf("launcher"))
            fail("The install started without space")
        } catch (e: CoreInstallException.NoSpace) {
            assertEquals(1_000L, e.availableBytes)
            assertTrue(e.requiredBytes > 1_000)
        }
        assertEquals(emptyList<String>(), opened)
        assertFalse(File(layout.componentsDir, "launcher").exists())
    }

    @Test
    fun aRuntimeNeedsMoreSpaceThanItsArchivesWeigh() {
        addRuntime("jre-17", "runtimes/jre-17")
        val archives = manifest().component("jre-17")!!.totalBytes
        var asked = 0L

        try {
            installer(freeSpace = { 0L }).install(listOf("jre-17"))
        } catch (e: CoreInstallException.NoSpace) {
            asked = e.requiredBytes
        }

        assertTrue("need $asked for archives of $archives", asked >= archives * 6)
    }

    // ---------------------------------------------------------------- отмена и прогресс

    @Test
    fun cancellationStopsTheInstallAndCleansUp() {
        addDir("launcher", "components/launcher", mapOf("a.jar" to "a".repeat(400_000)))
        var calls = 0

        try {
            installer().install(listOf("launcher")) {
                if (++calls == 2) throw CancellationException("cancelled")
            }
            fail("The install was not cancelled")
        } catch (e: CancellationException) {
            assertEquals("cancelled", e.message)
        }
        assertFalse(File(layout.componentsDir, "launcher").exists())
        assertEquals(emptyList<String>(), leftovers())
    }

    @Test
    fun cancellationKeepsThePreviousInstallation() {
        addDir("launcher", "components/launcher", mapOf("a.jar" to "old"), contentId = "1".repeat(64))
        installer().install(listOf("launcher"))
        manifestLines.clear()
        manifestLines += listOf("mcl-core 1", "abi arm64-v8a", "upstream ${"1".repeat(40)}")
        addDir("launcher", "components/launcher", mapOf("a.jar" to "n".repeat(400_000)), contentId = "2".repeat(64))

        try {
            installer().install(listOf("launcher")) { throw CancellationException("cancelled") }
            fail("The install was not cancelled")
        } catch (_: CancellationException) {
        }

        assertEquals("old", File(layout.componentsDir, "launcher/a.jar").readText())
        assertEquals(emptyList<String>(), leftovers())
    }

    @Test
    fun progressGrowsToTheTotalOfTheArchivesAndFiles() {
        addDir("launcher", "components/launcher", mapOf("a.jar" to "a".repeat(300_000), "b.jar" to "b".repeat(300_000)))
        addRuntime("jre-17", "runtimes/jre-17")
        val total = manifest().components.sumOf { it.totalBytes }
        val seen = ArrayList<CoreProgress>()

        installer().install(listOf("launcher", "jre-17")) { seen += it }

        assertTrue(seen.isNotEmpty())
        assertTrue("progress must never go back", seen.zipWithNext().all { (a, b) -> b.doneBytes >= a.doneBytes })
        assertTrue(seen.all { it.totalBytes == total })
        assertEquals(total, seen.last().doneBytes)
        assertEquals(1f, seen.last().fraction, 0f)
        assertEquals(setOf("launcher", "jre-17"), seen.map { it.componentId }.toSet())
    }

    @Test
    fun theTargetFolderMatchesTheEngineLayout() {
        addDir("lwjgl-3.4.1", "components/lwjgl/3.4.1", mapOf("lwjgl.jar" to "l"))
        addRuntime("jre-21", "runtimes/jre-21")
        val m = manifest()
        val installer = installer()

        assertEquals(layout.lwjglDir(com.mclauncher.engine.LwjglVersion.V3_4_1), installer.targetDir(m.component("lwjgl-3.4.1")!!))
        assertEquals(layout.runtimeDir(21), installer.targetDir(m.component("jre-21")!!))
        assertNotEquals(layout.runtimeDir(17), installer.targetDir(m.component("jre-21")!!))
    }

    @Test
    fun anInstalledSetPassesTheEngineCoreCheckForTheFiles() {
        addDir("launcher", "components/launcher", mapOf("MioLaunchWrapper.jar" to "w", "MioLibPatcher.jar" to "p"))
        addDir(
            "lwjgl-3.3.3", "components/lwjgl/3.3.3",
            mapOf("lwjgl.jar" to "l", "natives/arm64-v8a/liblwjgl.so" to "n"),
        )
        addRuntime("jre-17", "runtimes/jre-17")
        File(layout.nativeLibraryDir, "").mkdirs()
        File(layout.nativeLibraryDir, "libpojavexec.so").writeText("x")
        File(layout.nativeLibraryDir, "libopenal.so").writeText("x")

        installer().install(com.mclauncher.engine.install.CoreRequirements.idsFor(com.mclauncher.engine.LwjglRequirement.DEFAULT, 17)!!)

        val status = com.mclauncher.engine.EngineCore.check(layout, com.mclauncher.engine.LwjglRequirement.DEFAULT, 17)
        assertEquals(emptyList<String>(), status.missing)
    }
}
