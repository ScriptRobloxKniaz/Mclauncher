package com.mclauncher.engine.launch

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RendererAdvisorTest {

    private val v1214 = "2024-12-03T10:23:00+00:00"
    private val v1215snapshot = "2025-01-08T14:00:00+00:00"
    private val v1165 = "2021-01-14T16:05:32+00:00"
    private val v116old = "2013-04-25T15:45:00+00:00"
    private val v117 = "2021-06-08T11:00:40+00:00"

    @Test
    fun gl4esStopsAfter1214AndTheBoundaryItselfIsStillSupported() {
        assertTrue(RendererProfile.GL4ES.supportsRelease(v1214))
        assertFalse(RendererProfile.GL4ES.supportsRelease(v1215snapshot))
        assertTrue(RendererProfile.GL4ES.supportsRelease(v1165))
        assertTrue(RendererProfile.GL4ES.supportsRelease(v116old))
    }

    @Test
    fun mobileGluesStartsAt117() {
        assertTrue(RendererProfile.MOBILEGLUES.supportsRelease(v117))
        assertTrue(RendererProfile.MOBILEGLUES.supportsRelease(v1215snapshot))
        assertFalse(RendererProfile.MOBILEGLUES.supportsRelease(v1165))
        assertFalse(RendererProfile.MOBILEGLUES.supportsRelease(v116old))
    }

    @Test
    fun anUnknownOrMalformedDateIsNeverHeldAgainstTheRenderer() {
        for (value in listOf(null, "", "abc", "2024/12/03", "2024-1-03xx")) {
            assertTrue(value.toString(), RendererProfile.GL4ES.supportsRelease(value))
            assertTrue(value.toString(), RendererProfile.MOBILEGLUES.supportsRelease(value))
        }
    }

    @Test
    fun anUnboundedRendererSupportsEverything() {
        assertTrue(RendererProfile.KRYPTON.supportsRelease(v116old))
        assertTrue(RendererProfile.ZINK.supportsRelease(v1215snapshot))
    }

    @Test
    fun aSupportedChoiceIsLeftAlone() {
        val choice = RendererAdvisor.resolve(RendererProfile.GL4ES, v1214)

        assertEquals(RendererProfile.GL4ES, choice.profile)
        assertNull(choice.switchedFrom)
    }

    @Test
    fun gl4esOnANewerVersionIsSwitchedToMobileGlues() {
        val choice = RendererAdvisor.resolve(RendererProfile.GL4ES, v1215snapshot)

        assertEquals(RendererProfile.MOBILEGLUES, choice.profile)
        assertEquals(RendererProfile.GL4ES, choice.switchedFrom)
    }

    @Test
    fun mobileGluesOnAnOlderVersionIsSwitchedToGl4es() {
        val choice = RendererAdvisor.resolve(RendererProfile.MOBILEGLUES, v1165)

        assertEquals(RendererProfile.GL4ES, choice.profile)
        assertEquals(RendererProfile.MOBILEGLUES, choice.switchedFrom)
    }

    @Test
    fun gl4esWithAChosenOpenGlVersionIsStillRecognisedAsGl4es() {
        val requested = RendererProfile.GL4ES.withEnv("LIBGL_GL" to "30")

        val choice = RendererAdvisor.resolve(requested, v1215snapshot)

        assertEquals(RendererProfile.MOBILEGLUES, choice.profile)
        assertEquals(requested, choice.switchedFrom)
    }

    @Test
    fun unboundedRenderersAreNeverSwitched() {
        for (renderer in listOf(RendererProfile.KRYPTON, RendererProfile.ZINK)) {
            for (date in listOf(v116old, v1214, v1215snapshot)) {
                assertEquals(RendererChoice(renderer), RendererAdvisor.resolve(renderer, date))
            }
        }
    }

    @Test
    fun theRequestedProfileIsKeptWhenNoFallbackFits() {
        val picky = RendererProfile("x", "X", "libx.so", oldestRelease = "2030-01-01", newestRelease = "2030-01-02")

        assertEquals(RendererChoice(picky), RendererAdvisor.resolve(picky, v1214, fallbacks = listOf(picky, RendererProfile.MOBILEGLUES.copy(oldestRelease = "2031-01-01"))))
    }

    @Test
    fun theDefaultFallbacksCoverEveryReleaseDate() {
        // Если границы GL4ES и MobileGlues разойдутся, для каких-то версий замены не найдётся — тест это покажет.
        for (date in listOf("2009-05-17", "2013-04-25", "2021-06-07", "2021-06-08", "2024-12-03", "2024-12-04", "2026-06-09")) {
            val choice = RendererAdvisor.resolve(RendererProfile.ZINK.copy(oldestRelease = "2999-01-01"), "${date}T00:00:00+00:00")

            assertTrue(date, choice.profile.supportsRelease("${date}T00:00:00+00:00"))
        }
    }
}
