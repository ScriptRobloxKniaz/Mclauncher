package com.mclauncher.engine.install

import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.archivers.tar.TarConstants
import java.io.ByteArrayOutputStream
import java.security.MessageDigest

/** Собирает tar в памяти для тестов распаковщика и установщика. */
class TarBuilder {
    private val bytes = ByteArrayOutputStream()
    private val tar = TarArchiveOutputStream(bytes).apply {
        setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
    }

    fun file(name: String, content: String, mode: Int = 0b110_100_100): TarBuilder = file(name, content.toByteArray(), mode)

    fun file(name: String, content: ByteArray, mode: Int = 0b110_100_100): TarBuilder = apply {
        val entry = TarArchiveEntry(name)
        entry.size = content.size.toLong()
        entry.mode = mode
        tar.putArchiveEntry(entry)
        tar.write(content)
        tar.closeArchiveEntry()
    }

    fun dir(name: String): TarBuilder = apply {
        val entry = TarArchiveEntry(if (name.endsWith("/")) name else "$name/")
        tar.putArchiveEntry(entry)
        tar.closeArchiveEntry()
    }

    fun symlink(name: String, target: String): TarBuilder = apply {
        val entry = TarArchiveEntry(name, TarConstants.LF_SYMLINK)
        entry.linkName = target
        tar.putArchiveEntry(entry)
        tar.closeArchiveEntry()
    }

    fun hardlink(name: String, target: String): TarBuilder = apply {
        val entry = TarArchiveEntry(name, TarConstants.LF_LINK)
        entry.linkName = target
        tar.putArchiveEntry(entry)
        tar.closeArchiveEntry()
    }

    fun fifo(name: String): TarBuilder = apply {
        val entry = TarArchiveEntry(name, TarConstants.LF_FIFO)
        tar.putArchiveEntry(entry)
        tar.closeArchiveEntry()
    }

    fun build(): ByteArray {
        tar.finish()
        tar.close()
        return bytes.toByteArray()
    }
}

fun sha256Hex(data: ByteArray): String =
    MessageDigest.getInstance("SHA-256").digest(data).joinToString("") { "%02x".format(it) }
