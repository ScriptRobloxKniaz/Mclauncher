package com.mclauncher.engine.launch

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class GameExitReportTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val dir by lazy { File(tmp.root, "logs") }

    @Test
    fun formatAndParseRoundTrip() {
        val report = GameExitReport(exitCode = 134, isSignal = true, message = "line one\nline two\\end", logFile = "/g/logs/latest.log", timeMillis = 1234L)

        assertEquals(report, GameExitReport.parse(report.format()))
    }

    @Test
    fun parseRejectsTextWithoutAnExitCode() {
        assertNull(GameExitReport.parse(""))
        assertNull(GameExitReport.parse("signal=true\n"))
        assertNull(GameExitReport.parse("exit_code=abc\n"))
    }

    @Test
    fun onlyCodeZeroWithoutSignalIsNormal() {
        assertTrue(GameExitReport(0, false).isNormal)
        assertFalse(GameExitReport(0, true).isNormal)
        assertFalse(GameExitReport(1, false).isNormal)
    }

    @Test
    fun writeLeavesNoTemporaryFile() {
        GameExitReport.write(dir, GameExitReport(1, false))

        assertTrue(File(dir, GameExitReport.EXIT_FILE).isFile)
        assertFalse(File(dir, GameExitReport.EXIT_FILE + ".tmp").exists())
    }

    @Test
    fun aCrashedExitIsReportedOnceAndThenForgotten() {
        GameExitReport.markSessionStarted(dir, 10L)
        GameExitReport.write(dir, GameExitReport(exitCode = 1, isSignal = false, message = "boom"))

        val first = GameExitReport.consume(dir) { true }
        val second = GameExitReport.consume(dir) { true }

        assertNotNull(first)
        assertEquals(1, first!!.exitCode)
        assertEquals("boom", first.message)
        assertNull(second)
        assertFalse(File(dir, GameExitReport.SESSION_FILE).exists())
    }

    @Test
    fun aNormalExitProducesNothing() {
        GameExitReport.markSessionStarted(dir, 10L)
        GameExitReport.write(dir, GameExitReport(exitCode = 0, isSignal = false))

        assertNull(GameExitReport.consume(dir) { false })
        assertFalse(File(dir, GameExitReport.EXIT_FILE).exists())
        assertFalse(File(dir, GameExitReport.SESSION_FILE).exists())
    }

    @Test
    fun aRunningGameIsNotReported() {
        GameExitReport.markSessionStarted(dir, 10L)

        assertNull(GameExitReport.consume(dir) { true })
        assertTrue("the marker must stay while the game runs", File(dir, GameExitReport.SESSION_FILE).isFile)
    }

    @Test
    fun aVanishedProcessWithOnlyTheMarkerIsACrash() {
        GameExitReport.markSessionStarted(dir, 10L)

        val report = GameExitReport.consume(dir) { false }

        assertNotNull(report)
        assertTrue(report!!.isSignal)
        assertFalse(report.isNormal)
        assertFalse(File(dir, GameExitReport.SESSION_FILE).exists())
        assertNull(GameExitReport.consume(dir) { false })
    }

    @Test
    fun nothingHappenedWhenTheGameNeverStarted() {
        assertNull(GameExitReport.consume(dir) { false })
    }

    @Test
    fun anUnreadableReportIsStillReported() {
        dir.mkdirs()
        File(dir, GameExitReport.EXIT_FILE).writeText("garbage")

        val report = GameExitReport.consume(dir) { false }

        assertNotNull(report)
        assertFalse(report!!.isNormal)
        assertFalse(File(dir, GameExitReport.EXIT_FILE).exists())
    }

    @Test
    fun startingANewSessionDropsAStaleExitReport() {
        GameExitReport.write(dir, GameExitReport(1, false))

        GameExitReport.markSessionStarted(dir, 20L)

        assertFalse(File(dir, GameExitReport.EXIT_FILE).exists())
        assertTrue(File(dir, GameExitReport.SESSION_FILE).isFile)
    }

    @Test
    fun clearingTheMarkerIsSafeWhenThereIsNone() {
        GameExitReport.clearSessionMarker(dir)
        GameExitReport.markSessionStarted(dir, 1L)
        GameExitReport.clearSessionMarker(dir)

        assertFalse(File(dir, GameExitReport.SESSION_FILE).exists())
    }

    // ---------------------------------------------------------------- необработанные исключения и шаги запуска

    @Test
    fun aCrashReportNamesTheProcessThreadAndException() {
        val report = GameExitReport.crash("game", "main", IllegalStateException("no surface"), logFile = "/g/l.txt", timeMillis = 5L)

        assertEquals(GameExitReport.CRASH_EXIT_CODE, report.exitCode)
        assertFalse(report.isNormal)
        assertTrue(report.message!!.startsWith("[game/main] java.lang.IllegalStateException: no surface"))
        assertEquals("/g/l.txt", report.logFile)
        assertEquals(5L, report.timeMillis)
    }

    @Test
    fun aCrashReportKeepsTheCauseChain() {
        val report = GameExitReport.crash("launcher", "t", RuntimeException("outer", UnsatisfiedLinkError("dlopen failed: libx.so")))

        assertTrue(report.message!!.contains("Caused by: java.lang.UnsatisfiedLinkError: dlopen failed: libx.so"))
    }

    @Test
    fun theFramesShownBelongToTheRootCause() {
        val root = IllegalStateException("root")
        val report = GameExitReport.crash("game", "t", RuntimeException("wrapper", root))

        // Кадр первопричины — этот тест; обёртка создана в той же строке, поэтому отличаем по порядку заголовков.
        assertTrue(report.message!!.indexOf("Caused by: java.lang.IllegalStateException: root") < report.message!!.indexOf("  at "))
        assertTrue(report.message!!.contains("  at com.mclauncher.engine.launch.GameExitReportTest"))
    }

    @Test
    fun aCyclicCauseChainDoesNotLoopForever() {
        val a = RuntimeException("a")
        val b = RuntimeException("b", a)
        a.initCause(b)

        val message = GameExitReport.crash("game", "t", a).message!!

        assertTrue(message.contains("java.lang.RuntimeException: a"))
        assertTrue(message.contains("Caused by: java.lang.RuntimeException: b"))
    }

    @Test
    fun aCrashReportIsClippedToAReadableLength() {
        var deep: Throwable = RuntimeException("x".repeat(10_000))
        repeat(5) { deep = RuntimeException("y".repeat(10_000), deep) }

        val message = GameExitReport.crash("game", "t", deep).message!!

        assertTrue(message.length <= GameExitReport.MAX_MESSAGE_CHARS + 1)
        assertTrue(message.endsWith("…"))
    }

    @Test
    fun aCrashReportSurvivesTheFileRoundTripWithItsLines() {
        val report = GameExitReport.crash("game", "t", IllegalArgumentException("bad"))

        GameExitReport.write(dir, report)
        val read = GameExitReport.parse(File(dir, GameExitReport.EXIT_FILE).readText())

        assertEquals(report, read)
        assertTrue(read!!.message!!.contains("\n"))
    }

    @Test
    fun aCrashIsShownEvenThoughTheCodeIsNotZero() {
        GameExitReport.markSessionStarted(dir, 1L)
        GameExitReport.write(dir, GameExitReport.crash("game", "main", IllegalStateException("boom")))

        val shown = GameExitReport.consume(dir) { true }

        assertNotNull(shown)
        assertEquals(GameExitReport.CRASH_EXIT_CODE, shown!!.exitCode)
    }

    @Test
    fun aNativeCrashNamesTheLastStepReached() {
        GameExitReport.markSessionStarted(dir, 10L)
        GameExitReport.noteStage(dir, "dlopen /data/x/libjava.so")

        val report = GameExitReport.consume(dir) { false }

        assertNotNull(report)
        assertTrue(report!!.message!!.contains("last step: dlopen /data/x/libjava.so"))
        assertFalse(File(dir, GameExitReport.SESSION_FILE).exists())
    }

    @Test
    fun theLastStepKeepsOnlyTheNewestAndSurvivesNewlines() {
        GameExitReport.markSessionStarted(dir, 10L)
        GameExitReport.noteStage(dir, "first")
        GameExitReport.noteStage(dir, "second\nline")

        val report = GameExitReport.consume(dir) { false }

        assertTrue(report!!.message!!.contains("last step: second\nline"))
        assertFalse(report.message!!.contains("first"))
    }

    @Test
    fun noteStageWithoutASessionDoesNotFail() {
        GameExitReport.noteStage(File(tmp.root, "never/created"), "x")

        assertNull(GameExitReport.consume(dir) { false })
    }

    @Test
    fun aCrashWithoutAnyStepStillMentionsTheMissingReport() {
        GameExitReport.markSessionStarted(dir, 10L)

        val report = GameExitReport.consume(dir) { false }

        assertFalse(report!!.message!!.contains("last step"))
        assertTrue(report.message!!.contains("without a report"))
    }
}
