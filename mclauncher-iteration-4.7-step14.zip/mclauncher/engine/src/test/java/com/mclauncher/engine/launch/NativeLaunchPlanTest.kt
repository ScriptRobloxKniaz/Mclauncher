package com.mclauncher.engine.launch

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.ObjectInputStream
import java.io.ObjectOutputStream

class NativeLaunchPlanTest {

    private fun plan(argv: List<String>) = NativeLaunchPlan(
        argv = ArrayList(argv),
        workingDir = "/game",
        jvmLibraryPath = "/a:/b",
        environment = linkedMapOf("HOME" to "/home", "PATH" to "/bin"),
        dlopenLibraries = arrayListOf("/lib/libjli.so"),
        rendererLibrary = "libgl4es_114.so",
        rendererLibraryPath = "/native/libgl4es_114.so",
        rendererName = "GL4ES",
        windowWidth = 2400,
        windowHeight = 1080,
        useInputStackQueue = true,
        logFile = "/game/logs/latest.log",
        versionId = "1.21.1",
    )

    @Test
    fun accessTokenAndSessionAreHiddenInTheRedactedArgv() {
        val redacted = plan(listOf("/java", "--username", "Steve", "--accessToken", "SECRET", "--session", "S2", "--demo")).redactedArgv()

        assertEquals(listOf("/java", "--username", "Steve", "--accessToken", "********", "--session", "********", "--demo"), redacted)
        assertFalse("SECRET" in redacted)
    }

    @Test
    fun aTrailingAccessTokenFlagDoesNotCrash() {
        assertEquals(listOf("/java", "--accessToken"), plan(listOf("/java", "--accessToken")).redactedArgv())
    }

    @Test
    fun thePlanSurvivesSerializationBecauseItCrossesTheProcessBoundary() {
        val original = plan(listOf("/java", "-Xmx1G", "mio.Wrapper"))

        val bytes = ByteArrayOutputStream().also { ObjectOutputStream(it).use { out -> out.writeObject(original) } }.toByteArray()
        val copy = ObjectInputStream(ByteArrayInputStream(bytes)).use { it.readObject() } as NativeLaunchPlan

        assertEquals(original.argv, copy.argv)
        assertEquals(original.environment, copy.environment)
        assertEquals(original.dlopenLibraries, copy.dlopenLibraries)
        assertEquals(original.rendererLibraryPath, copy.rendererLibraryPath)
        assertEquals(original.windowWidth, copy.windowWidth)
        assertTrue(copy.useInputStackQueue)
        assertEquals(original.logFile, copy.logFile)
        // Порядок переменных окружения важен: часть значений зависит от предыдущих.
        assertEquals(original.environment.keys.toList(), copy.environment.keys.toList())
    }
}
