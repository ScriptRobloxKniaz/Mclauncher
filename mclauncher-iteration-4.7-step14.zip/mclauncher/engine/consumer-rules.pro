# Нативный код ядра (engine/src/main/jni) находит эти классы и методы по строковым именам через JNI (FindClass,
# GetStaticMethodID, RegisterNatives). R8 не видит этих обращений и без правил переименовал бы или удалил их —
# игра падала бы при запуске. Имена и сигнатуры проверяет scripts/check_bridge.py.
-keep class com.movtery.zalithlauncher.bridge.** { *; }
-keep class org.lwjgl.glfw.** { *; }
-keep class com.oracle.dalvik.** { *; }
