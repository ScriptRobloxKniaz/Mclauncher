// Модуль ядра игры. Чистая логика на Kotlin без Android-классов: раскладка компонентов, выбор LWJGL и Java, сборка
// команды запуска JVM и установка компонентов из ассетов (распаковка tar.xz, проверка SHA-256). Файлы ядра
// (src/main/assets/core, src/main/jniLibs) кладёт scripts/fetch_core.py --install; в git их нет.
//
// Нативная часть (src/main/jni, ndk-build) собирается ТОЛЬКО при -Pmclauncher.native=true: обычная сборка не требует NDK и
// не может сломаться из-за неё. В CI это отдельный необязательный шаг; подробности — docs/ENGINE.md, раздел 10.
plugins {
    alias(libs.plugins.android.library)
}

// Включает сборку C-кода ядра. Значение по умолчанию — выключено.
val nativeBuild: Boolean = providers.gradleProperty("mclauncher.native").map { it.toBoolean() }.getOrElse(false)

android {
    namespace = "com.mclauncher.engine"
    compileSdk = 37 // как у :app (см. комментарий там)

    defaultConfig {
        minSdk = 26
        // Правила для R8 приложения: C-код ищет классы моста и их методы по имени
        consumerProguardFiles("consumer-rules.pro")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    if (nativeBuild) {
        // Версия NDK — как в апстриме (ZalithLauncher 2): нативный код проверен именно с ней.
        ndkVersion = "25.2.9519653"

        defaultConfig {
            // Ядро игры собрано только под arm64 (решение владельца проекта; см. docs/ENGINE.md).
            ndk {
                abiFilters += "arm64-v8a"
            }
        }

        externalNativeBuild {
            ndkBuild {
                path = file("src/main/jni/Android.mk")
            }
        }

        buildFeatures {
            prefab = true // import-module,prefab/bytehook в Android.mk
        }
    }
}

dependencies {
    // Распаковка .tar.xz рантаймов Java: commons-compress читает tar, xz снимает сжатие
    implementation(libs.commons.compress)
    implementation(libs.xz)

    // @Keep и @Nullable в Java-мосту (com.movtery.zalithlauncher.bridge, org.lwjgl.glfw): JNI вызывает эти методы по имени
    implementation(libs.androidx.annotation)

    if (nativeBuild) {
        implementation(libs.bytehook)
    }

    testImplementation(libs.junit)
}
