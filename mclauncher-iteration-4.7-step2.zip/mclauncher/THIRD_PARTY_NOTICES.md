# Сторонний код и компоненты

Приложение распространяется под **GPL-3.0** (файл [LICENSE](LICENSE)). Этот файл перечисляет то, что
взято у других проектов. Он ведётся по факту: что реально есть в репозитории — в разделе 1; что будет
включено в APK при подключении нативной части ядра (этап 4.7b) — в разделе 2, с пометкой, что состав
уточняется. Я не юрист: это перечень источников, а не юридическое заключение.

## 1. Код, портированный в этот репозиторий (с этапа 4.7a)

### ZalithLauncher 2

- Проект: <https://github.com/ZalithLauncher/ZalithLauncher2>
- Лицензия: **GPL-3.0** с дополнительными условиями по разделу 7 (см. ниже).
- Авторские права: Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors.
- Ревизия, по которой написан порт: `144767e74d26a3fd9c378b8cb13a7a92684c8635` (закреплена в `engine/UPSTREAM`).

Что взято — не копированием файлов, а переписыванием логики на Kotlin под наши типы. Источник каждого правила
указан комментарием в коде:

| Где у нас | Откуда (файл апстрима) | Что |
|---|---|---|
| `engine/…/LwjglVersion.kt` | `game/launch/LaunchArgs.kt` | выбор набора LWJGL по версии игры, порядок jar'ов в classpath |
| `engine/…/LaunchCommandBuilder.kt` | `game/launch/LaunchArgs.kt`, `game/launch/Launcher.kt` | сборка команды запуска JVM: подмена `-Djava.library.path`, свойства окружения Android, память, `mio.Wrapper`, `--add-exports` |
| `engine/…/EngineLayout.kt` | `components/Components.kt`, `path/LibPath.kt` | имена папок и файлов компонентов ядра |
| `app/…/data/versions/EngineLibraryPolicy.kt` | `game/version/download/_LibraryReplacement.kt` | какие библиотеки не нужны, три замены (JNA, OSHI, asm-all) с их SHA-1 и размерами |
| `app/…/launch/LaunchSpecFactory.kt` | `game/launch/LaunchArgs.kt`, `game/launch/LibSortFix.kt` | значения шаблонов аккаунта и папок, правило про asm-all |

**Дополнительные условия Zalith (раздел 7 GPLv3), которые нужно выполнять:**

1. Распространяемая изменённая версия не должна называться «ZalithLauncher» или «ZL» и должна на стартовом экране
   или главном интерфейсе явно называться «неофициальной модифицированной версией».
   Наше имя — MCLauncher. **Пометка на главном экране ещё не добавлена** — её нужно добавить до того, как
   в приложение попадёт код или бинарные файлы Zalith (4.7b). Сейчас в приложение попала только логика сборки
   команды, но выполнить условие лучше заранее.
2. Нельзя удалять показываемые программой уведомления об авторских правах — для этого понадобится экран
   «О приложении» со списком компонентов (этап 8).

### PojavLauncher

- Проект: <https://github.com/PojavLauncherTeam/PojavLauncher>
- Лицензия: **LGPL-3.0** (по README репозитория).
- Через Zalith 2 в порт попала идея сборки classpath по описанию версии: в исходниках Zalith эти функции помечены
  как «Modified from PojavLauncher» (`Tools.java`). Сам код Pojav напрямую в репозиторий не копировался.

## 2. Компоненты, которые планируется включить в APK (этап 4.7b и далее)

Список составлен по таблице «Open Source Libraries and Licenses» в README Zalith 2 на указанной ревизии. **Это
план, а не факт**: точный состав и версии определятся, когда скрипт `scripts/fetch_core.py` начнёт копировать
файлы ядра в модуль `:engine`; тогда файл будет обновлён.

| Компонент | Лицензия по README апстрима |
|---|---|
| LWJGL (jar'ы и нативы набора 3.3.3 и 3.4.1, пропатченные в Zalith) | BSD 3-Clause |
| ANGLE | BSD 3-Clause |
| Mesa 3D (OSMesa) | MIT |
| gl4es_extra_extra, NG-GL4ES | MIT |
| MobileGlues | LGPL-2.1 |
| SimpleFPEWrapper | LGPL-3.0 |
| SDL3, sdl2-compat | Zlib |
| ByteHook | MIT |
| OpenJDK (рантаймы Java 8/17/21/25) | GPLv2 (по README Pojav) — детали Classpath Exception проверить |
| Нативные части PojavLauncher/Zalith (`libpojavexec.so` и др., сборка из `jni/` по `Android.mk`) | LGPL-3.0 / GPL-3.0 (как у апстрима) |

**Лицензии не найдены в таблице апстрима — установить до включения в APK:**
`authlib-injector.jar`, `nide8auth.jar`, `caciocavallo` (AWT-слой для Java), `MioLaunchWrapper.jar`,
`MioLibPatcher.jar`, `HMCLTransformerDiscoveryService`, `forge_installer.jar`, а также файлы в
`assets/runtimes/jna` и `libs/openal-soft`, `libs/kopper-zink`, `libs/spirv-cross-natives`.
Пока лицензия компонента не подтверждена, он не включается в сборку, которую получают другие люди.

## 3. Что не входит в репозиторий

Клиент, библиотеки и ассеты Minecraft — собственность Mojang AB / Microsoft. Они скачиваются на устройство
пользователя с серверов Mojang при установке версии и в репозиторий не попадают. Minecraft — торговая марка
Mojang AB / Microsoft; проект неофициальный.
