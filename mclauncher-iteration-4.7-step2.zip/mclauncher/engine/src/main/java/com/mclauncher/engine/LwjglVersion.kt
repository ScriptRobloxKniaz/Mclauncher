package com.mclauncher.engine

/*
 * Выбор набора LWJGL, который ядро подставит вместо jar'ов Mojang.
 *
 * Логика портирована из ZalithLauncher 2 (`game/launch/LaunchArgs.kt`: detectLwjglVersion, lwjglVersionDir),
 * GPL-3.0, Copyright (C) 2025-2026 MovTery and contributors — см. THIRD_PARTY_NOTICES.md.
 */

/** Набор LWJGL, который поставляет ядро: пропатченные jar'ы и нативы под Android. Имя папки — [dirName]. */
enum class LwjglVersion(val dirName: String) {
    V3_3_3("3.3.3"),
    V3_4_1("3.4.1"),
}

/**
 * Что требует версия игры.
 *
 * @property lwjgl какой набор подставить;
 * @property legacyLwjgl2 игра написана под LWJGL 2: к набору LWJGL 3 добавляется прослойка `lwjgl-lwjglx.jar`.
 */
data class LwjglRequirement(val lwjgl: LwjglVersion, val legacyLwjgl2: Boolean) {
    companion object {
        /** Версию определить не удалось: считаем LWJGL 3.3.3, как и апстрим. */
        val DEFAULT = LwjglRequirement(LwjglVersion.V3_3_3, legacyLwjgl2 = false)
    }
}

/**
 * Определяет требование по именам библиотек из описания версии (`org.lwjgl:lwjgl:3.3.3`, у LWJGL 2 —
 * `org.lwjgl.lwjgl:lwjgl:2.9.4-nightly-20150209`). Берётся первое подходящее имя.
 *
 * Версия превращается в число без точек: 3.3.3 → 333, 3.4.1 → 341, 2.9.4 → 294. Значения вне 200..999 игнорируются.
 * 341 и выше — набор 3.4.1, остальное (включая LWJGL 2) — набор 3.3.3.
 */
fun detectLwjglRequirement(libraryNames: List<String>): LwjglRequirement {
    for (name in libraryNames) {
        val prefix = when {
            name.startsWith("org.lwjgl.lwjgl:lwjgl:") -> "org.lwjgl.lwjgl:lwjgl:"
            name.startsWith("org.lwjgl:lwjgl:") -> "org.lwjgl:lwjgl:"
            else -> continue
        }
        val number = name.substring(prefix.length)
            .takeWhile { it.isDigit() || it == '.' }
            .filter { it != '.' }
            .toIntOrNull()
        if (number != null && number in 200..999) {
            return LwjglRequirement(
                lwjgl = if (number >= 341) LwjglVersion.V3_4_1 else LwjglVersion.V3_3_3,
                legacyLwjgl2 = number in 1..299,
            )
        }
    }
    return LwjglRequirement.DEFAULT
}

/**
 * Порядок jar'ов LWJGL в classpath: сначала ядро `lwjgl.jar`, затем сборный `lwjgl-<версия>-merged-modules.jar`,
 * затем остальные модули по алфавиту (у апстрима порядок зависит от файловой системы — здесь он стабильный),
 * в самом конце прослойка `lwjgl-lwjglx.jar`, и только для LWJGL 2.
 */
fun orderLwjglJars(names: List<String>, version: LwjglVersion, legacyLwjgl2: Boolean): List<String> {
    fun rank(name: String): Int = when (name) {
        "lwjgl.jar" -> 0
        "lwjgl-${version.dirName}-merged-modules.jar" -> 1
        "lwjgl-lwjglx.jar" -> 3
        else -> 2
    }
    return names
        .filter { it.endsWith(".jar") }
        .filter { legacyLwjgl2 || it != "lwjgl-lwjglx.jar" }
        .sortedWith(compareBy({ rank(it) }, { it }))
}
