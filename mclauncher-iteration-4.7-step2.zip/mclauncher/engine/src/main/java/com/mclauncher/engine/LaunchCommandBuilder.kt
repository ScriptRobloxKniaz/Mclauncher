package com.mclauncher.engine

import java.io.File

/*
 * Сборка командной строки JVM для игры.
 *
 * Правила портированы из ZalithLauncher 2 (`game/launch/LaunchArgs.kt`, `game/launch/Launcher.kt`), а те, в свою
 * очередь, — из PojavLauncher (LGPL-3.0). Лицензии и авторы — в THIRD_PARTY_NOTICES.md. Что именно взято и что
 * отличается, описано в docs/ENGINE.md. Работает ТОЛЬКО на бумаге: на устройстве эта команда ещё ни разу не
 * запускалась (нужен процесс игры из 4.7b), поэтому каждое правило помечено источником.
 */

/**
 * Собирает [LaunchCommand] из [EngineLaunchSpec]. Чистая функция: никакого Android, сети и записи на диск
 * (читаются только списки файлов — есть ли jar'ы на месте).
 *
 * Главное правило ядра: **нативы берутся только из папки ядра**. `-Djava.library.path` всегда указывает на неё,
 * а нативные jar'ы Mojang и сами jar'ы LWJGL Mojang в classpath не попадают (приложение их не передаёт,
 * см. `EngineLibraryPolicy` в :app).
 */
class LaunchCommandBuilder(
    private val layout: EngineLayout,
    private val env: EngineEnvironment,
) {

    /** @throws CommandBuildException если версии Java нет среди рантаймов ядра или у игры нет главного класса. */
    fun build(spec: EngineLaunchSpec): LaunchCommand {
        if (spec.mainClass.isBlank()) throw CommandBuildException("The version has no main class")
        val component = JavaRuntimes.componentFor(spec.javaMajor)
            ?: throw CommandBuildException(
                "Java ${spec.javaMajor} is newer than the runtimes shipped with the core ${JavaRuntimes.AVAILABLE}",
            )

        val natives = layout.lwjglNativesDir(spec.lwjgl.lwjgl)
        val classpath = classpath(spec)

        val variables = LinkedHashMap(spec.variables)
        variables[NATIVES_DIRECTORY] = natives.path
        variables[CLASSPATH] = classpath.joinToString(SEPARATOR)
        variables[CLASSPATH_SEPARATOR] = SEPARATOR

        val warnings = ArrayList<String>()
        val args = ArrayList<String>()

        // 1. Свойства окружения и память: Launcher.getJavaArgs / progressFinalUserArgs у апстрима.
        args += environmentProperties(spec, component, natives)
        args += memoryAndLibraryFlags(spec, natives)

        // 2. Агент-патчер библиотек. У апстрима — после агента cacio (AWT, 4.7c) и до `-cp`.
        args += "-javaagent:${layout.libPatcherJar.path}"

        // 3. Аргументы JVM из описания версии. Для старых версий их нет, ядро добавит `-cp` и java.library.path само.
        var hasClasspath = false
        var hasLibraryPath = false
        for (template in spec.jvmArgs) {
            if (template == "\${$CLASSPATH}") hasClasspath = true
            if (template.startsWith(LIBRARY_PATH_PREFIX)) hasLibraryPath = true
            args += substitute(rewriteJvmArgument(template, spec), variables, warnings)
        }
        if (!hasLibraryPath) args += "$LIBRARY_PATH_PREFIX${natives.path}"
        if (!hasClasspath) {
            args += "-cp"
            args += variables.getValue(CLASSPATH)
        }

        // 4. Java 9+: `--add-exports <пакет>/<пакет>=ALL-UNNAMED` для главного класса (апстрим делает это для всех).
        if (spec.javaMajor > 8) {
            val pkg = spec.mainClass.substringBeforeLast('.', missingDelimiterValue = "")
            if (pkg.isNotEmpty()) {
                args += "--add-exports"
                args += "$pkg/$pkg=ALL-UNNAMED"
            }
        }

        // 5. `mio.Wrapper` запускает настоящий главный класс, переданный первым аргументом.
        args += WRAPPER_CLASS
        args += spec.mainClass
        for (template in spec.gameArgs) args += substitute(template, variables, warnings)

        return LaunchCommand(
            javaExecutable = layout.javaExecutable(component),
            javaHome = layout.javaHome(component),
            args = args,
            classpath = classpath,
            nativesDir = natives,
            warnings = warnings,
        )
    }

    /**
     * LWJGL ядра → `mio.Wrapper` → библиотеки версии → клиентский jar. Повторы убираются. Библиотеки и клиентский jar,
     * которых нет на диске, пропускаются (у апстрима так же): их отсутствие обнаружит проверка установки.
     */
    private fun classpath(spec: EngineLaunchSpec): List<String> {
        val result = LinkedHashSet<String>()
        layout.lwjglJars(spec.lwjgl).forEach { result += it.path }
        result += layout.launchWrapperJar.path
        for (path in spec.libraryJars) if (File(path).exists()) result += path
        if (File(spec.clientJar).exists()) result += spec.clientJar
        return result.toList()
    }

    /** Правки аргументов JVM из описания версии: Launcher/LaunchArgs.processJvmArg у апстрима. */
    private fun rewriteJvmArgument(argument: String, spec: EngineLaunchSpec): String = when {
        // Mojang с 26.2 пишет сюда конкретный путь; игре нужна папка с нативами ядра.
        argument.startsWith(LIBRARY_PATH_PREFIX) -> "$LIBRARY_PATH_PREFIX\${$NATIVES_DIRECTORY}"

        argument.startsWith("-DignoreList=") -> "$argument,${spec.versionId}.jar"

        // Этим библиотекам нужна папка, в которую можно писать, а папка с нативами — только для чтения.
        argument.contains("-Dio.netty.native.workdir") ||
            argument.contains("-Djna.tmpdir") ||
            argument.contains("-Dorg.lwjgl.system.SharedLibraryExtractPath") ->
            argument.replace("\${$NATIVES_DIRECTORY}", env.cacheDir.path)

        else -> argument
    }

    /** Свойства, которые апстрим выставляет игре всегда (`Launcher.getJavaArgs`). Порядок сохраняется. */
    private fun environmentProperties(spec: EngineLaunchSpec, component: Int, natives: File): List<String> {
        val p = LinkedHashMap<String, String>()
        p["java.home"] = layout.javaHome(component).path
        p["java.io.tmpdir"] = env.cacheDir.path
        p["jna.boot.library.path"] = layout.nativeLibraryDir.path
        p["user.home"] = env.userHome.path
        if (env.language != null) p["user.language"] = env.language
        if (env.country != null) p["user.country"] = env.country
        p["user.timezone"] = env.timezone
        p["os.name"] = "Linux"
        p["os.version"] = "Android-${env.androidRelease}"
        p["pojav.path.minecraft"] = env.gameDir.path
        p["org.lwjgl.vulkan.libname"] = "libvulkan.so"
        // LWJGL 3.4 ищет нативы по этому свойству, поэтому оно указывает на папку нужной версии.
        p["org.lwjgl.librarypath"] = natives.path
        p["glfwstub.windowWidth"] = env.screenWidth.toString()
        p["glfwstub.windowHeight"] = env.screenHeight.toString()
        p["glfwstub.initEgl"] = "false"
        env.resolvConf?.let { p["ext.net.resolvPath"] = it.path }

        // Защита от уязвимостей log4j (Log4Shell) и удалённой загрузки кода.
        p["log4j2.formatMsgNoLookups"] = "true"
        p["java.rmi.server.useCodebaseOnly"] = "true"
        p["com.sun.jndi.rmi.object.trustURLCodebase"] = "false"
        p["com.sun.jndi.cosnaming.object.trustURLCodebase"] = "false"

        p["net.minecraft.clientmodname"] = spec.variables["launcher_name"] ?: "MCLauncher"

        // Forge/Fabric: окно загрузки на Android не показывается, часть проверок неприменима.
        p["fml.earlyprogresswindow"] = "false"
        p["fml.ignoreInvalidMinecraftCertificates"] = "true"
        p["fml.ignorePatchDiscrepancies"] = "true"
        p["loader.disable_forked_guis"] = "true"
        p["jdk.lang.Process.launchMechanism"] = "FORK"
        p["sodium.checks.issue2561"] = "false"

        p["file.encoding"] = "UTF-8"
        p["sun.stdout.encoding"] = "UTF-8"
        p["sun.stderr.encoding"] = "UTF-8"
        return p.map { (key, value) -> "-D$key=$value" }
    }

    /** `Launcher.progressFinalUserArgs` у апстрима: память и пути к библиотекам LWJGL. */
    private fun memoryAndLibraryFlags(spec: EngineLaunchSpec, natives: File): List<String> = listOf(
        "-Xms${spec.ramMb}M",
        "-Xmx${spec.ramMb}M",
        "-Dorg.lwjgl.openal.libname=${File(layout.nativeLibraryDir, "libopenal.so").path}",
        // FreeType берётся только из набора LWJGL: версия, которая идёт вместе с Java, может быть старой.
        "-Dorg.lwjgl.freetype.libname=${File(natives, "libfreetype.so").path}",
        // spirv-cross собран у ядра как shared-библиотека — отсюда имя.
        "-Dorg.lwjgl.spvc.libname=spirv-cross-c-shared",
        // jemalloc в LWJGL ядра нет: без этого в лог сыплются ошибки.
        "-Dorg.lwjgl.system.allocator=system",
        "-XX:ActiveProcessorCount=${env.cpuCores}",
    )

    /**
     * Раскрывает шаблоны `${имя}`. Незнакомый шаблон остаётся как есть и попадает в [warnings]: игра спокойно
     * принимает такую строку (так ведёт себя и апстрим), а мы не ломаем запуск из-за нового поля у Mojang.
     */
    private fun substitute(template: String, variables: Map<String, String>, warnings: MutableList<String>): String =
        PLACEHOLDER.replace(template) { match ->
            val name = match.groupValues[1]
            variables[name] ?: run {
                warnings += "Unknown placeholder \${$name} in: $template"
                match.value
            }
        }

    companion object {
        const val WRAPPER_CLASS = "mio.Wrapper"
        const val NATIVES_DIRECTORY = "natives_directory"
        const val CLASSPATH = "classpath"
        const val CLASSPATH_SEPARATOR = "classpath_separator"
        private const val SEPARATOR = ":"
        private const val LIBRARY_PATH_PREFIX = "-Djava.library.path="
        private val PLACEHOLDER = Regex("""\$\{([A-Za-z0-9_]+)}""")
    }
}
