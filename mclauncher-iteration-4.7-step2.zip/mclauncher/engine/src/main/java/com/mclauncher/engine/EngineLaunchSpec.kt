package com.mclauncher.engine

import java.io.File

/**
 * Всё, что приложение сообщает ядру о запуске. Здесь нет типов Mojang и Android: приложение само разбирает
 * описание версии (правила, библиотеки, аккаунт), а ядро знает только то, что относится к Pojav/Zalith, —
 * порядок classpath, свой LWJGL, свои нативы и флаги JVM для Android.
 */
data class EngineLaunchSpec(
    /** Идентификатор версии (`1.21.1`): нужен для `-DignoreList` и логов. */
    val versionId: String,

    /** Требуемая Java по описанию версии (`javaVersion.majorVersion`; у старых версий — 8). */
    val javaMajor: Int,

    /** Главный класс игры из описания версии. Ядро запускает его через `mio.Wrapper`. */
    val mainClass: String,

    /** Клиентский jar версии. Идёт в classpath последним. */
    val clientJar: String,

    /**
     * Библиотеки версии, уже отобранные приложением (правила ОС, замены, без LWJGL и `natives-*`), в порядке
     * из описания. Пути абсолютные. Отсутствующие на диске файлы ядро в classpath не включает.
     */
    val libraryJars: List<String>,

    /** Какой набор LWJGL подставить вместо LWJGL Mojang; см. [detectLwjglRequirement]. */
    val lwjgl: LwjglRequirement,

    /**
     * Аргументы JVM из описания версии, у которых правила уже вычислены, но шаблоны `${…}` не раскрыты.
     * Пусто у старых версий: нужные флаги добавляет ядро.
     */
    val jvmArgs: List<String>,

    /** Аргументы игры, тоже с вычисленными правилами и нераскрытыми шаблонами. */
    val gameArgs: List<String>,

    /**
     * Значения шаблонов: `auth_player_name`, `game_directory`, `assets_root`, `version_name`, `launcher_name`…
     * Шаблоны `natives_directory`, `classpath` и `classpath_separator` задаёт само ядро и подменяет любые
     * присланные приложением.
     */
    val variables: Map<String, String>,

    /** Память игры, МБ. Ядро ставит `-Xms` и `-Xmx` равными этому значению, как апстрим. */
    val ramMb: Int,
)

/**
 * Окружение устройства для флагов JVM. Собирается в Android-коде (4.7b), здесь — просто данные,
 * чтобы сборщик команды оставался чистой функцией.
 */
data class EngineEnvironment(
    /** Папка `.minecraft`. */
    val gameDir: File,

    /** `user.home` игры; у Pojav это папка, в которой лежит `.minecraft`. */
    val userHome: File,

    /** Кэш приложения: временные файлы JVM, Netty, JNA и распаковка библиотек LWJGL. Должна быть доступна на запись. */
    val cacheDir: File,

    /** Идентификатор часового пояса (`Asia/Baku`). */
    val timezone: String,

    /** `Build.VERSION.RELEASE`: попадает в `os.version` как `Android-<версия>`. */
    val androidRelease: String,

    /** Размер окна игры в пикселях (с учётом выбранного разрешения). */
    val screenWidth: Int,
    val screenHeight: Int,

    /** Число ядер устройства: JVM на Android иногда определяет его неверно. */
    val cpuCores: Int,

    /** Файл `resolv.conf` для DNS игры или `null`. */
    val resolvConf: File? = null,

    /** Язык и страна для `user.language` и `user.country`; `null` — не задавать. */
    val language: String? = null,
    val country: String? = null,
)

/**
 * Готовая команда запуска.
 *
 * @property args всё после исполняемого файла Java: флаги JVM, `-cp …`, `mio.Wrapper`, главный класс, аргументы игры;
 * @property classpath итоговый classpath отдельным списком (для лога и проверок);
 * @property nativesDir папка с нативами LWJGL ядра: именно она стоит в `-Djava.library.path`;
 * @property warnings замечания, не мешающие запуску (например, шаблон `${…}`, которого ядро не знает).
 */
class LaunchCommand(
    val javaExecutable: File,
    val javaHome: File,
    val args: List<String>,
    val classpath: List<String>,
    val nativesDir: File,
    val warnings: List<String> = emptyList(),
) {
    /** Полная командная строка. Содержит токен доступа — в логи пишите [redacted]. */
    fun argv(): List<String> = listOf(javaExecutable.path) + args

    /** То же, но значения после `--accessToken` и `--session` скрыты. */
    fun redacted(): List<String> {
        val result = ArrayList<String>(args.size + 1)
        result += javaExecutable.path
        var hide = false
        for (arg in args) {
            if (hide) {
                result += "********"
                hide = false
            } else {
                result += arg
                hide = arg == "--accessToken" || arg == "--session"
            }
        }
        return result
    }
}

/** Команду собрать нельзя: в данных приложения есть то, чего ядро не умеет обработать. Текст — для лога и поддержки. */
class CommandBuildException(message: String) : Exception(message)
