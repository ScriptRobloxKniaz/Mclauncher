package com.mclauncher.engine

import org.junit.Assert.assertEquals
import org.junit.Test

class LwjglVersionTest {

    private fun detect(vararg names: String) = detectLwjglRequirement(names.toList())

    @Test
    fun lwjgl333UsesTheDefaultSet() {
        assertEquals(LwjglRequirement(LwjglVersion.V3_3_3, false), detect("org.lwjgl:lwjgl:3.3.3"))
    }

    @Test
    fun lwjgl341AndNewerUseTheNewSet() {
        assertEquals(LwjglVersion.V3_4_1, detect("org.lwjgl:lwjgl:3.4.1").lwjgl)
        assertEquals(LwjglVersion.V3_4_1, detect("org.lwjgl:lwjgl:3.5.0").lwjgl)
    }

    @Test
    fun lwjgl340StaysOnTheDefaultSet() {
        assertEquals(LwjglVersion.V3_3_3, detect("org.lwjgl:lwjgl:3.4.0").lwjgl)
    }

    @Test
    fun oldLwjgl3VersionsAreServedByTheDefaultSet() {
        assertEquals(LwjglRequirement(LwjglVersion.V3_3_3, false), detect("org.lwjgl:lwjgl:3.2.2"))
    }

    @Test
    fun lwjgl2NeedsTheCompatibilityLayer() {
        val result = detect("org.lwjgl.lwjgl:lwjgl:2.9.4-nightly-20150209")

        assertEquals(LwjglRequirement(LwjglVersion.V3_3_3, legacyLwjgl2 = true), result)
    }

    @Test
    fun onlyTheCoreArtifactCounts() {
        // lwjgl-glfw и прочие модули не определяют версию набора.
        assertEquals(LwjglRequirement.DEFAULT, detect("org.lwjgl:lwjgl-glfw:3.4.1", "org.lwjgl:lwjgl-opengl:3.4.1"))
    }

    @Test
    fun firstUsableNameWins() {
        assertEquals(LwjglVersion.V3_4_1, detect("com.example:lib:1.0", "org.lwjgl:lwjgl:3.4.1", "org.lwjgl:lwjgl:3.3.3").lwjgl)
    }

    @Test
    fun noLwjglMeansDefault() {
        assertEquals(LwjglRequirement.DEFAULT, detect("com.mojang:brigadier:1.0.18"))
        assertEquals(LwjglRequirement.DEFAULT, detectLwjglRequirement(emptyList()))
    }

    @Test
    fun nonsenseVersionsAreIgnored() {
        // 1.0 → 10, вне допустимого диапазона: берём следующее подходящее имя.
        assertEquals(LwjglVersion.V3_4_1, detect("org.lwjgl:lwjgl:1.0", "org.lwjgl:lwjgl:3.4.1").lwjgl)
        assertEquals(LwjglRequirement.DEFAULT, detect("org.lwjgl:lwjgl:abc"))
        assertEquals(LwjglRequirement.DEFAULT, detect("org.lwjgl:lwjgl:"))
    }

    @Test
    fun jarOrderPutsTheCoreFirstAndTheCompatibilityLayerLast() {
        val names = listOf(
            "lwjgl-vulkan.jar", "lwjgl-lwjglx.jar", "lwjgl-stb.jar", "lwjgl-3.3.3-merged-modules.jar",
            "lwjgl.jar", "lwjgl-openal.jar",
        )

        assertEquals(
            listOf(
                "lwjgl.jar", "lwjgl-3.3.3-merged-modules.jar",
                "lwjgl-openal.jar", "lwjgl-stb.jar", "lwjgl-vulkan.jar",
                "lwjgl-lwjglx.jar",
            ),
            orderLwjglJars(names, LwjglVersion.V3_3_3, legacyLwjgl2 = true),
        )
    }

    @Test
    fun compatibilityLayerIsDroppedForLwjgl3Games() {
        val names = listOf("lwjgl.jar", "lwjgl-lwjglx.jar", "lwjgl-stb.jar")

        assertEquals(listOf("lwjgl.jar", "lwjgl-stb.jar"), orderLwjglJars(names, LwjglVersion.V3_3_3, legacyLwjgl2 = false))
    }

    @Test
    fun mergedModulesJarOfTheRightVersionComesRightAfterTheCore() {
        // «lwjgl-0.jar» по алфавиту раньше сборного jar'а, но место сборного — второе.
        val names = listOf("lwjgl-0.jar", "lwjgl-3.3.3-merged-modules.jar", "lwjgl.jar")

        assertEquals(
            listOf("lwjgl.jar", "lwjgl-3.3.3-merged-modules.jar", "lwjgl-0.jar"),
            orderLwjglJars(names, LwjglVersion.V3_3_3, false),
        )
    }

    @Test
    fun mergedModulesJarOfAnotherVersionHasNoSpecialPlace() {
        val names = listOf("lwjgl-0.jar", "lwjgl-3.3.3-merged-modules.jar", "lwjgl.jar")

        assertEquals(
            listOf("lwjgl.jar", "lwjgl-0.jar", "lwjgl-3.3.3-merged-modules.jar"),
            orderLwjglJars(names, LwjglVersion.V3_4_1, false),
        )
    }

    @Test
    fun nonJarFilesAreIgnored() {
        assertEquals(listOf("lwjgl.jar"), orderLwjglJars(listOf("version", "lwjgl.jar", "natives"), LwjglVersion.V3_3_3, false))
    }
}
