package com.mclauncher.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class LaunchCommandBuilderTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val layout by lazy {
        EngineLayout(
            componentsDir = File(tmp.root, "components"),
            runtimesDir = File(tmp.root, "runtimes"),
            nativeLibraryDir = File(tmp.root, "lib"),
            abi = "arm64-v8a",
        )
    }
    private val env by lazy {
        EngineEnvironment(
            gameDir = File(tmp.root, "home/.minecraft"),
            userHome = File(tmp.root, "home"),
            cacheDir = File(tmp.root, "cache"),
            timezone = "Asia/Baku",
            androidRelease = "15",
            screenWidth = 2400,
            screenHeight = 1080,
            cpuCores = 8,
        )
    }
    private val builder by lazy { LaunchCommandBuilder(layout, env) }

    private val nativesDir by lazy { layout.lwjglNativesDir(LwjglVersion.V3_3_3).path }

    private fun file(path: String): String = File(tmp.root, path).apply { parentFile.mkdirs(); writeText("x") }.path

    private fun lwjglJars() {
        listOf("lwjgl.jar", "lwjgl-3.3.3-merged-modules.jar", "lwjgl-stb.jar").forEach {
            file("components/lwjgl/3.3.3/$it")
        }
    }

    private val defaultVariables = mapOf(
        "auth_player_name" to "Steve",
        "auth_uuid" to "5627dd98e6be3c21b8a8e92344183641",
        "auth_access_token" to "SECRET-TOKEN",
        "game_directory" to "/data/.minecraft",
        "assets_root" to "/data/.minecraft/assets",
        "assets_index_name" to "17",
        "version_name" to "1.21.1",
        "version_type" to "release",
        "launcher_name" to "MCLauncher",
        "launcher_version" to "0.1.0",
    )

    private val modernJvm = listOf(
        "-Djava.library.path=\${natives_directory}",
        "-Dminecraft.launcher.brand=\${launcher_name}",
        "-Dminecraft.launcher.version=\${launcher_version}",
        "-cp",
        "\${classpath}",
    )

    private val modernGame = listOf(
        "--username", "\${auth_player_name}",
        "--version", "\${version_name}",
        "--accessToken", "\${auth_access_token}",
    )

    private fun spec(
        javaMajor: Int = 21,
        jvmArgs: List<String> = modernJvm,
        gameArgs: List<String> = modernGame,
        libraries: List<String> = emptyList(),
        client: String = file("game/1.21.1.jar"),
        variables: Map<String, String> = defaultVariables,
        mainClass: String = "net.minecraft.client.main.Main",
        lwjgl: LwjglRequirement = LwjglRequirement.DEFAULT,
    ) = EngineLaunchSpec(
        versionId = "1.21.1",
        javaMajor = javaMajor,
        mainClass = mainClass,
        clientJar = client,
        libraryJars = libraries,
        lwjgl = lwjgl,
        jvmArgs = jvmArgs,
        gameArgs = gameArgs,
        variables = variables,
        ramMb = 3072,
    )

    private fun LaunchCommand.libraryPathOptions() = args.filter { it.startsWith("-Djava.library.path=") }

    // ---------------------------------------------------------------- нативы только из ядра

    @Test
    fun libraryPathIsTheCoreNativesFolder() {
        lwjglJars()

        val command = builder.build(spec())

        assertEquals(listOf("-Djava.library.path=$nativesDir"), command.libraryPathOptions())
        assertEquals(File(nativesDir), command.nativesDir)
    }

    @Test
    fun aConcreteLibraryPathFromMojangIsReplaced() {
        // Начиная с новых версий Mojang пишет в описание готовый путь вместо шаблона.
        val mojang = listOf("-Djava.library.path=/mojang/natives/1.21.1", "-cp", "\${classpath}")

        val command = builder.build(spec(jvmArgs = mojang))

        assertEquals(listOf("-Djava.library.path=$nativesDir"), command.libraryPathOptions())
        assertFalse(command.args.any { it.contains("/mojang/natives") })
    }

    @Test
    fun oldVersionsWithoutJvmArgumentsStillGetLibraryPathAndClasspath() {
        lwjglJars()

        val command = builder.build(spec(jvmArgs = emptyList()))

        assertEquals(listOf("-Djava.library.path=$nativesDir"), command.libraryPathOptions())
        val cp = command.args.indexOf("-cp")
        assertTrue(cp >= 0)
        assertEquals(command.classpath.joinToString(":"), command.args[cp + 1])
    }

    @Test
    fun theClasspathOptionIsNotDuplicated() {
        val command = builder.build(spec())

        assertEquals(1, command.args.count { it == "-cp" })
    }

    @Test
    fun lwjglPointsAtTheCoreNativesToo() {
        val command = builder.build(spec())

        assertTrue("-Dorg.lwjgl.librarypath=$nativesDir" in command.args)
        assertTrue("-Dorg.lwjgl.freetype.libname=$nativesDir/libfreetype.so" in command.args)
    }

    @Test
    fun lwjgl341UsesItsOwnNativesFolder() {
        val command = builder.build(spec(lwjgl = LwjglRequirement(LwjglVersion.V3_4_1, false)))

        val expected = layout.lwjglNativesDir(LwjglVersion.V3_4_1).path
        assertEquals(listOf("-Djava.library.path=$expected"), command.libraryPathOptions())
        assertNotEquals(nativesDir, expected)
    }

    @Test
    fun appVariablesCannotOverrideTheNativesOrTheClasspath() {
        val hostile = defaultVariables + mapOf("natives_directory" to "/evil", "classpath" to "/evil.jar")

        val command = builder.build(spec(variables = hostile))

        assertEquals(listOf("-Djava.library.path=$nativesDir"), command.libraryPathOptions())
        assertFalse(command.args.any { it.contains("/evil") })
    }

    // ---------------------------------------------------------------- classpath

    @Test
    fun classpathOrderIsLwjglThenWrapperThenLibrariesThenClient() {
        lwjglJars()
        val wrapper = file("components/launcher/MioLaunchWrapper.jar")
        val libA = file("libraries/a.jar")
        val libB = file("libraries/b.jar")
        val client = file("game/1.21.1.jar")

        val command = builder.build(spec(libraries = listOf(libA, libB), client = client))

        val dir = "components/lwjgl/3.3.3"
        assertEquals(
            listOf(
                File(tmp.root, "$dir/lwjgl.jar").path,
                File(tmp.root, "$dir/lwjgl-3.3.3-merged-modules.jar").path,
                File(tmp.root, "$dir/lwjgl-stb.jar").path,
                wrapper, libA, libB, client,
            ),
            command.classpath,
        )
    }

    @Test
    fun missingLibrariesAndClientAreSkipped() {
        val present = file("libraries/present.jar")
        val absent = File(tmp.root, "libraries/absent.jar").path

        val command = builder.build(spec(libraries = listOf(present, absent), client = File(tmp.root, "no/client.jar").path))

        assertTrue(present in command.classpath)
        assertFalse(absent in command.classpath)
        assertFalse(command.classpath.any { it.endsWith("client.jar") })
    }

    @Test
    fun duplicateLibrariesAppearOnce() {
        val lib = file("libraries/a.jar")

        val command = builder.build(spec(libraries = listOf(lib, lib)))

        assertEquals(1, command.classpath.count { it == lib })
    }

    @Test
    fun theClasspathArgumentCarriesTheSameList() {
        lwjglJars()
        val lib = file("libraries/a.jar")

        val command = builder.build(spec(libraries = listOf(lib)))

        val cp = command.args.indexOf("-cp")
        assertEquals(command.classpath.joinToString(":"), command.args[cp + 1])
    }

    // ---------------------------------------------------------------- шаблоны и аргументы игры

    @Test
    fun templatesAreFilled() {
        val command = builder.build(spec())

        assertTrue("-Dminecraft.launcher.brand=MCLauncher" in command.args)
        assertTrue("-Dminecraft.launcher.version=0.1.0" in command.args)
        assertFalse(command.args.any { it.contains("\${") })
        assertTrue(command.warnings.isEmpty())
    }

    @Test
    fun gameStartsThroughTheWrapperWithTheRealMainClassFirst() {
        val command = builder.build(spec())

        val wrapper = command.args.indexOf("mio.Wrapper")
        assertTrue(wrapper > 0)
        assertEquals("net.minecraft.client.main.Main", command.args[wrapper + 1])
        assertEquals(
            listOf("--username", "Steve", "--version", "1.21.1", "--accessToken", "SECRET-TOKEN"),
            command.args.drop(wrapper + 2),
        )
    }

    @Test
    fun anUnknownTemplateStaysAsIsAndIsReported() {
        val command = builder.build(spec(gameArgs = listOf("--clientId", "\${clientid}")))

        assertTrue("\${clientid}" in command.args)
        assertEquals(1, command.warnings.size)
        assertTrue(command.warnings.single().contains("clientid"))
    }

    @Test
    fun theAccessTokenIsHiddenInTheRedactedCommand() {
        val command = builder.build(spec())

        assertTrue(command.argv().contains("SECRET-TOKEN"))
        assertFalse(command.redacted().contains("SECRET-TOKEN"))
        val redacted = command.redacted()
        assertEquals("********", redacted[redacted.indexOf("--accessToken") + 1])
    }

    @Test
    fun theFirstElementOfArgvIsTheJavaExecutable() {
        val command = builder.build(spec(javaMajor = 21))

        assertEquals(layout.javaExecutable(21).path, command.argv().first())
        assertEquals(layout.javaHome(21), command.javaHome)
    }

    // ---------------------------------------------------------------- правки аргументов JVM

    @Test
    fun writableFoldersReplaceTheNativesFolderInLibraryExtractionOptions() {
        val jvm = listOf(
            "-Djna.tmpdir=\${natives_directory}",
            "-Dorg.lwjgl.system.SharedLibraryExtractPath=\${natives_directory}",
            "-Dio.netty.native.workdir=\${natives_directory}",
        )

        val command = builder.build(spec(jvmArgs = jvm))

        assertTrue("-Djna.tmpdir=${env.cacheDir.path}" in command.args)
        assertTrue("-Dorg.lwjgl.system.SharedLibraryExtractPath=${env.cacheDir.path}" in command.args)
        assertTrue("-Dio.netty.native.workdir=${env.cacheDir.path}" in command.args)
    }

    @Test
    fun theClientJarIsAddedToTheIgnoreList() {
        val command = builder.build(spec(jvmArgs = listOf("-DignoreList=bootstraplauncher,securejarhandler")))

        assertTrue("-DignoreList=bootstraplauncher,securejarhandler,1.21.1.jar" in command.args)
    }

    @Test
    fun memoryIsFixedAtTheRequestedAmount() {
        val command = builder.build(spec())

        assertTrue("-Xms3072M" in command.args)
        assertTrue("-Xmx3072M" in command.args)
        assertTrue("-XX:ActiveProcessorCount=8" in command.args)
    }

    @Test
    fun theLibraryPatcherAgentComesBeforeTheClasspath() {
        val command = builder.build(spec())

        val agent = command.args.indexOf("-javaagent:${layout.libPatcherJar.path}")
        assertTrue(agent >= 0)
        assertTrue(agent < command.args.indexOf("-cp"))
    }

    @Test
    fun environmentPropertiesDescribeAnAndroidLinux() {
        val command = builder.build(spec())

        assertTrue("-Dos.name=Linux" in command.args)
        assertTrue("-Dos.version=Android-15" in command.args)
        assertTrue("-Duser.home=${env.userHome.path}" in command.args)
        assertTrue("-Duser.timezone=Asia/Baku" in command.args)
        assertTrue("-Dglfwstub.windowWidth=2400" in command.args)
        assertTrue("-Dglfwstub.windowHeight=1080" in command.args)
        assertTrue("-Djna.boot.library.path=${layout.nativeLibraryDir.path}" in command.args)
        assertTrue("-Dorg.lwjgl.openal.libname=${layout.nativeLibraryDir.path}/libopenal.so" in command.args)
    }

    @Test
    fun optionalEnvironmentPropertiesAreOmittedWhenNotGiven() {
        val command = builder.build(spec())

        assertFalse(command.args.any { it.startsWith("-Duser.language=") })
        assertFalse(command.args.any { it.startsWith("-Dext.net.resolvPath=") })
    }

    @Test
    fun languageAndDnsAreIncludedWhenGiven() {
        val resolv = File(tmp.root, "resolv.conf")
        val withExtras = LaunchCommandBuilder(layout, env.copy(language = "ru", country = "RU", resolvConf = resolv))

        val command = withExtras.build(spec())

        assertTrue("-Duser.language=ru" in command.args)
        assertTrue("-Duser.country=RU" in command.args)
        assertTrue("-Dext.net.resolvPath=${resolv.path}" in command.args)
    }

    // ---------------------------------------------------------------- версии Java

    @Test
    fun java8GetsNoAddExports() {
        val command = builder.build(spec(javaMajor = 8))

        assertFalse("--add-exports" in command.args)
        assertEquals(layout.javaExecutable(8), command.javaExecutable)
        assertTrue("-Djava.home=${layout.javaHome(8).path}" in command.args)
    }

    @Test
    fun newerJavaExportsThePackageOfTheMainClass() {
        val command = builder.build(spec(javaMajor = 17))

        val index = command.args.indexOf("--add-exports")
        assertTrue(index >= 0)
        assertEquals("net.minecraft.client.main/net.minecraft.client.main=ALL-UNNAMED", command.args[index + 1])
    }

    @Test
    fun java16UsesTheJava17Runtime() {
        val command = builder.build(spec(javaMajor = 16))

        assertEquals(layout.javaExecutable(17), command.javaExecutable)
    }

    @Test
    fun aMainClassWithoutPackageSkipsTheExport() {
        val command = builder.build(spec(javaMajor = 17, mainClass = "Main"))

        assertFalse("--add-exports" in command.args)
    }

    @Test
    fun javaNewerThanTheShippedRuntimesIsRejected() {
        try {
            builder.build(spec(javaMajor = 30))
            fail("expected CommandBuildException")
        } catch (e: CommandBuildException) {
            assertTrue(e.message!!.contains("30"))
        }
    }

    @Test
    fun aBlankMainClassIsRejected() {
        try {
            builder.build(spec(mainClass = " "))
            fail("expected CommandBuildException")
        } catch (e: CommandBuildException) {
            assertTrue(e.message!!.contains("main class"))
        }
    }
}
