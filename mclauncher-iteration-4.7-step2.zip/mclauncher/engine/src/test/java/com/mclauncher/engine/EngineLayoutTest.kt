package com.mclauncher.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class EngineLayoutTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val layout by lazy {
        EngineLayout(
            componentsDir = File(tmp.root, "components"),
            runtimesDir = File(tmp.root, "runtimes"),
            nativeLibraryDir = File(tmp.root, "lib"),
            abi = "arm64-v8a",
        )
    }

    @Test
    fun runtimeIsTheNearestNotOlderOne() {
        assertEquals(8, JavaRuntimes.componentFor(8))
        assertEquals(8, JavaRuntimes.componentFor(7))
        assertEquals(17, JavaRuntimes.componentFor(9))
        assertEquals(17, JavaRuntimes.componentFor(16)) // 1.17 просит Java 16
        assertEquals(17, JavaRuntimes.componentFor(17))
        assertEquals(21, JavaRuntimes.componentFor(18))
        assertEquals(21, JavaRuntimes.componentFor(21))
        assertEquals(25, JavaRuntimes.componentFor(22))
        assertEquals(25, JavaRuntimes.componentFor(25))
    }

    @Test
    fun newerThanAnyRuntimeIsUnsupported() {
        assertNull(JavaRuntimes.componentFor(26))
    }

    @Test
    fun javaEightKeepsItsHomeInTheNestedFolder() {
        assertEquals(File(tmp.root, "runtimes/jre-8/jre"), layout.javaHome(8))
        assertEquals(File(tmp.root, "runtimes/jre-8/bin/java"), layout.javaExecutable(8))
    }

    @Test
    fun newerJavaHomesAreTheRuntimeRoot() {
        assertEquals(File(tmp.root, "runtimes/jre-17"), layout.javaHome(17))
        assertEquals(File(tmp.root, "runtimes/jre-21/bin/java"), layout.javaExecutable(21))
    }

    @Test
    fun nativesLiveInAPerVersionPerAbiFolder() {
        assertEquals(File(tmp.root, "components/lwjgl/3.3.3/natives/arm64-v8a"), layout.lwjglNativesDir(LwjglVersion.V3_3_3))
        assertEquals(File(tmp.root, "components/lwjgl/3.4.1/natives/arm64-v8a"), layout.lwjglNativesDir(LwjglVersion.V3_4_1))
    }

    @Test
    fun launcherComponentsHaveFixedNames() {
        assertEquals(File(tmp.root, "components/launcher/MioLaunchWrapper.jar"), layout.launchWrapperJar)
        assertEquals(File(tmp.root, "components/launcher/MioLibPatcher.jar"), layout.libPatcherJar)
        assertEquals(File(tmp.root, "components/auth_libs/authlib-injector.jar"), layout.authlibInjectorJar)
    }

    @Test
    fun lwjglJarsAreReadFromDiskInClasspathOrder() {
        val dir = File(tmp.root, "components/lwjgl/3.3.3").apply { mkdirs() }
        listOf("lwjgl-stb.jar", "lwjgl.jar", "lwjgl-3.3.3-merged-modules.jar", "version", "lwjgl-lwjglx.jar")
            .forEach { File(dir, it).writeText("x") }

        val jars = layout.lwjglJars(LwjglRequirement(LwjglVersion.V3_3_3, legacyLwjgl2 = false))

        assertEquals(
            listOf("lwjgl.jar", "lwjgl-3.3.3-merged-modules.jar", "lwjgl-stb.jar").map { File(dir, it) },
            jars,
        )
    }

    @Test
    fun missingLwjglComponentGivesAnEmptyList() {
        assertEquals(emptyList<File>(), layout.lwjglJars(LwjglRequirement.DEFAULT))
    }

    @Test
    fun abiIsTheFirstSupportedOneInDevicePreferenceOrder() {
        assertEquals("arm64-v8a", EngineLayout.abiDirName(listOf("arm64-v8a", "armeabi-v7a", "armeabi")))
        assertEquals("armeabi-v7a", EngineLayout.abiDirName(listOf("armeabi", "armeabi-v7a")))
        assertEquals("x86_64", EngineLayout.abiDirName(listOf("x86_64", "x86")))
    }

    @Test
    fun unsupportedAbisGiveNull() {
        assertNull(EngineLayout.abiDirName(listOf("mips", "armeabi")))
        assertNull(EngineLayout.abiDirName(emptyList()))
    }
}
