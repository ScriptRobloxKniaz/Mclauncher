// Модуль ядра игры. Сейчас в нём только чистая логика на Kotlin (без Android-классов): раскладка компонентов,
// выбор LWJGL и Java, сборка команды запуска JVM. Нативная часть (ndk-build) и процесс игры добавятся в 4.7b —
// см. docs/ENGINE.md.
plugins {
    alias(libs.plugins.android.library)
}

android {
    namespace = "com.mclauncher.engine"
    compileSdk = 37 // как у :app (см. комментарий там)

    defaultConfig {
        minSdk = 26
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    testImplementation(libs.junit)
}
