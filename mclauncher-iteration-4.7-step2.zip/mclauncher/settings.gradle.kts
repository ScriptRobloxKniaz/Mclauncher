pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Нативные библиотеки ядра (Pojav/Zalith) сюда не подключаются: скрипт scripts/fetch_core.py
        // кладёт их прямо в папки модуля :engine (см. docs/ENGINE.md).
    }
}

rootProject.name = "MCLauncher"
include(":app")
include(":engine")
