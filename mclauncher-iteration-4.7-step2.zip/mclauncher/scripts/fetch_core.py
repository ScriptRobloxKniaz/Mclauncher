#!/usr/bin/env python3
"""Проверка закреплённой ревизии ядра игры (ZalithLauncher 2) — этап 4.7a.

Что делает:
  1. читает `engine/UPSTREAM` (адрес репозитория и SHA коммита);
  2. скачивает из GitHub ТОЛЬКО дерево файлов этого коммита (без содержимого файлов — несколько мегабайт,
     а не ~900 МБ);
  3. проверяет, что на месте все файлы, на которые опирается модуль :engine (см. REQUIRED и docs/ENGINE.md).

Ничего не копирует и не меняет в проекте. Копирование нативных библиотек, рантаймов и компонентов в модуль :engine
появится в этапе 4.7b как отдельный режим.

Запуск:  python3 -I scripts/fetch_core.py
Код возврата: 0 — всё на месте; 1 — чего-то нет или ревизия недоступна.
"""
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UPSTREAM_FILE = ROOT / "engine" / "UPSTREAM"

# Читаем адрес из файла проекта, но ходим только на известный хост: ошибка в файле не должна уводить на чужой сервер.
ALLOWED_REPOS = {"https://github.com/ZalithLauncher/ZalithLauncher2.git"}

# Относительно корня репозитория апстрима. Каждый путь проверен по ревизии из engine/UPSTREAM.
APP = "ZalithLauncher/src/main"
REQUIRED = [
    "LICENSE",
    # Нативная часть (ndk-build)
    f"{APP}/jni/Android.mk",
    f"{APP}/jni/Application.mk",
    f"{APP}/jni/jre_launcher.c",
    f"{APP}/jni/egl_bridge.c",
    # Java-классы моста: имена пакетов зашиты в JNI-символы libpojavexec.so
    f"{APP}/java/com/movtery/zalithlauncher/bridge/ZLBridge.java",
    f"{APP}/java/com/movtery/zalithlauncher/bridge/LoggerBridge.java",
    f"{APP}/java/org/lwjgl/glfw/CallbackBridge.java",
    # Эталон сборки команды запуска (портирован в :engine)
    f"{APP}/java/com/movtery/zalithlauncher/game/launch/LaunchArgs.kt",
    f"{APP}/java/com/movtery/zalithlauncher/game/launch/Launcher.kt",
    # Наборы LWJGL: пропатченные jar'ы (нативы лежат в AAR ниже)
    f"{APP}/assets/app_runtime/lwjgl/3.3.3/lwjgl.jar",
    f"{APP}/assets/app_runtime/lwjgl/3.4.1/lwjgl.jar",
    "ZalithLauncher/libs/lwjgl-3.3.3-natives-release.aar",
    "ZalithLauncher/libs/lwjgl-3.4.1-natives-release.aar",
    # Компоненты запуска
    f"{APP}/assets/components/launcher/MioLaunchWrapper.jar",
    f"{APP}/assets/components/launcher/MioLibPatcher.jar",
    f"{APP}/assets/components/auth_libs/authlib-injector.jar",
    # Рантаймы Java: общий архив и архив под архитектуру
    *[f"{APP}/assets/runtimes/jre-{v}/{name}" for v in (8, 17, 21, 25) for name in ("universal.tar.xz", "bin-arm64.tar.xz")],
    # Звук
    "ZalithLauncher/libs/openal-soft-release.aar",
]

SHA_RE = re.compile(r"^[0-9a-f]{40}$")


def read_pin() -> dict:
    pin = {}
    for line in UPSTREAM_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        pin[key.strip()] = value.strip()
    return pin


def git(args, cwd):
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0")
    result = subprocess.run(
        ["git", *args], cwd=cwd, env=env, capture_output=True, text=True, timeout=900, check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed ({result.returncode}): {result.stderr.strip()}")
    return result.stdout


def main() -> int:
    try:
        pin = read_pin()
    except OSError as e:
        print(f"Cannot read {UPSTREAM_FILE}: {e}")
        return 1

    repo, commit = pin.get("repo", ""), pin.get("commit", "")
    if repo not in ALLOWED_REPOS:
        print(f"Unexpected repo in engine/UPSTREAM: {repo!r}")
        return 1
    if not SHA_RE.match(commit):
        print(f"engine/UPSTREAM: 'commit' must be a full 40-character SHA, got {commit!r}")
        return 1

    print(f"Upstream: {repo}\nCommit:   {commit} ({pin.get('commit_date', '?')})")
    with tempfile.TemporaryDirectory() as tmp:
        try:
            git(["init", "-q"], tmp)
            git(["remote", "add", "origin", repo], tmp)
            # blob:none — только деревья и коммит, без содержимого файлов.
            git(["fetch", "-q", "--depth", "1", "--filter=blob:none", "origin", commit], tmp)
            listing = git(["ls-tree", "-r", "--name-only", "FETCH_HEAD"], tmp)
        except (RuntimeError, subprocess.TimeoutExpired, OSError) as e:
            print(f"Cannot fetch the pinned revision: {e}")
            return 1

    present = set(listing.splitlines())
    print(f"Files in the pinned tree: {len(present)}")
    missing = [path for path in REQUIRED if path not in present]
    for path in REQUIRED:
        print(("  ok       " if path in present else "  MISSING  ") + path)
    if missing:
        print(f"\n{len(missing)} required path(s) are missing: the layout of the upstream changed. See docs/ENGINE.md.")
        return 1
    print(f"\nAll {len(REQUIRED)} required paths are present.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
