package com.mclauncher.app.launch

import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.account.AccountType
import com.mclauncher.app.data.versions.EngineLibraryPolicy
import com.mclauncher.app.data.versions.Fixtures
import com.mclauncher.app.data.versions.InstallPlanner
import com.mclauncher.app.data.versions.OsEnvironment
import com.mclauncher.app.data.versions.VersionLayout
import com.mclauncher.app.data.versions.VersionParser
import com.mclauncher.engine.EngineEnvironment
import com.mclauncher.engine.EngineLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class PojavGameEngineTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val dirs by lazy { GameDirectories(File(tmp.root, ".minecraft")).also { it.ensureCreated() } }
    private val layout by lazy { VersionLayout(dirs) }
    private val account = Account(1, AccountType.OFFLINE, "Steve", "5627dd98-e6be-3c21-b8a8-e92344183641", true, 0L)

    private val engineLayout by lazy {
        EngineLayout(
            componentsDir = File(tmp.root, "components"),
            runtimesDir = File(tmp.root, "runtimes"),
            nativeLibraryDir = File(tmp.root, "lib"),
            abi = "arm64-v8a",
        )
    }

    private fun engine(layoutProvider: () -> EngineLayout? = { engineLayout }): PojavGameEngine {
        val env = OsEnvironment.LINUX_ARM64
        return PojavGameEngine(
            specFactory = LaunchSpecFactory(
                layout = layout,
                env = env,
                planner = InstallPlanner(layout, env, libraryFilter = EngineLibraryPolicy::isNeeded, libraryReplacement = EngineLibraryPolicy::replacement),
                launcherName = "MCLauncher",
                launcherVersion = "0.1.0",
            ),
            readVersion = { id -> VersionParser.parseVersion(layout.versionJson(id).readText()) },
            layout = layoutProvider,
            environment = { d ->
                EngineEnvironment(
                    gameDir = d.root, userHome = tmp.root, cacheDir = File(tmp.root, "cache"),
                    timezone = "Asia/Baku", androidRelease = "15", screenWidth = 2400, screenHeight = 1080, cpuCores = 8,
                )
            },
            ioDispatcher = Dispatchers.Unconfined,
        )
    }

    private fun request(versionId: String = "1.21.1") = LaunchRequest(account, versionId, ramMb = 2048, directories = dirs)

    private fun installVersionJson(id: String, text: String) {
        layout.versionDir(id).mkdirs()
        layout.versionJson(id).writeText(text)
    }

    private fun launch(engine: PojavGameEngine = engine(), versionId: String = "1.21.1") =
        runBlocking { engine.launch(request(versionId)) }

    private fun failure(result: LaunchResult): LaunchFailure =
        (result as? LaunchResult.Failed)?.failure ?: error("Expected Failed but got $result")

    private val reportFile get() = File(dirs.logs, PojavGameEngine.PREVIEW_FILE_NAME)

    @Test
    fun aDryRunSucceedsAsAPlaceholderAndPointsToTheReport() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))

        val result = launch()

        assertEquals(LaunchResult.Started(placeholder = true, note = reportFile.path), result)
        assertTrue(reportFile.isFile)
    }

    @Test
    fun theReportHasTheCommandAndTheMissingCoreParts() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))

        launch()

        val report = reportFile.readText()
        assertTrue(report.contains("dry run"))
        assertTrue(report.contains("Version:   1.21.1"))
        assertTrue(report.contains("Core: NOT READY"))
        assertTrue(report.contains("LWJGL 3.3.3 natives for arm64-v8a"))
        assertTrue(report.contains("Command (one argument per line):"))
        assertTrue(report.contains("-Djava.library.path=${engineLayout.lwjglNativesDir(com.mclauncher.engine.LwjglVersion.V3_3_3).path}"))
        assertTrue(report.contains("mio.Wrapper"))
    }

    @Test
    fun theReportNeverContainsTheAccessToken() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))

        launch()

        val lines = reportFile.readLines().map { it.trim() }
        val token = lines.indexOf("--accessToken")
        assertTrue(token >= 0)
        assertEquals("********", lines[token + 1])
    }

    @Test
    fun theReportListsFilesMissingOnDisk() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))

        launch()

        val report = reportFile.readText()
        assertTrue(report.contains("Files missing on disk"))
        assertTrue(report.contains("gson-2.10.1.jar"))
    }

    @Test
    fun anUnsupportedProcessorMeansTheEngineIsUnavailable() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))

        val result = launch(engine { null })

        assertEquals(LaunchFailure.EngineUnavailable, failure(result))
        assertFalse(reportFile.exists())
    }

    @Test
    fun aBrokenVersionDescriptionIsAnEngineError() {
        installVersionJson("1.21.1", "{ not json")

        val failure = failure(launch()) as LaunchFailure.EngineError

        assertTrue(failure.detail!!.contains("Cannot read the version description"))
    }

    @Test
    fun aMissingVersionFileIsAnEngineError() {
        val failure = failure(launch(versionId = "9.9.9")) as LaunchFailure.EngineError

        assertTrue(failure.detail!!.contains("Cannot read or write game files"))
    }

    @Test
    fun aJavaNewerThanTheRuntimesIsAnEngineError() {
        val text = Fixtures.text("version_modern.json").replace("\"majorVersion\": 21", "\"majorVersion\": 99")
        assertTrue(text.contains("99"))
        installVersionJson("1.21.1", text)

        val failure = failure(launch()) as LaunchFailure.EngineError

        assertTrue(failure.detail!!.contains("Cannot build the launch command"))
        assertTrue(failure.detail!!.contains("99"))
    }

    @Test
    fun anUnwritableLogsFolderIsReportedNotSwallowed() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        dirs.logs.deleteRecursively()
        dirs.logs.writeText("this is a file, not a folder")

        val failure = failure(launch()) as LaunchFailure.EngineError

        assertTrue(failure.detail!!.contains("Cannot read or write game files"))
    }

    @Test
    fun theWholeLauncherPathWorksWithTheDryRunEngine() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        val launcher = GameLauncher(engine(), dirs, isVersionInstalled = { true }, ioDispatcher = Dispatchers.Unconfined)

        val result = runBlocking { launcher.launch(account, "1.21.1") }

        assertEquals(LaunchResult.Started(placeholder = true, note = reportFile.path), result)
    }
}
