package com.mclauncher.app.launch

import com.mclauncher.app.data.versions.GameVersion
import com.mclauncher.app.data.versions.PlanException
import com.mclauncher.app.data.versions.VersionParseException
import com.mclauncher.engine.CommandBuildException
import com.mclauncher.engine.EngineCore
import com.mclauncher.engine.EngineEnvironment
import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.LaunchCommandBuilder
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * Игровое ядро на основе Pojav/Zalith (см. docs/ENGINE.md).
 *
 * ЭТАП 4.7a — ПРОБНЫЙ ЗАПУСК. Движок читает описание установленной версии, собирает настоящую команду запуска
 * JVM (с нативами ядра в `-Djava.library.path`), проверяет, чего ядру не хватает, и записывает всё это в отчёт
 * `logs/launch-preview.txt`. Саму игру он пока **не запускает**: процесс игры и JNI-мост — этап 4.7b, поэтому
 * результат всегда `Started(placeholder = true)`. Зато настоящие файлы настоящей версии на устройстве уже
 * проходят через сборку команды, и ошибки в данных видны в отчёте и в диалоге до подключения нативной части.
 *
 * Класс не зависит от Android: всё платформенное приходит через функции-поставщики (см. `LauncherApp`).
 */
class PojavGameEngine(
    private val specFactory: LaunchSpecFactory,
    /** Читает и разбирает `versions/<id>/<id>.json`. Бросает [VersionParseException] или [IOException]. */
    private val readVersion: (versionId: String) -> GameVersion,
    /** Раскладка ядра на этом устройстве или `null`, если архитектура процессора не поддерживается ядром. */
    private val layout: () -> EngineLayout?,
    private val environment: (GameDirectories) -> EngineEnvironment,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) : GameEngine {

    override suspend fun launch(request: LaunchRequest): LaunchResult = withContext(ioDispatcher) {
        val engineLayout = layout() ?: return@withContext LaunchResult.Failed(LaunchFailure.EngineUnavailable)

        try {
            val version = readVersion(request.versionId)
            val spec = specFactory.create(version, request.account, request.directories, request.ramMb)
            val command = LaunchCommandBuilder(engineLayout, environment(request.directories)).build(spec)
            val status = EngineCore.check(engineLayout, spec.lwjgl, spec.javaMajor)

            val report = File(request.directories.logs, PREVIEW_FILE_NAME)
            writeReport(report, LaunchPreview.render(spec, command, status))

            // 4.7b: если status.isReady — запустить процесс игры. Пока результат один и тот же.
            LaunchResult.Started(placeholder = true, note = report.path)
        } catch (e: VersionParseException) {
            failure("Cannot read the version description: ${e.message}")
        } catch (e: PlanException) {
            failure("The version description is unusable: ${e.message}")
        } catch (e: CommandBuildException) {
            failure("Cannot build the launch command: ${e.message}")
        } catch (e: IOException) {
            failure("Cannot read or write game files: ${e.message}")
        }
    }

    private fun failure(detail: String) = LaunchResult.Failed(LaunchFailure.EngineError(detail))

    /** Пока игра не стартует, отчёт — единственный результат запуска; сбой записи (диск полон) возвращается ошибкой. */
    private fun writeReport(file: File, text: String) {
        file.parentFile?.mkdirs()
        file.writeText(text)
    }

    companion object {
        const val PREVIEW_FILE_NAME = "launch-preview.txt"
    }
}
