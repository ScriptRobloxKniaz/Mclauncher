package com.mclauncher.app.ui.navigation

import android.net.Uri
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.AnimatedContentTransitionScope.SlideDirection
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.BackgroundPreset
import com.mclauncher.app.data.settings.BackgroundSelection
import com.mclauncher.app.data.versions.VersionLibraryState
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.ui.accounts.AccountsScreen
import com.mclauncher.app.ui.assistant.AssistantScreen
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.home.HomeScreen
import com.mclauncher.app.ui.placeholder.PlaceholderScreen
import com.mclauncher.app.ui.settings.CoreControls
import com.mclauncher.app.ui.settings.CoreViewModel
import com.mclauncher.app.ui.settings.SettingsScreen
import com.mclauncher.app.ui.settings.VideoControls
import com.mclauncher.app.ui.skins.SkinsScreen
import com.mclauncher.app.ui.versions.VersionsScreen

private const val ANIM_MS = 320

/** Переход на вкладку нижней панели с сохранением состояния каждой вкладки. */
fun NavController.navigateToTab(destination: Destination) {
    navigate(destination.route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

fun NavController.navigateTo(destination: Destination) {
    if (destination.inBottomBar) navigateToTab(destination) else navigate(destination.route) { launchSingleTop = true }
}

@Composable
fun LauncherNavHost(
    navController: NavHostController,
    activeAccount: ActiveAccountState,
    library: VersionLibraryState?,
    launchPhase: LaunchPhase,
    onPlay: (versionId: String?) -> Unit,
    onSelectVersion: (String) -> Unit,
    backgroundSelection: BackgroundSelection,
    customBackgroundPreview: ImageBitmap?,
    videoControls: VideoControls,
    onSelectPreset: (BackgroundPreset) -> Unit,
    onPickCustomBackground: (Uri) -> Unit,
    modifier: Modifier = Modifier,
) {
    NavHost(
        navController = navController,
        startDestination = Destination.Home.route,
        modifier = modifier,
        enterTransition = { enter() },
        exitTransition = { exit() },
        popEnterTransition = { enter() },
        popExitTransition = { exit() },
    ) {
        composable(Destination.Home.route) {
            HomeScreen(
                activeAccount = activeAccount,
                library = library,
                launchPhase = launchPhase,
                onPlay = onPlay,
                onSelectVersion = onSelectVersion,
                backgroundSelection = backgroundSelection,
                customBackgroundPreview = customBackgroundPreview,
                videoActive = videoControls.settings.active,
                onSelectPreset = onSelectPreset,
                onPickCustomBackground = onPickCustomBackground,
                onPickCustomVideo = videoControls.onPick,
                onNavigate = { destination -> navController.navigateTo(destination) },
            )
        }
        composable(Destination.Accounts.route) {
            AccountsScreen()
        }
        composable(Destination.Skins.route) {
            SkinsScreen(onOpenAccounts = { navController.navigateTo(Destination.Accounts) })
        }
        composable(Destination.Mods.route) {
            PlaceholderScreen(
                destination = Destination.Mods,
                message = stringResource(R.string.placeholder_mods),
            )
        }
        composable(Destination.Settings.route) {
            val coreViewModel: CoreViewModel = viewModel()
            val coreState by coreViewModel.state.collectAsStateWithLifecycle()
            SettingsScreen(
                video = videoControls,
                core = CoreControls(
                    state = coreState,
                    onInstall = coreViewModel::install,
                    onCancel = coreViewModel::cancel,
                    onRefresh = coreViewModel::refresh,
                ),
            )
        }
        composable(Destination.Assistant.route) {
            AssistantScreen(onBack = { navController.popBackStack() })
        }
        composable(Destination.Versions.route) {
            VersionsScreen(onBack = { navController.popBackStack() })
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Анимации переходов
//  - между вкладками: горизонтальный сдвиг в сторону порядка вкладок + fade;
//  - открытие ИИ-помощника: выезжает снизу, закрытие — уезжает вниз;
//  - экран версий: въезжает справа, при возврате уезжает вправо; экран под ним просто мягко гаснет.
// ---------------------------------------------------------------------------------------------

private fun AnimatedContentTransitionScope<NavBackStackEntry>.isAssistantTarget() =
    targetState.destination.route == Destination.Assistant.route

private fun AnimatedContentTransitionScope<NavBackStackEntry>.isAssistantInitial() =
    initialState.destination.route == Destination.Assistant.route

private fun AnimatedContentTransitionScope<NavBackStackEntry>.isVersionsTarget() =
    targetState.destination.route == Destination.Versions.route

private fun AnimatedContentTransitionScope<NavBackStackEntry>.isVersionsInitial() =
    initialState.destination.route == Destination.Versions.route

private fun AnimatedContentTransitionScope<NavBackStackEntry>.tabDirection(): SlideDirection {
    val from = Destination.tabs.indexOf(Destination.fromRoute(initialState.destination.route))
    val to = Destination.tabs.indexOf(Destination.fromRoute(targetState.destination.route))
    return if (to >= from) SlideDirection.Left else SlideDirection.Right
}

private fun AnimatedContentTransitionScope<NavBackStackEntry>.enter(): EnterTransition = when {
    isAssistantTarget() ->
        slideIntoContainer(SlideDirection.Up, tween(ANIM_MS)) + fadeIn(tween(ANIM_MS))

    isAssistantInitial() ->
        fadeIn(tween(ANIM_MS))

    isVersionsTarget() ->
        slideIntoContainer(SlideDirection.Left, tween(ANIM_MS)) + fadeIn(tween(ANIM_MS))

    isVersionsInitial() ->
        fadeIn(tween(ANIM_MS))

    else ->
        slideIntoContainer(tabDirection(), tween(ANIM_MS), initialOffset = { it / 5 }) + fadeIn(tween(ANIM_MS))
}

private fun AnimatedContentTransitionScope<NavBackStackEntry>.exit(): ExitTransition = when {
    isAssistantTarget() ->
        fadeOut(tween(ANIM_MS))

    isAssistantInitial() ->
        slideOutOfContainer(SlideDirection.Down, tween(ANIM_MS)) + fadeOut(tween(ANIM_MS))

    isVersionsTarget() ->
        fadeOut(tween(ANIM_MS))

    isVersionsInitial() ->
        slideOutOfContainer(SlideDirection.Right, tween(ANIM_MS)) + fadeOut(tween(ANIM_MS))

    else ->
        slideOutOfContainer(tabDirection(), tween(ANIM_MS), targetOffset = { it / 5 }) + fadeOut(tween(ANIM_MS))
}
