package com.mclauncher.app.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mclauncher.app.ui.theme.NeonColors

private val ButtonShape = RoundedCornerShape(12.dp)

private val SoftWhiteBorder = Color(0x33FFFFFF)
private val FocusWhiteBorder = Color(0xCCFFFFFF)

/**
 * Главная кнопка: синий градиент со свечением, как на макете. Компактная — по умолчанию 40 dp высотой.
 * [busy] — вместо значка крутится индикатор, нажатия игнорируются, но вид остаётся «живым».
 */
@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    busy: Boolean = false,
    height: Dp = 40.dp,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val focused by interactionSource.collectIsFocusedAsState()
    val active = enabled && !busy
    val scale by animateFloatAsState(
        targetValue = if (pressed && active) 0.97f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "neonButtonScale",
    )
    val contentColor = if (enabled) NeonColors.OnGradient else NeonColors.DisabledContent
    val borderColor = when {
        focused -> FocusWhiteBorder
        enabled -> SoftWhiteBorder
        else -> Color(0x1AFFFFFF)
    }

    Box(
        modifier = modifier
            .height(height)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(
                elevation = if (enabled && !pressed) 8.dp else 0.dp,
                shape = ButtonShape,
                ambientColor = NeonColors.Glow,
                spotColor = NeonColors.Glow,
            )
            .clip(ButtonShape)
            .background(
                when {
                    !enabled -> SolidColor(NeonColors.DisabledFill)
                    pressed -> NeonColors.pressedGradient
                    else -> NeonColors.gradient
                },
            )
            .border(1.dp, borderColor, ButtonShape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = Color.White),
                enabled = active,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (busy) {
                CircularProgressIndicator(
                    color = contentColor,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(18.dp),
                )
            } else if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(20.dp),
                )
            }
            Text(
                text = text,
                color = contentColor,
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/**
 * Вторичная кнопка: тёмная заливка и тонкая рамка; при нажатии или фокусе рамка загорается синим.
 * [danger] — красная рамка и значок, для «Удалить».
 */
@Composable
fun NeonSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    danger: Boolean = false,
    height: Dp = 40.dp,
) {
    val colors = MaterialTheme.colorScheme
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val focused by interactionSource.collectIsFocusedAsState()
    val accent = if (danger) colors.error else colors.primary
    val borderColor = when {
        !enabled -> colors.outlineVariant.copy(alpha = 0.5f)
        pressed || focused -> accent
        danger -> colors.error.copy(alpha = 0.7f)
        else -> colors.outlineVariant
    }
    val contentColor = when {
        !enabled -> NeonColors.DisabledContent
        danger -> colors.error
        else -> colors.onSurface
    }

    Box(
        modifier = modifier
            .height(height)
            .clip(ButtonShape)
            .background(if (pressed && enabled) colors.surfaceContainerHigh else colors.surfaceContainer)
            .border(1.dp, borderColor, ButtonShape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = accent),
                enabled = enabled,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(20.dp),
                )
            }
            Text(
                text = text,
                color = contentColor,
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Medium),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** Квадратная кнопка с одним значком (шапка главного экрана). [contentDescription] нужен для озвучки. */
@Composable
fun NeonIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
) {
    val colors = MaterialTheme.colorScheme
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val focused by interactionSource.collectIsFocusedAsState()

    Box(
        modifier = modifier
            .size(size)
            .clip(ButtonShape)
            .background(colors.surfaceContainer.copy(alpha = 0.92f))
            .border(1.dp, if (pressed || focused) colors.primary else colors.outlineVariant, ButtonShape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = colors.primary),
                role = Role.Button,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = colors.onSurface,
            modifier = Modifier.size(20.dp),
        )
    }
}
