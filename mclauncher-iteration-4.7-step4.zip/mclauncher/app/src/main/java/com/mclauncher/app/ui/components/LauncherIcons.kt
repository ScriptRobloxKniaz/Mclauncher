package com.mclauncher.app.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Иконки, которых нет в material-icons-core. Нарисованы вручную,
 * чтобы не тащить тяжёлый material-icons-extended.
 */
object LauncherIcons {

    /** Четырёхлучевая «искра» — значок ИИ-помощника. */
    val Sparkle: ImageVector by lazy {
        ImageVector.Builder(
            name = "Sparkle",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f)
                lineTo(14.4f, 9.6f)
                lineTo(22f, 12f)
                lineTo(14.4f, 14.4f)
                lineTo(12f, 22f)
                lineTo(9.6f, 14.4f)
                lineTo(2f, 12f)
                lineTo(9.6f, 9.6f)
                close()
            }
        }.build()
    }

    /** Рамка с горами — «выбрать картинку/фон». */
    val Image: ImageVector by lazy {
        ImageVector.Builder(
            name = "Image",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            // Рамка: внешний прямоугольник минус внутренний (even-odd).
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
                moveTo(3f, 4f)
                lineTo(21f, 4f)
                lineTo(21f, 20f)
                lineTo(3f, 20f)
                close()
                moveTo(5f, 6f)
                lineTo(5f, 18f)
                lineTo(19f, 18f)
                lineTo(19f, 6f)
                close()
            }
            // Горы
            path(fill = SolidColor(Color.Black)) {
                moveTo(6.5f, 16.5f)
                lineTo(10f, 11f)
                lineTo(12.8f, 14.6f)
                lineTo(14.8f, 12.2f)
                lineTo(17.5f, 16.5f)
                close()
            }
        }.build()
    }

    /** Три строки с маркерами — список версий игры. */
    val Versions: ImageVector by lazy {
        ImageVector.Builder(
            name = "Versions",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(fill = SolidColor(Color.Black)) {
                for (top in listOf(4f, 10f, 16f)) {
                    // маркер
                    moveTo(3f, top)
                    lineTo(7f, top)
                    lineTo(7f, top + 4f)
                    lineTo(3f, top + 4f)
                    close()
                    // строка
                    moveTo(9f, top)
                    lineTo(21f, top)
                    lineTo(21f, top + 4f)
                    lineTo(9f, top + 4f)
                    close()
                }
            }
        }.build()
    }

    /** Блок (изометрический куб) — значок версии игры. Три грани разной яркости дают объём. */
    val Cube: ImageVector by lazy {
        ImageVector.Builder(
            name = "Cube",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            // верхняя грань
            path(fill = SolidColor(Color.Black), fillAlpha = 1f) {
                moveTo(12f, 2f); lineTo(21f, 7f); lineTo(12f, 12f); lineTo(3f, 7f); close()
            }
            // левая грань
            path(fill = SolidColor(Color.Black), fillAlpha = 0.62f) {
                moveTo(3f, 7f); lineTo(12f, 12f); lineTo(12f, 22f); lineTo(3f, 17f); close()
            }
            // правая грань
            path(fill = SolidColor(Color.Black), fillAlpha = 0.8f) {
                moveTo(12f, 12f); lineTo(21f, 7f); lineTo(21f, 17f); lineTo(12f, 22f); close()
            }
        }.build()
    }

    /** Рамка с треугольником «играть» — видео. */
    val Video: ImageVector by lazy {
        ImageVector.Builder(
            name = "Video",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            // Рамка: внешний прямоугольник минус внутренний (even-odd).
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
                moveTo(3f, 5f); lineTo(21f, 5f); lineTo(21f, 19f); lineTo(3f, 19f); close()
                moveTo(5f, 7f); lineTo(5f, 17f); lineTo(19f, 17f); lineTo(19f, 7f); close()
            }
            path(fill = SolidColor(Color.Black)) {
                moveTo(10f, 9f); lineTo(15.5f, 12f); lineTo(10f, 15f); close()
            }
        }.build()
    }

    /** Динамик с двумя дугами — звук включён. */
    val VolumeOn: ImageVector by lazy {
        ImageVector.Builder(
            name = "VolumeOn",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 9f); lineTo(7f, 9f); lineTo(12f, 4f); lineTo(12f, 20f); lineTo(7f, 15f); lineTo(3f, 15f); close()
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
            ) {
                moveTo(15.5f, 9f); quadTo(17.5f, 12f, 15.5f, 15f)
                moveTo(18.2f, 6.5f); quadTo(22.2f, 12f, 18.2f, 17.5f)
            }
        }.build()
    }

    /** Динамик с крестиком — звук выключен. */
    val VolumeOff: ImageVector by lazy {
        ImageVector.Builder(
            name = "VolumeOff",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 9f); lineTo(7f, 9f); lineTo(12f, 4f); lineTo(12f, 20f); lineTo(7f, 15f); lineTo(3f, 15f); close()
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
            ) {
                moveTo(16f, 9.5f); lineTo(21f, 14.5f)
                moveTo(21f, 9.5f); lineTo(16f, 14.5f)
            }
        }.build()
    }
}
