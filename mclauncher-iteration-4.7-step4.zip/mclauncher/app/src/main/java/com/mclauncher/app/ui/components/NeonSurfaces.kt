package com.mclauncher.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp

/** Скругление карточек по умолчанию: небольшое, как на макете. */
val NeonCardShape = RoundedCornerShape(14.dp)

/**
 * Карточка: тёмно-синяя заливка на ступень светлее фона и тонкая рамка. Выбранная карточка получает яркую рамку
 * и более светлую заливку. Если задан [onClick], вся карточка нажимается.
 *
 * Заливка чуть прозрачная, чтобы на видео и картинке фон угадывался, но текст оставался читаемым.
 */
@Composable
fun NeonCard(
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null,
    shape: Shape = NeonCardShape,
    content: @Composable ColumnScope.() -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    Column(
        modifier = modifier
            .clip(shape)
            .background(if (selected) colors.surfaceContainerHigh.copy(alpha = 0.94f) else colors.surfaceContainer.copy(alpha = 0.90f))
            .border(if (selected) 1.5.dp else 1.dp, if (selected) colors.primary else colors.outlineVariant, shape)
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier),
        content = content,
    )
}
