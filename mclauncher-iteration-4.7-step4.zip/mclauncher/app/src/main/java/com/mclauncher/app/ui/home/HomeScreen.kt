package com.mclauncher.app.ui.home

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.BackgroundPreset
import com.mclauncher.app.data.settings.BackgroundSelection
import com.mclauncher.app.data.versions.VersionLibraryState
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.components.NeonIconButton
import com.mclauncher.app.ui.navigation.Destination

/**
 * Главный экран в альбомной ориентации из двух зон: слева шапка и сетка установленных версий (у каждой своя
 * кнопка «Запустить»), справа компактная панель профиля — скин, ник, статус, выбранная версия и кнопка запуска.
 * Стадии запуска показывают сами кнопки, итог — диалог в корне UI.
 *
 * Под шапкой всегда видна пометка «неофициальная модифицированная версия»: её требует лицензия ZalithLauncher 2.
 *
 * Если окно вдруг узкое (разделённый экран), зоны ставятся друг под другом.
 */
@Composable
fun HomeScreen(
    activeAccount: ActiveAccountState,
    library: VersionLibraryState?,
    launchPhase: LaunchPhase,
    /** `null` — запустить выбранную версию, иначе — именно эту (её сначала выбирают). */
    onPlay: (versionId: String?) -> Unit,
    onSelectVersion: (String) -> Unit,
    backgroundSelection: BackgroundSelection,
    customBackgroundPreview: ImageBitmap?,
    /** Сейчас на заднем плане играет видео: в окне выбора фона отмечается оно, а не картинка или пресет. */
    videoActive: Boolean,
    onSelectPreset: (BackgroundPreset) -> Unit,
    onPickCustomBackground: (Uri) -> Unit,
    onPickCustomVideo: (Uri) -> Unit,
    onNavigate: (Destination) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var showBackgroundSheet by rememberSaveable { mutableStateOf(false) }

    // SAF: системный выбор картинки. Права на чтение действуют на один этот вызов — этого достаточно,
    // потому что картинка сразу копируется в хранилище приложения. С видео то же самое.
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            showBackgroundSheet = false
            onPickCustomBackground(uri)
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            showBackgroundSheet = false
            onPickCustomVideo(uri)
        }
    }

    // Общая проверка для всех кнопок «Запустить»: аккаунт и версия должны быть, иначе объясняем и ведём куда нужно.
    val play: (String?) -> Unit = { versionId ->
        when (decidePlay(activeAccount, library, versionId)) {
            PlayDecision.LAUNCH -> onPlay(versionId)

            PlayDecision.NEED_ACCOUNT -> {
                Toast.makeText(context, R.string.play_need_account, Toast.LENGTH_SHORT).show()
                onNavigate(Destination.Accounts)
            }

            PlayDecision.NEED_VERSION -> {
                Toast.makeText(context, R.string.play_need_version, Toast.LENGTH_SHORT).show()
                onNavigate(Destination.Versions)
            }

            PlayDecision.PICK_VERSION ->
                Toast.makeText(context, R.string.play_pick_version, Toast.LENGTH_SHORT).show()

            PlayDecision.WAIT -> Unit
        }
    }

    val installed = library?.installed.orEmpty()
    val canLaunch = launchPhase == LaunchPhase.IDLE

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        // Размеры берём в локальные переменные: внутри вложенных лямбд так надёжнее, чем обращаться к scope.
        val availableWidth = maxWidth
        val availableHeight = maxHeight
        // Две зоны, пока окно шире, чем выше (альбомная ориентация закреплена в манифесте). Друг под другом их ставим
        // только в «высоком» или совсем узком окне — например, в разделённом экране.
        val narrow = availableWidth < availableHeight || availableWidth < 420.dp
        val panelWidth = when {
            availableWidth > 900.dp -> 300.dp
            availableWidth >= 640.dp -> 260.dp
            else -> 230.dp
        }
        // Фигура скина занимает свободное место по высоте, но в разумных пределах: панель компактная.
        val skinHeight: Dp = if (narrow) 88.dp else (availableHeight - 230.dp).coerceIn(64.dp, 150.dp)

        val header: @Composable () -> Unit = {
            HomeHeader(
                onOpenAssistant = { onNavigate(Destination.Assistant) },
                onOpenVersions = { onNavigate(Destination.Versions) },
                onChangeBackground = { showBackgroundSheet = true },
            )
        }
        val grid: @Composable (Modifier) -> Unit = { gridModifier ->
            VersionGrid(
                installed = installed,
                selectedId = library?.selected?.id,
                loaded = library != null,
                canLaunch = canLaunch,
                onSelect = onSelectVersion,
                onLaunch = { versionId -> play(versionId) },
                onOpenVersions = { onNavigate(Destination.Versions) },
                modifier = gridModifier,
            )
        }
        val panel: @Composable (Modifier) -> Unit = { panelModifier ->
            ProfilePanel(
                account = activeAccount,
                version = library?.selected,
                launchPhase = launchPhase,
                onPlay = { play(null) },
                onOpenAccounts = { onNavigate(Destination.Accounts) },
                onOpenVersions = { onNavigate(Destination.Versions) },
                modifier = panelModifier,
                skinHeight = skinHeight,
            )
        }

        if (narrow) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                header()
                // Панель прокручивается внутри себя, поэтому её можно ограничить: сетка версий не уедет за экран.
                panel(Modifier.fillMaxWidth().heightIn(max = availableHeight * 0.55f))
                grid(Modifier.weight(1f))
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    header()
                    grid(Modifier.weight(1f))
                }
                panel(
                    Modifier
                        .width(panelWidth)
                        .fillMaxHeight(),
                )
            }
        }
    }

    if (showBackgroundSheet) {
        BackgroundSheet(
            selection = backgroundSelection,
            customPreview = customBackgroundPreview,
            videoActive = videoActive,
            onSelectPreset = onSelectPreset,
            onPickFromGallery = { imagePicker.launch(arrayOf("image/*")) },
            onPickVideo = { videoPicker.launch(arrayOf("video/*")) },
            onDismiss = { showBackgroundSheet = false },
        )
    }
}

/** Шапка: девиз, пометка о неофициальной версии и три кнопки-значка справа. Текст лежит на фоне, поэтому с тенью. */
@Composable
private fun HomeHeader(
    onOpenAssistant: () -> Unit,
    onOpenVersions: () -> Unit,
    onChangeBackground: () -> Unit,
) {
    val shadow = Shadow(color = Color(0x99000000), offset = Offset(0f, 2f), blurRadius = 8f)
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.home_tagline),
                style = MaterialTheme.typography.titleLarge.merge(
                    TextStyle(color = Color.White, fontWeight = FontWeight.Bold, shadow = shadow),
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = stringResource(R.string.home_unofficial),
                style = MaterialTheme.typography.labelSmall.merge(
                    TextStyle(color = Color(0xCCFFFFFF), shadow = shadow),
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        NeonIconButton(LauncherIcons.Sparkle, stringResource(R.string.assistant_title), onOpenAssistant)
        NeonIconButton(LauncherIcons.Versions, stringResource(R.string.versions_title), onOpenVersions)
        NeonIconButton(LauncherIcons.Image, stringResource(R.string.background_change), onChangeBackground)
    }
}
