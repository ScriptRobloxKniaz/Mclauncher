package com.mclauncher.app.ui.components

import android.net.Uri
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LifecycleStartEffect
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.mclauncher.app.data.settings.sanitizeVolume

/**
 * Видео на заднем плане: заполняет экран с обрезкой по краям, играет по кругу и по умолчанию без звука.
 *
 *  - плеер создаётся под конкретное видео ([BackgroundVideo.stamp]) и освобождается, когда видео убирают;
 *  - когда приложение уходит с экрана, видео ставится на паузу и не жжёт батарею, а при возвращении продолжается;
 *  - громкость меняется на лету, без перезапуска видео ([volume] от 0 до 1);
 *  - если видео не играется (повреждён файл, неподдерживаемый кодек), вызывается [onError], а вызывающий код
 *    выключает видео-фон — под ним остаётся обычный фон.
 *
 * Аннотация Suppress: часть классов Media3 помечена как нестабильные. Это проверяет только lint, компилятору всё равно.
 */
@Suppress("UnsafeOptInUsageError")
@Composable
fun VideoBackground(
    video: BackgroundVideo,
    volume: Float,
    onError: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val currentOnError by rememberUpdatedState(onError)
    val startVolume = sanitizeVolume(volume)

    val exoPlayer = remember(video.file.path, video.stamp) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            // Громкость задаём до начала воспроизведения: иначе при выключенном звуке мог бы мелькнуть звук.
            this.volume = startVolume
            addListener(
                object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        currentOnError()
                    }
                },
            )
            setMediaItem(MediaItem.fromUri(Uri.fromFile(video.file)))
            playWhenReady = true
            prepare()
        }
    }

    // Объявлен первым, поэтому выполняется последним: сначала пауза, потом освобождение плеера.
    DisposableEffect(exoPlayer) {
        onDispose { exoPlayer.release() }
    }

    LaunchedEffect(exoPlayer, volume) {
        exoPlayer.volume = sanitizeVolume(volume)
    }

    LifecycleStartEffect(exoPlayer) {
        exoPlayer.play()
        onStopOrDispose { exoPlayer.pause() }
    }

    AndroidView(
        factory = { viewContext ->
            PlayerView(viewContext).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                player = exoPlayer
            }
        },
        update = { view -> view.player = exoPlayer },
        onRelease = { view -> view.player = null },
        modifier = modifier.fillMaxSize(),
    )
}
