package com.mclauncher.app.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

/**
 * Цвета, которых нет в схеме Material: градиент главных кнопок и свечение. Остальное берётся из [MaterialTheme].
 * Палитра — «синий неон»: тёмно-синий фон, карточки на ступень светлее и яркий синий акцент.
 */
object NeonColors {
    /** Начало и конец градиента главной кнопки и выбранного пункта меню. */
    val GradientStart = Color(0xFF2F7BFF)
    val GradientEnd = Color(0xFF5B5BF0)

    /** Градиент, нажатая кнопка: темнее. */
    val PressedStart = Color(0xFF1E55C2)
    val PressedEnd = Color(0xFF4040B8)

    /** Свечение при наведении/фокусе и подсветка выбранной карточки. */
    val Glow = Color(0xFF4C8DFF)

    /** Заливка и текст недоступной кнопки. */
    val DisabledFill = Color(0xFF18233F)
    val DisabledContent = Color(0xFF5C6B92)

    /** Текст и значки на градиенте. */
    val OnGradient = Color.White

    val gradient: Brush get() = Brush.horizontalGradient(listOf(GradientStart, GradientEnd))
    val pressedGradient: Brush get() = Brush.horizontalGradient(listOf(PressedStart, PressedEnd))
}

private val DarkColors = darkColorScheme(
    primary = Color(0xFF3D85FF),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFF1B4FD6),
    onPrimaryContainer = Color(0xFFE3ECFF),
    inversePrimary = Color(0xFF1E5BE0),
    secondary = Color(0xFF8FA6FF),
    onSecondary = Color(0xFF0A1740),
    secondaryContainer = Color(0xFF16284F),
    onSecondaryContainer = Color(0xFFD6E2FF),
    tertiary = Color(0xFF7F7BFF),
    onTertiary = Color(0xFF0E0B4A),
    tertiaryContainer = Color(0xFF2A2A78),
    onTertiaryContainer = Color(0xFFE0DEFF),
    background = Color(0xFF050A17),
    onBackground = Color(0xFFE4EAFF),
    surface = Color(0xFF0A1226),
    onSurface = Color(0xFFE4EAFF),
    surfaceVariant = Color(0xFF152140),
    onSurfaceVariant = Color(0xFF9DB0D8),
    surfaceTint = Color(0xFF3D85FF),
    inverseSurface = Color(0xFFE4EAFF),
    inverseOnSurface = Color(0xFF0A1226),
    error = Color(0xFFFF5468),
    onError = Color(0xFF3B0008),
    errorContainer = Color(0xFF5A1020),
    onErrorContainer = Color(0xFFFFD9DE),
    outline = Color(0xFF3A507F),
    outlineVariant = Color(0xFF1D2D54),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFF1B2A55),
    surfaceDim = Color(0xFF050A17),
    surfaceContainerLowest = Color(0xFF050A17),
    surfaceContainerLow = Color(0xFF0A1226),
    surfaceContainer = Color(0xFF0D1730),
    surfaceContainerHigh = Color(0xFF121E3C),
    surfaceContainerHighest = Color(0xFF182650),
)

// Светлая схема пока не используется (тема всегда тёмная, см. MainActivity); она тоже синяя, чтобы не осталось
// чужих цветов, когда выбор темы появится в настройках (итерация 8).
private val LightColors = lightColorScheme(
    primary = Color(0xFF1F5FE0),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD9E5FF),
    onPrimaryContainer = Color(0xFF001A4D),
    secondary = Color(0xFF4A5C8F),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDCE4FF),
    onSecondaryContainer = Color(0xFF0A1A44),
    tertiary = Color(0xFF5750D6),
    background = Color(0xFFF6F8FF),
    onBackground = Color(0xFF0B1230),
    surface = Color(0xFFF6F8FF),
    onSurface = Color(0xFF0B1230),
    surfaceVariant = Color(0xFFDDE3F5),
    onSurfaceVariant = Color(0xFF424B6A),
)

@Composable
fun MCLauncherTheme(
    // Пока всегда тёмная (см. MainActivity).
    darkTheme: Boolean = true,
    // По умолчанию выключено, чтобы сохранить собственную палитру лаунчера.
    // Позже можно вынести в настройки.
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content,
    )
}
