package com.mclauncher.app.data.settings

/** Встроенные фоны. Сам рисунок живёт в UI-слое (ui/components/PresetBackground.kt). */
enum class BackgroundPreset(val id: String) {
    NEON("neon"),
    MEADOW("meadow"),
    DUSK("dusk"),
    DEEP("deep");

    companion object {
        /** Синий «неон» — под цвет интерфейса. Уже сохранённый выбор других пресетов не меняется. */
        val Default = NEON

        fun fromId(id: String?): BackgroundPreset = entries.firstOrNull { it.id == id } ?: Default
    }
}

/** Что пользователь выбрал в качестве фона. */
sealed interface BackgroundSelection {

    data class Preset(val preset: BackgroundPreset) : BackgroundSelection

    /**
     * Своя картинка. Сам файл лежит в приватном хранилище приложения
     * (см. BackgroundImageStore), а [stamp] — момент импорта: он меняется при каждой
     * новой картинке и заставляет UI перезагрузить файл.
     */
    data class Custom(val stamp: Long) : BackgroundSelection
}
