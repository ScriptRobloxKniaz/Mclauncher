package com.mclauncher.app.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.skin.SkinModel
import com.mclauncher.app.data.versions.InstalledVersion
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.ui.accounts.isOnline
import com.mclauncher.app.ui.accounts.labelRes
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.components.NeonButton
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.components.PlayButton
import com.mclauncher.app.ui.launch.playLabelRes
import com.mclauncher.app.ui.skins.SkinFront
import com.mclauncher.app.ui.skins.rememberSkinBitmap
import com.mclauncher.app.ui.versions.labelRes

// Статус — смысловые цвета, а не часть палитры: «в сети» зелёный, «оффлайн» янтарный, как на макете.
private val OnlineDot = Color(0xFF3DDC84)
private val OfflineDot = Color(0xFFFFB84D)

/**
 * Правая панель главного экрана: скин, ник и статус аккаунта, выбранная версия и кнопка запуска.
 * Если аккаунта нет — вместо профиля кнопка «Добавить аккаунт». Нажатие на аккаунт открывает экран аккаунтов,
 * на версию — экран версий.
 *
 * [skinHeight] — высота фигуры скина; на низких экранах её уменьшают, чтобы всё поместилось без прокрутки.
 */
@Composable
fun ProfilePanel(
    account: ActiveAccountState,
    version: InstalledVersion?,
    launchPhase: LaunchPhase,
    onPlay: () -> Unit,
    onOpenAccounts: () -> Unit,
    onOpenVersions: () -> Unit,
    modifier: Modifier = Modifier,
    skinHeight: Dp = 120.dp,
) {
    NeonCard(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            when (account) {
                // Резервируем место, чтобы панель не «прыгала», когда база ответит.
                ActiveAccountState.Loading -> Spacer(Modifier.height(skinHeight + 44.dp))

                ActiveAccountState.None -> NoAccount(onClick = onOpenAccounts, height = skinHeight + 44.dp)

                is ActiveAccountState.Selected -> AccountBlock(account.account, skinHeight, onOpenAccounts)
            }

            VersionLine(version = version, onClick = onOpenVersions)

            PlayButton(
                label = stringResource(launchPhase.playLabelRes),
                onClick = onPlay,
                busy = launchPhase != LaunchPhase.IDLE,
                height = 44.dp,
            )
        }
    }
}

@Composable
private fun AccountBlock(account: Account, skinHeight: Dp, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
            modifier = Modifier.padding(vertical = 2.dp),
        ) {
            SkinFront(
                skin = rememberSkinBitmap(account),
                model = account.skin?.model ?: SkinModel.WIDE,
                height = skinHeight,
            )
            Text(
                text = account.username,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Spacer(
                    Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (account.type.isOnline) OnlineDot else OfflineDot),
                )
                Text(
                    text = stringResource(account.type.labelRes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun NoAccount(onClick: () -> Unit, height: Dp) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(height),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        NeonButton(
            text = stringResource(R.string.home_add_account),
            onClick = onClick,
            icon = Icons.Filled.Add,
        )
    }
}

/** Строка «какая версия запустится». Нажатие открывает экран версий. */
@Composable
private fun VersionLine(version: InstalledVersion?, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = colors.surfaceContainerHigh.copy(alpha = 0.75f),
        border = BorderStroke(1.dp, colors.outlineVariant),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(
                imageVector = LauncherIcons.Cube,
                contentDescription = null,
                tint = colors.primary,
                modifier = Modifier.size(20.dp),
            )
            if (version == null) {
                Text(
                    text = stringResource(R.string.home_choose_version),
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.onSurface,
                    maxLines = 1,
                )
            } else {
                Column {
                    Text(
                        text = version.id,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = stringResource(version.type.labelRes),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.onSurfaceVariant,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}
