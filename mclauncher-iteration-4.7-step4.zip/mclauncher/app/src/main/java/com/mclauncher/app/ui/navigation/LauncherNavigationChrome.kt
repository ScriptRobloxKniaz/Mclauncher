package com.mclauncher.app.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mclauncher.app.R
import com.mclauncher.app.ui.theme.NeonColors

/** Нижняя панель для портретной ориентации. */
@Composable
fun LauncherBottomBar(
    current: Destination?,
    onSelect: (Destination) -> Unit,
    modifier: Modifier = Modifier,
) {
    NavigationBar(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
    ) {
        Destination.tabs.forEach { destination ->
            val label = stringResource(destination.labelRes)
            NavigationBarItem(
                selected = destination == current,
                onClick = { onSelect(destination) },
                icon = { Icon(destination.icon, contentDescription = null) },
                label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            )
        }
    }
}

/**
 * Боковая панель для альбомных экранов.
 *
 * [expanded] — на широком экране это боковое меню как на макете: логотип сверху и строки «иконка + подпись»;
 * на узком остаётся компактная колонка из одних иконок, чтобы не отнимать место у главной.
 */
@Composable
fun LauncherRail(
    current: Destination?,
    onSelect: (Destination) -> Unit,
    modifier: Modifier = Modifier,
    expanded: Boolean = false,
) {
    if (expanded) {
        LauncherSidebar(current = current, onSelect = onSelect, modifier = modifier)
    } else {
        CompactRail(current = current, onSelect = onSelect, modifier = modifier)
    }
}

/** Ширина бокового меню: «Аккаунты» и «Настройки» помещаются в одну строку и при крупном шрифте системы. */
private val SidebarWidth = 176.dp

private val ItemShape = RoundedCornerShape(10.dp)

@Composable
private fun LauncherSidebar(
    current: Destination?,
    onSelect: (Destination) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    Row(modifier = modifier.fillMaxHeight()) {
        // Заливка идёт раньше отступов под системные панели, поэтому доходит до самых краёв экрана.
        // Прокрутка — страховка для очень низких окон (разделённый экран, крупный шрифт): пункты не обрезаются.
        Column(
            modifier = Modifier
                .width(SidebarWidth)
                .fillMaxHeight()
                .background(colors.surface.copy(alpha = 0.92f))
                .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Vertical + WindowInsetsSides.Start))
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            SidebarBrand()
            Spacer(Modifier.height(10.dp))
            Destination.tabs.forEach { destination ->
                SidebarItem(
                    destination = destination,
                    selected = destination == current,
                    onClick = { onSelect(destination) },
                )
            }
        }
        // Тонкая линия-разделитель между меню и содержимым.
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(1.dp)
                .background(colors.outlineVariant),
        )
    }
}

/** Логотип и название приложения над пунктами меню. Логотип — буква на градиентной плитке. */
@Composable
private fun SidebarBrand() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 2.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(NeonColors.gradient),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = "M",
                color = NeonColors.OnGradient,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
            )
        }
        Text(
            text = stringResource(R.string.app_name).uppercase(),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            softWrap = false,
        )
    }
}

@Composable
private fun SidebarItem(
    destination: Destination,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val label = stringResource(destination.labelRes)
    val textColor = if (selected) colors.onSurface else colors.onSurfaceVariant
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(42.dp)
            .clip(ItemShape)
            .background(if (selected) colors.primaryContainer.copy(alpha = 0.45f) else Color.Transparent)
            .border(1.dp, if (selected) colors.primary.copy(alpha = 0.85f) else Color.Transparent, ItemShape)
            .selectable(selected = selected, onClick = onClick, role = Role.Tab)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(
            imageVector = destination.icon,
            contentDescription = null,
            tint = if (selected) colors.primary else textColor,
            modifier = Modifier.size(22.dp),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = textColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Компактная панель из одних иконок (подписи скрыты, чтобы поместиться по высоте). */
@Composable
private fun CompactRail(
    current: Destination?,
    onSelect: (Destination) -> Unit,
    modifier: Modifier = Modifier,
) {
    NavigationRail(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
        windowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Vertical + WindowInsetsSides.Start),
    ) {
        Spacer(Modifier.weight(1f))
        Destination.tabs.forEach { destination ->
            val label = stringResource(destination.labelRes)
            NavigationRailItem(
                selected = destination == current,
                onClick = { onSelect(destination) },
                icon = { Icon(destination.icon, contentDescription = label) },
                label = { Text(label, maxLines = 1) },
                alwaysShowLabel = false,
            )
        }
        Spacer(Modifier.weight(1f))
    }
}
