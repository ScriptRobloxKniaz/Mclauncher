package com.mclauncher.app.ui.root

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mclauncher.app.ui.common.CollectUiEvents
import com.mclauncher.app.ui.components.BackgroundContent
import com.mclauncher.app.ui.components.LauncherBackground
import com.mclauncher.app.ui.launch.LaunchResultDialog
import com.mclauncher.app.ui.navigation.Destination
import com.mclauncher.app.ui.navigation.LauncherBottomBar
import com.mclauncher.app.ui.navigation.LauncherNavHost
import com.mclauncher.app.ui.navigation.LauncherRail
import com.mclauncher.app.ui.navigation.navigateToTab
import com.mclauncher.app.ui.settings.VideoControls

/**
 * Корень интерфейса: фон на весь экран + адаптивная навигация
 * (нижняя панель в портрете, боковой rail в альбомной ориентации) + NavHost.
 */
@Composable
fun LauncherRoot(viewModel: LauncherViewModel = viewModel()) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val current = Destination.fromRoute(backStackEntry?.destination?.route)
    // Нижняя панель только на вкладках: полноэкранные Assistant и Versions открываются поверх неё.
    val showNavigation = current?.inBottomBar != false

    val selection by viewModel.selection.collectAsStateWithLifecycle()
    val backgroundContent by viewModel.backgroundContent.collectAsStateWithLifecycle()
    val activeAccount by viewModel.activeAccount.collectAsStateWithLifecycle()
    val library by viewModel.library.collectAsStateWithLifecycle()
    val launchPhase by viewModel.launchPhase.collectAsStateWithLifecycle()
    val launchOutcome by viewModel.launchOutcome.collectAsStateWithLifecycle()
    val videoSettings by viewModel.videoSettings.collectAsStateWithLifecycle()
    val backgroundVideo by viewModel.backgroundVideo.collectAsStateWithLifecycle()
    val videoVolume by viewModel.videoVolume.collectAsStateWithLifecycle()

    // Всё про видео-фон одним объектом: его читают главный экран («Видео» в окне фона) и «Настройки».
    val videoControls = remember(videoSettings, viewModel) {
        VideoControls(
            settings = videoSettings,
            onPick = viewModel::importVideoBackground,
            onEnabledChange = viewModel::setVideoEnabled,
            onMutedChange = viewModel::setVideoMuted,
            onVolumePreview = viewModel::previewVideoVolume,
            onVolumeCommit = viewModel::commitVideoVolume,
            onRemove = viewModel::removeVideoBackground,
        )
    }

    // Одноразовые сообщения об ошибках (понятный текст пользователю, а не стектрейс).
    CollectUiEvents(viewModel.events)

    // На главной фон почти не затемняем (но делаем читаемым), на остальных экранах — сильнее.
    val scrim by animateColorAsState(
        targetValue = if (current == Destination.Home) {
            Color.Black.copy(alpha = 0.30f)
        } else {
            MaterialTheme.colorScheme.background.copy(alpha = 0.86f)
        },
        animationSpec = tween(durationMillis = 400),
        label = "backgroundScrim",
    )

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val wide = maxWidth > maxHeight
        // Подписи у пунктов меню показываем, только если экрану хватает ширины: на узком главной нужнее место.
        val expandedRail = wide && maxWidth >= 720.dp

        // Видео играет поверх обычного фона; при ошибке воспроизведения ViewModel его выключит, и фон останется прежним.
        LauncherBackground(
            content = backgroundContent,
            scrim = scrim,
            video = backgroundVideo,
            videoVolume = videoVolume,
            onVideoError = viewModel::onVideoPlaybackError,
        )

        // Отступы под системные панели: сверху всегда; снизу/сбоку — только там,
        // где их ещё не обработала навигационная панель.
        val insetSides = when {
            !showNavigation -> WindowInsetsSides.Top + WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
            wide -> WindowInsetsSides.Top + WindowInsetsSides.End + WindowInsetsSides.Bottom
            else -> WindowInsetsSides.Top + WindowInsetsSides.Horizontal
        }
        val contentModifier = Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(insetSides))

        val navHost: @Composable (Modifier) -> Unit = { hostModifier ->
            LauncherNavHost(
                navController = navController,
                activeAccount = activeAccount,
                library = library,
                launchPhase = launchPhase,
                onPlay = viewModel::launchGame,
                onSelectVersion = viewModel::selectVersion,
                backgroundSelection = selection,
                customBackgroundPreview = (backgroundContent as? BackgroundContent.Image)?.bitmap,
                videoControls = videoControls,
                onSelectPreset = viewModel::selectPreset,
                onPickCustomBackground = viewModel::importCustomBackground,
                modifier = hostModifier,
            )
        }

        // Итог запуска показываем поверх любого экрана; состояние живёт в ViewModel и переживает поворот.
        launchOutcome?.let { outcome ->
            LaunchResultDialog(result = outcome, onDismiss = viewModel::dismissLaunchOutcome)
        }

        if (wide) {
            Row(modifier = Modifier.fillMaxSize()) {
                AnimatedVisibility(visible = showNavigation) {
                    LauncherRail(
                        current = current,
                        onSelect = navController::navigateToTab,
                        expanded = expandedRail,
                    )
                }
                navHost(Modifier.weight(1f).then(contentModifier))
            }
        } else {
            Column(modifier = Modifier.fillMaxSize()) {
                navHost(Modifier.weight(1f).then(contentModifier))
                AnimatedVisibility(visible = showNavigation) {
                    LauncherBottomBar(current = current, onSelect = navController::navigateToTab)
                }
            }
        }
    }
}
