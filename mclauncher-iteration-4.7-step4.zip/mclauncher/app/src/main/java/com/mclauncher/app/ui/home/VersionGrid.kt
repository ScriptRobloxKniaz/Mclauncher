package com.mclauncher.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.versions.InstalledVersion
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.components.NeonButton
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.theme.NeonColors
import com.mclauncher.app.ui.versions.labelRes
import com.mclauncher.app.ui.versions.releaseDate

/**
 * Сетка компактных карточек установленных версий. Нажатие на карточку выбирает версию, кнопка на ней запускает
 * именно её. В конце — карточка «Установить версию». Если версий ещё нет, вместо сетки — подсказка с кнопкой.
 */
@Composable
fun VersionGrid(
    installed: List<InstalledVersion>,
    selectedId: String?,
    loaded: Boolean,
    canLaunch: Boolean,
    onSelect: (String) -> Unit,
    onLaunch: (String) -> Unit,
    onOpenVersions: () -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 168.dp),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        when {
            // Пока список читается с диска, не показываем ни «пусто», ни кнопку установки: иначе она мигнёт.
            !loaded -> Unit

            installed.isEmpty() -> item(key = "empty", span = { GridItemSpan(maxLineSpan) }) {
                EmptyVersions(onOpenVersions = onOpenVersions)
            }

            else -> {
                items(installed, key = { it.id }) { version ->
                    VersionCard(
                        version = version,
                        selected = version.id == selectedId,
                        canLaunch = canLaunch,
                        onSelect = { onSelect(version.id) },
                        onLaunch = { onLaunch(version.id) },
                    )
                }
                item(key = "install") { InstallCard(onClick = onOpenVersions) }
            }
        }
    }
}

@Composable
private fun VersionCard(
    version: InstalledVersion,
    selected: Boolean,
    canLaunch: Boolean,
    onSelect: () -> Unit,
    onLaunch: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val date = releaseDate(version.releaseTime)
    NeonCard(
        selected = selected,
        onClick = onSelect,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(NeonColors.gradient),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = LauncherIcons.Cube,
                        contentDescription = null,
                        tint = NeonColors.OnGradient,
                        modifier = Modifier.size(20.dp),
                    )
                }
                Spacer(Modifier.size(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = version.id,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = listOfNotNull(stringResource(version.type.labelRes), date).joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (selected) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = stringResource(R.string.versions_selected),
                        tint = colors.primary,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
            NeonButton(
                text = stringResource(R.string.play),
                onClick = onLaunch,
                modifier = Modifier.fillMaxWidth(),
                icon = Icons.Filled.PlayArrow,
                enabled = canLaunch,
                height = 36.dp,
            )
        }
    }
}

@Composable
private fun InstallCard(onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    NeonCard(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 98.dp)
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = null,
                tint = colors.primary,
                modifier = Modifier.size(28.dp),
            )
            Text(
                text = stringResource(R.string.home_install_version),
                style = MaterialTheme.typography.labelLarge,
                color = colors.onSurface,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun EmptyVersions(onOpenVersions: () -> Unit) {
    NeonCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(
                imageVector = LauncherIcons.Cube,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp),
            )
            Text(
                text = stringResource(R.string.home_no_versions_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
            )
            Text(
                text = stringResource(R.string.home_no_versions_message),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            NeonButton(
                text = stringResource(R.string.home_install_version),
                onClick = onOpenVersions,
                icon = Icons.Filled.Add,
            )
        }
    }
}
