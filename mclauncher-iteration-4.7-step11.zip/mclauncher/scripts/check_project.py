#!/usr/bin/env python3
"""Быстрая проверка проекта без Android SDK: то, что компилятор нашёл бы не сразу, а в CI — только через несколько минут.

Что проверяется:
  1. Строки: набор имён в values/strings.xml (en) и values-ru/strings.xml совпадает, нет дубликатов,
     у одной строки в обоих языках одинаковые подстановки (%1$s, %2$d).
  2. Каждая `R.string.имя` в коде и каждая `@string/имя` в XML существует.
  3. Каждый `import com.mclauncher...` указывает на объявленный в проекте класс, функцию или свойство.
  4. Во всех ленивых списках (LazyColumn, LazyVerticalGrid, ...) у `item`/`items` задан `key`.
  5. Скобки в каждом .kt-файле сбалансированы (с учётом строк и комментариев).

Это не замена компилятору: типы, перегрузки и сигнатуры Compose он не проверяет. Запуск: `python3 scripts/check_project.py`.
Код возврата 0 — всё в порядке, 1 — есть замечания.
"""
import re
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
errors: list[str] = []


def fail(message: str) -> None:
    errors.append(message)


def kotlin_files() -> list[Path]:
    return sorted(
        p for module in ("app", "engine") for p in (ROOT / module / "src" / "main").rglob("*.kt")
    )


# ---------------------------------------------------------------- 1. строки

def load_strings(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        fail(f"нет файла {path.relative_to(ROOT)}")
        return result
    for node in ET.parse(path).getroot().findall("string"):
        name = node.get("name")
        if name in result:
            fail(f"{path.relative_to(ROOT)}: строка {name} объявлена дважды")
        result[name] = "".join(node.itertext())
    return result


def placeholders(text: str) -> list[str]:
    return sorted(re.findall(r"%\d+\$[sd]|%[sd]", text))


res = ROOT / "app" / "src" / "main" / "res"
en = load_strings(res / "values" / "strings.xml")
ru = load_strings(res / "values-ru" / "strings.xml")
for name in sorted(set(en) - set(ru)):
    fail(f"строка {name} есть в en, но нет в ru")
for name in sorted(set(ru) - set(en)):
    fail(f"строка {name} есть в ru, но нет в en")
for name in sorted(set(en) & set(ru)):
    if placeholders(en[name]) != placeholders(ru[name]):
        fail(f"строка {name}: подстановки в en {placeholders(en[name])} и в ru {placeholders(ru[name])} различаются")
    if not ru[name].strip() or not en[name].strip():
        fail(f"строка {name}: пустой текст")

# ---------------------------------------------------------------- 2. ссылки на строки

used: set[str] = set()
for path in kotlin_files():
    for match in re.finditer(r"\bR\.string\.(\w+)", path.read_text(encoding="utf-8")):
        used.add(match.group(1))
        if match.group(1) not in en:
            fail(f"{path.relative_to(ROOT)}: R.string.{match.group(1)} не объявлена в strings.xml")
for path in list((ROOT / "app" / "src" / "main").rglob("*.xml")):
    if "values" in path.parts[-2]:
        continue
    for match in re.finditer(r"@string/(\w+)", path.read_text(encoding="utf-8")):
        used.add(match.group(1))
        if match.group(1) not in en:
            fail(f"{path.relative_to(ROOT)}: @string/{match.group(1)} не объявлена")

# ---------------------------------------------------------------- 3. импорты проекта

DECL = re.compile(
    r"^[ \t]*(?:@\w+(?:\([^)]*\))?[ \t]*)*"
    r"(?:(?:public|internal|private|protected|inline|data|sealed|enum|abstract|open|value|annotation|const|"
    r"lateinit|suspend|operator|infix|tailrec|external|fun)[ \t]+)*"
    r"(class|object|interface|fun|val|var|typealias)[ \t]+(?:<[^>]+>[ \t]+)?([\w.<>?,* ]*?)(\w+)[ \t]*(?=[(:=<{ \n]|$)",
    re.M,
)
declared: dict[str, set[str]] = defaultdict(set)
for path in kotlin_files():
    text = path.read_text(encoding="utf-8")
    package = re.search(r"^package ([\w.]+)", text, re.M)
    if not package:
        continue
    for match in DECL.finditer(text):
        declared[package.group(1)].add(match.group(3))
    # Объявления внутри enum/sealed/object тоже можно импортировать (`import ...Destination.Home`), но такие импорты
    # начинаются с имени вложенного класса: проверяем только первый сегмент после пакета.

for path in kotlin_files():
    text = path.read_text(encoding="utf-8")
    for match in re.finditer(r"^import (com\.mclauncher\.[\w.]+?)(?: as \w+)?$", text, re.M):
        full = match.group(1)
        if full == "com.mclauncher.app.R":  # генерируется Android Gradle Plugin, в исходниках его нет
            continue
        parts = full.split(".")
        # Ищем самый длинный префикс-пакет, в котором объявлено следующее имя.
        found = any(
            ".".join(parts[:i]) in declared and parts[i] in declared[".".join(parts[:i])]
            for i in range(2, len(parts))
        )
        if not found:
            fail(f"{path.relative_to(ROOT)}: import {full} не найден в проекте")

# ---------------------------------------------------------------- 4. ключи в ленивых списках

LAZY_CALL = re.compile(r"\b(items|itemsIndexed|item)\(")


def call_arguments(text: str, open_paren: int) -> str:
    depth = 0
    for i in range(open_paren, len(text)):
        if text[i] == "(":
            depth += 1
        elif text[i] == ")":
            depth -= 1
            if depth == 0:
                return text[open_paren + 1 : i]
    return text[open_paren + 1 :]


for path in kotlin_files():
    text = path.read_text(encoding="utf-8")
    if "androidx.compose.foundation.lazy" not in text:
        continue
    for match in LAZY_CALL.finditer(text):
        args = call_arguments(text, match.end() - 1)
        line = text.count("\n", 0, match.start()) + 1
        if not re.search(r"\bkey\s*=", args):
            fail(f"{path.relative_to(ROOT)}:{line}: {match.group(1)}(...) в ленивом списке без key")

# ---------------------------------------------------------------- 5. скобки


def strip_noise(text: str) -> str:
    """Убирает строки, символы и комментарии, чтобы скобки внутри них не мешали подсчёту."""
    out = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if text.startswith("//", i):
            while i < n and text[i] != "\n":
                i += 1
        elif text.startswith("/*", i):
            depth = 1
            i += 2
            while i < n and depth:
                if text.startswith("/*", i):
                    depth += 1
                    i += 2
                elif text.startswith("*/", i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
        elif text.startswith('"""', i):
            i += 3
            while i < n and not text.startswith('"""', i):
                i += 1
            i += 3
        elif c == '"':
            i += 1
            while i < n and text[i] != '"':
                i += 2 if text[i] == "\\" else 1
            i += 1
        elif c == "'":
            i += 1
            while i < n and text[i] != "'":
                i += 2 if text[i] == "\\" else 1
            i += 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


for path in kotlin_files():
    clean = strip_noise(path.read_text(encoding="utf-8"))
    for open_c, close_c in ("()", "[]", "{}"):
        if clean.count(open_c) != clean.count(close_c):
            fail(f"{path.relative_to(ROOT)}: скобки {open_c}{close_c} не сбалансированы ({clean.count(open_c)} / {clean.count(close_c)})")

# ---------------------------------------------------------------- 6. повторные объявления верхнего уровня

# Компилятор Kotlin ругается на два одноимённых `val`/`class`/`object` на верхнем уровне одного файла («Conflicting
# declarations») — так однажды сломалась сборка из-за второй `private const val MEGABYTE`. Функции не проверяются:
# перегрузки законны. Между файлами сравниваются только непубличные... точнее, только объявления без `private`.
TOP_DECL = re.compile(
    r"^(?P<mods>(?:(?:private|internal|public|const|data|sealed|enum|annotation|value|fun|open|abstract|inline)\s+)*)"
    r"(?P<kind>val|var|class|object|interface|typealias)\s+(?:<[^>]+>\s+)?(?P<name>[\w.]+)",
    re.M,
)
PACKAGE = re.compile(r"^package\s+([\w.]+)", re.M)
public_decls: dict[tuple[str, str, str], Path] = {}
for path in kotlin_files():
    clean = strip_noise(path.read_text(encoding="utf-8"))
    package = (PACKAGE.search(clean) or [None, ""])[1]
    seen_in_file: dict[tuple[str, str], int] = {}
    for m in TOP_DECL.finditer(clean):
        kind = "property" if m["kind"] in ("val", "var") else "type"
        key = (kind, m["name"])
        seen_in_file[key] = seen_in_file.get(key, 0) + 1
        if seen_in_file[key] == 2:
            fail(f"{path.relative_to(ROOT)}: «{m['name']}» объявлено на верхнем уровне больше одного раза (Conflicting declarations)")
        if "private" not in m["mods"].split():
            other = public_decls.setdefault((package, kind, m["name"]), path)
            if other != path:
                fail(f"{path.relative_to(ROOT)}: «{m['name']}» уже объявлено в {other.relative_to(ROOT)} (пакет {package})")

# ---------------------------------------------------------------- итог

unused = sorted(set(en) - used)
if errors:
    print("Замечания:")
    for message in errors:
        print("  -", message)
    sys.exit(1)
print(f"OK: строк {len(en)} (en) / {len(ru)} (ru), Kotlin-файлов {len(kotlin_files())}")
if unused:
    print(f"Справка: строки, на которые нет ссылок в коде ({len(unused)}): {', '.join(unused)}")
