package com.mclauncher.engine.launch

import java.io.Serializable

/*
 * Рендерер игры: какая библиотека переводит вызовы OpenGL игры в то, что умеет телефон, и какие переменные окружения
 * ей нужны. Значения портированы из ZalithLauncher 2 (`game/renderer/renderers/GL4ESRenderer.kt` и
 * `setRendererEnv` в `game/launch/GameLauncher.kt`), GPL-3.0, Copyright (C) 2025-2026 MovTery and contributors —
 * см. THIRD_PARTY_NOTICES.md.
 */

/**
 * @property id значение `POJAV_RENDERER` и `SDL_OPENGL_LIBRARY`; по нему нативный код (`egl_bridge.c`) выбирает путь работы;
 * @property library имя файла библиотеки в папке нативных библиотек приложения; передаётся игре как
 *   `-Dorg.lwjgl.opengl.libname` и подгружается через `dlopen` до старта JVM;
 * @property env переменные окружения именно этого рендерера (общие для немесовых рендереров добавляет [environment]);
 * @property mesaBased библиотека собрана на основе Mesa: ей не нужны переменные Zink.
 */
data class RendererProfile(
    val id: String,
    val displayName: String,
    val library: String,
    val env: Map<String, String> = emptyMap(),
    val mesaBased: Boolean = false,
) : Serializable {

    /**
     * Полный набор переменных окружения рендерера, как у апстрима. [cacheDir] — папка для кэша шейдеров Mesa.
     */
    fun environment(cacheDir: String): Map<String, String> {
        val result = LinkedHashMap<String, String>()
        result["SDL_OPENGL_LIBRARY"] = id
        if (id.startsWith("opengles2")) {
            result["LIBGL_ES"] = "2"
            result["LIBGL_MIPMAP"] = "3"
            result["LIBGL_NOERROR"] = "1"
            result["LIBGL_NOINTOVLHACK"] = "1"
            result["LIBGL_NORMALIZE"] = "1"
        }
        result.putAll(env)
        result["POJAV_RENDERER"] = id

        if (!mesaBased) {
            // Апстрим выставляет это всем рендерерам не на Mesa — и GL4ES тоже; на GL4ES эти переменные ничего не меняют.
            result["MESA_LOADER_DRIVER_OVERRIDE"] = "zink"
            result["MESA_GLSL_CACHE_DIR"] = cacheDir
            result["MESA_GL_VERSION_OVERRIDE"] = "4.6"
            result["MESA_GLSL_VERSION_OVERRIDE"] = "460"
            result["force_glsl_extensions_warn"] = "true"
            result["allow_higher_compat_version"] = "true"
            result["allow_glsl_extension_directive_midshader"] = "true"
            result["LIB_MESA_NAME"] = library
        }
        return result
    }

    companion object {
        /**
         * GL4ES: OpenGL ES 2 → OpenGL 2.1. Самый простой и совместимый рендерер; подходит для версий примерно до 1.21.4
         * (так у апстрима). Единственный, подключённый на этапе 4.7c-1.
         */
        val GL4ES = RendererProfile(
            id = "opengles2",
            displayName = "GL4ES",
            library = "libgl4es_114.so",
        )
    }
}
