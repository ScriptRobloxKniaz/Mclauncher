package com.mclauncher.engine.launch

import com.mclauncher.engine.CommandBuildException
import com.mclauncher.engine.EngineEnvironment
import com.mclauncher.engine.EngineLaunchSpec
import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.JavaRuntimes
import com.mclauncher.engine.LaunchCommand
import java.io.File

/*
 * Что нужно сделать в процессе игры перед стартом JVM: пути поиска библиотек, переменные окружения, порядок `dlopen`.
 * Правила портированы из ZalithLauncher 2 (`game/launch/Launcher.kt`: getRuntimeLibraryPath, getLibraryPath, setJavaEnv,
 * dlopenJavaRuntime, dlopenEngine; `GameLauncher.dlopenEngine`), GPL-3.0, Copyright (C) 2025-2026 MovTery and
 * contributors — см. THIRD_PARTY_NOTICES.md. Отличия от апстрима перечислены в docs/ENGINE.md (раздел 11).
 */

/**
 * Собирает [NativeLaunchPlan] из готовой [LaunchCommand]. Чистая логика: читаются только списки файлов рантайма
 * (какая папка `lib/<arch>` и `server` или `client`), больше ничего.
 */
class NativeLaunchPlanner(
    private val layout: EngineLayout,
    private val env: EngineEnvironment,
) {

    /**
     * @param currentPath значение `PATH` процесса; `bin` рантайма Java добавляется перед ним
     * @param logFile журнал игры
     * @throws CommandBuildException если версии Java нет среди рантаймов ядра
     */
    fun plan(
        spec: EngineLaunchSpec,
        command: LaunchCommand,
        renderer: RendererProfile,
        currentPath: String?,
        logFile: File,
    ): NativeLaunchPlan {
        val component = JavaRuntimes.componentFor(spec.javaMajor)
            ?: throw CommandBuildException("Java ${spec.javaMajor} is newer than the runtimes shipped with the core")
        val runtimeRoot = layout.runtimeDir(component)
        val javaHome = layout.javaHome(component)
        val javaLib = javaLibDir(javaHome)
        val jvmLib = jvmLibDir(javaHome, javaLib)
        val natives = command.nativesDir.path
        val systemLibs = systemLibraryDirs()

        // ZLBridge.setLdLibraryPath — где JVM ищет свои и системные библиотеки.
        val jvmPaths = ArrayList<String>()
        jvmPaths += "${javaHome.path}$javaLib/jli"
        jvmPaths += "${javaHome.path}$javaLib$jvmLib"
        jvmPaths += systemLibs
        jvmPaths += natives
        jvmPaths += layout.nativeLibraryDir.path

        // LD_LIBRARY_PATH процесса (Launcher.getLibraryPath): нативы LWJGL первыми, чтобы устаревшие не перекрыли их.
        val processLibraryPath = (listOf(natives) + systemLibs + layout.nativeLibraryDir.path).joinToString(":")

        val environment = LinkedHashMap<String, String>()
        environment["POJAV_NATIVEDIR"] = layout.nativeLibraryDir.path
        environment["JAVA_HOME"] = javaHome.path
        environment["HOME"] = env.userHome.path
        environment["TMPDIR"] = env.cacheDir.path
        environment["LD_LIBRARY_PATH"] = processLibraryPath
        environment["PATH"] = listOfNotNull("${runtimeRoot.path}/bin", currentPath?.takeIf { it.isNotEmpty() }).joinToString(":")
        environment["AWTSTUB_WIDTH"] = env.screenWidth.toString()
        environment["AWTSTUB_HEIGHT"] = env.screenHeight.toString()
        environment["MOD_ANDROID_RUNTIME"] = ""
        environment["ALSOFT_DRIVERS"] = "opensl"
        environment.putAll(renderer.environment(env.cacheDir.path))

        // dlopen: сначала сама JVM и её библиотеки, потом всё остальное из рантайма, звук и рендерер.
        val dlopen = LinkedHashSet<String>()
        val javaLibPath = "${javaHome.path}$javaLib"
        val jliDir = if (File("$javaLibPath/jli/libjli.so").exists()) "$javaLibPath/jli" else javaLibPath
        dlopen += "$jliDir/libjli.so"
        dlopen += "$javaLibPath$jvmLib/libjvm.so"
        for (name in CORE_JAVA_LIBRARIES) dlopen += "$javaLibPath/$name"
        dlopen += locateLibraries(runtimeRoot)
        dlopen += File(layout.nativeLibraryDir, "libopenal.so").path

        // Игре — какую библиотеку OpenGL брать (Launcher: «-Dorg.lwjgl.opengl.libname»).
        val argv = ArrayList<String>(command.args.size + 2)
        argv += command.javaExecutable.path
        argv += "-Dorg.lwjgl.opengl.libname=${renderer.library}"
        argv += command.args

        return NativeLaunchPlan(
            argv = argv,
            workingDir = env.gameDir.path,
            jvmLibraryPath = jvmPaths.joinToString(":"),
            environment = environment,
            dlopenLibraries = ArrayList(dlopen),
            rendererLibrary = renderer.library,
            rendererLibraryPath = File(layout.nativeLibraryDir, renderer.library).path,
            rendererName = renderer.displayName,
            windowWidth = env.screenWidth,
            windowHeight = env.screenHeight,
            useInputStackQueue = spec.newArgumentFormat,
            logFile = logFile.path,
            versionId = spec.versionId,
        )
    }

    /** `/lib/aarch64` у рантайма для arm64 и `/lib`, если такой папки нет (`Launcher.getJavaLibDir`). */
    private fun javaLibDir(javaHome: File): String {
        val arch = JAVA_ARCH_DIRS[layout.abi]
        return if (arch != null && File(javaHome, "lib/$arch").isDirectory) "/lib/$arch" else "/lib"
    }

    /** `/server`, если у рантайма есть серверная JVM, иначе `/client` (`Launcher.getJvmLibDir`). */
    private fun jvmLibDir(javaHome: File, javaLib: String): String =
        if (File("${javaHome.path}$javaLib/server/libjvm.so").exists()) "/server" else "/client"

    private fun systemLibraryDirs(): List<String> {
        val dir = if (layout.abi == "arm64-v8a" || layout.abi == "x86_64") "lib64" else "lib"
        return listOf("/system/$dir", "/vendor/$dir", "/vendor/$dir/hw", "/system_ext/$dir")
    }

    /** Все `.so` внутри рантайма (`Launcher.locateLibs`). Порядок стабильный: по пути. */
    private fun locateLibraries(root: File): List<String> {
        val found = ArrayList<String>()
        fun walk(dir: File) {
            val children = dir.listFiles() ?: return
            for (child in children) {
                when {
                    child.isFile && child.name.endsWith(".so") -> found += child.path
                    child.isDirectory -> walk(child)
                }
            }
        }
        walk(root)
        found.sort()
        return found
    }

    private companion object {
        /** Какая папка `lib/<…>` у рантайма Java под каждый ABI Android. Поставляется только arm64. */
        val JAVA_ARCH_DIRS = mapOf(
            "arm64-v8a" to "aarch64",
            "armeabi-v7a" to "arm",
            "x86_64" to "amd64",
            "x86" to "i386",
        )

        /** Порядок как в `Launcher.dlopenJavaRuntime`: сначала то, от чего зависят остальные. */
        val CORE_JAVA_LIBRARIES = listOf(
            "libfreetype.so", "libverify.so", "libjava.so", "libnet.so", "libnio.so",
            "libawt.so", "libawt_headless.so", "libfontmanager.so",
        )
    }
}
