package com.mclauncher.engine.launch

import com.mclauncher.engine.CommandBuildException
import com.mclauncher.engine.EngineEnvironment
import com.mclauncher.engine.EngineLaunchSpec
import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.LaunchCommand
import com.mclauncher.engine.LaunchCommandBuilder
import com.mclauncher.engine.LwjglRequirement
import com.mclauncher.engine.LwjglVersion
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class NativeLaunchPlannerTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val layout by lazy {
        EngineLayout(
            componentsDir = File(tmp.root, "components"),
            runtimesDir = File(tmp.root, "runtimes"),
            nativeLibraryDir = File(tmp.root, "lib"),
            abi = "arm64-v8a",
        )
    }
    private val env by lazy {
        EngineEnvironment(
            gameDir = File(tmp.root, "home/.minecraft"),
            userHome = File(tmp.root, "home"),
            cacheDir = File(tmp.root, "cache"),
            timezone = "Asia/Baku",
            androidRelease = "15",
            screenWidth = 2400,
            screenHeight = 1080,
            cpuCores = 8,
        )
    }
    private val planner by lazy { NativeLaunchPlanner(layout, env) }
    private val log by lazy { File(tmp.root, "home/.minecraft/logs/latest.log") }

    private fun touch(path: String): File = File(tmp.root, path).apply { parentFile.mkdirs(); writeText("x") }

    /** Рантайм Java 17 в раскладке поставляемого ядра: плоский, `lib/aarch64/{server,jli}`. */
    private fun runtime17(withJli: Boolean = true, withServer: Boolean = true) {
        touch("runtimes/jre-17/bin/java")
        touch("runtimes/jre-17/lib/aarch64/libjava.so")
        touch("runtimes/jre-17/lib/aarch64/libnet.so")
        touch("runtimes/jre-17/lib/aarch64/libfreetype.so")
        if (withServer) touch("runtimes/jre-17/lib/aarch64/server/libjvm.so") else touch("runtimes/jre-17/lib/aarch64/client/libjvm.so")
        if (withJli) touch("runtimes/jre-17/lib/aarch64/jli/libjli.so")
        touch("runtimes/jre-17/lib/aarch64/libextra.so")
        touch("runtimes/jre-17/lib/security/readme.txt")
    }

    private fun spec(
        javaMajor: Int = 17,
        jvmArgs: List<String> = listOf("-cp", "\${classpath}"),
        newArgumentFormat: Boolean = true,
    ) = EngineLaunchSpec(
        versionId = "1.20.1",
        javaMajor = javaMajor,
        mainClass = "net.minecraft.client.main.Main",
        clientJar = touch("game/1.20.1.jar").path,
        libraryJars = emptyList(),
        lwjgl = LwjglRequirement.DEFAULT,
        jvmArgs = jvmArgs,
        gameArgs = listOf("--username", "Steve", "--accessToken", "TOKEN"),
        variables = mapOf("launcher_name" to "MCLauncher"),
        ramMb = 2048,
        newArgumentFormat = newArgumentFormat,
    )

    private fun command(spec: EngineLaunchSpec): LaunchCommand = LaunchCommandBuilder(layout, env).build(spec)

    private fun plan(spec: EngineLaunchSpec = spec(), path: String? = "/system/bin"): NativeLaunchPlan =
        planner.plan(spec, command(spec), RendererProfile.GL4ES, path, log)

    // ---------------------------------------------------------------- команда

    @Test
    fun argvStartsWithTheJavaExecutableThenTheRendererLibrary() {
        runtime17()

        val plan = plan()

        assertEquals(File(tmp.root, "runtimes/jre-17/bin/java").path, plan.argv[0])
        assertEquals("-Dorg.lwjgl.opengl.libname=libgl4es_114.so", plan.argv[1])
        assertTrue("-Xmx2048M" in plan.argv)
        assertTrue("mio.Wrapper" in plan.argv)
    }

    @Test
    fun theGameArgumentsKeepTheirOrderAtTheEnd() {
        runtime17()

        val argv = plan().argv

        assertEquals(listOf("mio.Wrapper", "net.minecraft.client.main.Main", "--username", "Steve", "--accessToken", "TOKEN"), argv.takeLast(6))
    }

    @Test
    fun theAccessTokenIsRedactedInThePlanLog() {
        runtime17()

        assertFalse("TOKEN" in plan().redactedArgv())
    }

    // ---------------------------------------------------------------- пути библиотек JVM

    @Test
    fun jvmLibraryPathHasJliJvmSystemNativesAndAppLibsInOrder() {
        runtime17()
        val nativesDir = layout.lwjglNativesDir(LwjglVersion.V3_3_3).path
        val home = File(tmp.root, "runtimes/jre-17").path

        val paths = plan().jvmLibraryPath.split(":")

        assertEquals(
            listOf(
                "$home/lib/aarch64/jli",
                "$home/lib/aarch64/server",
                "/system/lib64", "/vendor/lib64", "/vendor/lib64/hw", "/system_ext/lib64",
                nativesDir,
                layout.nativeLibraryDir.path,
            ),
            paths,
        )
    }

    @Test
    fun aRuntimeWithoutAServerJvmFallsBackToClient() {
        runtime17(withServer = false)
        val home = File(tmp.root, "runtimes/jre-17").path

        val plan = plan()

        assertTrue("$home/lib/aarch64/client" in plan.jvmLibraryPath.split(":"))
        assertTrue(plan.dlopenLibraries.contains("$home/lib/aarch64/client/libjvm.so"))
    }

    @Test
    fun theProcessLibraryPathPutsTheLwjglNativesFirst() {
        runtime17()
        val nativesDir = layout.lwjglNativesDir(LwjglVersion.V3_3_3).path

        val ld = plan().environment.getValue("LD_LIBRARY_PATH").split(":")

        assertEquals(nativesDir, ld.first())
        assertEquals(layout.nativeLibraryDir.path, ld.last())
        assertTrue("/system/lib64" in ld)
    }

    // ---------------------------------------------------------------- окружение

    @Test
    fun environmentHasThePojavVariables() {
        runtime17()
        val home = File(tmp.root, "runtimes/jre-17").path

        val e = plan().environment

        assertEquals(layout.nativeLibraryDir.path, e["POJAV_NATIVEDIR"])
        assertEquals(home, e["JAVA_HOME"])
        assertEquals(env.userHome.path, e["HOME"])
        assertEquals(env.cacheDir.path, e["TMPDIR"])
        assertEquals("$home/bin:/system/bin", e["PATH"])
        assertEquals("2400", e["AWTSTUB_WIDTH"])
        assertEquals("1080", e["AWTSTUB_HEIGHT"])
        assertEquals("opensl", e["ALSOFT_DRIVERS"])
        assertEquals("opengles2", e["POJAV_RENDERER"])
        assertEquals(env.cacheDir.path, e["MESA_GLSL_CACHE_DIR"])
    }

    @Test
    fun pathWithoutACurrentValueIsJustTheRuntimeBin() {
        runtime17()

        assertEquals(File(tmp.root, "runtimes/jre-17/bin").path, plan(path = null).environment["PATH"])
        assertEquals(File(tmp.root, "runtimes/jre-17/bin").path, plan(path = "").environment["PATH"])
    }

    @Test
    fun theProcessEnvironmentDoesNotCarryTheDalvikPointers() {
        // Их знает только процесс игры (адрес JavaVM и Application): план собирается в процессе лаунчера.
        runtime17()

        val e = plan().environment

        assertFalse("DALVIK_JAVAVM" in e)
        assertFalse("DALVIK_APPLICATION" in e)
    }

    // ---------------------------------------------------------------- dlopen

    @Test
    fun dlopenOrderIsJliJvmCoreLibrariesRuntimeLibrariesThenOpenAl() {
        runtime17()
        val java = File(tmp.root, "runtimes/jre-17").path

        val libs = plan().dlopenLibraries

        assertEquals("$java/lib/aarch64/jli/libjli.so", libs[0])
        assertEquals("$java/lib/aarch64/server/libjvm.so", libs[1])
        // Библиотеки из «ядра» Java — в порядке апстрима, а найденные при обходе рантайма идут после них без повторов.
        assertEquals("$java/lib/aarch64/libfreetype.so", libs[2])
        assertTrue(libs.indexOf("$java/lib/aarch64/libjava.so") < libs.indexOf("$java/lib/aarch64/libnet.so"))
        assertTrue(libs.indexOf("$java/lib/aarch64/libnet.so") < libs.indexOf("$java/lib/aarch64/libextra.so"))
        assertEquals(libs.size, libs.toSet().size)
        assertEquals(File(layout.nativeLibraryDir, "libopenal.so").path, libs.last())
    }

    @Test
    fun theRendererLibraryIsNotInTheDlopenListButHasItsOwnFields() {
        runtime17()

        val plan = plan()

        assertEquals("libgl4es_114.so", plan.rendererLibrary)
        assertEquals(File(layout.nativeLibraryDir, "libgl4es_114.so").path, plan.rendererLibraryPath)
        assertEquals("GL4ES", plan.rendererName)
        assertFalse(plan.dlopenLibraries.any { it.endsWith("libgl4es_114.so") })
    }

    @Test
    fun theWalkOnlyCollectsSharedLibraries() {
        runtime17()

        assertFalse(plan().dlopenLibraries.any { it.endsWith("readme.txt") })
    }

    @Test
    fun aMissingJliFolderMakesJliFallBackToTheLibDirectory() {
        runtime17(withJli = false)
        val java = File(tmp.root, "runtimes/jre-17").path

        assertEquals("$java/lib/aarch64/libjli.so", plan().dlopenLibraries.first())
    }

    // ---------------------------------------------------------------- прочее

    @Test
    fun windowLogAndVersionComeFromTheEnvironmentAndSpec() {
        runtime17()

        val plan = plan()

        assertEquals(2400, plan.windowWidth)
        assertEquals(1080, plan.windowHeight)
        assertEquals(env.gameDir.path, plan.workingDir)
        assertEquals(log.path, plan.logFile)
        assertEquals("1.20.1", plan.versionId)
    }

    @Test
    fun theInputQueueIsOnlyUsedByTheNewArgumentFormat() {
        runtime17()

        assertTrue(plan(spec(newArgumentFormat = true)).useInputStackQueue)
        assertFalse(plan(spec(newArgumentFormat = false)).useInputStackQueue)
        // Флаги JVM у старой версии не пусты (приложение добавляет свои) — режим от них не зависит.
        assertFalse(plan(spec(jvmArgs = listOf("-Dminecraft.client.jar=x"), newArgumentFormat = false)).useInputStackQueue)
    }

    @Test
    fun aJavaNewerThanTheShippedRuntimesIsRefused() {
        runtime17()
        val good = spec()
        val tooNew = spec(javaMajor = 99)

        try {
            planner.plan(tooNew, command(good), RendererProfile.GL4ES, null, log)
            fail("expected CommandBuildException")
        } catch (e: CommandBuildException) {
            assertTrue(e.message!!.contains("99"))
        }
    }
}
