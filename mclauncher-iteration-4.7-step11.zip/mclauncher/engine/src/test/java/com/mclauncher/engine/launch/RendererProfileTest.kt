package com.mclauncher.engine.launch

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RendererProfileTest {

    private val env = RendererProfile.GL4ES.environment("/cache")

    @Test
    fun gl4esIdentityMatchesUpstream() {
        assertEquals("opengles2", RendererProfile.GL4ES.id)
        assertEquals("libgl4es_114.so", RendererProfile.GL4ES.library)
        assertFalse(RendererProfile.GL4ES.mesaBased)
    }

    @Test
    fun gl4esSetsTheEsEnvironment() {
        assertEquals("opengles2", env["POJAV_RENDERER"])
        assertEquals("opengles2", env["SDL_OPENGL_LIBRARY"])
        assertEquals("2", env["LIBGL_ES"])
        assertEquals("3", env["LIBGL_MIPMAP"])
        assertEquals("1", env["LIBGL_NOERROR"])
        assertEquals("1", env["LIBGL_NOINTOVLHACK"])
        assertEquals("1", env["LIBGL_NORMALIZE"])
    }

    @Test
    fun nonMesaRenderersGetTheSharedMesaVariables() {
        // Так делает апстрим для всех рендереров не на Mesa; значения должны совпадать буквально.
        assertEquals("zink", env["MESA_LOADER_DRIVER_OVERRIDE"])
        assertEquals("/cache", env["MESA_GLSL_CACHE_DIR"])
        assertEquals("4.6", env["MESA_GL_VERSION_OVERRIDE"])
        assertEquals("460", env["MESA_GLSL_VERSION_OVERRIDE"])
        assertEquals("true", env["force_glsl_extensions_warn"])
        assertEquals("true", env["allow_higher_compat_version"])
        assertEquals("true", env["allow_glsl_extension_directive_midshader"])
        assertEquals("libgl4es_114.so", env["LIB_MESA_NAME"])
    }

    @Test
    fun mesaBasedRenderersDoNotGetTheZinkVariables() {
        val mesa = RendererProfile(id = "vulkan_zink", displayName = "Zink", library = "libOSMesa.so", mesaBased = true)

        val result = mesa.environment("/cache")

        assertNull(result["MESA_LOADER_DRIVER_OVERRIDE"])
        assertNull(result["LIB_MESA_NAME"])
        assertEquals("vulkan_zink", result["POJAV_RENDERER"])
        assertFalse("LIBGL_ES" in result)
    }

    @Test
    fun rendererSpecificVariablesComeBeforeThePojavRendererName() {
        val custom = RendererProfile(id = "x", displayName = "X", library = "libx.so", env = mapOf("A" to "1", "POJAV_RENDERER" to "ignored"))

        val result = custom.environment("/c")

        assertEquals("1", result["A"])
        assertEquals("x", result["POJAV_RENDERER"])
        assertTrue(result.keys.indexOf("A") < result.keys.indexOf("POJAV_RENDERER"))
    }
}
