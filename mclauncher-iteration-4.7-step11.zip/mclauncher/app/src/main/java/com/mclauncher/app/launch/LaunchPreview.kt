package com.mclauncher.app.launch

import com.mclauncher.engine.CoreStatus
import com.mclauncher.engine.EngineLaunchSpec
import com.mclauncher.engine.LaunchCommand
import java.io.File

/**
 * Текстовый отчёт о запуске: какая команда будет выполнена, чего не хватает ядру, какие файлы classpath
 * отсутствуют. Его можно открыть из папки игры и приложить к сообщению об ошибке. Токен доступа скрыт.
 */
object LaunchPreview {

    fun render(spec: EngineLaunchSpec, command: LaunchCommand, status: CoreStatus): String = buildString {
        appendLine("MCLauncher launch report")
        appendLine(if (status.isReady) "Status:    the core is ready; the game is being started" else "Status:    the core is NOT ready; the game is NOT started")
        appendLine()
        appendLine("Version:   ${spec.versionId}")
        appendLine("Main class: ${spec.mainClass}")
        appendLine("Java:      ${spec.javaMajor} (runtime: ${command.javaHome.path})")
        appendLine("LWJGL:     ${spec.lwjgl.lwjgl.dirName}${if (spec.lwjgl.legacyLwjgl2) " (+ LWJGL 2 compatibility layer)" else ""}")
        appendLine("Natives:   ${command.nativesDir.path}")
        appendLine("Memory:    ${spec.ramMb} MB")
        appendLine()

        if (status.isReady) {
            appendLine("Core: ready")
        } else {
            appendLine("Core: NOT READY — ${status.missing.size} item(s) missing:")
            status.missing.forEach { appendLine("  - $it") }
            appendLine("  Runtimes, LWJGL and launch components: Settings → Game core → Install.")
            appendLine("  Native libraries (libpojavexec.so, libgl4es_114.so, ...) come only with the APK \"with core and natives\".")
        }
        appendLine()

        if (command.warnings.isNotEmpty()) {
            appendLine("Warnings:")
            command.warnings.forEach { appendLine("  - $it") }
            appendLine()
        }

        val missingLibraries = spec.libraryJars.filterNot { File(it).exists() }
        if (missingLibraries.isNotEmpty() || !File(spec.clientJar).exists()) {
            appendLine("Files missing on disk (skipped in classpath):")
            missingLibraries.forEach { appendLine("  - $it") }
            if (!File(spec.clientJar).exists()) appendLine("  - ${spec.clientJar}")
            appendLine()
        }

        appendLine("Command (one argument per line):")
        command.redacted().forEach { appendLine("  $it") }
        appendLine()
        appendLine("Classpath (${command.classpath.size} entries):")
        command.classpath.forEach { appendLine("  $it") }
    }
}
