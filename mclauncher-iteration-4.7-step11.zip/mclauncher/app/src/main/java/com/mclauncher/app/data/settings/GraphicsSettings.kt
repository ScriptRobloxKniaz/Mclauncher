package com.mclauncher.app.data.settings

/**
 * Графический рендерер игры. Пока значения только сохраняются в DataStore; в 4.7b они превратятся в переменные
 * окружения и аргументы запуска ядра Pojav/Zalith.
 *
 * [id] попадает в файл настроек, поэтому **менять уже выданные значения нельзя**: у пользователей они сохранены.
 */
enum class Renderer(val id: String) {
    /** Vulkan-слой: OpenGL поверх Vulkan. Нужен телефон с Vulkan 1.1+. */
    ZINK("zink"),

    /** Рендер на стороне виртуального GPU (virglrenderer). */
    VIRGL("virgl"),

    /** OpenGL → OpenGL ES (набор GL4ES). Самый совместимый вариант, поэтому он по умолчанию. */
    GL4ES("gl4es"),

    /** Системный OpenGL ES без трансляции. */
    OPENGL("opengl");

    /** Рендереру нужна поддержка Vulkan на устройстве. */
    val needsVulkan: Boolean get() = this == ZINK

    companion object {
        val Default = GL4ES

        fun fromId(id: String?): Renderer = entries.firstOrNull { it.id == id } ?: Default
    }
}

/**
 * Версия OpenGL, которую GL4ES показывает игре. [AUTO] — пусть решает ядро.
 * Список предварительный: в 4.7b его сверят с тем, что действительно принимает ядро.
 */
enum class OpenGlVersion(val id: String) {
    AUTO("auto"),
    GL_2_1("2.1"),
    GL_3_0("3.0"),
    GL_3_2("3.2");

    /** Подпись для чисел (`2.1`); у [AUTO] подписи нет — её берут из строковых ресурсов. */
    val numberLabel: String? get() = if (this == AUTO) null else id

    companion object {
        val Default = AUTO

        fun fromId(id: String?): OpenGlVersion = entries.firstOrNull { it.id == id } ?: Default
    }
}

/**
 * Настройки графики. Выпадающий список рендеров и переключатель «Использовать Zink» — два способа выбрать одно и то же,
 * поэтому они всегда согласованы: Zink выбран в списке ⇔ переключатель включён. Менять настройки нужно только
 * через [withRenderer] и [withUseZink], а читать сохранённое — через [fromStored].
 */
data class GraphicsSettings(
    val renderer: Renderer = Renderer.Default,
    val glVersion: OpenGlVersion = OpenGlVersion.Default,
    val useZink: Boolean = false,
) {
    /** Рендерер, который будет передан ядру. */
    val effectiveRenderer: Renderer get() = if (useZink) Renderer.ZINK else renderer

    /** Версия OpenGL имеет смысл только для GL4ES. */
    val glVersionApplies: Boolean get() = effectiveRenderer == Renderer.GL4ES

    /** Выбор в списке рендеров. Выбор Zink включает переключатель, любой другой — выключает. */
    fun withRenderer(value: Renderer): GraphicsSettings = copy(renderer = value, useZink = value == Renderer.ZINK)

    /**
     * Переключатель «Использовать Zink». Включение выбирает Zink в списке; выключение возвращает рендерер по
     * умолчанию, если в списке стоял Zink, и не трогает остальное.
     */
    fun withUseZink(enabled: Boolean): GraphicsSettings = when {
        enabled -> copy(renderer = Renderer.ZINK, useZink = true)
        renderer == Renderer.ZINK -> copy(renderer = Renderer.Default, useZink = false)
        else -> copy(useZink = false)
    }

    fun withGlVersion(value: OpenGlVersion): GraphicsSettings = copy(glVersion = value)

    companion object {
        /**
         * Собирает настройки из сохранённых значений. Неизвестные и повреждённые значения заменяются на значения
         * по умолчанию, а противоречия («Zink» в списке при выключенном переключателе) устраняются.
         */
        fun fromStored(rendererId: String?, glVersionId: String?, useZink: Boolean?): GraphicsSettings {
            val renderer = Renderer.fromId(rendererId)
            val zink = renderer == Renderer.ZINK || useZink == true
            return GraphicsSettings(
                renderer = if (zink) Renderer.ZINK else renderer,
                glVersion = OpenGlVersion.fromId(glVersionId),
                useZink = zink,
            )
        }
    }
}
