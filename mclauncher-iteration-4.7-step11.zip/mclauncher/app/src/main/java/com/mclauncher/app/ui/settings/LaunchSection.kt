package com.mclauncher.app.ui.settings

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.JvmArguments
import com.mclauncher.app.data.settings.LaunchSettings
import com.mclauncher.app.data.settings.RejectReason
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.components.NeonSecondaryButton
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/** Состояние раздела «Запуск и загрузка» и его действия. */
@Immutable
data class LaunchControls(
    val settings: LaunchSettings,
    val deviceTotalMb: Long,
    /** Ползунок памяти отпустили: значение запоминается. */
    val onRamChange: (Int) -> Unit,
    val onRamAuto: () -> Unit,
    val onJvmArgumentsChange: (String) -> Unit,
    /** Ползунок потоков отпустили: значение запоминается. */
    val onDownloadThreadsChange: (Int) -> Unit,
)

@get:StringRes
private val RejectReason.messageRes: Int
    get() = when (this) {
        RejectReason.NOT_AN_OPTION -> R.string.settings_launch_reject_not_option
        RejectReason.MEMORY -> R.string.settings_launch_reject_memory
        RejectReason.MANAGED -> R.string.settings_launch_reject_managed
        RejectReason.TEMPLATE -> R.string.settings_launch_reject_template
    }

/** Пауза после последнего нажатия клавиши, после которой аргументы Java сохраняются (чтобы не писать на диск на каждую букву). */
private const val JVM_ARGS_SAVE_DELAY_MS = 600L

/**
 * Раздел «Запуск и загрузка»: память игры (ползунок до 70% памяти устройства или «автоматически»), свои аргументы
 * Java (с показом тех, что не будут применены, и почему) и число одновременных загрузок.
 */
@Composable
fun LaunchSection(controls: LaunchControls, modifier: Modifier = Modifier) {
    val settings = controls.settings
    val colors = MaterialTheme.colorScheme

    NeonCard(modifier = modifier) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = LauncherIcons.Download,
                    contentDescription = null,
                    tint = colors.primary,
                    modifier = Modifier.size(24.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.settings_launch_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.onSurface,
                    )
                    Text(
                        text = stringResource(R.string.settings_launch_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                    )
                }
            }

            RamControl(controls)
            JvmArgumentsControl(controls)
            DownloadThreadsControl(controls)
        }
    }
}

@Composable
private fun RamControl(controls: LaunchControls) {
    val settings = controls.settings
    val colors = MaterialTheme.colorScheme
    val maxRam = LaunchSettings.maxRamMb(controls.deviceTotalMb)
    val effective = settings.effectiveRamMb(controls.deviceTotalMb)
    val adjustable = maxRam > LaunchSettings.MIN_RAM_MB

    // Положение ползунка, пока его тянут; сбрасывается, когда сохранённое значение обновилось.
    var drag by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(effective) { drag = null }
    val shown = (drag ?: effective.toFloat()).roundToInt()

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = stringResource(
                if (settings.ramMb == null) R.string.settings_launch_ram_auto else R.string.settings_launch_ram,
                shown,
            ),
            style = MaterialTheme.typography.labelLarge,
            color = colors.onSurface,
        )
        Slider(
            value = shown.toFloat(),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { controls.onRamChange(it.roundToInt()) } },
            valueRange = LaunchSettings.MIN_RAM_MB.toFloat()..maxRam.toFloat().coerceAtLeast(LaunchSettings.MIN_RAM_MB + 1f),
            steps = (((maxRam - LaunchSettings.MIN_RAM_MB) / LaunchSettings.RAM_STEP_MB) - 1).coerceAtLeast(0),
            enabled = adjustable,
        )
        Text(
            text = stringResource(R.string.settings_launch_ram_note, controls.deviceTotalMb.toInt(), maxRam),
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant,
        )
        NeonSecondaryButton(
            text = stringResource(R.string.settings_launch_ram_auto_button),
            onClick = controls.onRamAuto,
            enabled = settings.ramMb != null,
        )
    }
}

@Composable
private fun JvmArgumentsControl(controls: LaunchControls) {
    val colors = MaterialTheme.colorScheme
    // Пока игрок не печатал, показываем сохранённое; после первой правки текст принадлежит полю (иначе запись
    // в DataStore, пришедшая с опозданием, затёрла бы только что набранные символы).
    var edited by remember { mutableStateOf<String?>(null) }
    val shown = edited ?: controls.settings.jvmArguments

    LaunchedEffect(edited) {
        val text = edited ?: return@LaunchedEffect
        if (text != controls.settings.jvmArguments) {
            delay(JVM_ARGS_SAVE_DELAY_MS)
            controls.onJvmArgumentsChange(text)
        }
    }

    val parsed = remember(shown) { JvmArguments.parse(shown) }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(
            value = shown,
            onValueChange = { edited = it.take(JvmArguments.MAX_TEXT_LENGTH) },
            label = { Text(stringResource(R.string.settings_launch_jvm)) },
            placeholder = { Text("-XX:+UseG1GC -Dfoo=bar") },
            isError = parsed.rejected.isNotEmpty(),
            minLines = 2,
            maxLines = 4,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
            supportingText = {
                if (parsed.rejected.isEmpty()) {
                    Text(stringResource(R.string.settings_launch_jvm_hint))
                } else {
                    Column {
                        Text(stringResource(R.string.settings_launch_jvm_rejected))
                        parsed.rejected.take(MAX_REJECTED_SHOWN).forEach { rejected ->
                            Text("• ${rejected.argument} — ${stringResource(rejected.reason.messageRes)}")
                        }
                        if (parsed.rejected.size > MAX_REJECTED_SHOWN) {
                            Text(stringResource(R.string.settings_launch_jvm_more, parsed.rejected.size - MAX_REJECTED_SHOWN))
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            text = stringResource(R.string.settings_launch_jvm_note),
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant,
        )
    }
}

private const val MAX_REJECTED_SHOWN = 5

@Composable
private fun DownloadThreadsControl(controls: LaunchControls) {
    val colors = MaterialTheme.colorScheme
    val saved = controls.settings.safeDownloadThreads
    var drag by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(saved) { drag = null }
    val shown = (drag ?: saved.toFloat()).roundToInt()

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = stringResource(R.string.settings_launch_threads, shown),
            style = MaterialTheme.typography.labelLarge,
            color = colors.onSurface,
        )
        Slider(
            value = shown.toFloat(),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { controls.onDownloadThreadsChange(it.roundToInt()) } },
            valueRange = LaunchSettings.MIN_DOWNLOAD_THREADS.toFloat()..LaunchSettings.MAX_DOWNLOAD_THREADS.toFloat(),
            steps = ((LaunchSettings.MAX_DOWNLOAD_THREADS - LaunchSettings.MIN_DOWNLOAD_THREADS) / LaunchSettings.DOWNLOAD_THREADS_STEP) - 1,
        )
        Text(
            text = stringResource(R.string.settings_launch_threads_note),
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant,
        )
    }
}
