package com.mclauncher.app.ui.root

import android.app.Application
import android.database.sqlite.SQLiteException
import android.net.Uri
import android.util.Log
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mclauncher.app.LauncherApp
import com.mclauncher.app.R
import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.background.VideoImportException
import com.mclauncher.app.data.background.VideoImportReason
import com.mclauncher.app.data.settings.BackgroundPreset
import com.mclauncher.app.data.settings.BackgroundSelection
import com.mclauncher.app.data.settings.VideoBackgroundSettings
import com.mclauncher.app.data.settings.sanitizeVolume
import com.mclauncher.app.data.settings.shouldUnmuteOnVolumeChange
import com.mclauncher.app.data.versions.VersionLibraryState
import com.mclauncher.app.data.settings.LaunchSettings
import com.mclauncher.app.launch.DeviceMemory
import com.mclauncher.app.launch.LaunchFailure
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.launch.LaunchResult
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.common.UiEvent
import com.mclauncher.app.ui.components.BackgroundContent
import com.mclauncher.app.ui.components.BackgroundVideo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * Корневая ViewModel: состояние фона, активный аккаунт и общие одноразовые события.
 * Никакой тяжёлой работы в главном потоке: декодирование и запись идут на Dispatchers.IO
 * внутри [com.mclauncher.app.data.background.BackgroundImageStore], а база — через Room/корутины.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as LauncherApp
    private val settings = app.settings
    private val store = app.backgroundStore
    private val videoStore = app.backgroundVideoStore
    private val accounts = app.accountRepository
    private val launcher = app.gameLauncher
    private val versions = app.versionLibrary

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events: Flow<UiEvent> = _events.receiveAsFlow()

    /** Стадия запуска игры: кнопка «Играть» показывает прогресс и не принимает повторные нажатия. */
    val launchPhase: StateFlow<LaunchPhase> = launcher.phase

    private val _launchOutcome = MutableStateFlow<LaunchResult?>(null)

    /** Итог последнего запуска, который нужно показать пользователю (ошибка или пометка «заглушка»). */
    val launchOutcome: StateFlow<LaunchResult?> = _launchOutcome.asStateFlow()

    /** Активный аккаунт для главного экрана («Играть» и плашка с ником). */
    val activeAccount: StateFlow<ActiveAccountState> = accounts.activeAccount
        .map<Account?, ActiveAccountState> { account ->
            if (account == null) ActiveAccountState.None else ActiveAccountState.Selected(account)
        }
        .catch { e ->
            if (e is SQLiteException) {
                Log.w(TAG, "Failed to read active account", e)
                _events.trySend(UiEvent(R.string.error_accounts_db))
                emit(ActiveAccountState.None)
            } else {
                throw e
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = ActiveAccountState.Loading,
        )

    /**
     * Установленные версии и выбранная из них. `null`, пока список не прочитан с диска, — главный экран в это время
     * не рисует «ничего не установлено», чтобы не мигать.
     */
    val library: StateFlow<VersionLibraryState?> = versions.state
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = null,
        )

    /** Выбор из DataStore — для отметки «выбрано» в окне выбора фона. */
    val selection: StateFlow<BackgroundSelection> = settings.background.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = BackgroundSelection.Preset(BackgroundPreset.Default),
    )

    /** Готовое содержимое фона: пресет или уже загруженная картинка. */
    val backgroundContent: StateFlow<BackgroundContent> = selection
        .mapLatest { resolve(it) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = BackgroundContent.Preset(BackgroundPreset.Default),
        )

    // --- Видео-фон ---

    /** Настройки видео: включено ли, звук, громкость. Для экрана «Настройки» и окна выбора фона. */
    val videoSettings: StateFlow<VideoBackgroundSettings> = settings.videoBackground.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = VideoBackgroundSettings(),
    )

    /** Громкость, выбранная ползунком и ещё не сохранённая (или уже сохранённая — тогда совпадает с настройками). */
    private val liveVolume = MutableStateFlow<Float?>(null)

    /** Громкость плеера: 0, пока звук выключен (по умолчанию он выключен), иначе — положение ползунка. */
    val videoVolume: StateFlow<Float> = combine(videoSettings, liveVolume) { video, live ->
        if (video.muted) 0f else sanitizeVolume(live ?: video.volume)
    }
        .distinctUntilChanged()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = 0f,
        )

    /**
     * Видео, которое нужно играть сейчас, или `null`. Наличие файла проверяется на Dispatchers.IO; при смене только
     * громкости значение не меняется, и плеер не перезапускается.
     */
    val backgroundVideo: StateFlow<BackgroundVideo?> = videoSettings
        .map { video ->
            val stamp = video.stamp
            if (!video.enabled || stamp == null) null else videoStore.fileOrNull()?.let { BackgroundVideo(it, stamp) }
        }
        .distinctUntilChanged()
        .flowOn(Dispatchers.IO)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = null,
        )

    init {
        // Читаем с диска, какие версии установлены; до ответа сетка версий показывает «загрузку».
        viewModelScope.launch { versions.refresh() }
    }

    /** Запоминает выбор версии для большой кнопки «Запустить». Если выбор не сохранился — говорит об этом. */
    fun selectVersion(id: String) {
        viewModelScope.launch {
            if (!versions.select(id)) _events.trySend(UiEvent(R.string.error_settings_save))
        }
    }

    /**
     * Запуск версии активным аккаунтом. [versionId] — карточка, на кнопку которой нажали; `null` — запустить
     * выбранную. Версия с карточки заодно становится выбранной, чтобы большая кнопка запускала её же.
     * Вся работа идёт в корутине; результат — в [launchOutcome].
     */
    fun launchGame(versionId: String? = null) {
        val account = (activeAccount.value as? ActiveAccountState.Selected)?.account
        viewModelScope.launch {
            val target = versionId ?: library.value?.selected?.id
            // Не удалось запомнить выбор — не страшно: версия всё равно запускается по явному идентификатору.
            if (versionId != null) versions.select(versionId)
            // Память и аргументы Java берутся из настроек при каждом запуске: сменили — и со следующего запуска действует.
            val launchSettings = try {
                withContext(Dispatchers.IO) { settings.launch.first() }
            } catch (e: IOException) {
                LaunchSettings()
            }
            val ramMb = launchSettings.effectiveRamMb(DeviceMemory.totalMb(app))
            val extraJvmArgs = launchSettings.parsedJvmArguments().accepted
            when (val result = launcher.launch(account, versionId = target, ramMb = ramMb, extraJvmArgs = extraJvmArgs)) {
                // Настоящий запуск уводит пользователя в игру — отдельное сообщение не нужно.
                // Заглушка же обязана честно сказать, что игра не стартовала.
                is LaunchResult.Started -> if (result.placeholder) _launchOutcome.value = result

                is LaunchResult.Failed -> {
                    // Файлы версии пропали уже после того, как мы прочитали список: обновим его, чтобы плашка не врала.
                    if (result.failure is LaunchFailure.VersionNotInstalled) versions.refresh()
                    // Повторное нажатие во время запуска — не ошибка, молча игнорируем.
                    if (result.failure != LaunchFailure.AlreadyLaunching) _launchOutcome.value = result
                }
            }
        }
    }

    /**
     * Вызывается, когда лаунчер снова на виду: если игра в прошлый раз закрылась с ошибкой или упала, показывает
     * причину. Нормальное закрытие ничего не показывает. Каждый итог показывается один раз.
     */
    fun checkGameExit() {
        viewModelScope.launch {
            val report = withContext(Dispatchers.IO) { app.consumeGameExit() } ?: return@launch
            val detail = listOfNotNull(report.message, report.logFile).joinToString(" · ").ifEmpty { null }
            _launchOutcome.value = LaunchResult.Failed(LaunchFailure.GameExited(report.exitCode, report.isSignal, detail))
        }
    }

    fun dismissLaunchOutcome() {
        _launchOutcome.value = null
    }

    fun selectPreset(preset: BackgroundPreset) {
        viewModelScope.launch {
            try {
                settings.setBackgroundPreset(preset)
                settings.setVideoEnabled(false) // иначе видео по-прежнему закрывало бы выбранный фон
                store.delete() // освободить место: своя картинка больше не нужна
            } catch (e: IOException) {
                Log.w(TAG, "Failed to save background preset", e)
                _events.trySend(UiEvent(R.string.error_settings_save))
            }
        }
    }

    /** [uri] — результат системного выбора файла (SAF). Картинка копируется в приватное хранилище. */
    fun importCustomBackground(uri: Uri) {
        viewModelScope.launch {
            try {
                store.importFrom(uri)
                settings.setBackgroundCustom(stamp = System.currentTimeMillis())
                settings.setVideoEnabled(false)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onImportFailed(e)
            } catch (e: OutOfMemoryError) {
                onImportFailed(e)
            }
        }
    }

    /** [uri] — результат системного выбора видео (SAF). Файл копируется в приватное хранилище и сразу становится фоном. */
    fun importVideoBackground(uri: Uri) {
        viewModelScope.launch {
            try {
                videoStore.importFrom(uri)
                settings.setVideoImported(stamp = System.currentTimeMillis())
            } catch (e: CancellationException) {
                throw e
            } catch (e: VideoImportException) {
                Log.w(TAG, "Video import rejected: ${e.reason}", e)
                _events.trySend(UiEvent(e.reason.messageRes()))
            } catch (e: Exception) {
                Log.w(TAG, "Failed to import video background", e)
                _events.trySend(UiEvent(R.string.error_video_import_unreadable))
            }
        }
    }

    fun setVideoEnabled(enabled: Boolean) = saveVideoSetting { settings.setVideoEnabled(enabled) }

    fun setVideoMuted(muted: Boolean) = saveVideoSetting { settings.setVideoMuted(muted) }

    /** Ползунок громкости ещё тянут: меняем громкость плеера сразу, но не пишем на диск на каждый пиксель. */
    fun previewVideoVolume(volume: Float) {
        val value = sanitizeVolume(volume)
        liveVolume.value = value
        // Ползунок тянут при выключенном звуке — значит, хотят слышать видео: звук включается сам.
        if (shouldUnmuteOnVolumeChange(videoSettings.value.muted, value)) setVideoMuted(false)
    }

    /** Ползунок отпустили: громкость запоминается. */
    fun commitVideoVolume(volume: Float) {
        val value = sanitizeVolume(volume)
        liveVolume.value = value
        saveVideoSetting { settings.setVideoVolume(value) }
    }

    /** Убирает выбранное видео и удаляет его файл. Выключенный и убранный фон возвращают прежнюю картинку или пресет. */
    fun removeVideoBackground() {
        viewModelScope.launch {
            try {
                settings.clearVideo() // сначала настройка: плеер отпускает файл, потом файл удаляется
                videoStore.delete()
            } catch (e: IOException) {
                Log.w(TAG, "Failed to remove video background", e)
                _events.trySend(UiEvent(R.string.error_settings_save))
            }
        }
    }

    /** Плеер не смог проиграть видео (повреждено, неподдерживаемый кодек): выключаем его и говорим об этом. */
    fun onVideoPlaybackError() {
        if (!videoSettings.value.enabled) return // уже выключено: повторные сообщения не нужны
        Log.w(TAG, "Video background playback failed; turning it off")
        _events.trySend(UiEvent(R.string.error_video_playback))
        saveVideoSetting { settings.setVideoEnabled(false) }
    }

    private fun saveVideoSetting(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: IOException) {
                Log.w(TAG, "Failed to save video setting", e)
                _events.trySend(UiEvent(R.string.error_settings_save))
            }
        }
    }

    private fun VideoImportReason.messageRes(): Int = when (this) {
        VideoImportReason.NOT_VIDEO -> R.string.error_video_import_not_video
        VideoImportReason.TOO_LARGE -> R.string.error_video_import_too_large
        VideoImportReason.NO_SPACE -> R.string.error_video_import_space
        VideoImportReason.UNREADABLE -> R.string.error_video_import_unreadable
    }

    private suspend fun resolve(selection: BackgroundSelection): BackgroundContent = when (selection) {
        is BackgroundSelection.Preset -> BackgroundContent.Preset(selection.preset)
        is BackgroundSelection.Custom -> try {
            BackgroundContent.Image(store.load().asImageBitmap())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            onLoadFailed(e)
        } catch (e: OutOfMemoryError) {
            onLoadFailed(e)
        }
    }

    /** Файл фона пропал/повреждён: возвращаем стандартный фон и сообщаем об этом. */
    private fun onLoadFailed(e: Throwable): BackgroundContent {
        Log.w(TAG, "Failed to load custom background", e)
        _events.trySend(UiEvent(R.string.error_background_load))
        viewModelScope.launch {
            try {
                settings.setBackgroundPreset(BackgroundPreset.Default)
            } catch (io: IOException) {
                Log.w(TAG, "Failed to reset background preset", io)
            }
        }
        return BackgroundContent.Preset(BackgroundPreset.Default)
    }

    private fun onImportFailed(e: Throwable) {
        Log.w(TAG, "Failed to import custom background", e)
        _events.trySend(UiEvent(R.string.error_background_import))
    }

    private companion object {
        const val TAG = "LauncherViewModel"
    }
}
