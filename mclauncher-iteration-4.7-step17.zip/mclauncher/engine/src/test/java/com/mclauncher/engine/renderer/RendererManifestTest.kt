package com.mclauncher.engine.renderer

import com.mclauncher.engine.launch.RendererProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.File

class RendererManifestTest {

    private val sha = "a".repeat(64)
    private val commit = "0123456789abcdef0123456789abcdef01234567"

    private val valid = """
        # комментарий
        mcl-renderers 1
        abi arm64-v8a
        upstream $commit
        renderer opengles2
        download 2649480 $sha Zalith/src/jniLibs/arm64-v8a/libgl4es_114.so - libgl4es_114.so
        renderer opengles3_desktopgl_zink_kopper
        download 16002238 $sha Zalith/libs/kopper-zink-release.aar jni/arm64-v8a/ libglxshim.so,libEGL_mesa.so
    """.trimIndent()

    private fun rejects(text: String, contains: String) {
        try {
            RendererManifest.parse(text)
            fail("must be rejected: $contains")
        } catch (e: RendererManifestException) {
            assertTrue("'${e.message}' should mention '$contains'", e.message.orEmpty().contains(contains))
        }
    }

    @Test
    fun aValidManifestIsParsed() {
        val manifest = RendererManifest.parse(valid)

        assertEquals("arm64-v8a", manifest.abi)
        assertEquals(commit, manifest.upstream)
        assertEquals(listOf("opengles2", "opengles3_desktopgl_zink_kopper"), manifest.packages.map { it.rendererId })
        val zink = manifest.packageFor("opengles3_desktopgl_zink_kopper")!!
        assertEquals(listOf("libglxshim.so", "libEGL_mesa.so"), zink.files)
        assertEquals(16002238L, zink.totalBytes)
        assertEquals("jni/arm64-v8a/", zink.downloads.single().zipDir)
        assertNull(manifest.packageFor("opengles2")!!.downloads.single().zipDir)
        assertNull(manifest.packageFor("nope"))
    }

    @Test
    fun theUrlIsBuiltFromThePinnedRevisionNotTakenFromTheManifest() {
        val manifest = RendererManifest.parse(valid)

        val url = manifest.urlOf(manifest.packageFor("opengles2")!!.downloads.single())

        assertEquals(
            "https://raw.githubusercontent.com/ZalithLauncher/ZalithLauncher2/$commit/Zalith/src/jniLibs/arm64-v8a/libgl4es_114.so",
            url,
        )
        assertEquals("libgl4es_114.so", manifest.packageFor("opengles2")!!.downloads.single().fileName)
    }

    @Test
    fun aManifestCannotCarryItsOwnUrl() {
        rejects(valid.replace("Zalith/src/jniLibs/arm64-v8a/libgl4es_114.so", "https://evil.example/libgl4es_114.so"), "unsafe repository path")
    }

    @Test
    fun unsafePathsAndNamesAreRejected() {
        rejects(valid.replace("Zalith/libs/kopper-zink-release.aar", "../kopper-zink-release.aar"), "unsafe repository path")
        rejects(valid.replace("libglxshim.so,libEGL_mesa.so", "libglxshim.so,../libEGL_mesa.so"), "unsafe file name")
        rejects(valid.replace("libglxshim.so,libEGL_mesa.so", "libglxshim.so,.hidden"), "unsafe file name")
        rejects(valid.replace("jni/arm64-v8a/", "jni/../x/"), "unsafe archive folder")
        rejects(valid.replace("jni/arm64-v8a/", "jni/arm64-v8a"), "unsafe archive folder")
    }

    @Test
    fun badNumbersAndHashesAreRejected() {
        rejects(valid.replace("2649480", "0"), "bad size")
        rejects(valid.replace("2649480", "-5"), "bad size")
        rejects(valid.replace("2649480", "many"), "bad size")
        rejects(valid.replaceFirst(sha, "z".repeat(64)), "bad sha256")
        rejects(valid.replaceFirst(sha, "A".repeat(64)), "bad sha256")
        rejects(valid.replaceFirst(sha, "a".repeat(40)), "bad sha256")
        rejects(valid.replace(commit, "main"), "bad upstream")
    }

    @Test
    fun structuralMistakesAreRejected() {
        rejects(valid.replace("mcl-renderers 1", "mcl-renderers 2"), "unsupported format")
        rejects(valid.replace("mcl-renderers 1\n", ""), "header")
        rejects(valid.replace("abi arm64-v8a\n", ""), "'abi' is missing")
        rejects(valid.replace("upstream $commit\n", ""), "'upstream' is missing")
        rejects(valid.replace("renderer opengles2\n", ""), "before any 'renderer'")
        rejects(valid + "\nrenderer opengles2\ndownload 1 $sha p/x.so - x.so", "duplicate renderer")
        rejects(valid + "\nrenderer empty_one", "nothing to download")
        rejects(valid + "\nsurprise 1", "unknown line")
        rejects("mcl-renderers 1\nabi arm64-v8a\nupstream $commit", "no renderers")
        rejects(valid.replace("download 2649480", "download"), "5 fields")
    }

    @Test
    fun aRendererIdHasToLookLikeOne() {
        rejects(valid.replace("renderer opengles2", "renderer ../etc"), "bad renderer id")
        rejects(valid.replace("renderer opengles2", "renderer Opengles2"), "bad renderer id")
    }

    @Test
    fun aPlainDownloadCarriesExactlyItsOwnFile() {
        rejects(valid.replace("- libgl4es_114.so", "- libgl4es_114.so,libother.so"), "exactly one file")
        rejects(valid.replace("- libgl4es_114.so", "- libother.so"), "is not")
    }

    @Test
    fun aFileCannotBeListedTwiceForOneRenderer() {
        rejects(
            valid + "\ndownload 5 $sha Zalith/libs/other.aar jni/arm64-v8a/ libglxshim.so",
            "listed twice",
        )
        rejects(valid.replace("libglxshim.so,libEGL_mesa.so", "libglxshim.so,libglxshim.so"), "duplicate file")
    }

    // ---------------------------------------------------------------- манифест из репозитория

    /**
     * Корень проекта: свойство `mclauncher.root` или ближайшая папка выше текущей с `settings.gradle.kts` (Gradle запускает
     * тесты из папки модуля). Не нашли — тест падает, а не молча пропускается: иначе порча манифеста осталась бы незамеченной.
     */
    private fun projectRoot(): File {
        System.getProperty("mclauncher.root")?.let { return File(it) }
        var dir: File? = File(System.getProperty("user.dir")).absoluteFile
        while (dir != null) {
            if (File(dir, "settings.gradle.kts").isFile) return dir
            dir = dir.parentFile
        }
        fail("the project root (settings.gradle.kts) was not found from ${System.getProperty("user.dir")}")
        throw IllegalStateException()
    }

    @Test
    fun theManifestInTheRepositoryCoversEveryRendererTheProfilesNeed() {
        val file = File(projectRoot(), "app/src/main/assets/renderers/renderers-manifest.txt")
        assertTrue("the renderer manifest is missing: ${file.path}", file.isFile)
        val manifest = RendererManifest.parse(file.readText())

        for (profile in RendererProfile.ALL) {
            val pack = manifest.packageFor(profile.id)
            assertNotNull("no download for ${profile.displayName} (${profile.id})", pack)
            assertEquals(
                "${profile.displayName}: the manifest and RendererProfile.requiredLibraries disagree",
                profile.requiredLibraries.sorted(),
                pack!!.files.sorted(),
            )
        }
        assertEquals(RendererProfile.ALL.map { it.id }.toSet(), manifest.packages.map { it.rendererId }.toSet())
        assertFalse(manifest.packages.any { it.totalBytes <= 0 })
    }
}
