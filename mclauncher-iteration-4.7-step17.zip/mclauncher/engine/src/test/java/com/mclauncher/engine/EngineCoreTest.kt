package com.mclauncher.engine

import com.mclauncher.engine.launch.RendererProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class EngineCoreTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val layout by lazy {
        EngineLayout(
            componentsDir = File(tmp.root, "components"),
            runtimesDir = File(tmp.root, "runtimes"),
            nativeLibraryDir = File(tmp.root, "lib"),
            abi = "arm64-v8a",
        )
    }

    private fun touch(file: File) {
        file.parentFile.mkdirs()
        file.writeText("x")
    }

    /** Раскладка, как после первой распаковки ядра. */
    /** Рендерер скачивается в свою папку (`renderers/<id>/`), а не лежит в папке нативных библиотек приложения. */
    private fun installRendererFile(renderer: RendererProfile, name: String) {
        touch(layout.rendererLibrary(renderer.id, name))
    }

    private fun installCore(lwjgl: LwjglVersion = LwjglVersion.V3_3_3, java: Int = 17) {
        touch(File(layout.nativeLibraryDir, "libpojavexec.so"))
        touch(File(layout.nativeLibraryDir, "libopenal.so"))
        touch(File(layout.lwjglDir(lwjgl), "lwjgl.jar"))
        touch(File(layout.lwjglNativesDir(lwjgl), "liblwjgl.so"))
        touch(layout.launchWrapperJar)
        touch(layout.libPatcherJar)
        touch(layout.javaExecutable(java))
    }

    @Test
    fun anEmptyDeviceMissesEverything() {
        val status = EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17)

        assertFalse(status.isReady)
        assertEquals(7, status.missing.size)
    }

    @Test
    fun aFullCoreIsReady() {
        installCore()

        val status = EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17)

        assertTrue(status.missing.toString(), status.isReady)
    }

    @Test
    fun theRendererLibraryIsOnlyRequiredWhenARendererIsGiven() {
        installCore()

        assertTrue(EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17).isReady)

        val withRenderer = EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17, renderer = RendererProfile.GL4ES)
        assertEquals(1, withRenderer.missing.size)
        assertTrue(withRenderer.missing.single().contains("GL4ES"))
        assertTrue(withRenderer.missing.single().contains("libgl4es_114.so"))

        installRendererFile(RendererProfile.GL4ES, "libgl4es_114.so")
        assertTrue(EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17, renderer = RendererProfile.GL4ES).isReady)
    }

    @Test
    fun theRuntimeIsCheckedForTheRequiredJavaOnly() {
        installCore(java = 17)

        assertTrue(EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17).isReady)
        val needs21 = EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 21)
        assertEquals(1, needs21.missing.size)
        assertTrue(needs21.missing.single().contains("Java 21"))
    }

    @Test
    fun theLwjglSetIsCheckedForTheRequiredVersionOnly() {
        installCore(lwjgl = LwjglVersion.V3_3_3)

        val status = EngineCore.check(layout, LwjglRequirement(LwjglVersion.V3_4_1, false), javaMajor = 17)

        assertEquals(2, status.missing.size) // jar и нативы набора 3.4.1
        assertTrue(status.missing.all { it.contains("3.4.1") })
    }

    @Test
    fun nativesOfAnotherAbiDoNotCount() {
        installCore()
        val otherAbi = EngineLayout(layout.componentsDir, layout.runtimesDir, layout.nativeLibraryDir, abi = "armeabi-v7a")

        val status = EngineCore.check(otherAbi, LwjglRequirement.DEFAULT, javaMajor = 17)

        assertEquals(1, status.missing.size)
        assertTrue(status.missing.single().contains("armeabi-v7a"))
    }

    @Test
    fun anUnsupportedJavaIsReportedWithoutThrowing() {
        installCore()

        val status = EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 40)

        assertEquals(1, status.missing.size)
        assertTrue(status.missing.single().contains("40"))
    }

    @Test
    fun aDirectoryInsteadOfAFileDoesNotCount() {
        installCore()
        File(layout.nativeLibraryDir, "libpojavexec.so").delete()
        File(layout.nativeLibraryDir, "libpojavexec.so").mkdirs()

        val status = EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17)

        assertEquals(1, status.missing.size)
        assertTrue(status.missing.single().contains("Pojav bridge"))
    }

    @Test
    fun everyLibraryOfARendererIsRequiredAndNamedWhenMissing() {
        installRendererFile(RendererProfile.ZINK, "libglxshim.so")
        installRendererFile(RendererProfile.ZINK, "libEGL_mesa.so")

        val status = EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17, renderer = RendererProfile.ZINK)

        val text = status.missing.joinToString("\n")
        assertTrue(text.contains("libzink_dri.so"))
        assertTrue(text.contains("libglapi.so"))
        assertTrue(text.contains("libcutils.so"))
        assertFalse(text.contains("libglxshim.so"))
        assertFalse(text.contains("libEGL_mesa.so"))
        assertTrue(text.contains("Zink (Kopper)"))
    }

    @Test
    fun aRendererOwnEglMustBePresentToo() {
        val withoutEgl = RendererProfile(id = "x", displayName = "X", library = "libx.so", eglLibrary = "libx_egl.so")
        installRendererFile(withoutEgl, "libx.so")

        val status = EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17, renderer = withoutEgl)

        assertTrue(status.missing.any { it.contains("libx_egl.so") })
        assertFalse(status.missing.any { it.contains("libx.so ") || it.endsWith("libx.so)") })
    }

    @Test
    fun missingNativeLibrariesAreToldApartFromMissingComponents() {
        // Ничего нет: не хватает и библиотек APK, и компонентов — главное, что APK без ядра.
        assertTrue(EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17).nativeLibrariesMissing)

        // Не хватает одной библиотеки APK (сборка без нативной части).
        installCore()
        File(layout.nativeLibraryDir, "libpojavexec.so").delete()
        assertTrue(EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17).nativeLibrariesMissing)
    }

    @Test
    fun missingComponentsAloneAreNotBlamedOnTheApk() {
        // Библиотеки APK на месте, компоненты ещё не распакованы: поможет кнопка «Установить ядро».
        touch(File(layout.nativeLibraryDir, "libpojavexec.so"))
        touch(File(layout.nativeLibraryDir, "libopenal.so"))

        val status = EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17)

        assertFalse(status.isReady)
        assertFalse(status.missing.toString(), status.nativeLibrariesMissing)
    }

    @Test
    fun aRendererThatIsNotDownloadedIsToldApartFromAnApkWithoutTheCore() {
        installCore()

        val status = EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17, renderer = RendererProfile.KRYPTON)

        assertTrue(status.rendererMissing)
        assertFalse("a renderer is downloaded, it is not part of the APK", status.nativeLibrariesMissing)
        assertEquals(1, status.missing.size)
        assertTrue(status.missing.single().contains("not downloaded"))
    }

    @Test
    fun aRendererLibraryInTheApkLibraryFolderDoesNotCount() {
        // До шага 16 рендерер лежал в nativeLibraryDir. Теперь его там не ищут: нужен файл в папке рендерера.
        installCore()
        touch(File(layout.nativeLibraryDir, "libng_gl4es.so"))

        val status = EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17, renderer = RendererProfile.KRYPTON)

        assertTrue(status.rendererMissing)
    }

    @Test
    fun aDownloadedRendererMakesTheCoreReadyAndEachRendererHasItsOwnFolder() {
        installCore()
        installRendererFile(RendererProfile.KRYPTON, "libng_gl4es.so")

        assertTrue(EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17, renderer = RendererProfile.KRYPTON).isReady)
        // Файл Krypton не годится для GL4ES: у каждого рендерера своя папка.
        assertTrue(EngineCore.check(layout, LwjglRequirement.DEFAULT, javaMajor = 17, renderer = RendererProfile.GL4ES).rendererMissing)
    }

    @Test
    fun theRendererFolderSitsNextToTheComponentsByDefault() {
        val byDefault = EngineLayout(File(tmp.root, "engine/components"), File(tmp.root, "engine/runtimes"), File(tmp.root, "lib"), "arm64-v8a")

        assertEquals(File(tmp.root, "engine/renderers/opengles2"), byDefault.rendererDir("opengles2"))
        assertEquals(File(tmp.root, "engine/renderers/opengles2/libgl4es_114.so"), byDefault.rendererLibrary("opengles2", "libgl4es_114.so"))
    }
}
