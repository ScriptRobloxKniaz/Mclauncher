package com.mclauncher.engine.launch

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RendererProfileTest {

    private val env = RendererProfile.GL4ES.environment("/cache")

    @Test
    fun gl4esIdentityMatchesUpstream() {
        assertEquals("opengles2", RendererProfile.GL4ES.id)
        assertEquals("libgl4es_114.so", RendererProfile.GL4ES.library)
        assertFalse(RendererProfile.GL4ES.mesaBased)
    }

    @Test
    fun gl4esSetsTheEsEnvironment() {
        assertEquals("opengles2", env["POJAV_RENDERER"])
        assertEquals("opengles2", env["SDL_OPENGL_LIBRARY"])
        assertEquals("2", env["LIBGL_ES"])
        assertEquals("3", env["LIBGL_MIPMAP"])
        assertEquals("1", env["LIBGL_NOERROR"])
        assertEquals("1", env["LIBGL_NOINTOVLHACK"])
        assertEquals("1", env["LIBGL_NORMALIZE"])
    }

    @Test
    fun nonMesaRenderersGetTheSharedMesaVariables() {
        // Так делает апстрим для всех рендереров не на Mesa; значения должны совпадать буквально.
        assertEquals("zink", env["MESA_LOADER_DRIVER_OVERRIDE"])
        assertEquals("/cache", env["MESA_GLSL_CACHE_DIR"])
        assertEquals("4.6", env["MESA_GL_VERSION_OVERRIDE"])
        assertEquals("460", env["MESA_GLSL_VERSION_OVERRIDE"])
        assertEquals("true", env["force_glsl_extensions_warn"])
        assertEquals("true", env["allow_higher_compat_version"])
        assertEquals("true", env["allow_glsl_extension_directive_midshader"])
        assertEquals("libgl4es_114.so", env["LIB_MESA_NAME"])
    }

    @Test
    fun mesaBasedRenderersDoNotGetTheZinkVariables() {
        val mesa = RendererProfile(id = "vulkan_zink", displayName = "Zink", library = "libOSMesa.so", mesaBased = true)

        val result = mesa.environment("/cache")

        assertNull(result["MESA_LOADER_DRIVER_OVERRIDE"])
        assertNull(result["LIB_MESA_NAME"])
        assertEquals("vulkan_zink", result["POJAV_RENDERER"])
        assertFalse("LIBGL_ES" in result)
    }

    @Test
    fun rendererSpecificVariablesComeBeforeThePojavRendererName() {
        val custom = RendererProfile(id = "x", displayName = "X", library = "libx.so", env = mapOf("A" to "1", "POJAV_RENDERER" to "ignored"))

        val result = custom.environment("/c")

        assertEquals("1", result["A"])
        assertEquals("x", result["POJAV_RENDERER"])
        assertTrue(result.keys.indexOf("A") < result.keys.indexOf("POJAV_RENDERER"))
    }

    // --- шаг 12: другие рендереры ---

    @Test
    fun everyShippedRendererHasAUniqueIdAndLibrary() {
        val all = RendererProfile.ALL
        assertEquals(listOf("opengles2", "opengles3", "opengles3_mobileglues", "opengles3_desktopgl_zink_kopper"), all.map { it.id })
        assertEquals(all.size, all.map { it.id }.toSet().size)
        assertEquals(all.size, all.map { it.library }.toSet().size)
    }

    @Test
    fun everyRendererSelectsTheEsContextVersionExplicitly() {
        // Нативный код берёт версию контекста из LIBGL_ES; без неё апстрим опрашивает устройство, а мы — нет.
        for (renderer in RendererProfile.ALL) {
            val result = renderer.environment("/cache")
            assertTrue("${renderer.id} has no LIBGL_ES", result["LIBGL_ES"] in setOf("2", "3"))
            assertEquals(renderer.id, result["POJAV_RENDERER"])
            assertEquals(renderer.id, result["SDL_OPENGL_LIBRARY"])
        }
    }

    @Test
    fun theNativeBridgeSendsEveryRendererExceptTheGl4esFamilyDownTheSamePath() {
        // egl_bridge.c: идентификатор, начинающийся с «opengles», выбирает мост GL4ES (EGL + GLES). Если это изменится,
        // рендереры ниже перестанут запускаться, поэтому проверяем сами идентификаторы.
        for (renderer in listOf(RendererProfile.GL4ES, RendererProfile.KRYPTON, RendererProfile.MOBILEGLUES, RendererProfile.ZINK)) {
            assertTrue(renderer.id, renderer.id.startsWith("opengles"))
        }
        // …а Kopper Zink распознаётся именно по полному идентификатору.
        assertEquals("opengles3_desktopgl_zink_kopper", RendererProfile.ZINK.id)
    }

    @Test
    fun kryptonUsesTheNextGenerationLibraryAndEs3() {
        val result = RendererProfile.KRYPTON.environment("/cache")

        assertEquals("libng_gl4es.so", RendererProfile.KRYPTON.library)
        assertEquals("3", result["LIBGL_ES"])
        assertEquals("31", result["LIBGL_GL"])
        assertEquals("1", result["LIBGL_USE_MC_COLOR"])
        assertNull("the ES 2 block is only for opengles2", result["LIBGL_MIPMAP"])
        assertNull(result["POJAVEXEC_EGL"])
        assertEquals("libng_gl4es.so", result["LIB_MESA_NAME"])
    }

    @Test
    fun mobileGluesBringsItsOwnEglAndAPrivateFolder() {
        val lib = java.nio.file.Files.createTempDirectory("native").toFile()
        val data = java.io.File("/home/data/mobileglues")
        java.io.File(lib, "libmobileglues.so").writeText("x")

        val result = RendererProfile.MOBILEGLUES.environment("/cache", lib, data)

        assertEquals("opengles3_mobileglues", result["POJAV_RENDERER"])
        assertEquals("3", result["LIBGL_ES"])
        assertEquals("libmobileglues.so", result["LIBGL_EGL"])
        assertEquals("libmobileglues.so", result["POJAVEXEC_EGL"])
        assertEquals(java.io.File(lib, "libmobileglues.so").path, result["SDL_EGL_LIBRARY"])
        assertEquals(data.path, result["MG_DIR_PATH"])
        assertNull("not passed: the purpose of the upstream default is unknown", result["MG_COUNT_LAUNCH"])
        assertEquals("libmobileglues.so", result["LIB_MESA_NAME"])
    }

    @Test
    fun theSdlEglPathIsOnlySetWhenTheFileExists() {
        val lib = java.nio.file.Files.createTempDirectory("empty").toFile()

        val missing = RendererProfile.MOBILEGLUES.environment("/cache", lib, null)
        val unknownFolder = RendererProfile.MOBILEGLUES.environment("/cache", null, null)

        assertEquals("libmobileglues.so", missing["POJAVEXEC_EGL"])
        assertNull(missing["SDL_EGL_LIBRARY"])
        assertNull(unknownFolder["SDL_EGL_LIBRARY"])
        assertNull("no folder given, nothing to point at", unknownFolder["MG_DIR_PATH"])
    }

    @Test
    fun rendererWithoutAPrivateFolderNeverGetsThePathVariable() {
        val data = java.io.File("/home/data/x")

        assertNull(RendererProfile.GL4ES.environment("/cache", null, data)["MG_DIR_PATH"])
        assertNull(RendererProfile.GL4ES.dataDir(java.io.File("/home")))
        assertEquals(java.io.File("/home/mobileglues"), RendererProfile.MOBILEGLUES.dataDir(java.io.File("/home")))
    }

    @Test
    fun zinkIsMesaBasedUsesTheSystemVulkanDriverAndBringsEverythingItLoads() {
        val result = RendererProfile.ZINK.environment("/cache")

        assertTrue(RendererProfile.ZINK.mesaBased)
        assertNull(result["MESA_LOADER_DRIVER_OVERRIDE"])
        assertNull(result["LIB_MESA_NAME"])
        assertEquals("1", result["POJAV_ZINK_PREFER_SYSTEM_DRIVER"])
        assertEquals("libEGL_mesa.so", result["POJAVEXEC_EGL"])
        assertEquals(
            listOf("libglxshim.so", "libEGL_mesa.so", "libzink_dri.so", "libglapi.so", "libcutils.so"),
            RendererProfile.ZINK.requiredLibraries,
        )
    }

    @Test
    fun requiredLibrariesHaveNoRepeats() {
        assertEquals(listOf("libgl4es_114.so"), RendererProfile.GL4ES.requiredLibraries)
        // MobileGlues — и библиотека рендерера, и своя EGL: файл один.
        assertEquals(listOf("libmobileglues.so"), RendererProfile.MOBILEGLUES.requiredLibraries)
    }

    @Test
    fun withEnvAddsAndReplacesButLeavesTheOriginalAlone() {
        val changed = RendererProfile.KRYPTON.withEnv("LIBGL_GL" to "32", "NEW" to "1")

        assertEquals("32", changed.environment("/c")["LIBGL_GL"])
        assertEquals("1", changed.environment("/c")["NEW"])
        assertEquals("31", RendererProfile.KRYPTON.environment("/c")["LIBGL_GL"])
    }

    @Test
    fun profilesSurviveSerializationBecauseThePlanTravelsInAnIntent() {
        for (renderer in RendererProfile.ALL + RendererProfile.GL4ES.withEnv("LIBGL_GL" to "30")) {
            val bytes = java.io.ByteArrayOutputStream().also { java.io.ObjectOutputStream(it).use { out -> out.writeObject(renderer) } }
            val copy = java.io.ObjectInputStream(bytes.toByteArray().inputStream()).use { it.readObject() }

            assertEquals(renderer, copy)
        }
    }

    @Test
    fun theLoadOrderPutsDependenciesFirstAndTheLibraryItselfLast() {
        // Zink: extraLibraries перечислены от зависящих к тем, от кого зависят → грузим в обратном порядке.
        assertEquals(
            listOf("libcutils.so", "libglapi.so", "libzink_dri.so", "libEGL_mesa.so", "libglxshim.so"),
            RendererProfile.ZINK.loadOrder,
        )
        assertEquals(listOf("libgl4es_114.so"), RendererProfile.GL4ES.loadOrder)
        // У MobileGlues библиотека и EGL — один файл: он не грузится дважды.
        assertEquals(listOf("libmobileglues.so"), RendererProfile.MOBILEGLUES.loadOrder)
    }

    @Test
    fun everyProfileLoadsExactlyTheFilesItRequires() {
        for (profile in RendererProfile.ALL) {
            assertEquals(profile.displayName, profile.requiredLibraries.sorted(), profile.loadOrder.sorted())
            assertEquals(profile.displayName, profile.library, profile.loadOrder.last())
        }
    }
}
