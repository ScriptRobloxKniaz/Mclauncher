package com.mclauncher.engine.launch

/**
 * Итог подбора рендерера: [profile] — с которым игра будет запущена; [switchedFrom] — какой был выбран в настройках,
 * если пришлось заменить (иначе `null`).
 */
data class RendererChoice(val profile: RendererProfile, val switchedFrom: RendererProfile? = null)

/**
 * Не даёт запустить игру с рендерером, который заведомо с ней не работает (по границам апстрима, см.
 * [RendererProfile.oldestRelease] и [RendererProfile.newestRelease]): такая игра стартует и сразу закрывается, а
 * игрок не понимает почему. Выбор в настройках не меняется — подмена действует только на этот запуск.
 *
 * Подменяют двумя рендерерами с широким охватом: GL4ES для старых версий и MobileGlues для новых.
 */
object RendererAdvisor {

    private val FALLBACKS = listOf(RendererProfile.GL4ES, RendererProfile.MOBILEGLUES)

    /**
     * Идентификаторы рендереров, которыми подменяют выбранный: их стоит скачать заранее, иначе подмена упрётся в
     * рендерер, которого на устройстве нет.
     */
    val fallbackIds: List<String> get() = FALLBACKS.map { it.id }

    /** [fallbacks] — кем заменять, по порядку; по умолчанию GL4ES и MobileGlues. */
    fun resolve(requested: RendererProfile, releaseTime: String?, fallbacks: List<RendererProfile> = FALLBACKS): RendererChoice {
        if (requested.supportsRelease(releaseTime)) return RendererChoice(requested)
        val replacement = fallbacks.firstOrNull { it.id != requested.id && it.supportsRelease(releaseTime) }
            ?: return RendererChoice(requested)
        return RendererChoice(replacement, switchedFrom = requested)
    }
}
