package com.mclauncher.engine.launch

import android.content.Context
import android.system.Os
import com.movtery.zalithlauncher.bridge.LoggerBridge
import com.movtery.zalithlauncher.bridge.ZLBridge
import com.movtery.zalithlauncher.bridge.ZLNativeInvoker
import com.oracle.dalvik.VMLauncher
import org.lwjgl.glfw.CallbackBridge
import java.io.File

/*
 * Порядок запуска JVM портирован из ZalithLauncher 2 (`game/launch/Launcher.kt`: launchJvm, setEnv, dlopenJavaRuntime,
 * dlopenEngine, launchJavaVM; `GameLauncher.dlopenEngine`), GPL-3.0, Copyright (C) 2025-2026 MovTery and contributors —
 * см. THIRD_PARTY_NOTICES.md. Отличия: план приходит готовым ([NativeLaunchPlan]), ошибки превращаются в отчёт
 * ([GameExitReport]) вместо исключений, а подробный журнал запуска пишется в журнал игры.
 */

/**
 * Запускает JVM игры в ТЕКУЩЕМ процессе. Вызывать только в процессе игры (`:game`) и только один раз за его жизнь:
 * вторая JVM в том же процессе не создаётся.
 *
 * Метод блокирует поток до выхода JVM. На практике он обычно не возвращается: при выходе JVM нативный код вызывает
 * [ZLNativeInvoker.Host.onJvmExit] и затем `System.exit` — процесс игры завершается. Возврат из метода значит, что JVM
 * не удалось запустить или она вернула управление сама; в обоих случаях отчёт уже записан.
 *
 * Работает ТОЛЬКО на устройстве; JVM-тестов нет (нужны libpojavexec и рантайм Java). Каждый шаг помечен источником.
 */
object GameRunner {

    /**
     * @param surface поверхность окна игры (`android.view.Surface`); передаётся как `Object`, чтобы этот файл
     *   не зависел от версии API
     * @param host реализация [ZLNativeInvoker.Host]; его [ZLNativeInvoker.Host.onJvmExit] должен вызвать [recordExit]
     * @param onFirstFrame вызывается, когда игра выводит первый кадр (из нативного потока)
     *
     * Каждый шаг записывается в метку сессии ([GameExitReport.noteStage]) до выполнения: если процесс упадёт в нативном
     * коде, лаунчер покажет, на каком шаге (и на какой библиотеке) это случилось.
     */
    fun run(context: Context, plan: NativeLaunchPlan, host: ZLNativeInvoker.Host, surface: Any, onFirstFrame: (() -> Unit)? = null): GameExitReport {
        val reportDir = File(plan.reportDir)
        var stage = "prepare"
        fun step(name: String) {
            stage = name
            GameExitReport.noteStage(reportDir, name)
        }
        try {
            GameExitReport.markSessionStarted(reportDir, System.currentTimeMillis())
            ZLNativeInvoker.setHost(host)

            // Первое обращение к CallbackBridge загружает libpojavexec (статический блок класса): если библиотека не
            // загрузится, ошибка должна попасть в отчёт, а не уронить главный поток экрана.
            step("load libpojavexec")
            if (onFirstFrame != null) CallbackBridge.setGraphicOutputListener { onFirstFrame() }

            step("window")
            ZLBridge.setupBridgeWindow(surface)
            CallbackBridge.sendUpdateWindowSize(plan.windowWidth, plan.windowHeight)

            step("log")
            val logFile = File(plan.logFile)
            logFile.parentFile?.mkdirs()
            // Нативный код открывает файл без O_CREAT: он должен уже существовать (как у апстрима).
            if (!logFile.exists() && !logFile.createNewFile()) {
                return fail(reportDir, plan, "Cannot create the game log ${plan.logFile}")
            }
            LoggerBridge.start(logFile.absolutePath)
            LoggerBridge.appendTitle("Launch Minecraft")
            LoggerBridge.appendInfo("Version: ${plan.versionId}")
            LoggerBridge.appendInfo("Renderer: ${plan.rendererName} (${plan.rendererLibrary})")
            LoggerBridge.appendInfo("Window: ${plan.windowWidth}x${plan.windowHeight}")

            step("input")
            CallbackBridge.nativeSetUseInputStackQueue(plan.useInputStackQueue)

            step("library path")
            ZLBridge.setLdLibraryPath(plan.jvmLibraryPath)

            step("environment")
            LoggerBridge.appendTitle("Env Map")
            setEnvironment(context, plan)

            LoggerBridge.appendTitle("DLOPEN Java Runtime")
            for (library in plan.dlopenLibraries) {
                step("dlopen $library")
                dlopen(library)
            }
            LoggerBridge.appendTitle("DLOPEN Renderer")
            // Зависимости рендерера — до него самого, по полным путям (он лежит в своей папке, система их не найдёт).
            for (library in plan.rendererPreloadPaths) {
                step("dlopen $library")
                dlopen(library)
            }
            step("dlopen renderer ${plan.rendererLibrary}")
            if (!ZLBridge.dlopen(plan.rendererLibrary) && !ZLBridge.dlopen(plan.rendererLibraryPath)) {
                LoggerBridge.appendInfo("Failed to load renderer ${plan.rendererLibrary}")
            }

            LoggerBridge.appendTitle("JVM Args")
            for (arg in plan.redactedArgv()) LoggerBridge.appendInfo(arg)

            step("exit hook")
            ZLBridge.setupExitMethod(context.applicationContext)
            ZLBridge.initializeGameExitHook()
            ZLBridge.chdir(plan.workingDir)

            step("jvm (VMLauncher.launchJVM)")
            val exitCode = VMLauncher.launchJVM(plan.argv.toTypedArray())
            LoggerBridge.append("Java Exit code: $exitCode")
            // Обычно сюда не доходим (см. KDoc); если дошли — JVM вернула управление без вызова jvmExit.
            val report = GameExitReport(exitCode, isSignal = false, logFile = plan.logFile, timeMillis = System.currentTimeMillis())
            recordExit(reportDir, report)
            return report
        } catch (e: Throwable) {
            // UnsatisfiedLinkError (нет libpojavexec или не совпала сигнатура JNI) тоже попадает сюда.
            return fail(reportDir, plan, "$stage: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    /**
     * Сохраняет итог игры. Вызывается из `onJvmExit` и из [run]; синхронная запись обязательна: после `onJvmExit`
     * процесс завершается сразу.
     */
    fun recordExit(reportDir: File, report: GameExitReport) {
        try {
            GameExitReport.write(reportDir, report)
        } catch (ignored: Exception) {
            // Если записать нечего и некуда — лаунчер увидит пометку сессии без отчёта и сообщит о сбое.
        }
    }

    private fun fail(reportDir: File, plan: NativeLaunchPlan, message: String): GameExitReport {
        val report = GameExitReport(
            exitCode = -1,
            isSignal = false,
            message = message,
            logFile = plan.logFile,
            timeMillis = System.currentTimeMillis(),
        )
        recordExit(reportDir, report)
        return report
    }

    private fun dlopen(path: String) {
        // Отсутствие файла — не ошибка запуска: у разных рантаймов состав библиотек разный (так же у апстрима).
        if (!ZLBridge.dlopen(path)) LoggerBridge.appendInfo("dlopen skipped: $path")
    }

    /** `Launcher.setEnv`: переменные из плана плюс два указателя на среду Android, которые знает только этот процесс. */
    private fun setEnvironment(context: Context, plan: NativeLaunchPlan) {
        val all = LinkedHashMap(plan.environment)
        all["DALVIK_JAVAVM"] = ZLBridge.getJavaVMPointer().toString()
        all["DALVIK_APPLICATION"] = ZLBridge.jObjectToString(context.applicationContext)
        for ((key, value) in all) {
            LoggerBridge.appendInfo("$key = $value")
            try {
                Os.setenv(key, value, true)
            } catch (e: Exception) {
                LoggerBridge.appendInfo("Unable to set $key: ${e.message}")
            }
        }
    }
}
