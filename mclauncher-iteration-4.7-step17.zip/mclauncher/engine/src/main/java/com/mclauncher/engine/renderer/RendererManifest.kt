package com.mclauncher.engine.renderer

import com.mclauncher.engine.install.CoreManifest

/*
 * Манифест рендереров: что приложение скачивает на устройстве при первом запуске и как это проверить. Его пишет
 * `scripts/fetch_core.py --renderer-manifest`, лежит он в git и в ассетах APK (`renderers/renderers-manifest.txt`).
 * Формат построчный, поля через пробел:
 *
 *   mcl-renderers 1
 *   abi arm64-v8a
 *   upstream <40 hex>
 *   renderer <id>
 *   download <размер> <sha256> <путь в репозитории апстрима> <папка внутри архива | -> <файл,файл,…>
 *
 * Строка `download` относится к последней строке `renderer`. Если папка внутри архива — `-`, скачивается сам файл
 * (GL4ES лежит в апстриме готовым .so); иначе это AAR (zip), из которого берутся перечисленные файлы папки.
 * URL в манифесте нет: приложение строит его само по закреплённому SHA ([RendererManifest.urlOf]), поэтому
 * манифест не может отправить его куда-то, кроме репозитория апстрима. Любое отклонение — [RendererManifestException]:
 * лучше ничего не скачать, чем скачать то, что не поняли.
 */

class RendererManifestException(message: String) : Exception(message)

/**
 * Один скачиваемый файл.
 * @property size размер скачиваемого файла (AAR целиком, а не его содержимого) — по нему считается прогресс;
 * @property sha256 сумма скачиваемого файла: сверяется до распаковки;
 * @property repoPath путь файла в репозитории апстрима;
 * @property zipDir папка внутри архива (`jni/arm64-v8a/`) или `null`, если скачивается сам файл;
 * @property files имена файлов, которые должны оказаться в папке рендерера (для AAR — взятые из [zipDir]).
 */
data class RendererDownload(
    val size: Long,
    val sha256: String,
    val repoPath: String,
    val zipDir: String?,
    val files: List<String>,
) {
    /** Короткое имя для временного файла и сообщений: последний сегмент [repoPath]. */
    val fileName: String get() = repoPath.substringAfterLast('/')
}

data class RendererPackage(val rendererId: String, val downloads: List<RendererDownload>) {
    /** Сколько байт придётся скачать. */
    val totalBytes: Long get() = downloads.sumOf { it.size }

    /** Файлы, которые должны лежать в папке рендерера после установки. */
    val files: List<String> get() = downloads.flatMap { it.files }
}

data class RendererManifest(val abi: String, val upstream: String, val packages: List<RendererPackage>) {

    fun packageFor(rendererId: String): RendererPackage? = packages.firstOrNull { it.rendererId == rendererId }

    /** Адрес файла в репозитории апстрима на закреплённой ревизии (неизменяемый: ссылка на SHA, а не на ветку). */
    fun urlOf(download: RendererDownload): String = "$RAW_BASE/$upstream/${download.repoPath}"

    companion object {
        const val ASSET_NAME = "renderers/renderers-manifest.txt"
        const val FORMAT = 1

        /** Единственный адрес, откуда приложение скачивает рендереры. Репозиторий — тот же, что в `engine/UPSTREAM`. */
        const val RAW_BASE = "https://raw.githubusercontent.com/ZalithLauncher/ZalithLauncher2"

        private val ID_RE = Regex("^[a-z0-9][a-z0-9_]*$")
        private val HEX64 = Regex("^[0-9a-f]{64}$")
        private val SHA1_HEX = Regex("^[0-9a-f]{40}$")
        private val SEGMENT = Regex("^[A-Za-z0-9._+\\-]+$")

        fun parse(text: String): RendererManifest {
            var formatSeen = false
            var abi: String? = null
            var upstream: String? = null
            val order = ArrayList<String>()
            val downloads = LinkedHashMap<String, ArrayList<RendererDownload>>()
            var current: String? = null

            text.lineSequence().forEachIndexed { index, raw ->
                val line = raw.trim()
                if (line.isEmpty() || line.startsWith("#")) return@forEachIndexed
                val n = index + 1
                val parts = line.split(' ')
                fun fail(why: String): Nothing = throw RendererManifestException("renderers-manifest.txt:$n: $why")

                when (parts[0]) {
                    "mcl-renderers" -> {
                        if (parts.size != 2 || parts[1] != FORMAT.toString()) fail("unsupported format '${parts.drop(1).joinToString(" ")}'")
                        formatSeen = true
                    }
                    "abi" -> {
                        if (parts.size != 2 || !SEGMENT.matches(parts[1])) fail("bad abi line")
                        abi = parts[1]
                    }
                    "upstream" -> {
                        if (parts.size != 2 || !SHA1_HEX.matches(parts[1])) fail("bad upstream revision")
                        upstream = parts[1]
                    }
                    "renderer" -> {
                        if (!formatSeen) fail("'mcl-renderers' header must come first")
                        if (parts.size != 2 || !ID_RE.matches(parts[1])) fail("bad renderer id")
                        if (parts[1] in downloads) fail("duplicate renderer '${parts[1]}'")
                        current = parts[1]
                        order += parts[1]
                        downloads[parts[1]] = ArrayList()
                    }
                    "download" -> {
                        val id = current ?: fail("'download' before any 'renderer'")
                        if (parts.size != 6) fail("a download line needs 5 fields")
                        val (sizeText, sha, repoPath, zipDirToken, fileList) = parts.drop(1)
                        val size = sizeText.toLongOrNull()?.takeIf { it > 0 } ?: fail("bad size '$sizeText'")
                        if (!HEX64.matches(sha)) fail("bad sha256")
                        if (!CoreManifest.isSafeRelativePath(repoPath)) fail("unsafe repository path '$repoPath'")
                        val zipDir = if (zipDirToken == "-") {
                            null
                        } else {
                            if (!zipDirToken.endsWith("/") || !CoreManifest.isSafeRelativePath(zipDirToken.removeSuffix("/"))) {
                                fail("unsafe archive folder '$zipDirToken'")
                            }
                            zipDirToken
                        }
                        val files = fileList.split(',')
                        for (file in files) {
                            // Плоское безопасное имя: файл окажется прямо в папке рендерера, а не где-то вне её.
                            if (!SEGMENT.matches(file) || file == "." || file == ".." || file.startsWith(".")) fail("unsafe file name '$file'")
                        }
                        if (files.toSet().size != files.size) fail("duplicate file in '$fileList'")
                        if (zipDir == null && files.size != 1) fail("a plain download carries exactly one file")
                        if (zipDir == null && repoPath.substringAfterLast('/') != files[0]) fail("file '${files[0]}' is not '$repoPath'")
                        val all = downloads.getValue(id)
                        if (all.any { d -> d.files.any { it in files } }) fail("a file is listed twice in '$id'")
                        all += RendererDownload(size, sha, repoPath, zipDir, files)
                    }
                    else -> fail("unknown line '${parts[0]}'")
                }
            }

            if (!formatSeen) throw RendererManifestException("renderers-manifest.txt: the 'mcl-renderers' header is missing")
            val abiValue = abi ?: throw RendererManifestException("renderers-manifest.txt: 'abi' is missing")
            val upstreamValue = upstream ?: throw RendererManifestException("renderers-manifest.txt: 'upstream' is missing")
            val packages = order.map { id ->
                val list = downloads.getValue(id)
                if (list.isEmpty()) throw RendererManifestException("renderers-manifest.txt: renderer '$id' has nothing to download")
                RendererPackage(id, list.toList())
            }
            if (packages.isEmpty()) throw RendererManifestException("renderers-manifest.txt: no renderers")
            return RendererManifest(abiValue, upstreamValue, packages)
        }
    }
}
