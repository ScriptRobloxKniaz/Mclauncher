package com.mclauncher.engine

import com.mclauncher.engine.launch.RendererProfile
import java.io.File

/**
 * Готово ли ядро к запуску. [missing] — человекочитаемый список того, чего не хватает (по-английски: это текст для
 * лога и поддержки, а не для экрана); пуст, когда всё на месте.
 *
 * @property nativeLibrariesMissing не хватает файлов из папки нативных библиотек приложения. Их кладёт в APK сборка, а не
 *   кнопка «Установить ядро»: значит, установлен APK без ядра или без нативной части, и распаковка компонентов не поможет;
 * @property rendererMissing не хватает файлов выбранного рендерера: он ещё не скачан (см. `EngineLayout.rendererDir`).
 */
data class CoreStatus(
    val missing: List<String>,
    val nativeLibrariesMissing: Boolean = false,
    val rendererMissing: Boolean = false,
) {
    val isReady: Boolean get() = missing.isEmpty()
}

/**
 * Проверка состава ядра на диске: нативные библиотеки приложения, распакованные компоненты и Java-рантайм.
 * Только проверка наличия файлов — работоспособность библиотек подтверждается лишь запуском на устройстве.
 */
object EngineCore {

    /**
     * Что нужно именно для запуска версии с таким [lwjgl] и Java [javaMajor].
     * @param renderer если задан, нужны ещё и скачанные библиотеки этого рендерера (`libgl4es_114.so`; у Zink их несколько)
     */
    fun check(
        layout: EngineLayout,
        lwjgl: LwjglRequirement,
        javaMajor: Int,
        renderer: RendererProfile? = null,
    ): CoreStatus {
        val missing = ArrayList<String>()
        var nativeLibrariesMissing = false
        var rendererMissing = false

        fun require(file: File, what: String) {
            if (!file.isFile) missing += "$what (${file.path})"
        }

        fun requireNative(name: String, what: String) {
            val file = File(layout.nativeLibraryDir, name)
            if (!file.isFile) {
                nativeLibrariesMissing = true
                missing += "$what (${file.path})"
            }
        }

        // Библиотеки, которые Android кладёт в папку нативных библиотек приложения (jniLibs).
        requireNative("libpojavexec.so", "Pojav bridge library")
        requireNative("libopenal.so", "OpenAL library")
        // Рендерер приложение скачивает при первом запуске в свою папку.
        if (renderer != null) {
            for (name in renderer.requiredLibraries) {
                val file = layout.rendererLibrary(renderer.id, name)
                if (!file.isFile) {
                    rendererMissing = true
                    missing += "${renderer.displayName} renderer library, not downloaded (${file.path})"
                }
            }
        }

        // Компоненты, которые распаковываются из ассетов при первом запуске.
        val lwjglDir = layout.lwjglDir(lwjgl.lwjgl)
        require(File(lwjglDir, "lwjgl.jar"), "LWJGL ${lwjgl.lwjgl.dirName} core jar")
        require(File(layout.lwjglNativesDir(lwjgl.lwjgl), "liblwjgl.so"), "LWJGL ${lwjgl.lwjgl.dirName} natives for ${layout.abi}")
        require(layout.launchWrapperJar, "Launch wrapper")
        require(layout.libPatcherJar, "Library patcher")

        val component = JavaRuntimes.componentFor(javaMajor)
        if (component == null) {
            missing += "Java runtime for Java $javaMajor (the core ships ${JavaRuntimes.AVAILABLE})"
        } else {
            require(layout.javaExecutable(component), "Java $component runtime")
        }
        return CoreStatus(missing, nativeLibrariesMissing, rendererMissing)
    }
}
