package com.mclauncher.engine

import java.io.File

/*
 * Раскладка файлов ядра на диске. Имена папок и файлов повторяют ZalithLauncher 2 (`components/…`, `runtimes/…`),
 * чтобы их поставляемые архивы распаковывались как есть, — см. docs/ENGINE.md и THIRD_PARTY_NOTICES.md.
 */

/**
 * Какой из поставляемых Java-рантаймов нужен версии игры.
 * В ядре есть 8, 17, 21 и 25; Mojang указывает точную версию (например, 16 у 1.17), поэтому берётся ближайший
 * не меньший.
 */
object JavaRuntimes {
    val AVAILABLE: List<Int> = listOf(8, 17, 21, 25)

    /** `null`, если версия новее всех поставляемых рантаймов. */
    fun componentFor(requiredMajor: Int): Int? = AVAILABLE.firstOrNull { it >= requiredMajor }
}

/**
 * Где лежат распакованные компоненты ядра.
 *
 * Класс только строит пути (и читает список jar'ов LWJGL), поэтому проверяется обычными JVM-тестами.
 * Распаковка архивов из ассетов приложения — задача 4.7b.
 *
 * @param componentsDir корень компонентов: `lwjgl/<версия>/…`, `launcher/…`, `auth_libs/…`;
 * @param runtimesDir распакованные рантаймы Java: `jre-8`, `jre-17`, `jre-21`, `jre-25`;
 * @param nativeLibraryDir папка нативных библиотек приложения (`ApplicationInfo.nativeLibraryDir`): сюда Android
 *   кладёт `libpojavexec.so`, `libopenal.so` и остальное из `jniLibs`;
 * @param abi имя папки ABI в компонентах: `arm64-v8a`, `armeabi-v7a`, `x86`, `x86_64` (см. [abiDirName]);
 * @param renderersDir скачанные рендереры: `<renderersDir>/<id рендерера>/<библиотеки>` (см. [rendererDir]). Это не
 *   `nativeLibraryDir`: рендереры приложение скачивает при первом запуске, а не получает в составе APK. По умолчанию —
 *   `renderers` рядом с папкой компонентов.
 */
class EngineLayout(
    val componentsDir: File,
    val runtimesDir: File,
    val nativeLibraryDir: File,
    val abi: String,
    val renderersDir: File = File(componentsDir.absoluteFile.parentFile ?: componentsDir.absoluteFile, "renderers"),
) {
    /** Папка одного рендерера (по [com.mclauncher.engine.launch.RendererProfile.id]): в ней лежат все его библиотеки. */
    fun rendererDir(rendererId: String): File = File(renderersDir, rendererId)

    /** Библиотека рендерера [name] на устройстве (может отсутствовать, пока рендерер не скачан). */
    fun rendererLibrary(rendererId: String, name: String): File = File(rendererDir(rendererId), name)

    fun lwjglDir(version: LwjglVersion): File = File(componentsDir, "lwjgl/${version.dirName}")

    /** Нативные библиотеки LWJGL под ABI устройства. Единственное место, откуда игра берёт нативы. */
    fun lwjglNativesDir(version: LwjglVersion): File = File(lwjglDir(version), "natives/$abi")

    /** Jar'ы LWJGL в порядке classpath (см. [orderLwjglJars]); пусто, если компонент ещё не распакован. */
    fun lwjglJars(requirement: LwjglRequirement): List<File> {
        val dir = lwjglDir(requirement.lwjgl)
        val names = dir.list()?.toList().orEmpty()
        return orderLwjglJars(names, requirement.lwjgl, requirement.legacyLwjgl2).map { File(dir, it) }
    }

    /** `mio.Wrapper`: запускает настоящий главный класс игры, который передаётся ему первым аргументом. */
    val launchWrapperJar: File get() = File(componentsDir, "launcher/MioLaunchWrapper.jar")

    /** Java-агент, который подправляет библиотеки игры при загрузке. Подключается до `-cp`. */
    val libPatcherJar: File get() = File(componentsDir, "launcher/MioLibPatcher.jar")

    /** Java-агент для оффлайн-скина и серверов авторизации (вариант C из docs/OFFLINE_SKINS.md). */
    val authlibInjectorJar: File get() = File(componentsDir, "auth_libs/authlib-injector.jar")

    /** Папка рантайма, например `…/runtimes/jre-17`. */
    fun runtimeDir(component: Int): File = File(runtimesDir, "jre-$component")

    /**
     * Значение `java.home`. Определяется по тому, что лежит на диске, как у Zalith (`RuntimesManager.isJDK8`,
     * `Launcher.getJavaHome`): вложенная папка `jre` используется только у полного JDK 8 — когда есть и `jre/`, и
     * `bin/javac`. Поставляемый рантайм Java 8 — плоский (`bin/java`, `lib/aarch64/…` прямо в корне; проверено по
     * архивам `runtimes/jre-8` на закреплённой ревизии), поэтому его `java.home` — корень, как у 17 и 21.
     */
    fun javaHome(component: Int): File {
        val root = runtimeDir(component)
        return if (hasNestedJre(root)) File(root, "jre") else root
    }

    private fun hasNestedJre(root: File): Boolean =
        File(root, "jre").isDirectory && File(root, "bin/javac").exists()

    fun javaExecutable(component: Int): File = File(File(runtimeDir(component), "bin"), "java")

    companion object {
        /** По списку ABI устройства (`Build.SUPPORTED_ABIS`) — первый из поддерживаемых ядром; `null`, если ни одного. */
        fun abiDirName(supportedAbis: List<String>): String? =
            supportedAbis.firstOrNull { it in SUPPORTED_ABIS }

        val SUPPORTED_ABIS = listOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86")
    }
}
