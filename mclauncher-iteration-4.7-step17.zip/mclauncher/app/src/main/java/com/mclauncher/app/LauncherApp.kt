package com.mclauncher.app

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.os.Build
import android.util.Log
import com.mclauncher.app.core.CoreInstallManager
import com.mclauncher.app.data.account.AccountRepository
import com.mclauncher.app.data.background.BackgroundImageStore
import com.mclauncher.app.data.background.BackgroundVideoStore
import com.mclauncher.app.data.db.LauncherDatabase
import com.mclauncher.app.data.net.HttpSource
import com.mclauncher.app.data.net.UrlConnectionHttpSource
import com.mclauncher.app.data.settings.LaunchSettings
import com.mclauncher.app.data.settings.SettingsRepository
import com.mclauncher.app.data.skin.SkinRepository
import com.mclauncher.app.data.skin.SkinStore
import com.mclauncher.app.data.versions.EngineLibraryPolicy
import com.mclauncher.app.data.versions.GameVersion
import com.mclauncher.app.data.versions.InstallManager
import com.mclauncher.app.data.versions.InstallPlanner
import com.mclauncher.app.data.versions.OsEnvironment
import com.mclauncher.app.data.versions.VersionCatalog
import com.mclauncher.app.data.versions.VersionInstaller
import com.mclauncher.app.data.versions.VersionLayout
import com.mclauncher.app.data.versions.VersionLibrary
import com.mclauncher.app.data.versions.VersionParser
import com.mclauncher.app.data.versions.VersionStore
import com.mclauncher.app.download.DownloadService
import com.mclauncher.app.game.CrashRecorder
import com.mclauncher.app.game.GameActivity
import com.mclauncher.app.launch.ApkInspector
import com.mclauncher.app.launch.GameDirectories
import com.mclauncher.app.launch.GameEngine
import com.mclauncher.app.launch.GameLauncher
import com.mclauncher.app.launch.LaunchSpecFactory
import com.mclauncher.app.launch.PojavGameEngine
import com.mclauncher.app.renderer.DiskRendererBackend
import com.mclauncher.app.renderer.RendererInstaller
import com.mclauncher.app.renderer.RendererManager
import com.mclauncher.app.renderer.RendererStore
import com.mclauncher.engine.EngineEnvironment
import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.launch.GameExitReport
import com.mclauncher.engine.renderer.RendererManifest
import com.mclauncher.engine.renderer.RendererManifestException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.TimeZone

/**
 * Точка входа процесса и «ручной DI»: тяжёлые объекты создаются лениво и живут,
 * пока жив процесс. База открывается при первом запросе, и Room делает это вне главного потока.
 */
class LauncherApp : Application() {

    override fun onCreate() {
        super.onCreate()
        // До первого сетевого запроса процесса: иначе платформа оставит пул из 5 соединений, и параллельные загрузки
        // будут заново устанавливать соединения вместо повторного использования.
        UrlConnectionHttpSource.enlargeConnectionPool()
        // Причина любого вылета (и лаунчера, и процесса игры) сохраняется и показывается при следующем показе лаунчера.
        val gameProcess = isGameProcess()
        CrashRecorder.install(label = if (gameProcess) "game" else "launcher") { gameDirectories.logs }
        // Пока идёт установка версии, держим процесс службой переднего плана (в процессе игры она не нужна).
        if (!gameProcess) {
            DownloadService.watch(this, installManager.state, appScope)
            // Какие рендереры уже скачаны: по этому решается, показывать ли окно «Скачайте рендереры» (читает диск в фоне).
            rendererManager.refresh()
        }
    }

    /** Приложение запускается отдельным процессом `:game` для экрана игры; Application создаётся в каждом процессе. */
    private fun isGameProcess(): Boolean {
        val name = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            Application.getProcessName()
        } else {
            runCatching { File("/proc/self/cmdline").readText().trim('\u0000') }.getOrNull()
        }
        return name?.endsWith(":game") == true
    }

    val settings: SettingsRepository by lazy { SettingsRepository(this) }
    val backgroundStore: BackgroundImageStore by lazy { BackgroundImageStore(this) }
    val backgroundVideoStore: BackgroundVideoStore by lazy { BackgroundVideoStore(this) }

    private val database: LauncherDatabase by lazy { LauncherDatabase.create(this) }
    val accountRepository: AccountRepository by lazy { AccountRepository(database) }

    private val skinStore: SkinStore by lazy { SkinStore(this) }
    val skinRepository: SkinRepository by lazy { SkinRepository(this, accountRepository, skinStore) }

    /** Папка `.minecraft` (app-specific хранилище). Создаётся при запуске игры и при импорте модов. */
    val gameDirectories: GameDirectories by lazy { GameDirectories.forContext(this) }

    // --- Установка версий игры (итерация 4.6) ---

    /** Живёт, пока жив процесс: установка версии не должна обрываться при уходе с экрана. */
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Единственная точка выхода в сеть для загрузок. Идентификатор клиента не содержит данных об устройстве. */
    val httpSource: HttpSource by lazy { UrlConnectionHttpSource(userAgent = "MCLauncher/${BuildConfig.VERSION_NAME}") }

    private val versionLayout: VersionLayout by lazy { VersionLayout(gameDirectories) }
    val versionStore: VersionStore by lazy { VersionStore(versionLayout) }

    /** Список версий Mojang; последняя удачная копия лежит в кэше приложения (его можно очистить без вреда). */
    val versionCatalog: VersionCatalog by lazy { VersionCatalog(httpSource, File(cacheDir, "version_manifest_v2.json")) }

    /** Что установлено и что выбрано для кнопки «Играть». */
    val versionLibrary: VersionLibrary by lazy { VersionLibrary(versionStore, settings) }

    /** Для правил библиотек Android — это «linux» с архитектурой устройства. */
    private val osEnvironment: OsEnvironment by lazy { OsEnvironment.android(Build.SUPPORTED_ABIS.toList()) }

    /**
     * Один отбор библиотек и для установки, и для запуска: установленное и запускаемое не разойдутся.
     * LWJGL и его нативы приносит ядро, а три устаревшие библиотеки заменяются (docs/ENGINE.md).
     */
    private val installPlanner: InstallPlanner by lazy {
        InstallPlanner(
            layout = versionLayout,
            env = osEnvironment,
            libraryFilter = EngineLibraryPolicy::isNeeded,
            libraryReplacement = EngineLibraryPolicy::replacement,
        )
    }

    /** Установщик с числом потоков из настроек: создаётся на каждую установку, поэтому смена настройки действует сразу. */
    private fun versionInstaller(threads: Int): VersionInstaller =
        VersionInstaller(
            directories = gameDirectories,
            http = httpSource,
            env = osEnvironment,
            layout = versionLayout,
            store = versionStore,
            planner = installPlanner,
            concurrency = threads,
            largeFileConcurrency = LaunchSettings.largeFileConcurrency(threads),
        )

    private suspend fun downloadThreads(): Int = try {
        settings.launch.first().safeDownloadThreads
    } catch (e: IOException) {
        LaunchSettings.DEFAULT_DOWNLOAD_THREADS
    }

    val installManager: InstallManager by lazy {
        InstallManager(
            install = { entry, onProgress ->
                versionInstaller(downloadThreads()).install(entry, onProgress).also { versionLibrary.onInstallResult(it) }
            },
            scope = appScope,
        )
    }

    // --- Ядро игры (итерация 4.7) ---

    /**
     * Раскладка компонентов ядра во внутреннем хранилище. `null`, если процессор устройства ядро не поддерживает.
     * Компоненты (рантаймы Java, LWJGL, нативы) приходят в ассетах APK и распаковываются [coreManager]; ассеты в APK
     * появляются, только если перед сборкой выполнен `scripts/fetch_core.py --install` (docs/ENGINE.md).
     */
    private val engineLayout: EngineLayout? by lazy {
        val abi = EngineLayout.abiDirName(Build.SUPPORTED_ABIS.toList()) ?: return@lazy null
        EngineLayout(
            componentsDir = File(filesDir, "engine/components"),
            runtimesDir = File(filesDir, "engine/runtimes"),
            nativeLibraryDir = File(applicationInfo.nativeLibraryDir),
            abi = abi,
        )
    }

    /** Установка игрового ядра из ассетов APK в фоне (WorkManager + служба переднего плана). */
    val coreManager: CoreInstallManager by lazy {
        CoreInstallManager(
            context = this,
            layout = engineLayout,
            deviceAbi = Build.SUPPORTED_ABIS.firstOrNull(),
            nativeLibraryDir = File(applicationInfo.nativeLibraryDir),
        )
    }

    /**
     * Рендереры не входят в APK: приложение скачивает их при первом входе в `files/engine/renderers` (список, размеры и
     * суммы лежат в ассетах, `renderers/renderers-manifest.txt`). Скачивание идёт в процессе приложения и не обрывается
     * при уходе с экрана. Если манифеста в сборке нет или процессор не подходит, скачивать нечего (`available = false`).
     */
    val rendererManager: RendererManager by lazy {
        RendererManager(
            backendLoader = {
                val layout = engineLayout
                val manifest = readRendererManifest()
                if (layout == null || manifest == null || manifest.abi != layout.abi) {
                    null
                } else {
                    DiskRendererBackend(manifest, RendererStore(layout, manifest), RendererInstaller(httpSource, layout, manifest))
                }
            },
            scope = appScope,
        )
    }

    /** Манифест рендереров из ассетов; `null`, если файла нет или он не читается (тогда скачивать нечего). */
    private fun readRendererManifest(): RendererManifest? = try {
        RendererManifest.parse(assets.open(RendererManifest.ASSET_NAME).bufferedReader().use { it.readText() })
    } catch (_: IOException) {
        null
    } catch (e: RendererManifestException) {
        Log.e("Renderers", "The renderer manifest in the APK is unusable: ${e.message}")
        null
    }

    private fun engineEnvironment(directories: GameDirectories): EngineEnvironment {
        val metrics = resources.displayMetrics
        val locale = Locale.getDefault()
        return EngineEnvironment(
            gameDir = directories.root,
            userHome = directories.root.parentFile ?: directories.root,
            cacheDir = File(cacheDir, "engine"),
            timezone = TimeZone.getDefault().id,
            androidRelease = Build.VERSION.RELEASE,
            // Экран всегда альбомный, но порядок сторон не должен ломать запуск, если это изменится.
            screenWidth = maxOf(metrics.widthPixels, metrics.heightPixels),
            screenHeight = minOf(metrics.widthPixels, metrics.heightPixels),
            cpuCores = Runtime.getRuntime().availableProcessors(),
            language = locale.language.takeIf { it.isNotEmpty() },
            country = locale.country.takeIf { it.isNotEmpty() },
        )
    }

    /**
     * Ядро игры. Собирает команду, проверяет состав ядра и открывает экран игры в процессе `:game` (docs/ENGINE.md).
     * Остальной код о запуске знает только интерфейс [GameEngine].
     */
    val gameEngine: GameEngine by lazy {
        PojavGameEngine(
            specFactory = LaunchSpecFactory(
                layout = versionLayout,
                env = osEnvironment,
                planner = installPlanner,
                launcherName = LAUNCHER_NAME,
                launcherVersion = BuildConfig.VERSION_NAME,
            ),
            readVersion = { id: String -> readVersion(id) },
            layout = { engineLayout },
            environment = ::engineEnvironment,
            startGame = { plan -> startActivity(GameActivity.intent(this, plan)) },
            isGameRunning = ::isGameProcessAlive,
            apkSummary = { ApkInspector.summaryOrNull(File(applicationInfo.sourceDir), File(applicationInfo.nativeLibraryDir)) },
        )
    }

    /** Жив ли процесс игры (`<пакет>:game`). Для приложения система показывает только его собственные процессы. */
    private fun isGameProcessAlive(): Boolean {
        val manager = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return false
        val gameProcess = "$packageName:game"
        return manager.runningAppProcesses.orEmpty().any { it.processName == gameProcess }
    }

    /**
     * Итог прошлой игры, если она закрылась с ошибкой или упала (`null` — игра ещё идёт, не запускалась или закрыта
     * нормально). Каждый итог отдаётся один раз. Читает диск: вызывать вне главного потока.
     */
    fun consumeGameExit(): GameExitReport? = GameExitReport.consume(gameDirectories.logs, ::isGameProcessAlive)

    private fun readVersion(id: String): GameVersion = VersionParser.parseVersion(versionLayout.versionJson(id).readText())

    val gameLauncher: GameLauncher by lazy {
        GameLauncher(gameEngine, gameDirectories, isVersionInstalled = versionStore::isInstalled)
    }

    private companion object {
        /** Имя, которое видят игра и серверы. Отличается от «ZalithLauncher» — это требование его лицензии (§7). */
        const val LAUNCHER_NAME = "MCLauncher"
    }
}
