package com.mclauncher.app.renderer

import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.renderer.RendererManifest
import com.mclauncher.engine.renderer.RendererPackage
import java.io.File
import java.io.IOException

/**
 * Что из рендереров уже скачано. Рендерер считается скачанным, только если в его папке (`EngineLayout.rendererDir`) лежит
 * отметка [MARKER], совпадающая с манифестом, и все его файлы на месте и не пусты. Отметку пишет установщик последней, и
 * вся папка попадает на место одним переименованием, поэтому недокачанный рендерер скачанным не выглядит.
 *
 * Если приложение обновилось и манифест требует другие файлы (изменились суммы), прежняя установка перестаёт совпадать
 * с отметкой, и рендерер нужно скачать заново. Запуск при этом проверяет только наличие файлов (`EngineCore.check`).
 *
 * Читает и удаляет файлы: вызывать вне главного потока.
 */
class RendererStore(private val layout: EngineLayout, private val manifest: RendererManifest) {

    fun isInstalled(rendererId: String): Boolean {
        val pkg = manifest.packageFor(rendererId) ?: return false
        val dir = layout.rendererDir(rendererId)
        val marker = File(dir, MARKER)
        val text = try {
            if (marker.isFile) marker.readText(Charsets.UTF_8) else return false
        } catch (_: IOException) {
            return false
        }
        if (text != markerText(pkg)) return false
        return pkg.files.all { name -> File(dir, name).let { it.isFile && it.length() > 0 } }
    }

    /** Удаляет рендерер с диска. `true`, если после этого его папки нет. */
    fun delete(rendererId: String): Boolean {
        val dir = layout.rendererDir(rendererId)
        return !dir.exists() || dir.deleteRecursively()
    }

    companion object {
        /** Имя файла-отметки внутри папки рендерера. Точка в начале: это не библиотека. */
        const val MARKER = ".installed"

        /** Содержимое отметки: формат и суммы скачанных файлов из манифеста. */
        fun markerText(pkg: RendererPackage): String =
            "mcl-renderer 1\n" + pkg.downloads.joinToString("") { it.sha256 + "\n" }
    }
}
