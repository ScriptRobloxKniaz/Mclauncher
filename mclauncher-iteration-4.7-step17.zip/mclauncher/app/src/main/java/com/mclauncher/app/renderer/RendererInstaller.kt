package com.mclauncher.app.renderer

import com.mclauncher.app.data.net.HttpSource
import com.mclauncher.app.data.net.HttpStatusException
import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.renderer.RendererDownload
import com.mclauncher.engine.renderer.RendererManifest
import com.mclauncher.engine.renderer.RendererPackage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.Files
import java.security.MessageDigest
import java.util.zip.ZipException
import java.util.zip.ZipFile

/** Рендерер не скачан. [reason] определяет, повторять ли попытку и что сказать пользователю. */
class RendererInstallException(
    val reason: Reason,
    message: String,
    val status: Int? = null,
    cause: Throwable? = null,
) : IOException(message, cause) {

    enum class Reason {
        /** Нет связи или обрыв. */
        NETWORK,

        /** Сервер ответил кодом не из 2xx. */
        HTTP,

        /** Сумма SHA-256 скачанного файла не совпала с манифестом. */
        HASH,

        /** Размер скачанного файла не совпал с манифестом. */
        SIZE,

        /** На устройстве не хватает места. */
        NO_SPACE,

        /** Файл скачан и проверен, но внутри нет того, что обещает манифест (или это не библиотека). */
        CORRUPT,

        /** Не получилось записать файлы на устройство. */
        STORAGE,

        /** В манифесте такого рендерера нет. */
        UNKNOWN_RENDERER,
    }

    /** Повторять имеет смысл при сбоях сети и сервера и при испорченных данных, а не при «нет файла» или «нет места». */
    val isRetryable: Boolean
        get() = when (reason) {
            Reason.NETWORK, Reason.HASH, Reason.SIZE -> true
            Reason.HTTP -> status != null && (status >= 500 || status == 408 || status == 429)
            Reason.NO_SPACE, Reason.CORRUPT, Reason.STORAGE, Reason.UNKNOWN_RENDERER -> false
        }
}

/**
 * Скачивает рендерер на устройство: файлы из манифеста во временную папку, проверка размера и SHA-256, распаковка нужных
 * файлов из AAR, проверка, что это библиотеки (ELF), и перенос готовой папки на место одним переименованием.
 *
 * Адрес берётся из закреплённой ревизии апстрима ([RendererManifest.urlOf]); скачанное принимается только при совпадении
 * с суммой из манифеста, поэтому подмена по дороге не пройдёт. Не бросает ничего, кроме [RendererInstallException] и
 * отмены корутины; при любом исходе временная папка удаляется.
 *
 * @param onBytes в [install]: сколько байт принято с прошлого вызова; при повторе неудачной попытки значение
 *   отрицательное (откат), чтобы прогресс не уходил за 100%.
 */
class RendererInstaller(
    private val http: HttpSource,
    private val layout: EngineLayout,
    private val manifest: RendererManifest,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val maxAttempts: Int = 3,
    private val retryDelayMs: (attempt: Int) -> Long = { attempt -> 400L shl (attempt - 1) },
    private val freeSpace: (File) -> Long = { it.usableSpace },
) {

    suspend fun install(rendererId: String, onBytes: (Long) -> Unit = {}) {
        val pkg = manifest.packageFor(rendererId)
            ?: throw RendererInstallException(RendererInstallException.Reason.UNKNOWN_RENDERER, "No such renderer in the manifest: $rendererId")
        withContext(ioDispatcher) {
            val root = layout.renderersDir
            val work = File(root, ".tmp-$rendererId")
            try {
                prepare(root, work, pkg)
                val staging = File(work, "files")
                if (!staging.mkdirs() && !staging.isDirectory) storage("Cannot create ${staging.path}")

                for (download in pkg.downloads) {
                    val archive = File(work, download.fileName)
                    fetchVerified(download, archive, onBytes)
                    if (download.zipDir == null) {
                        move(archive, File(staging, download.files.single()))
                    } else {
                        extract(archive, download, staging)
                        archive.delete()
                    }
                }
                checkLibraries(pkg, staging)
                try {
                    File(staging, RendererStore.MARKER).writeText(RendererStore.markerText(pkg), Charsets.UTF_8)
                } catch (e: IOException) {
                    throw RendererInstallException(RendererInstallException.Reason.STORAGE, "Cannot write the marker", cause = e)
                }
                swapIn(staging, layout.rendererDir(rendererId))
            } finally {
                work.deleteRecursively()
            }
        }
    }

    /** Корень рендереров создан, прежний мусор убран, места хватает. */
    private fun prepare(root: File, work: File, pkg: RendererPackage) {
        if (!root.isDirectory && !root.mkdirs() && !root.isDirectory) storage("Cannot create ${root.path}")
        work.deleteRecursively()
        if (!work.mkdirs() && !work.isDirectory) storage("Cannot create ${work.path}")
        // Архив и распакованные файлы лежат рядом, пока идёт установка; с запасом на файловую систему.
        val needed = pkg.totalBytes * SPACE_FACTOR + SPACE_MARGIN
        if (freeSpace(work) < needed) {
            throw RendererInstallException(RendererInstallException.Reason.NO_SPACE, "Need about $needed bytes of free space")
        }
    }

    private suspend fun fetchVerified(download: RendererDownload, file: File, onBytes: (Long) -> Unit) {
        var attempt = 0
        while (true) {
            attempt++
            val received = LongArray(1)
            try {
                fetchOnce(download, file) { n ->
                    received[0] += n
                    onBytes(n)
                }
                return
            } catch (e: RendererInstallException) {
                onBytes(-received[0])
                if (!e.isRetryable || attempt >= maxAttempts) throw e
                delay(retryDelayMs(attempt))
            }
        }
    }

    private suspend fun fetchOnce(download: RendererDownload, file: File, report: (Long) -> Unit) {
        try {
            http.get(manifest.urlOf(download)) { body ->
                val digest = MessageDigest.getInstance("SHA-256")
                var total = 0L
                val out = try {
                    FileOutputStream(file)
                } catch (e: IOException) {
                    throw RendererInstallException(RendererInstallException.Reason.STORAGE, "Cannot write ${file.path}", cause = e)
                }
                out.use {
                    val buffer = ByteArray(BUFFER_SIZE)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = body.stream.read(buffer) // сбой чтения — это сеть
                        if (n < 0) break
                        total += n
                        // Сервер шлёт больше, чем в манифесте: не заполняем диск, ответ всё равно будет отвергнут.
                        if (total > download.size) {
                            throw RendererInstallException(RendererInstallException.Reason.SIZE, "More than ${download.size} bytes received: ${download.fileName}")
                        }
                        try {
                            out.write(buffer, 0, n)
                        } catch (e: IOException) {
                            throw RendererInstallException(RendererInstallException.Reason.STORAGE, "Cannot write ${file.path}", cause = e)
                        }
                        digest.update(buffer, 0, n)
                        report(n.toLong())
                    }
                }
                if (total != download.size) {
                    throw RendererInstallException(RendererInstallException.Reason.SIZE, "Expected ${download.size} bytes but received $total: ${download.fileName}")
                }
                if (!hex(digest.digest()).equals(download.sha256, ignoreCase = true)) {
                    throw RendererInstallException(RendererInstallException.Reason.HASH, "SHA-256 mismatch: ${download.fileName}")
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: RendererInstallException) {
            throw e
        } catch (e: HttpStatusException) {
            throw RendererInstallException(RendererInstallException.Reason.HTTP, e.message.orEmpty(), status = e.status, cause = e)
        } catch (e: IOException) {
            throw RendererInstallException(RendererInstallException.Reason.NETWORK, e.message ?: "Network error", cause = e)
        }
    }

    /** Достаёт из AAR файлы [RendererDownload.files] из папки [RendererDownload.zipDir]; остальное содержимое не трогает. */
    private fun extract(archive: File, download: RendererDownload, into: File) {
        val zipDir = download.zipDir ?: return
        try {
            ZipFile(archive).use { zip ->
                for (name in download.files) {
                    val entry = zip.getEntry(zipDir + name)
                        ?: throw RendererInstallException(RendererInstallException.Reason.CORRUPT, "$zipDir$name is missing in ${archive.name}")
                    if (entry.isDirectory) {
                        throw RendererInstallException(RendererInstallException.Reason.CORRUPT, "$zipDir$name is a folder in ${archive.name}")
                    }
                    writeEntry(zip.getInputStream(entry), File(into, name))
                }
            }
        } catch (e: ZipException) {
            throw RendererInstallException(RendererInstallException.Reason.CORRUPT, "Not a valid archive: ${archive.name}", cause = e)
        } catch (e: IOException) {
            if (e is RendererInstallException) throw e
            throw RendererInstallException(RendererInstallException.Reason.STORAGE, "Cannot unpack ${archive.name}", cause = e)
        }
    }

    /** Копирует запись архива в файл; размер записи не доверяется заранее: считаются реальные байты. */
    private fun writeEntry(input: java.io.InputStream, target: File) {
        // Имена в манифесте плоские (см. RendererManifest.parse), но запись вне папки недопустима ни при каких условиях.
        if (target.parentFile == null || target.name.isEmpty()) {
            throw RendererInstallException(RendererInstallException.Reason.CORRUPT, "Bad target name: ${target.path}")
        }
        input.use { source ->
            FileOutputStream(target).use { out ->
                val buffer = ByteArray(BUFFER_SIZE)
                var total = 0L
                while (true) {
                    val n = source.read(buffer)
                    if (n < 0) break
                    total += n
                    if (total > MAX_LIBRARY_BYTES) {
                        throw RendererInstallException(RendererInstallException.Reason.CORRUPT, "${target.name} is unreasonably large")
                    }
                    out.write(buffer, 0, n)
                }
            }
        }
    }

    /** Каждый обещанный файл на месте, не пуст и начинается с сигнатуры ELF. */
    private fun checkLibraries(pkg: RendererPackage, dir: File) {
        for (name in pkg.files) {
            val file = File(dir, name)
            if (!file.isFile || file.length() == 0L) {
                throw RendererInstallException(RendererInstallException.Reason.CORRUPT, "$name is missing or empty after unpacking")
            }
            val head = ByteArray(ELF_MAGIC.size)
            val read = try {
                FileInputStream(file).use { it.read(head) }
            } catch (e: IOException) {
                throw RendererInstallException(RendererInstallException.Reason.STORAGE, "Cannot read ${file.path}", cause = e)
            }
            if (read != ELF_MAGIC.size || !head.contentEquals(ELF_MAGIC)) {
                throw RendererInstallException(RendererInstallException.Reason.CORRUPT, "$name is not a native library")
            }
            // Android 14+ для динамически загружаемого кода требует файлов только для чтения; удалить такой файл можно
            // (это право папки), так что «Удалить» и повторное скачивание работают как раньше.
            file.setReadOnly()
        }
    }

    /** Заменяет папку рендерера готовой: старая (если была) удаляется, новая переименовывается на её место. */
    private fun swapIn(staging: File, target: File) {
        if (target.exists() && !target.deleteRecursively()) storage("Cannot remove the old ${target.path}")
        try {
            Files.move(staging.toPath(), target.toPath())
        } catch (e: IOException) {
            throw RendererInstallException(RendererInstallException.Reason.STORAGE, "Cannot move the renderer into ${target.path}", cause = e)
        }
    }

    private fun move(from: File, to: File) {
        try {
            Files.move(from.toPath(), to.toPath())
        } catch (e: IOException) {
            throw RendererInstallException(RendererInstallException.Reason.STORAGE, "Cannot move ${from.name} into place", cause = e)
        }
    }

    private fun storage(message: String): Nothing =
        throw RendererInstallException(RendererInstallException.Reason.STORAGE, message)

    private fun hex(bytes: ByteArray): String {
        val chars = CharArray(bytes.size * 2)
        for (i in bytes.indices) {
            val v = bytes[i].toInt() and 0xFF
            chars[i * 2] = HEX[v ushr 4]
            chars[i * 2 + 1] = HEX[v and 0x0F]
        }
        return String(chars)
    }

    private companion object {
        const val BUFFER_SIZE = 32 * 1024

        /** Во сколько раз нужно больше места, чем размер скачиваемого: архив + распакованное + запас. */
        const val SPACE_FACTOR = 3L
        const val SPACE_MARGIN = 16L * 1024 * 1024

        /** Одна библиотека рендерера не бывает больше (самая большая, `libzink_dri.so`, около 12 МБ). */
        const val MAX_LIBRARY_BYTES = 128L * 1024 * 1024

        val ELF_MAGIC = byteArrayOf(0x7F, 'E'.code.toByte(), 'L'.code.toByte(), 'F'.code.toByte())
        val HEX = "0123456789abcdef".toCharArray()
    }
}
