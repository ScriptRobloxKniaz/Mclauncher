package com.mclauncher.app.launch

import java.io.File
import java.io.IOException
import java.util.zip.ZipFile

/** Какая именно сборка лаунчера установлена: по тому, что реально лежит в APK и на устройстве. */
enum class ApkBuild {
    /** Нет ядра в APK: обычная сборка (`MCLauncher-1-NO-GAME-CORE`). Игру запустить не может. */
    WITHOUT_CORE,

    /** Ядро есть, но нет нативной части (`libpojavexec.so` и/или `libopenal.so`). Игру запустить не может. */
    CORE_WITHOUT_NATIVES,

    /** Нужные файлы есть в APK, но не распакованы в папку нативных библиотек: установка повреждена. */
    NOT_EXTRACTED,

    /** Всё на месте (`MCLauncher-3-FULL-INSTALL-THIS`). */
    FULL,
}

/**
 * Содержимое установленного APK, важное для запуска игры.
 *
 * @property apkBytes размер APK;
 * @property hasCoreAssets есть ли в APK ядро (`assets/core/core-manifest.txt`);
 * @property nativeInApk имена файлов `.so` из папок `lib/<abi>/` APK (сводно по всем ABI);
 * @property nativeExtracted что лежит в папке нативных библиотек на устройстве (куда система распаковывает `lib/`).
 */
data class ApkContents(
    val apkBytes: Long,
    val hasCoreAssets: Boolean,
    val nativeInApk: Set<String>,
    val nativeExtracted: Set<String>,
) {
    private val hasPojavExec get() = POJAV_EXEC in nativeInApk
    private val hasOpenAl get() = OPENAL in nativeInApk

    val build: ApkBuild
        get() = when {
            !hasCoreAssets -> ApkBuild.WITHOUT_CORE
            !hasPojavExec || !hasOpenAl -> ApkBuild.CORE_WITHOUT_NATIVES
            POJAV_EXEC !in nativeExtracted || OPENAL !in nativeExtracted -> ApkBuild.NOT_EXTRACTED
            else -> ApkBuild.FULL
        }

    /** Несколько строк для отчёта: вывод и факты, на которых он основан. */
    fun summary(): String = buildString {
        append("APK: ")
        appendLine(
            when (build) {
                ApkBuild.WITHOUT_CORE -> "установлена обычная сборка БЕЗ ядра игры, запустить игру она не может. Нужен APK MCLauncher-3-FULL-INSTALL-THIS."
                ApkBuild.CORE_WITHOUT_NATIVES -> "в сборке есть ядро, но нет нативной части (libpojavexec.so и/или libopenal.so), запустить игру она не может. Нужен APK MCLauncher-3-FULL-INSTALL-THIS."
                ApkBuild.NOT_EXTRACTED -> "нужные файлы есть в APK, но система не распаковала их на устройство: переустановите APK."
                ApkBuild.FULL -> "полная сборка (ядро и нативная часть на месте)."
            },
        )
        appendLine("  размер APK: ${"%.1f".format(apkBytes / 1_048_576.0)} МБ")
        appendLine("  assets/core (ядро): ${yesNo(hasCoreAssets)}")
        appendLine("  в APK libpojavexec.so: ${yesNo(hasPojavExec)}; libopenal.so: ${yesNo(hasOpenAl)}")
        append("  на устройстве libpojavexec.so: ${yesNo(POJAV_EXEC in nativeExtracted)}; libopenal.so: ${yesNo(OPENAL in nativeExtracted)}")
    }

    private fun yesNo(value: Boolean) = if (value) "есть" else "НЕТ"

    companion object {
        const val POJAV_EXEC = "libpojavexec.so"
        const val OPENAL = "libopenal.so"
        const val CORE_MANIFEST = "assets/core/core-manifest.txt"
    }
}

/** Читает [ApkContents] из установленного APK и папки нативных библиотек. */
object ApkInspector {

    /** Бросает [IOException], если APK не читается; вызывающий решает, что с этим делать (отчёт без этого блока). */
    fun inspect(apk: File, nativeLibraryDir: File): ApkContents {
        var hasCore = false
        val inApk = HashSet<String>()
        ZipFile(apk).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val name = entries.nextElement().name
                if (name == ApkContents.CORE_MANIFEST) hasCore = true
                if (name.startsWith("lib/") && name.endsWith(".so")) inApk += name.substringAfterLast('/')
            }
        }
        val extracted = nativeLibraryDir.list()?.toSet().orEmpty()
        return ApkContents(apk.length(), hasCore, inApk, extracted)
    }

    /** Текст для отчёта или `null`, если APK прочитать нельзя (это не должно мешать самому отчёту). */
    fun summaryOrNull(apk: File, nativeLibraryDir: File): String? = try {
        inspect(apk, nativeLibraryDir).summary()
    } catch (e: IOException) {
        null
    } catch (e: SecurityException) {
        null
    }
}
