package com.mclauncher.app.ui.renderer

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mclauncher.app.LauncherApp
import com.mclauncher.app.launch.toProfile
import com.mclauncher.app.renderer.RendererSetupState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.IOException

/**
 * Скачиваемые рендереры для экранов: окна первого входа и раздела настроек. Сами скачивание и удаление живут в
 * `LauncherApp.rendererManager` (процесс приложения), поэтому не обрываются при смене экрана; здесь только доступ к ним.
 */
class RendererViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as LauncherApp
    private val manager = app.rendererManager
    private val settings = app.settings

    val state: StateFlow<RendererSetupState> = manager.state

    /** `RendererProfile.id` рендерера, выбранного в настройках графики, или `null`, пока настройки не прочитаны. */
    val selectedId: StateFlow<String?> = settings.graphics
        .map { it.effectiveRenderer.toProfile().id }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    /** Нажато ли «Позже» в окне первого входа; `null` — настройки ещё не прочитаны (окно в это время не показываем). */
    val setupDismissed: StateFlow<Boolean?> = settings.rendererSetupDismissed
        .map<Boolean, Boolean?> { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun refresh() = manager.refresh()

    fun download(ids: Collection<String>) = manager.download(ids)

    fun cancel() = manager.cancel()

    fun delete(rendererId: String) = manager.delete(rendererId)

    fun acknowledgeFailure() = manager.acknowledgeFailure()

    /** «Позже»: окно больше не появляется само; рендереры остаются в «Настройки → Рендереры». */
    fun dismissSetup() {
        viewModelScope.launch {
            try {
                settings.setRendererSetupDismissed(true)
            } catch (e: IOException) {
                Log.w(TAG, "Failed to save the renderer setup choice", e)
            }
        }
    }

    private companion object {
        const val TAG = "RendererViewModel"
    }
}
