package com.mclauncher.app.launch

import com.mclauncher.app.data.versions.GameVersion
import com.mclauncher.app.data.versions.PlanException
import com.mclauncher.app.data.versions.VersionParseException
import com.mclauncher.engine.CommandBuildException
import com.mclauncher.engine.EngineCore
import com.mclauncher.engine.EngineEnvironment
import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.LaunchCommandBuilder
import com.mclauncher.engine.launch.NativeLaunchPlan
import com.mclauncher.engine.launch.NativeLaunchPlanner
import com.mclauncher.engine.launch.RendererAdvisor
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * Игровое ядро на основе Pojav/Zalith (см. docs/ENGINE.md).
 *
 * Читает описание установленной версии, собирает команду запуска JVM, проверяет состав ядра (вместе с библиотеками
 * выбранного рендерера, [LaunchRequest.renderer]) и пишет отчёт
 * `logs/launch-preview.txt` (его можно приложить к сообщению об ошибке). Дальше:
 *  - ядро не готово → [LaunchFailure.CoreNotReady] со списком недостающего (игра не стартует);
 *  - предыдущая игра ещё идёт → [LaunchFailure.AlreadyLaunching];
 *  - иначе строится [NativeLaunchPlan] и передаётся в [startGame] — приложение открывает экран игры в отдельном
 *    процессе `:game`, где план выполняет `GameRunner`. Результат — `Started(placeholder = false)`.
 *
 * О том, чем закончилась игра, лаунчер узнаёт позже, при возвращении на экран: см. `GameExitReport`.
 * Что запуск настоящий, подтверждено только на бумаге и тестами плана: на устройстве он проверяется впервые (этап 4.7b).
 *
 * Класс не зависит от Android: всё платформенное приходит через функции-поставщики (см. `LauncherApp`).
 */
class PojavGameEngine(
    private val specFactory: LaunchSpecFactory,
    /** Читает и разбирает `versions/<id>/<id>.json`. Бросает [VersionParseException] или [IOException]. */
    private val readVersion: (versionId: String) -> GameVersion,
    /** Раскладка ядра на этом устройстве или `null`, если архитектура процессора не поддерживается ядром. */
    private val layout: () -> EngineLayout?,
    private val environment: (GameDirectories) -> EngineEnvironment,
    /** Открывает экран игры в процессе `:game` и передаёт ему план. Вызывается не в главном потоке. */
    private val startGame: (NativeLaunchPlan) -> Unit,
    /** Идёт ли сейчас процесс игры: второй запуск поверх первого невозможен (JVM в процессе одна). */
    private val isGameRunning: () -> Boolean = { false },
    /** `PATH` процесса лаунчера: `bin` рантайма Java добавляется перед ним. */
    private val currentPath: () -> String? = { System.getenv("PATH") },
    /**
     * Что лежит в установленном APK (см. [ApkInspector]): добавляется к отчёту и к сообщению «ядро не готово», чтобы по
     * ним сразу было видно, какая сборка установлена. `null` — узнать нельзя.
     */
    private val apkSummary: () -> String? = { null },
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) : GameEngine {

    override suspend fun launch(request: LaunchRequest): LaunchResult = withContext(ioDispatcher) {
        val engineLayout = layout() ?: return@withContext LaunchResult.Failed(LaunchFailure.EngineUnavailable)

        try {
            val version = readVersion(request.versionId)
            val spec = specFactory.create(version, request.account, request.directories, request.ramMb, request.extraJvmArgs)
            val engineEnv = environment(request.directories)
            val command = LaunchCommandBuilder(engineLayout, engineEnv).build(spec)
            // Рендерер, который заведомо не работает с этой версией (GL4ES на версиях новее 1.21.4), заменяется на запуске:
            // иначе игра стартует и сразу закрывается. Выбор в настройках при этом не трогаем.
            val choice = RendererAdvisor.resolve(request.renderer, version.releaseTime)
            val renderer = choice.profile
            val status = EngineCore.check(engineLayout, spec.lwjgl, spec.javaMajor, renderer)

            val report = File(request.directories.logs, PREVIEW_FILE_NAME)
            val apk = if (status.isReady) null else apkSummary()
            val preview = LaunchPreview.render(spec, command, status, renderer, choice.switchedFrom)
            writeReport(report, if (apk == null) preview else preview.trimEnd() + "\n\n" + apk + "\n")

            if (!status.isReady) {
                val missing = status.missing.joinToString("; ")
                return@withContext LaunchResult.Failed(
                    LaunchFailure.CoreNotReady(
                        missing = if (apk == null) missing else missing + "\n\n" + apk,
                        nativeLibrariesMissing = status.nativeLibrariesMissing,
                        rendererMissing = status.rendererMissing,
                    ),
                )
            }
            if (isGameRunning()) return@withContext LaunchResult.Failed(LaunchFailure.AlreadyLaunching)

            // Папка для временных файлов JVM и кэша шейдеров должна существовать до старта: создать её потом некому.
            if (!engineEnv.cacheDir.isDirectory && !engineEnv.cacheDir.mkdirs() && !engineEnv.cacheDir.isDirectory) {
                throw IOException("Cannot create the cache directory: ${engineEnv.cacheDir.path}")
            }
            // Личная папка рендерера (у MobileGlues — для его настроек и журнала) должна существовать до старта.
            renderer.dataDir(engineEnv.userHome)?.let { dir ->
                if (!dir.isDirectory && !dir.mkdirs() && !dir.isDirectory) throw IOException("Cannot create the renderer folder: ${dir.path}")
            }
            val logFile = File(request.directories.logs, GAME_LOG_NAME)
            val plan = NativeLaunchPlanner(engineLayout, engineEnv).plan(spec, command, renderer, currentPath(), logFile)
            startGame(plan)
            LaunchResult.Started(placeholder = false, note = logFile.path)
        } catch (e: VersionParseException) {
            failure("Cannot read the version description: ${e.message}")
        } catch (e: PlanException) {
            failure("The version description is unusable: ${e.message}")
        } catch (e: CommandBuildException) {
            failure("Cannot build the launch command: ${e.message}")
        } catch (e: IOException) {
            failure("Cannot read or write game files: ${e.message}")
        }
    }

    private fun failure(detail: String) = LaunchResult.Failed(LaunchFailure.EngineError(detail))

    /** Отчёт — главный материал для поддержки, поэтому сбой записи (диск полон) возвращается ошибкой, а не глотается. */
    private fun writeReport(file: File, text: String) {
        file.parentFile?.mkdirs()
        file.writeText(text)
    }

    companion object {
        const val PREVIEW_FILE_NAME = "launch-preview.txt"

        /** Журнал игры: сюда нативный код пишет всё, что игра выводит в консоль. */
        const val GAME_LOG_NAME = "latest.log"
    }
}
