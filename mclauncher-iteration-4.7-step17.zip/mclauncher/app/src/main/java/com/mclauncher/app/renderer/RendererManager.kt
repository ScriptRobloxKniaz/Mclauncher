package com.mclauncher.app.renderer

import com.mclauncher.engine.renderer.RendererManifest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/*
 * Скачиваемые рендереры для экрана. Здесь только логика без Android-классов (проверяется JVM-тестами): диск, сеть и
 * манифест приходят через [RendererBackend], а запуск в фоне — через переданный scope (в приложении он живёт, пока
 * жив процесс: скачивание не обрывается при уходе с экрана).
 */

/** То, чем пользуется [RendererManager]: манифест и работа с диском/сетью. */
interface RendererBackend {
    val manifest: RendererManifest

    /** Читает диск: вызывать вне главного потока. */
    fun isInstalled(rendererId: String): Boolean

    suspend fun install(rendererId: String, onBytes: (Long) -> Unit)

    fun remove(rendererId: String)
}

/** Настоящая работа: [RendererStore] и [RendererInstaller]. */
class DiskRendererBackend(
    override val manifest: RendererManifest,
    private val store: RendererStore,
    private val installer: RendererInstaller,
) : RendererBackend {
    override fun isInstalled(rendererId: String) = store.isInstalled(rendererId)
    override suspend fun install(rendererId: String, onBytes: (Long) -> Unit) = installer.install(rendererId, onBytes)
    override fun remove(rendererId: String) {
        store.delete(rendererId)
    }
}

/** Почему скачивание не удалось, в терминах, понятных пользователю. Тексты подбирает экран. */
enum class RendererFailure {
    NETWORK,
    NO_SPACE,

    /** Файл не прошёл проверку (сумма, размер, содержимое). */
    CORRUPT,
    STORAGE,
    OTHER,
}

fun RendererInstallException.toFailure(): RendererFailure = when (reason) {
    RendererInstallException.Reason.NETWORK, RendererInstallException.Reason.HTTP -> RendererFailure.NETWORK
    RendererInstallException.Reason.HASH, RendererInstallException.Reason.SIZE, RendererInstallException.Reason.CORRUPT -> RendererFailure.CORRUPT
    RendererInstallException.Reason.NO_SPACE -> RendererFailure.NO_SPACE
    RendererInstallException.Reason.STORAGE -> RendererFailure.STORAGE
    RendererInstallException.Reason.UNKNOWN_RENDERER -> RendererFailure.OTHER
}

/** Один рендерер в списке. [bytes] — сколько нужно скачать. [id] — `RendererProfile.id`. */
data class RendererEntry(val id: String, val bytes: Long, val installed: Boolean)

/**
 * Что показывает экран. [loaded] — диск уже проверен (до этого показывать нечего); [available] — в сборке есть манифест
 * рендереров, из которого можно скачать (в обычной сборке без ядра его нет).
 */
data class RendererSetupState(
    val loaded: Boolean = false,
    val available: Boolean = false,
    val entries: List<RendererEntry> = emptyList(),
    val working: Boolean = false,
    /** Какой рендерер качается сейчас. */
    val currentId: String? = null,
    val doneBytes: Long = 0,
    val totalBytes: Long = 0,
    val failure: RendererFailure? = null,
    val failedId: String? = null,
    /** Подробности сбоя (по-английски: для журнала и поддержки, а не для экрана). */
    val detail: String? = null,
) {
    /** 0..1, пока [working]. */
    val progress: Float get() = if (totalBytes > 0) (doneBytes.toFloat() / totalBytes).coerceIn(0f, 1f) else 0f

    fun isInstalled(rendererId: String): Boolean = entries.firstOrNull { it.id == rendererId }?.installed == true

    fun entry(rendererId: String): RendererEntry? = entries.firstOrNull { it.id == rendererId }

    val anyInstalled: Boolean get() = entries.any { it.installed }

    /** Показывать ли окно «скачайте рендереры» при первом входе: есть что скачивать и ничего ещё не скачано. */
    fun shouldOfferSetup(dismissed: Boolean): Boolean =
        loaded && available && entries.isNotEmpty() && !anyInstalled && !dismissed
}

/**
 * Скачивание, отмена и удаление рендереров. Одновременно идёт одна операция: пока качается, повторный запуск и удаление
 * игнорируются. Диск читается только на [ioDispatcher].
 *
 * @param backendLoader создаёт [RendererBackend] (читает манифест из ассетов) или возвращает `null`, если скачивать нечего;
 *   вызывается один раз, на [ioDispatcher].
 */
class RendererManager(
    private val backendLoader: () -> RendererBackend?,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) {
    private val _state = MutableStateFlow(RendererSetupState())
    val state: StateFlow<RendererSetupState> = _state.asStateFlow()

    private var backend: RendererBackend? = null
    private var backendLoaded = false

    @Volatile
    private var job: Job? = null

    /** Перечитать диск (при старте и после возвращения на экран). Во время скачивания ничего не меняет. */
    fun refresh() {
        scope.launch(ioDispatcher) { reload() }
    }

    /** Скачать рендереры [ids]; уже скачанные и неизвестные пропускаются. Прошлая ошибка сбрасывается. */
    fun download(ids: Collection<String>) {
        if (job?.isActive == true) return
        val launched = scope.launch(ioDispatcher) { performDownload(ids) }
        job = launched
    }

    /** Прервать скачивание. Файлы, не доехавшие до конца, удаляются установщиком. */
    fun cancel() {
        job?.cancel()
    }

    fun delete(rendererId: String) {
        if (job?.isActive == true) return
        scope.launch(ioDispatcher) {
            backendOrNull()?.remove(rendererId)
            reload()
        }
    }

    /** Пользователь увидел ошибку. */
    fun acknowledgeFailure() {
        _state.update { it.copy(failure = null, failedId = null, detail = null) }
    }

    private suspend fun performDownload(ids: Collection<String>) {
        val b = backendOrNull() ?: return
        reload()
        val wanted = ids.distinct().mapNotNull { id -> _state.value.entry(id) }.filter { !it.installed }
        if (wanted.isEmpty()) return

        _state.update {
            it.copy(
                working = true,
                currentId = wanted.first().id,
                doneBytes = 0,
                totalBytes = wanted.sumOf { entry -> entry.bytes },
                failure = null,
                failedId = null,
                detail = null,
            )
        }
        try {
            for (entry in wanted) {
                _state.update { it.copy(currentId = entry.id) }
                try {
                    b.install(entry.id) { n -> _state.update { s -> s.copy(doneBytes = (s.doneBytes + n).coerceIn(0, s.totalBytes)) } }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: RendererInstallException) {
                    _state.update { it.copy(failure = e.toFailure(), failedId = entry.id, detail = e.message) }
                    return
                } catch (e: Exception) {
                    // Непредвиденное (например, отказ системы): сообщаем как общий сбой, а не роняем приложение.
                    _state.update { it.copy(failure = RendererFailure.OTHER, failedId = entry.id, detail = e.toString()) }
                    return
                }
                // Рендерер встал: список обновляем сразу, не дожидаясь остальных.
                markInstalled(entry.id, b)
            }
        } finally {
            withContext(NonCancellable) {
                reload()
                _state.update { it.copy(working = false, currentId = null, doneBytes = 0, totalBytes = 0) }
            }
        }
    }

    private fun markInstalled(rendererId: String, b: RendererBackend) {
        val now = b.isInstalled(rendererId)
        _state.update { s -> s.copy(entries = s.entries.map { if (it.id == rendererId) it.copy(installed = now) else it }) }
    }

    /** Список и «скачан ли» из манифеста и диска. Состояние скачивания (прогресс, ошибка) не трогает. */
    private fun reload() {
        val b = backendOrNull()
        if (b == null) {
            _state.update { it.copy(loaded = true, available = false, entries = emptyList()) }
            return
        }
        val entries = b.manifest.packages.map { RendererEntry(it.rendererId, it.totalBytes, b.isInstalled(it.rendererId)) }
        _state.update { it.copy(loaded = true, available = true, entries = entries) }
    }

    @Synchronized
    private fun backendOrNull(): RendererBackend? {
        if (!backendLoaded) {
            backend = backendLoader()
            backendLoaded = true
        }
        return backend
    }
}
