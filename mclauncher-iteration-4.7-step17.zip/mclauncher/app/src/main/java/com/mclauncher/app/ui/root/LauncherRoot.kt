package com.mclauncher.app.ui.root

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleStartEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mclauncher.app.ui.common.CollectUiEvents
import com.mclauncher.app.ui.components.BackgroundContent
import com.mclauncher.app.ui.components.LauncherBackground
import com.mclauncher.app.ui.launch.LaunchResultDialog
import com.mclauncher.app.ui.navigation.Destination
import com.mclauncher.app.ui.navigation.LauncherBottomBar
import com.mclauncher.app.ui.navigation.LauncherNavHost
import com.mclauncher.app.ui.navigation.LauncherRail
import com.mclauncher.app.ui.navigation.Placement
import com.mclauncher.app.ui.navigation.navigateTo
import com.mclauncher.app.ui.settings.VideoControls
import com.mclauncher.app.ui.renderer.RendererSetupDialog
import com.mclauncher.app.ui.renderer.RendererViewModel

/**
 * Корень интерфейса: фон на весь экран + адаптивная навигация
 * (нижняя панель на узком окне, боковая панель в альбомной ориентации) + NavHost.
 */
@Composable
fun LauncherRoot(viewModel: LauncherViewModel = viewModel()) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val current = Destination.fromRoute(backStackEntry?.destination?.route)
    // Меню видно везде, кроме полноэкранных экранов (версии): они открываются поверх него.
    val showNavigation = current?.showsNavigation != false
    // Подсвеченный пункт меню: у аккаунтов и скинов своего пункта нет.
    val highlighted = current?.takeIf { it.placement == Placement.SIDEBAR }

    val selection by viewModel.selection.collectAsStateWithLifecycle()
    val backgroundContent by viewModel.backgroundContent.collectAsStateWithLifecycle()
    val activeAccount by viewModel.activeAccount.collectAsStateWithLifecycle()
    val library by viewModel.library.collectAsStateWithLifecycle()
    val launchPhase by viewModel.launchPhase.collectAsStateWithLifecycle()
    val launchOutcome by viewModel.launchOutcome.collectAsStateWithLifecycle()
    val videoSettings by viewModel.videoSettings.collectAsStateWithLifecycle()
    val backgroundVideo by viewModel.backgroundVideo.collectAsStateWithLifecycle()
    val videoVolume by viewModel.videoVolume.collectAsStateWithLifecycle()

    // Рендереры не входят в APK: при первом входе предлагаем скачать. Пока настройки не прочитаны (null), окно не показываем.
    // Полное имя: параметр `viewModel` этой функции заслоняет одноимённую функцию.
    val rendererViewModel: RendererViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val rendererState by rendererViewModel.state.collectAsStateWithLifecycle()
    val selectedRendererId by rendererViewModel.selectedId.collectAsStateWithLifecycle()
    val setupDismissed by rendererViewModel.setupDismissed.collectAsStateWithLifecycle()
    // Окно, из которого запущено скачивание, остаётся на экране, пока оно идёт или закончилось ошибкой.
    var setupStarted by remember { mutableStateOf(false) }

    // Приложение на переднем плане? Свёрнутое — видео-фон не играет и скоро освобождает плеер.
    var appStarted by remember { mutableStateOf(true) }
    LifecycleStartEffect(Unit) {
        appStarted = true
        // Вернулись из игры (или лаунчер перезапущен после неё): если игра упала, покажем причину.
        viewModel.checkGameExit()
        onStopOrDispose { appStarted = false }
    }
    // Видео на виду только на главном экране: на остальных экранах оно закрыто плотной вуалью и впустую жгло батарею.
    val videoVisible = current == Destination.Home && appStarted

    // Всё про видео-фон одним объектом: его читают главный экран («Видео» в окне фона) и «Настройки».
    val videoControls = remember(videoSettings, viewModel) {
        VideoControls(
            settings = videoSettings,
            onPick = viewModel::importVideoBackground,
            onEnabledChange = viewModel::setVideoEnabled,
            onMutedChange = viewModel::setVideoMuted,
            onVolumePreview = viewModel::previewVideoVolume,
            onVolumeCommit = viewModel::commitVideoVolume,
            onRemove = viewModel::removeVideoBackground,
        )
    }

    // Одноразовые сообщения об ошибках (понятный текст пользователю, а не стектрейс).
    CollectUiEvents(viewModel.events)

    // На главной фон почти не затемняем (но делаем читаемым), на остальных экранах — сильнее.
    // Состояние анимации НЕ разворачивается через `by`: цвет читается в фазе рисования (см. LauncherBackground),
    // иначе каждый кадр перехода перекомпоновывал бы весь корень.
    val backgroundColor = MaterialTheme.colorScheme.background
    val scrimState = animateColorAsState(
        targetValue = if (current == Destination.Home) {
            Color.Black.copy(alpha = 0.30f)
        } else {
            backgroundColor.copy(alpha = 0.86f)
        },
        animationSpec = tween(durationMillis = 400),
        label = "backgroundScrim",
    )

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val wide = maxWidth > maxHeight
        // Подписи у пунктов меню показываем, только если экрану хватает ширины: на узком главной нужнее место.
        val expandedRail = wide && maxWidth >= 720.dp

        // Видео играет поверх обычного фона; при ошибке воспроизведения ViewModel его выключит, и фон останется прежним.
        LauncherBackground(
            content = backgroundContent,
            scrim = { scrimState.value },
            video = backgroundVideo,
            videoVisible = videoVisible,
            videoVolume = videoVolume,
            onVideoError = viewModel::onVideoPlaybackError,
        )

        // Отступы под системные панели: сверху всегда; снизу/сбоку — только там,
        // где их ещё не обработала навигационная панель.
        val insetSides = when {
            !showNavigation -> WindowInsetsSides.Top + WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
            wide -> WindowInsetsSides.Top + WindowInsetsSides.End + WindowInsetsSides.Bottom
            else -> WindowInsetsSides.Top + WindowInsetsSides.Horizontal
        }
        val contentModifier = Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(insetSides))

        val navHost: @Composable (Modifier) -> Unit = { hostModifier ->
            LauncherNavHost(
                navController = navController,
                activeAccount = activeAccount,
                library = library,
                launchPhase = launchPhase,
                onPlay = viewModel::launchGame,
                onSelectVersion = viewModel::selectVersion,
                backgroundSelection = selection,
                customBackgroundPreview = (backgroundContent as? BackgroundContent.Image)?.bitmap,
                videoControls = videoControls,
                onSelectPreset = viewModel::selectPreset,
                onPickCustomBackground = viewModel::importCustomBackground,
                modifier = hostModifier,
            )
        }

        val setupOffered = setupDismissed == false && rendererState.shouldOfferSetup(dismissed = false)
        val setupBusy = setupDismissed == false && setupStarted && (rendererState.working || rendererState.failure != null)
        if (setupOffered || setupBusy) {
            RendererSetupDialog(
                state = rendererState,
                selectedId = selectedRendererId,
                onDownload = { ids ->
                    setupStarted = true
                    rendererViewModel.download(ids)
                },
                onCancel = rendererViewModel::cancel,
                onLater = rendererViewModel::dismissSetup,
                onAcknowledgeFailure = rendererViewModel::acknowledgeFailure,
            )
        }

        // Итог запуска показываем поверх любого экрана; состояние живёт в ViewModel и переживает поворот.
        launchOutcome?.let { outcome ->
            LaunchResultDialog(result = outcome, onDismiss = viewModel::dismissLaunchOutcome)
        }

        // Меню показывается и скрывается мгновенно, без анимации ширины: она заставляла заново измерять весь экран
        // на каждом кадре.
        if (wide) {
            Row(modifier = Modifier.fillMaxSize()) {
                if (showNavigation) {
                    LauncherRail(
                        current = highlighted,
                        onSelect = navController::navigateTo,
                        expanded = expandedRail,
                    )
                }
                navHost(Modifier.weight(1f).then(contentModifier))
            }
        } else {
            Column(modifier = Modifier.fillMaxSize()) {
                navHost(Modifier.weight(1f).then(contentModifier))
                if (showNavigation) {
                    LauncherBottomBar(current = highlighted, onSelect = navController::navigateTo)
                }
            }
        }
    }
}
