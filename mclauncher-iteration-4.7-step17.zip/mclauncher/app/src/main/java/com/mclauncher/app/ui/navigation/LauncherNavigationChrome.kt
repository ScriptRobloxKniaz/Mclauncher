package com.mclauncher.app.ui.navigation

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mclauncher.app.R
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.components.NeonChip
import com.mclauncher.app.ui.theme.NeonColors

/** Заливка боковой панели и нижней панели: почти непрозрачная, чтобы пункты читались поверх любого фона. */
private val ChromeFill = Color(0xEB0A0719)

/** Нижняя панель для узкого окна. */
@Composable
fun LauncherBottomBar(
    current: Destination?,
    onSelect: (Destination) -> Unit,
    modifier: Modifier = Modifier,
) {
    NavigationBar(
        modifier = modifier,
        containerColor = ChromeFill,
    ) {
        Destination.compactTabs.forEach { destination ->
            val label = stringResource(destination.labelRes)
            NavigationBarItem(
                selected = destination == current,
                onClick = { onSelect(destination) },
                icon = { Icon(destination.icon, contentDescription = null) },
                label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            )
        }
    }
}

/**
 * Боковая панель для альбомных экранов.
 *
 * [expanded] — на широком экране это боковое меню как на макете: логотип сверху, строки «значок + подпись»,
 * карточка ИИ-помощника и «О лаунчере» внизу; на узком остаётся компактная колонка из одних значков.
 */
@Composable
fun LauncherRail(
    current: Destination?,
    onSelect: (Destination) -> Unit,
    modifier: Modifier = Modifier,
    expanded: Boolean = false,
) {
    if (expanded) {
        LauncherSidebar(current = current, onSelect = onSelect, modifier = modifier)
    } else {
        CompactRail(current = current, onSelect = onSelect, modifier = modifier)
    }
}

/** Ширина бокового меню: «Ресурспаки» и «Настройки» помещаются в одну строку и при крупном шрифте системы. */
private val SidebarWidth = 156.dp

private val ItemShape = RoundedCornerShape(12.dp)

@Composable
private fun LauncherSidebar(
    current: Destination?,
    onSelect: (Destination) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    Row(modifier = modifier.fillMaxHeight()) {
        // Заливка идёт раньше отступов под системные панели, поэтому доходит до самых краёв экрана.
        // Прокрутка — страховка для очень низких окон (разделённый экран, крупный шрифт): пункты не обрезаются.
        // При высоком окне SpaceBetween прижимает «О лаунчере» к низу: прокрутка не мешает, потому что
        // fillMaxHeight задаёт колонке минимальную высоту, равную высоте окна.
        Column(
            modifier = Modifier
                .width(SidebarWidth)
                .fillMaxHeight()
                .background(ChromeFill)
                .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Vertical + WindowInsetsSides.Start))
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                SidebarLogo()
                Spacer(Modifier.height(6.dp))
                Destination.sidebarMain.forEach { destination ->
                    SidebarItem(
                        destination = destination,
                        selected = destination == current,
                        onClick = { onSelect(destination) },
                    )
                }
                Spacer(Modifier.height(3.dp))
                AssistantItem(
                    selected = current == Destination.Assistant,
                    onClick = { onSelect(Destination.Assistant) },
                )
            }
            AboutItem(
                selected = current == Destination.About,
                onClick = { onSelect(Destination.About) },
            )
        }
        // Тонкая линия-разделитель между меню и содержимым.
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(1.dp)
                .background(colors.outlineVariant),
        )
    }
}

/** Логотип приложения: знак «M» из значка (`drawable-nodpi/logo_mark.png`) в скруглённой рамке. */
@Composable
private fun SidebarLogo() {
    val shape = RoundedCornerShape(11.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.logo_mark),
            contentDescription = stringResource(R.string.app_name),
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(36.dp)
                .clip(shape)
                .border(1.dp, Color(0x40FFFFFF), shape),
        )
    }
}

@Composable
private fun SidebarItem(
    destination: Destination,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val label = stringResource(destination.labelRes)
    val textColor = if (selected) Color.White else colors.onSurfaceVariant
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(36.dp)
            .clip(ItemShape)
            .then(if (selected) Modifier.background(NeonColors.sidebarSelected) else Modifier)
            .then(if (selected) Modifier.border(1.dp, Color(0x40FFFFFF), ItemShape) else Modifier)
            .selectable(selected = selected, onClick = onClick, role = Role.Tab)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(
            imageVector = destination.icon,
            contentDescription = null,
            tint = if (selected) Color.White else colors.primary,
            modifier = Modifier.size(20.dp),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = textColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** ИИ-помощник: отдельная карточка с меткой «Beta» под основными пунктами. */
@Composable
private fun AssistantItem(
    selected: Boolean,
    onClick: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val label = stringResource(R.string.assistant_title)
    NeonCard(
        modifier = Modifier.fillMaxWidth(),
        highlight = selected,
        onClick = onClick,
        shape = ItemShape,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(
                imageVector = Destination.Assistant.icon,
                contentDescription = null,
                tint = if (selected) Color.White else colors.primary,
                modifier = Modifier.size(20.dp),
            )
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelLarge,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (selected) Color.White else colors.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                NeonChip(text = stringResource(R.string.badge_beta))
            }
        }
    }
}

/** «О лаунчере» внизу панели: значок в круглой плашке и подпись. */
@Composable
private fun AboutItem(
    selected: Boolean,
    onClick: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val label = stringResource(Destination.About.labelRes)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .clip(ItemShape)
            .then(if (selected) Modifier.background(NeonColors.sidebarSelected) else Modifier)
            .selectable(selected = selected, onClick = onClick, role = Role.Tab)
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0x33FFFFFF)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Destination.About.icon,
                contentDescription = null,
                tint = if (selected) Color.White else colors.onSurfaceVariant,
                modifier = Modifier.size(16.dp),
            )
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) Color.White else colors.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Компактная панель из одних значков (подписи скрыты, чтобы поместиться по высоте). */
@Composable
private fun CompactRail(
    current: Destination?,
    onSelect: (Destination) -> Unit,
    modifier: Modifier = Modifier,
) {
    NavigationRail(
        modifier = modifier,
        containerColor = ChromeFill,
        windowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Vertical + WindowInsetsSides.Start),
    ) {
        Spacer(Modifier.weight(1f))
        Destination.compactTabs.forEach { destination ->
            val label = stringResource(destination.labelRes)
            NavigationRailItem(
                selected = destination == current,
                onClick = { onSelect(destination) },
                icon = { Icon(destination.icon, contentDescription = label) },
                label = { Text(label, maxLines = 1) },
                alwaysShowLabel = false,
            )
        }
        Spacer(Modifier.weight(1f))
    }
}
