package com.mclauncher.app.ui.renderer

import android.text.format.Formatter
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.Renderer
import com.mclauncher.app.launch.toProfile
import com.mclauncher.app.renderer.RendererEntry
import com.mclauncher.app.renderer.RendererFailure
import com.mclauncher.app.renderer.RendererSetup
import com.mclauncher.app.renderer.RendererSetupState
import com.mclauncher.app.ui.components.NeonButton
import com.mclauncher.app.ui.components.NeonCard
import com.mclauncher.app.ui.components.NeonSecondaryButton
import com.mclauncher.app.ui.settings.labelRes
import com.mclauncher.app.ui.settings.noteRes

/** Состояние скачиваемых рендереров и действия над ними: для окна первого входа и раздела настроек. */
@Immutable
data class RendererControls(
    val state: RendererSetupState,
    /** `RendererProfile.id` выбранного в настройках рендерера (в списке он помечается). */
    val selectedId: String?,
    val onDownload: (Collection<String>) -> Unit,
    val onCancel: () -> Unit,
    val onDelete: (String) -> Unit,
    val onRefresh: () -> Unit,
    val onAcknowledgeFailure: () -> Unit,
)

private fun rendererOf(id: String): Renderer? = Renderer.entries.firstOrNull { it.toProfile().id == id }

@Composable
private fun rendererTitle(id: String): String = rendererOf(id)?.let { stringResource(it.labelRes) } ?: id

@Composable
private fun failureText(failure: RendererFailure): String = stringResource(
    when (failure) {
        RendererFailure.NETWORK -> R.string.renderer_err_network
        RendererFailure.NO_SPACE -> R.string.renderer_err_no_space
        RendererFailure.CORRUPT -> R.string.renderer_err_corrupt
        RendererFailure.STORAGE -> R.string.renderer_err_storage
        RendererFailure.OTHER -> R.string.renderer_err_other
    },
)

/**
 * Окно первого входа: рендереры не входят в APK, их нужно скачать. Предлагает рекомендуемый набор (см.
 * [RendererSetup.defaultSelection]), показывает размер, прогресс и причину сбоя. Пока идёт скачивание, закрыть окно
 * нельзя — только «Отмена». «Позже» запоминается: само окно больше не появится, рендереры останутся в настройках.
 */
@Composable
fun RendererSetupDialog(
    state: RendererSetupState,
    selectedId: String?,
    onDownload: (Collection<String>) -> Unit,
    onCancel: () -> Unit,
    onLater: () -> Unit,
    onAcknowledgeFailure: () -> Unit,
) {
    val context = LocalContext.current
    val colors = MaterialTheme.colorScheme
    var chosen by remember(selectedId, state.entries.map { it.id }) {
        mutableStateOf(RendererSetup.defaultSelection(selectedId, state.entries))
    }
    val busy = state.working
    val bytes = RendererSetup.bytesToDownload(state.entries, chosen)

    AlertDialog(
        onDismissRequest = { if (!busy) onLater() },
        title = { Text(stringResource(R.string.renderer_setup_title)) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = stringResource(R.string.renderer_setup_text),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.onSurfaceVariant,
                )
                state.entries.forEach { entry ->
                    key(entry.id) {
                        ChoiceRow(
                            entry = entry,
                            checked = entry.installed || entry.id in chosen,
                            enabled = !busy && !entry.installed,
                            onToggle = { on -> chosen = if (on) chosen + entry.id else chosen - entry.id },
                        )
                    }
                }
                if (busy) {
                    LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                    Text(
                        text = stringResource(
                            R.string.renderer_setup_progress,
                            state.currentId?.let { rendererTitle(it) }.orEmpty(),
                            (state.progress * 100).toInt(),
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                    )
                }
                state.failure?.let { failure ->
                    Text(
                        text = failureText(failure),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.error,
                    )
                }
            }
        },
        confirmButton = {
            if (busy) {
                TextButton(onClick = onCancel) { Text(stringResource(R.string.renderer_setup_cancel)) }
            } else {
                TextButton(
                    enabled = chosen.isNotEmpty(),
                    onClick = {
                        onAcknowledgeFailure()
                        onDownload(chosen)
                    },
                ) {
                    Text(stringResource(R.string.renderer_setup_download, Formatter.formatShortFileSize(context, bytes)))
                }
            }
        },
        dismissButton = {
            if (!busy) {
                TextButton(
                    onClick = {
                        onAcknowledgeFailure()
                        onLater()
                    },
                ) { Text(stringResource(R.string.renderer_setup_later)) }
            }
        },
    )
}

@Composable
private fun ChoiceRow(entry: RendererEntry, checked: Boolean, enabled: Boolean, onToggle: (Boolean) -> Unit) {
    val colors = MaterialTheme.colorScheme
    val context = LocalContext.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .toggleable(value = checked, enabled = enabled, role = Role.Checkbox, onValueChange = onToggle),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Checkbox(checked = checked, onCheckedChange = null, enabled = enabled)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = rendererTitle(entry.id),
                style = MaterialTheme.typography.bodyLarge,
                color = colors.onSurface,
            )
            rendererOf(entry.id)?.let { renderer ->
                Text(
                    text = stringResource(renderer.noteRes),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant,
                )
            }
        }
        Text(
            text = if (entry.installed) {
                stringResource(R.string.renderer_status_installed)
            } else {
                Formatter.formatShortFileSize(context, entry.bytes)
            },
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant,
        )
    }
}

/**
 * Раздел «Рендереры» в настройках: что скачано, скачать и удалить по одному. Скачивание идёт в процессе приложения и не
 * обрывается при уходе с экрана.
 */
@Composable
fun RendererSection(renderers: RendererControls, modifier: Modifier = Modifier) {
    val state = renderers.state
    val colors = MaterialTheme.colorScheme
    val context = LocalContext.current

    // Каждый раз, когда экран открывается, перечитываем диск: рендерер могли скачать или удалить, пока его не было.
    LaunchedEffect(Unit) { renderers.onRefresh() }

    NeonCard(modifier = modifier) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Build,
                    contentDescription = null,
                    tint = colors.primary,
                    modifier = Modifier.size(24.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.renderers_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.onSurface,
                    )
                    Text(
                        text = stringResource(R.string.renderers_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                    )
                }
            }

            if (state.loaded && !state.available) {
                Text(
                    text = stringResource(R.string.renderers_unavailable),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.onSurface,
                )
            }

            state.entries.forEach { entry ->
                key(entry.id) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = rendererTitle(entry.id) +
                                    if (entry.id == renderers.selectedId) " · " + stringResource(R.string.renderer_selected_badge) else "",
                                style = MaterialTheme.typography.bodyLarge,
                                color = colors.onSurface,
                            )
                            Text(
                                text = if (entry.installed) {
                                    stringResource(R.string.renderer_status_installed)
                                } else {
                                    stringResource(R.string.renderer_status_missing) + " · " +
                                        Formatter.formatShortFileSize(context, entry.bytes)
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (entry.installed) colors.primary else colors.onSurfaceVariant,
                            )
                        }
                        if (entry.installed) {
                            NeonSecondaryButton(
                                text = stringResource(R.string.renderer_action_delete),
                                onClick = { renderers.onDelete(entry.id) },
                                icon = Icons.Filled.Delete,
                                enabled = !state.working,
                                danger = true,
                                height = 36.dp,
                            )
                        } else {
                            NeonButton(
                                text = stringResource(R.string.renderer_action_download),
                                onClick = { renderers.onDownload(listOf(entry.id)) },
                                icon = Icons.Filled.Add,
                                enabled = !state.working,
                                height = 36.dp,
                            )
                        }
                    }
                }
            }

            if (state.working) {
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = stringResource(
                            R.string.renderer_setup_progress,
                            state.currentId?.let { rendererTitle(it) }.orEmpty(),
                            (state.progress * 100).toInt(),
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                    )
                    NeonSecondaryButton(
                        text = stringResource(R.string.renderer_setup_cancel),
                        onClick = renderers.onCancel,
                        icon = Icons.Filled.Close,
                        danger = true,
                        height = 36.dp,
                    )
                }
            }

            state.failure?.let { failure ->
                Text(
                    text = failureText(failure),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.error,
                )
            }
        }
    }
}
