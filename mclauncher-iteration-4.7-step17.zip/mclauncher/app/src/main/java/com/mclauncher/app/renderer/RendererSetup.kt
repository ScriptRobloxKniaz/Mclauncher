package com.mclauncher.app.renderer

import com.mclauncher.engine.launch.RendererAdvisor

/** Что предложить скачать в окне первого входа. Чистая логика без Android: проверяется JVM-тестами. */
object RendererSetup {

    /**
     * Рекомендуемый набор: рендерер, выбранный в настройках, и те, которыми `RendererAdvisor` подменяет его для версий
     * игры, с которыми он не работает (иначе игра на такой версии упёрлась бы в рендерер, которого нет). Уже
     * скачанные не включаются. Порядок — как в [entries].
     */
    fun defaultSelection(selectedId: String?, entries: List<RendererEntry>): Set<String> {
        val wanted = HashSet(RendererAdvisor.fallbackIds)
        if (selectedId != null) wanted += selectedId
        return entries.filter { it.id in wanted && !it.installed }.map { it.id }.toCollection(LinkedHashSet())
    }

    /** Сколько ещё нужно скачать для [ids]: уже скачанные и неизвестные не считаются. */
    fun bytesToDownload(entries: List<RendererEntry>, ids: Collection<String>): Long =
        entries.filter { it.id in ids && !it.installed }.sumOf { it.bytes }
}
