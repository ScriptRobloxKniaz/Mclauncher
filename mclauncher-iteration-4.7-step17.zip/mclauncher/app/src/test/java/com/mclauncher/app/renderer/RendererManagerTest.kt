package com.mclauncher.app.renderer

import com.mclauncher.engine.renderer.RendererManifest
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Collections

class RendererManagerTest {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @After
    fun tearDown() {
        scope.cancel()
    }

    private val manifest = RendererManifest.parse(
        """
        mcl-renderers 1
        abi arm64-v8a
        upstream 0123456789abcdef0123456789abcdef01234567
        renderer opengles2
        download 1000 ${"a".repeat(64)} libs/gl4es.so - gl4es.so
        renderer opengles3
        download 4000 ${"b".repeat(64)} libs/krypton.aar jni/arm64-v8a/ libk.so
        renderer zinkish
        download 6000 ${"c".repeat(64)} libs/zink.aar jni/arm64-v8a/ libz.so
        """.trimIndent() + "\n",
    )

    /** Диск и сеть одним объектом: «скачанное» — это просто множество; [install] можно подменить. */
    private class FakeBackend(
        override val manifest: RendererManifest,
        installed: Set<String> = emptySet(),
        var install: suspend (String, (Long) -> Unit) -> Unit = { _, _ -> },
    ) : RendererBackend {
        val disk: MutableSet<String> = Collections.synchronizedSet(installed.toMutableSet())
        val installCalls = Collections.synchronizedList(ArrayList<String>())

        override fun isInstalled(rendererId: String) = rendererId in disk

        override suspend fun install(rendererId: String, onBytes: (Long) -> Unit) {
            installCalls += rendererId
            install.invoke(rendererId, onBytes)
            disk += rendererId
        }

        override fun remove(rendererId: String) {
            disk -= rendererId
        }
    }

    private fun manager(backend: RendererBackend?) = RendererManager({ backend }, scope)

    private suspend fun RendererManager.await(predicate: (RendererSetupState) -> Boolean): RendererSetupState =
        withTimeout(10_000) { state.first(predicate) }

    @Test
    fun nothingIsKnownUntilTheDiskHasBeenChecked() {
        val state = manager(FakeBackend(manifest)).state.value

        assertFalse(state.loaded)
        assertFalse(state.shouldOfferSetup(dismissed = false))
    }

    @Test
    fun refreshListsTheRenderersWithTheirSizesAndWhetherTheyAreInstalled() = runBlocking {
        val m = manager(FakeBackend(manifest, installed = setOf("opengles2")))

        m.refresh()
        val state = m.await { it.loaded }

        assertTrue(state.available)
        assertEquals(listOf("opengles2", "opengles3", "zinkish"), state.entries.map { it.id })
        assertEquals(listOf(1000L, 4000L, 6000L), state.entries.map { it.bytes })
        assertEquals(listOf(true, false, false), state.entries.map { it.installed })
    }

    @Test
    fun aBuildWithoutTheManifestOffersNothing() = runBlocking {
        val m = manager(null)

        m.refresh()
        val state = m.await { it.loaded }

        assertFalse(state.available)
        assertTrue(state.entries.isEmpty())
        assertFalse(state.shouldOfferSetup(dismissed = false))
    }

    @Test
    fun theFirstRunOfferNeedsSomethingToDownloadAndNothingDownloadedYet() = runBlocking {
        val fresh = manager(FakeBackend(manifest))
        fresh.refresh()
        val s = fresh.await { it.loaded }
        assertTrue(s.shouldOfferSetup(dismissed = false))
        assertFalse("«Позже» must be remembered", s.shouldOfferSetup(dismissed = true))

        val used = manager(FakeBackend(manifest, installed = setOf("opengles3")))
        used.refresh()
        assertFalse(used.await { it.loaded }.shouldOfferSetup(dismissed = false))
    }

    @Test
    fun downloadingInstallsOnlyWhatIsMissingAndReportsProgress() = runBlocking {
        val gate = CompletableDeferred<Unit>()
        val backend = FakeBackend(manifest, installed = setOf("opengles2"))
        backend.install = { id, onBytes ->
            onBytes(if (id == "opengles3") 1000 else 6000)
            if (id == "opengles3") gate.await()
        }
        val m = manager(backend)
        m.refresh()
        m.await { it.loaded }

        m.download(listOf("opengles2", "opengles3", "zinkish", "unknown"))

        val busy = m.await { it.working && it.doneBytes >= 1000 }
        assertEquals("opengles3", busy.currentId)
        assertEquals(10_000L, busy.totalBytes)
        assertEquals(0.1f, busy.progress, 0.001f)

        gate.complete(Unit)
        val done = m.await { !it.working && it.entries.all { e -> e.installed } }
        assertEquals(listOf("opengles3", "zinkish"), backend.installCalls.toList())
        assertNull(done.failure)
        assertEquals(0L, done.totalBytes)
    }

    @Test
    fun aSecondDownloadAndADeleteAreIgnoredWhileOneIsRunning() = runBlocking {
        val gate = CompletableDeferred<Unit>()
        val backend = FakeBackend(manifest, installed = setOf("opengles2"))
        backend.install = { _, _ -> gate.await() }
        val m = manager(backend)
        m.refresh()
        m.await { it.loaded }

        m.download(listOf("opengles3"))
        m.await { it.working }
        m.download(listOf("zinkish"))
        m.delete("opengles2")
        Thread.sleep(100)

        assertEquals(listOf("opengles3"), backend.installCalls.toList())
        assertTrue("delete must wait for the download to finish", "opengles2" in backend.disk)
        gate.complete(Unit)
        m.await { !it.working }
        Unit
    }

    @Test
    fun aFailureIsReportedWithItsRendererAndTheRestIsNotAttempted() = runBlocking {
        val backend = FakeBackend(manifest)
        backend.install = { id, _ ->
            if (id == "opengles3") throw RendererInstallException(RendererInstallException.Reason.NO_SPACE, "disk is full")
        }
        val m = manager(backend)
        m.refresh()
        m.await { it.loaded }

        m.download(listOf("opengles2", "opengles3", "zinkish"))

        val state = m.await { !it.working && it.failure != null }
        assertEquals(RendererFailure.NO_SPACE, state.failure)
        assertEquals("opengles3", state.failedId)
        assertEquals("disk is full", state.detail)
        assertEquals(listOf("opengles2", "opengles3"), backend.installCalls.toList())
        assertTrue("what was downloaded before the failure stays", state.isInstalled("opengles2"))
        assertFalse(state.isInstalled("zinkish"))
    }

    @Test
    fun anUnexpectedErrorBecomesAGeneralFailureInsteadOfACrash() = runBlocking {
        val backend = FakeBackend(manifest)
        backend.install = { _, _ -> throw IllegalStateException("boom") }
        val m = manager(backend)
        m.refresh()
        m.await { it.loaded }

        m.download(listOf("opengles2"))

        val state = m.await { !it.working && it.failure != null }
        assertEquals(RendererFailure.OTHER, state.failure)
        assertTrue(state.detail!!.contains("boom"))
    }

    @Test
    fun acknowledgingClearsTheFailureAndATryAgainWorks() = runBlocking {
        val backend = FakeBackend(manifest)
        var fail = true
        backend.install = { _, _ ->
            if (fail) throw RendererInstallException(RendererInstallException.Reason.NETWORK, "offline")
        }
        val m = manager(backend)
        m.refresh()
        m.await { it.loaded }
        m.download(listOf("opengles2"))
        m.await { !it.working && it.failure == RendererFailure.NETWORK }

        m.acknowledgeFailure()
        assertNull(m.state.value.failure)
        fail = false
        m.download(listOf("opengles2"))

        val done = m.await { !it.working && it.isInstalled("opengles2") }
        assertNull(done.failure)
    }

    @Test
    fun cancellingStopsTheDownloadWithoutAFailure() = runBlocking {
        val backend = FakeBackend(manifest)
        backend.install = { _, onBytes -> onBytes(10); awaitCancellation() }
        val m = manager(backend)
        m.refresh()
        m.await { it.loaded }
        m.download(listOf("opengles2"))
        m.await { it.working && it.doneBytes > 0 }

        m.cancel()

        val state = m.await { !it.working }
        assertNull(state.failure)
        assertFalse(state.isInstalled("opengles2"))
        assertEquals(0L, state.doneBytes)
    }

    @Test
    fun deleteRemovesARendererAndRefreshesTheList() = runBlocking {
        val backend = FakeBackend(manifest, installed = setOf("opengles2", "opengles3"))
        val m = manager(backend)
        m.refresh()
        m.await { it.loaded }

        m.delete("opengles3")

        val state = m.await { !it.isInstalled("opengles3") }
        assertTrue(state.isInstalled("opengles2"))
    }

    @Test
    fun failuresAreMappedToWhatTheUserCanActOn() {
        fun map(reason: RendererInstallException.Reason) = RendererInstallException(reason, "x").toFailure()

        assertEquals(RendererFailure.NETWORK, map(RendererInstallException.Reason.NETWORK))
        assertEquals(RendererFailure.NETWORK, map(RendererInstallException.Reason.HTTP))
        assertEquals(RendererFailure.CORRUPT, map(RendererInstallException.Reason.HASH))
        assertEquals(RendererFailure.CORRUPT, map(RendererInstallException.Reason.SIZE))
        assertEquals(RendererFailure.CORRUPT, map(RendererInstallException.Reason.CORRUPT))
        assertEquals(RendererFailure.NO_SPACE, map(RendererInstallException.Reason.NO_SPACE))
        assertEquals(RendererFailure.STORAGE, map(RendererInstallException.Reason.STORAGE))
        assertEquals(RendererFailure.OTHER, map(RendererInstallException.Reason.UNKNOWN_RENDERER))
    }
}
