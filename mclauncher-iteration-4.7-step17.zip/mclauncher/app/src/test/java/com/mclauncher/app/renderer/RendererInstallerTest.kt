package com.mclauncher.app.renderer

import com.mclauncher.app.data.versions.FakeHttpSource
import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.renderer.RendererManifest
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class RendererInstallerTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val http = FakeHttpSource()
    private val upstream = "0123456789abcdef0123456789abcdef01234567"

    private val layout by lazy {
        EngineLayout(
            componentsDir = File(tmp.root, "engine/components"),
            runtimesDir = File(tmp.root, "engine/runtimes"),
            nativeLibraryDir = File(tmp.root, "native"),
            abi = "arm64-v8a",
            renderersDir = File(tmp.root, "engine/renderers"),
        )
    }

    // Содержимое «библиотек»: сигнатура ELF и полезная нагрузка.
    private fun elf(tag: String) = byteArrayOf(0x7F, 'E'.code.toByte(), 'L'.code.toByte(), 'F'.code.toByte()) + tag.toByteArray()

    private fun zip(entries: Map<String, ByteArray>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            for ((name, data) in entries) {
                z.putNextEntry(ZipEntry(name))
                z.write(data)
                z.closeEntry()
            }
        }
        return out.toByteArray()
    }

    private fun sha256(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    private val glBytes = elf("gl4es")
    private val aarEntries = mapOf(
        "AndroidManifest.xml" to "<manifest/>".toByteArray(),
        "classes.jar" to "jar".toByteArray(),
        "jni/arm64-v8a/libmain.so" to elf("main"),
        "jni/arm64-v8a/libdep.so" to elf("dep"),
        "jni/armeabi-v7a/libmain.so" to elf("32-bit"),
    )
    private val aarBytes = zip(aarEntries)

    private fun manifestText(
        glSha: String = sha256(glBytes),
        aarSha: String = sha256(aarBytes),
        aarSize: Long = aarBytes.size.toLong(),
        aarFiles: String = "libmain.so,libdep.so",
    ) = """
        mcl-renderers 1
        abi arm64-v8a
        upstream $upstream
        renderer opengles2
        download ${glBytes.size} $glSha libs/libgl4es.so - libgl4es.so
        renderer zinkish
        download $aarSize $aarSha libs/zinkish.aar jni/arm64-v8a/ $aarFiles
    """.trimIndent() + "\n"

    private fun manifest(text: String = manifestText()) = RendererManifest.parse(text)

    private fun urlOf(m: RendererManifest, id: String) = m.urlOf(m.packageFor(id)!!.downloads.first())

    private fun installer(
        m: RendererManifest,
        attempts: Int = 3,
        freeSpace: (File) -> Long = { Long.MAX_VALUE },
    ) = RendererInstaller(http, layout, m, Dispatchers.IO, attempts, { 0L }, freeSpace)

    private fun failure(block: suspend () -> Unit): RendererInstallException =
        assertThrows(RendererInstallException::class.java) { runBlocking { block() } }

    private fun serveAll(m: RendererManifest) {
        http.serve(urlOf(m, "opengles2"), glBytes)
        http.serve(urlOf(m, "zinkish"), aarBytes)
    }

    private fun assertNothingLeft(id: String) {
        assertFalse("the renderer folder must not appear", layout.rendererDir(id).exists())
        val leftovers = layout.renderersDir.listFiles().orEmpty().map { it.name }
        assertTrue("temporary folders must be removed: $leftovers", leftovers.none { it.startsWith(".tmp-") })
    }

    @Test
    fun aPlainLibraryIsDownloadedVerifiedAndPlacedWithItsMarker() = runBlocking {
        val m = manifest()
        serveAll(m)
        val received = AtomicLong()

        installer(m).install("opengles2") { received.addAndGet(it) }

        val dir = layout.rendererDir("opengles2")
        assertEquals(glBytes.toList(), File(dir, "libgl4es.so").readBytes().toList())
        assertTrue(File(dir, RendererStore.MARKER).isFile)
        assertEquals(glBytes.size.toLong(), received.get())
        assertTrue(RendererStore(layout, m).isInstalled("opengles2"))
        assertEquals(setOf(".installed", "libgl4es.so"), dir.list()!!.toSet())
        assertEquals(listOf("opengles2"), layout.renderersDir.list()!!.toList())
    }

    @Test
    fun onlyTheListedFilesAreTakenFromAnArchiveForTheDevicesAbi() = runBlocking {
        val m = manifest()
        serveAll(m)

        installer(m).install("zinkish")

        val dir = layout.rendererDir("zinkish")
        assertEquals(setOf(".installed", "libmain.so", "libdep.so"), dir.list()!!.toSet())
        assertEquals(elf("main").toList(), File(dir, "libmain.so").readBytes().toList())
        assertEquals(elf("dep").toList(), File(dir, "libdep.so").readBytes().toList())
        assertTrue(RendererStore(layout, m).isInstalled("zinkish"))
    }

    @Test
    fun aWrongChecksumIsRetriedThenRejectedAndLeavesNothing() {
        val m = manifest(manifestText(glSha = "0".repeat(64)))
        serveAll(m)

        val e = failure { installer(m).install("opengles2") }

        assertEquals(RendererInstallException.Reason.HASH, e.reason)
        assertEquals(3, http.requestCount(urlOf(m, "opengles2")))
        assertNothingLeft("opengles2")
    }

    @Test
    fun aBodyOfTheWrongSizeIsRejectedBothWhenLongerAndWhenShorter() {
        val m = manifest()
        http.serve(urlOf(m, "opengles2"), glBytes + byteArrayOf(1, 2, 3))
        assertEquals(RendererInstallException.Reason.SIZE, failure { installer(m, attempts = 1).install("opengles2") }.reason)

        http.serve(urlOf(m, "opengles2"), glBytes.copyOf(glBytes.size - 2))
        assertEquals(RendererInstallException.Reason.SIZE, failure { installer(m, attempts = 1).install("opengles2") }.reason)
        assertNothingLeft("opengles2")
    }

    @Test
    fun aDroppedConnectionIsRetriedAndTheProgressIsRolledBack() = runBlocking {
        val m = manifest()
        http.serveSequence(
            urlOf(m, "opengles2"),
            FakeHttpSource.Reply.Fail("connection reset"),
            FakeHttpSource.Reply.Ok(glBytes),
        )
        val received = AtomicLong()

        installer(m).install("opengles2") { received.addAndGet(it) }

        assertEquals(2, http.requestCount(urlOf(m, "opengles2")))
        assertEquals("the net progress must not exceed the file size", glBytes.size.toLong(), received.get())
        assertTrue(RendererStore(layout, m).isInstalled("opengles2"))
    }

    @Test
    fun aMissingFileIsNotRetriedButAServerErrorIs() {
        val m = manifest()
        http.serveSequence(urlOf(m, "opengles2"), FakeHttpSource.Reply.Status(404))
        val notFound = failure { installer(m).install("opengles2") }
        assertEquals(RendererInstallException.Reason.HTTP, notFound.reason)
        assertEquals(1, http.requestCount(urlOf(m, "opengles2")))

        http.serveSequence(urlOf(m, "zinkish"), FakeHttpSource.Reply.Status(503), FakeHttpSource.Reply.Ok(aarBytes))
        runBlocking { installer(m).install("zinkish") }
        assertEquals(2, http.requestCount(urlOf(m, "zinkish")))
    }

    @Test
    fun anArchiveWithoutAPromisedFileIsCorrupt() {
        val m = manifest(manifestText(aarFiles = "libmain.so,libmissing.so"))
        serveAll(m)

        val e = failure { installer(m).install("zinkish") }

        assertEquals(RendererInstallException.Reason.CORRUPT, e.reason)
        assertNothingLeft("zinkish")
    }

    @Test
    fun aFileThatIsNotANativeLibraryIsRejectedEvenWithAMatchingChecksum() {
        val notElf = "just text, not a library".toByteArray()
        val aar = zip(mapOf("jni/arm64-v8a/libmain.so" to notElf, "jni/arm64-v8a/libdep.so" to elf("dep")))
        val m = manifest(manifestText(aarSha = sha256(aar), aarSize = aar.size.toLong()))
        http.serve(urlOf(m, "zinkish"), aar)

        val e = failure { installer(m).install("zinkish") }

        assertEquals(RendererInstallException.Reason.CORRUPT, e.reason)
        assertNothingLeft("zinkish")
    }

    @Test
    fun anArchiveThatIsNotAZipIsCorrupt() {
        val junk = "definitely not a zip file".toByteArray()
        val m = manifest(manifestText(aarSha = sha256(junk), aarSize = junk.size.toLong()))
        http.serve(urlOf(m, "zinkish"), junk)

        assertEquals(RendererInstallException.Reason.CORRUPT, failure { installer(m).install("zinkish") }.reason)
        assertNothingLeft("zinkish")
    }

    @Test
    fun withoutEnoughFreeSpaceNothingIsRequested() {
        val m = manifest()
        serveAll(m)

        val e = failure { installer(m, freeSpace = { 1_000L }).install("zinkish") }

        assertEquals(RendererInstallException.Reason.NO_SPACE, e.reason)
        assertEquals(0, http.totalRequests)
        assertNothingLeft("zinkish")
    }

    @Test
    fun anUnknownRendererIsRefused() {
        val e = failure { installer(manifest()).install("virgl") }

        assertEquals(RendererInstallException.Reason.UNKNOWN_RENDERER, e.reason)
        assertEquals(0, http.totalRequests)
    }

    @Test
    fun aReinstallReplacesTheOldFolderCompletely() = runBlocking {
        val m = manifest()
        serveAll(m)
        val dir = layout.rendererDir("zinkish")
        dir.mkdirs()
        File(dir, "stale.so").writeText("old")
        File(dir, "libmain.so").writeText("old")

        installer(m).install("zinkish")

        assertFalse(File(dir, "stale.so").exists())
        assertEquals(elf("main").toList(), File(dir, "libmain.so").readBytes().toList())
    }

    @Test
    fun aCancelledDownloadLeavesNeitherARendererNorTemporaryFiles() = runBlocking {
        val m = manifest(manifestText(aarSize = 1_000_000))
        http.serveSequence(urlOf(m, "zinkish"), FakeHttpSource.Reply.Slow(chunks = 500, chunkSize = 1024, pauseMs = 10))
        val started = CompletableDeferred<Unit>()
        val job = launch(Dispatchers.IO) {
            installer(m).install("zinkish") { started.complete(Unit) }
        }

        withTimeout(10_000) { started.await() }
        job.cancelAndJoin()

        assertNothingLeft("zinkish")
    }

    @Test
    fun theDownloadAddressComesFromThePinnedRevisionOnly() = runBlocking {
        val m = manifest()
        serveAll(m)

        installer(m).install("opengles2")

        assertEquals(
            listOf("https://raw.githubusercontent.com/ZalithLauncher/ZalithLauncher2/$upstream/libs/libgl4es.so"),
            http.requestedUrls,
        )
    }
}
