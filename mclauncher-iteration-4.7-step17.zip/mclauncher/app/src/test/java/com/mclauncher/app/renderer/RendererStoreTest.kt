package com.mclauncher.app.renderer

import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.renderer.RendererManifest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class RendererStoreTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val sha = "ab".repeat(32)
    private val manifest = RendererManifest.parse(
        """
        mcl-renderers 1
        abi arm64-v8a
        upstream 0123456789abcdef0123456789abcdef01234567
        renderer zinkish
        download 100 $sha libs/zinkish.aar jni/arm64-v8a/ libmain.so,libdep.so
        """.trimIndent() + "\n",
    )
    // Папка правила TemporaryFolder появляется только перед тестом, поэтому всё, что от неё зависит, создаётся лениво.
    private val layout by lazy {
        EngineLayout(
            componentsDir = File(tmp.root, "components"),
            runtimesDir = File(tmp.root, "runtimes"),
            nativeLibraryDir = File(tmp.root, "native"),
            abi = "arm64-v8a",
            renderersDir = File(tmp.root, "renderers"),
        )
    }
    private val store by lazy { RendererStore(layout, manifest) }
    private val dir get() = layout.rendererDir("zinkish")

    private fun installProperly() {
        dir.mkdirs()
        File(dir, "libmain.so").writeText("x")
        File(dir, "libdep.so").writeText("y")
        File(dir, RendererStore.MARKER).writeText(RendererStore.markerText(manifest.packageFor("zinkish")!!))
    }

    @Test
    fun aProperlyInstalledRendererIsReported() {
        installProperly()

        assertTrue(store.isInstalled("zinkish"))
    }

    @Test
    fun nothingOnDiskMeansNotInstalled() {
        assertFalse(store.isInstalled("zinkish"))
        assertFalse(store.isInstalled("unknown"))
    }

    @Test
    fun filesWithoutTheMarkerDoNotCount() {
        installProperly()
        File(dir, RendererStore.MARKER).delete()

        assertFalse(store.isInstalled("zinkish"))
    }

    @Test
    fun aMarkerFromAnotherManifestMeansTheRendererIsOutdated() {
        installProperly()
        File(dir, RendererStore.MARKER).writeText("mcl-renderer 1\n" + "cd".repeat(32) + "\n")

        assertFalse(store.isInstalled("zinkish"))
    }

    @Test
    fun aMissingOrEmptyLibraryMeansNotInstalled() {
        installProperly()
        File(dir, "libdep.so").delete()
        assertFalse(store.isInstalled("zinkish"))

        File(dir, "libdep.so").writeText("")
        assertFalse(store.isInstalled("zinkish"))
    }

    @Test
    fun deleteRemovesTheWholeFolder() {
        installProperly()

        assertTrue(store.delete("zinkish"))

        assertFalse(dir.exists())
        assertFalse(store.isInstalled("zinkish"))
        assertTrue("deleting what is not there is fine", store.delete("zinkish"))
    }

    @Test
    fun theMarkerCarriesTheChecksums() {
        assertEquals("mcl-renderer 1\n$sha\n", RendererStore.markerText(manifest.packageFor("zinkish")!!))
    }
}
