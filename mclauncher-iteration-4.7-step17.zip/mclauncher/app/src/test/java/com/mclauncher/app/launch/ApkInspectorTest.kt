package com.mclauncher.app.launch

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ApkInspectorTest {

    private val temp: File = Files.createTempDirectory("apk-inspector").toFile()

    @After
    fun tearDown() {
        temp.deleteRecursively()
    }

    private fun apk(vararg entries: String): File {
        val file = File(temp, "app-${entries.hashCode()}.apk")
        ZipOutputStream(file.outputStream()).use { zip ->
            for (name in entries) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(1)
                zip.closeEntry()
            }
        }
        return file
    }

    private fun libDir(vararg names: String): File {
        val dir = File(temp, "lib-${names.hashCode()}").apply { mkdirs() }
        names.forEach { File(dir, it).writeText("x") }
        return dir
    }

    private val core = "assets/core/core-manifest.txt"
    private val exec = "lib/arm64-v8a/libpojavexec.so"
    private val openal = "lib/arm64-v8a/libopenal.so"

    @Test
    fun anApkWithoutTheCoreIsThePlainBuild() {
        val contents = ApkInspector.inspect(apk("classes.dex", "lib/arm64-v8a/libjnidispatch.so"), libDir("libjnidispatch.so"))

        assertEquals(ApkBuild.WITHOUT_CORE, contents.build)
        assertTrue(contents.summary().contains("БЕЗ ядра"))
    }

    @Test
    fun theCoreWithoutTheBridgeLibraryIsTheBuildWithoutNatives() {
        // Как «with-core»: рантаймы и OpenAL есть, мост (libpojavexec.so) собирается отдельно.
        val contents = ApkInspector.inspect(apk(core, openal), libDir("libopenal.so"))

        assertEquals(ApkBuild.CORE_WITHOUT_NATIVES, contents.build)
        assertTrue(contents.summary().contains("libpojavexec.so: НЕТ"))
    }

    @Test
    fun theBridgeLibraryWithoutOpenAlIsStillNotEnough() {
        assertEquals(ApkBuild.CORE_WITHOUT_NATIVES, ApkInspector.inspect(apk(core, exec), libDir("libpojavexec.so")).build)
    }

    @Test
    fun filesPresentInTheApkButMissingOnTheDeviceAreAnInstallProblem() {
        val contents = ApkInspector.inspect(apk(core, exec, openal), libDir("libopenal.so"))

        assertEquals(ApkBuild.NOT_EXTRACTED, contents.build)
    }

    @Test
    fun everythingInPlaceIsTheFullBuild() {
        val contents = ApkInspector.inspect(apk(core, exec, openal), libDir("libpojavexec.so", "libopenal.so"))

        assertEquals(ApkBuild.FULL, contents.build)
        assertTrue(contents.summary().startsWith("APK: полная сборка"))
    }

    @Test
    fun theLibrariesAreFoundUnderAnyAbiFolder() {
        val contents = ApkInspector.inspect(apk(core, "lib/armeabi-v7a/libpojavexec.so", "lib/armeabi-v7a/libopenal.so"), libDir("libpojavexec.so", "libopenal.so"))

        assertEquals(ApkBuild.FULL, contents.build)
    }

    @Test
    fun theSummaryCarriesTheFactsBehindTheVerdict() {
        val text = ApkInspector.inspect(apk(core, openal), libDir()).summary()

        assertTrue(text.contains("размер APK:"))
        assertTrue(text.contains("assets/core (ядро): есть"))
        assertTrue(text.contains("в APK libpojavexec.so: НЕТ; libopenal.so: есть"))
        assertTrue(text.contains("на устройстве libpojavexec.so: НЕТ; libopenal.so: НЕТ"))
    }

    @Test
    fun aMissingNativeFolderCountsAsEmpty() {
        val contents = ApkInspector.inspect(apk(core, exec, openal), File(temp, "no-such-dir"))

        assertEquals(emptySet<String>(), contents.nativeExtracted)
        assertEquals(ApkBuild.NOT_EXTRACTED, contents.build)
    }

    @Test
    fun anUnreadableApkGivesNoSummaryInsteadOfAnError() {
        assertNull(ApkInspector.summaryOrNull(File(temp, "missing.apk"), temp))
        val broken = File(temp, "broken.apk").apply { writeText("not a zip") }
        assertNull(ApkInspector.summaryOrNull(broken, temp))
    }
}
