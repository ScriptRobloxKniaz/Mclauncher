package com.mclauncher.app.renderer

import org.junit.Assert.assertEquals
import org.junit.Test

class RendererSetupTest {

    private val gl4es = "opengles2"
    private val krypton = "opengles3"
    private val mobileGlues = "opengles3_mobileglues"
    private val zink = "opengles3_desktopgl_zink_kopper"

    private fun entries(installed: Set<String> = emptySet()) = listOf(
        RendererEntry(gl4es, 2_600_000, gl4es in installed),
        RendererEntry(krypton, 9_300_000, krypton in installed),
        RendererEntry(mobileGlues, 8_200_000, mobileGlues in installed),
        RendererEntry(zink, 16_000_000, zink in installed),
    )

    @Test
    fun theSelectedRendererComesWithTheOnesThatReplaceIt() {
        val ids = RendererSetup.defaultSelection(zink, entries())

        // Выбран Zink; для версий, с которыми он не работает, лаунчер подставит GL4ES или MobileGlues.
        assertEquals(listOf(gl4es, mobileGlues, zink), ids.toList())
    }

    @Test
    fun aSelectedFallbackIsNotDuplicated() {
        assertEquals(listOf(gl4es, mobileGlues), RendererSetup.defaultSelection(gl4es, entries()).toList())
    }

    @Test
    fun installedRenderersAreNotOfferedAgain() {
        val ids = RendererSetup.defaultSelection(zink, entries(installed = setOf(gl4es, zink)))

        assertEquals(listOf(mobileGlues), ids.toList())
    }

    @Test
    fun anUnknownSelectionIsIgnored() {
        assertEquals(listOf(gl4es, mobileGlues), RendererSetup.defaultSelection("nope", entries()).toList())
        assertEquals(listOf(gl4es, mobileGlues), RendererSetup.defaultSelection(null, entries()).toList())
    }

    @Test
    fun nothingIsOfferedWhenThereAreNoEntries() {
        assertEquals(emptySet<String>(), RendererSetup.defaultSelection(zink, emptyList()))
    }

    @Test
    fun theSizeCountsOnlyWhatIsStillToDownload() {
        val list = entries(installed = setOf(gl4es))

        assertEquals(8_200_000L + 16_000_000L, RendererSetup.bytesToDownload(list, listOf(gl4es, mobileGlues, zink, "nope")))
        assertEquals(0L, RendererSetup.bytesToDownload(list, emptyList()))
    }
}
