package com.mclauncher.app.launch

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DeviceFactsTest {

    private fun facts(page: Long?) = DeviceFacts(
        manufacturer = "Google", model = "Pixel 9", androidRelease = "16", sdkInt = 36,
        abis = listOf("arm64-v8a"), pageSizeBytes = page, totalMemoryMb = 11534, kernel = "6.1.99",
    )

    @Test
    fun theDescriptionHasTheDeviceTheAndroidTheAbiAndTheMemory() {
        val text = facts(4096).describe()

        assertTrue(text.contains("Устройство: Google Pixel 9"))
        assertTrue(text.contains("Android: 16 (API 36)"))
        assertTrue(text.contains("Процессор (ABI): arm64-v8a"))
        assertTrue(text.contains("Ядро Linux: 6.1.99"))
        assertTrue(text.contains("Оперативная память: 11534 МБ"))
    }

    @Test
    fun theStandardPageSizeIsReportedPlainly() {
        val text = facts(4096).describe()

        assertFalse(facts(4096).hasUnusualPageSize)
        assertTrue(text.contains("Страница памяти: 4096 байт"))
        assertFalse(text.contains("НЕ 4096"))
    }

    @Test
    fun anUnusualPageSizeIsFlaggedBecauseItIsALikelySuspect() {
        val text = facts(16384).describe()

        assertTrue(facts(16384).hasUnusualPageSize)
        assertTrue(text.contains("16384 байт (НЕ 4096"))
    }

    @Test
    fun unknownThingsAreSaidSoAndNeverBreakTheReport() {
        val text = DeviceFacts("", "", "", 0, emptyList(), null, 0, null).describe()

        assertFalse(DeviceFacts("", "", "", 0, emptyList(), null, 0, null).hasUnusualPageSize)
        assertTrue(text.contains("Устройство: ?"))
        assertTrue(text.contains("Страница памяти: не удалось узнать"))
        assertTrue(text.contains("Оперативная память: не удалось узнать"))
        assertFalse(text.contains("Ядро Linux"))
    }
}
