package com.mclauncher.app.launch

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class GameLogDiagnosisTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun log(text: String): File = tmp.newFile().apply { writeText(text) }

    @Test
    fun theTailKeepsTheLastLinesInOrder() {
        val file = log((1..100).joinToString("\n") { "line $it" } + "\n")

        val tail = GameLogDiagnosis.tail(file, maxLines = 3)

        assertEquals("line 98\nline 99\nline 100", tail)
    }

    @Test
    fun aShortFileIsReturnedWholeWithoutTrailingBlankLines() {
        assertEquals("a\nb", GameLogDiagnosis.tail(log("a\nb\n\n\n")))
    }

    @Test
    fun aMissingEmptyOrBlankLogHasNoTail() {
        assertNull(GameLogDiagnosis.tail(null))
        assertNull(GameLogDiagnosis.tail(File(tmp.root, "none.log")))
        assertNull(GameLogDiagnosis.tail(log("")))
        assertNull(GameLogDiagnosis.tail(log("\n\n  \n")))
        assertNull(GameLogDiagnosis.tail(tmp.root)) // папка, а не файл
    }

    @Test
    fun onlyTheLastBytesAreReadAndABrokenFirstLineIsDropped() {
        val file = log("x".repeat(50_000) + "\nfirst whole line\nlast line\n")

        val tail = GameLogDiagnosis.tail(file, maxLines = 10, maxBytes = 1024)

        assertEquals("first whole line\nlast line", tail)
    }

    @Test
    fun aWindowThatCutsInsideTheOnlyLineGivesNothingInsteadOfGarbage() {
        assertNull(GameLogDiagnosis.tail(log("y".repeat(5000)), maxBytes = 100))
    }

    @Test
    fun nonPositiveLimitsGiveNothing() {
        assertNull(GameLogDiagnosis.tail(log("a\n"), maxLines = 0))
        assertNull(GameLogDiagnosis.tail(log("a\n"), maxBytes = 0))
    }

    @Test
    fun memoryProblemsAreRecognised() {
        for (text in listOf(
            "java.lang.OutOfMemoryError: Java heap space",
            "Error occurred during initialization of VM\nCould not reserve enough space for 2097152KB object heap",
            "There is insufficient memory for the Java Runtime Environment to continue.",
        )) {
            assertEquals(text, listOf(LogHint.MEMORY), GameLogDiagnosis.hints(text))
        }
    }

    @Test
    fun aWrongJavaVersionIsRecognised() {
        val text = "java.lang.UnsupportedClassVersionError: net/minecraft/client/main/Main has been compiled by a more recent version of the Java Runtime"

        assertEquals(listOf(LogHint.JAVA_VERSION), GameLogDiagnosis.hints(text))
    }

    @Test
    fun aMissingNativeLibraryIsRecognised() {
        assertEquals(listOf(LogHint.NATIVE_LIBRARY), GameLogDiagnosis.hints("java.lang.UnsatisfiedLinkError: no lwjgl in java.library.path"))
    }

    @Test
    fun graphicsErrorsAreRecognised() {
        for (text in listOf("GLFW error 65543: EGL: Failed to create context", "Failed to create the GLFW window", "Unable to create OpenGL context")) {
            assertEquals(text, listOf(LogHint.GRAPHICS), GameLogDiagnosis.hints(text))
        }
    }

    @Test
    fun severalSignsGiveSeveralHintsInAStableOrderWithoutRepeats() {
        val text = "UnsatisfiedLinkError\nGLFW error 1\nOutOfMemoryError\nOutOfMemoryError\nGLFW error 2"

        assertEquals(listOf(LogHint.MEMORY, LogHint.NATIVE_LIBRARY, LogHint.GRAPHICS), GameLogDiagnosis.hints(text))
    }

    @Test
    fun anOrdinaryLogHasNoHints() {
        assertTrue(GameLogDiagnosis.hints(null).isEmpty())
        assertTrue(GameLogDiagnosis.hints("").isEmpty())
        assertFalse(GameLogDiagnosis.hints("[Render thread/INFO]: Setting user: Steve").isNotEmpty())
    }

    // --- hs_err: сбой самой Java ---

    /** Урезанный настоящий hs_err (JRE 8.0_442 на aarch64), в нём то, что нужно отчёту, и лишнее, что отчёту не нужно. */
    private val hsErr = """
        #
        # A fatal error has been detected by the Java Runtime Environment:
        #
        #  Internal Error (assembler_aarch64.hpp:237), pid=30111, tid=0x0000007080bb46f0
        #  guarantee(val < (1U << nbits)) failed: Field too big for insn
        #
        # JRE version:  (8.0_442) (build )
        # Java VM: OpenJDK 64-Bit Server VM (25.442-b00 mixed mode linux-aarch64 compressed oops)
        # Failed to write core dump. Core dumps have been disabled.
        #

        ---------------  T H R E A D  ---------------

        Current thread (0x0000007151a10800):  JavaThread "Unknown thread" [_thread_in_vm, id=30118]

        Stack: [0x0000007080abc000,0x0000007080bb6000],  sp=0x0000007080bb3fe0,  free space=1015k
        Native frames: (J=compiled Java code, j=interpreted, Vv=VM code, C=native code)
        V  [libjvm.so+0x6e0b7c]  Assembler::adr(Register, long)+0x40
        V  [libjvm.so+0x5a1c20]  StubGenerator::generate_call_stub()+0x100
        C  [libc.so+0x7a000]  __start_thread+0x40

        ---------------  P R O C E S S  ---------------

        VM Arguments:
        jvm_args: -Xms2048M -Xmx2048M -XX:ActiveProcessorCount=8
        java_command: mio.Wrapper net.minecraft.client.main.Main

        Memory: 16k page, physical 11823960k(7234228k free), swap 4194300k(4194300k free)

        CPU:total 8 (initial active 8) aarch64 fp asimd
        uname:Linux 6.1.99-android14 #1 SMP PREEMPT aarch64
        --------------- dynamic libraries ---------------
        70c0000000-70c0010000 r-xp /system/lib64/libfoo.so
    """.trimIndent()

    @Test
    fun theHsErrExcerptKeepsTheCauseTheMemoryLineAndTheFirstFrames() {
        val excerpt = GameLogDiagnosis.hsErrExcerpt(hsErr)!!

        assertTrue(excerpt.contains("Internal Error (assembler_aarch64.hpp:237)"))
        assertTrue(excerpt.contains("Field too big for insn"))
        assertTrue(excerpt.contains("Memory: 16k page"))
        assertTrue(excerpt.contains("jvm_args: -Xms2048M"))
        assertTrue(excerpt.contains("uname:Linux 6.1.99"))
        assertTrue(excerpt.contains("StubGenerator::generate_call_stub()"))
        assertFalse("the dynamic libraries list is noise", excerpt.contains("libfoo.so"))
        assertFalse("the empty comment lines are dropped", excerpt.lines().any { it == "#" })
    }

    @Test
    fun theHsErrExcerptHasALimit() {
        val huge = hsErr + "\n" + (1..5000).joinToString("\n") { "V  [libjvm.so+0x$it]  frame $it" }

        val excerpt = GameLogDiagnosis.hsErrExcerpt(huge, maxChars = 1000)!!

        assertTrue(excerpt.length <= 1000)
        assertTrue(excerpt.endsWith("…"))
        assertTrue("only a few frames are kept", GameLogDiagnosis.hsErrExcerpt(huge)!!.lines().count { it.startsWith("V  [") } <= 13)
    }

    @Test
    fun aBlankHsErrHasNoExcerpt() {
        assertNull(GameLogDiagnosis.hsErrExcerpt("  \n\n"))
        assertNull(GameLogDiagnosis.hsErrExcerpt(null as File?))
        assertNull(GameLogDiagnosis.hsErrExcerpt(File(tmp.root, "none.log")))
    }

    @Test
    fun theHsErrFileIsReadFromDisk() {
        val file = tmp.newFile("hs_err_pid1.log").apply { writeText(hsErr) }

        assertTrue(GameLogDiagnosis.hsErrExcerpt(file)!!.contains("Field too big for insn"))
    }

    @Test
    fun theHsErrPathIsTakenFromTheGameLog() {
        val log = "# An error report file with more information is saved as:\n" +
            "# /storage/emulated/0/Android/data/com.mclauncher.app/files/.minecraft/hs_err_pid30111.log\n" +
            "fdsan: attempted to close file descriptor 181"

        assertEquals(
            "/storage/emulated/0/Android/data/com.mclauncher.app/files/.minecraft/hs_err_pid30111.log",
            GameLogDiagnosis.hsErrPath(log),
        )
        assertNull(GameLogDiagnosis.hsErrPath("no crash here"))
        assertNull(GameLogDiagnosis.hsErrPath(null))
    }

    @Test
    fun theNewestFreshHsErrIsFoundInTheGameFolder() {
        val old = tmp.newFile("hs_err_pid1.log").apply { writeText("a"); setLastModified(1_000L) }
        val fresh = tmp.newFile("hs_err_pid2.log").apply { writeText("b"); setLastModified(5_000L) }
        tmp.newFile("hs_err_notes.txt").apply { setLastModified(9_000L) }

        assertEquals(fresh, GameLogDiagnosis.newestHsErr(tmp.root, notBeforeMs = 500L))
        assertEquals(fresh, GameLogDiagnosis.newestHsErr(tmp.root, notBeforeMs = 2_000L))
        assertNull("an old file belongs to an earlier run", GameLogDiagnosis.newestHsErr(tmp.root, notBeforeMs = 6_000L))
        assertNull(GameLogDiagnosis.newestHsErr(null, 0L))
        assertTrue(old.exists())
    }

    @Test
    fun aJvmCrashGetsItsOwnHint() {
        val hints = GameLogDiagnosis.hints("# A fatal error has been detected by the Java Runtime Environment:\n# Internal Error")

        assertTrue(LogHint.JVM_CRASH in hints)
        assertTrue(LogHint.JVM_CRASH in GameLogDiagnosis.hints("saved as: /x/hs_err_pid7.log"))
        assertFalse(LogHint.JVM_CRASH in GameLogDiagnosis.hints("java.lang.OutOfMemoryError: Java heap space"))
    }

    @Test
    fun theReportTextJoinsTheTailTheHsErrAndTheDevice() {
        val text = GameLogDiagnosis.withExtras("tail", "crash", "phone")!!

        assertEquals("tail\n\n— hs_err (выдержка) —\ncrash\n\n— устройство —\nphone", text)
        assertEquals("tail", GameLogDiagnosis.withExtras("tail", null, "  "))
        assertEquals("— устройство —\nphone", GameLogDiagnosis.withExtras(null, "", "phone"))
        assertNull(GameLogDiagnosis.withExtras(null, null, null))
        assertNull(GameLogDiagnosis.withExtras(" ", "", ""))
    }
}
