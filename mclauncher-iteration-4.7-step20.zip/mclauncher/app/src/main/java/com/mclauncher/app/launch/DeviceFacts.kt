package com.mclauncher.app.launch

/**
 * Что известно об устройстве и может объяснить падение игры или Java: модель, Android, процессор, размер страницы памяти,
 * объём памяти. Попадает в отчёт о вылете («Скопировать отчёт»). Чтение с устройства — в [DeviceFactsReader], здесь
 * только данные и текст, поэтому класс проверяется обычными JVM-тестами.
 *
 * @property pageSizeBytes размер страницы памяти ядра Linux (`sysconf(_SC_PAGESIZE)`): обычно 4096, на новых телефонах
 *   с Android 15+ бывает 16384; часть программ (в том числе старые сборки Java) на нём ведёт себя иначе. `null` — не узнали.
 */
data class DeviceFacts(
    val manufacturer: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val abis: List<String>,
    val pageSizeBytes: Long?,
    val totalMemoryMb: Long,
    val kernel: String?,
) {
    /** Страница памяти отличается от обычных 4 КБ. */
    val hasUnusualPageSize: Boolean get() = pageSizeBytes != null && pageSizeBytes != STANDARD_PAGE_SIZE

    fun describe(): String = buildString {
        appendLine("Устройство: ${listOf(manufacturer, model).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "?" }}")
        appendLine("Android: $androidRelease (API $sdkInt)")
        appendLine("Процессор (ABI): ${abis.joinToString(", ").ifBlank { "?" }}")
        if (!kernel.isNullOrBlank()) appendLine("Ядро Linux: $kernel")
        val page = pageSizeBytes
        appendLine(
            "Страница памяти: " + when {
                page == null -> "не удалось узнать"
                hasUnusualPageSize -> "$page байт (НЕ 4096: на таких телефонах некоторые программы работают иначе)"
                else -> "$page байт"
            },
        )
        append("Оперативная память: ${if (totalMemoryMb > 0) "$totalMemoryMb МБ" else "не удалось узнать"}")
    }

    companion object {
        const val STANDARD_PAGE_SIZE = 4096L
    }
}
