package com.mclauncher.app.launch

import android.content.Context
import android.os.Build
import android.system.Os
import android.system.OsConstants

/** Читает [DeviceFacts] с устройства. Любой сбой чтения превращается в «не удалось узнать»: отчёт важнее одной строки. */
object DeviceFactsReader {

    fun read(context: Context): DeviceFacts = DeviceFacts(
        manufacturer = Build.MANUFACTURER.orEmpty(),
        model = Build.MODEL.orEmpty(),
        androidRelease = Build.VERSION.RELEASE.orEmpty(),
        sdkInt = Build.VERSION.SDK_INT,
        abis = Build.SUPPORTED_ABIS?.toList().orEmpty(),
        pageSizeBytes = pageSize(),
        totalMemoryMb = DeviceMemory.totalMb(context),
        kernel = try {
            System.getProperty("os.version")
        } catch (e: SecurityException) {
            null
        },
    )

    private fun pageSize(): Long? = try {
        Os.sysconf(OsConstants._SC_PAGESIZE).takeIf { it > 0 }
    } catch (e: Exception) {
        null
    }
}
