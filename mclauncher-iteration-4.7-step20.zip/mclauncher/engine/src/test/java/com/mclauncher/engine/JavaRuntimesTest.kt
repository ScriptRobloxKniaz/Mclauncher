package com.mclauncher.engine

import org.junit.Assert.assertEquals
import org.junit.Test

class JavaRuntimesTest {

    @Test
    fun autoKeepsTheRequiredVersion() {
        assertEquals(8, JavaRuntimes.choose(8, null))
        assertEquals(21, JavaRuntimes.choose(21, null))
    }

    @Test
    fun aNewerChoiceWins() {
        assertEquals(17, JavaRuntimes.choose(8, 17))
        assertEquals(21, JavaRuntimes.choose(8, 21))
        assertEquals(21, JavaRuntimes.choose(17, 21))
    }

    @Test
    fun anOlderOrEqualChoiceNeverLowersTheRequirement() {
        assertEquals(17, JavaRuntimes.choose(17, 8))
        assertEquals(21, JavaRuntimes.choose(21, 17))
        assertEquals(17, JavaRuntimes.choose(17, 17))
    }

    @Test
    fun aChoiceBetweenShippedRuntimesGoesToTheNextShippedOne() {
        // Mojang указывает, например, 16 (1.17): рантайма 16 нет, берётся ближайший не меньший
        assertEquals(17, JavaRuntimes.choose(8, 11))
        assertEquals(21, JavaRuntimes.choose(8, 18))
    }

    @Test
    fun aChoiceNewerThanEveryRuntimeFallsBackToTheRequirement() {
        assertEquals(8, JavaRuntimes.choose(8, 99))
    }
}
