#!/usr/bin/env python3
"""Быстрая проверка проекта без Android SDK: то, что компилятор нашёл бы не сразу, а в CI — только через несколько минут.

Что проверяется:
  1. Строки: набор имён в values/strings.xml (en) и values-ru/strings.xml совпадает, нет дубликатов,
     у одной строки в обоих языках одинаковые подстановки (%1$s, %2$d).
  2. Каждая `R.string.имя` в коде и каждая `@string/имя` в XML существует.
  3. Каждый `import com.mclauncher...` указывает на объявленный в проекте класс, функцию или свойство.
  4. Во всех ленивых списках (LazyColumn, LazyVerticalGrid, ...) у `item`/`items` задан `key`.
  5. Скобки в каждом .kt-файле сбалансированы (с учётом строк и комментариев).
  (6–9: повторные объявления, библиотеки рендереров, регулярные выражения для Android, вложенные комментарии;
  10: скрипты, которые вызывает workflow, существуют.)

Это не замена компилятору: типы, перегрузки и сигнатуры Compose он не проверяет. Запуск: `python3 scripts/check_project.py`.
Код возврата 0 — всё в порядке, 1 — есть замечания.
"""
import re
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
errors: list[str] = []


def fail(message: str) -> None:
    errors.append(message)


def kotlin_files() -> list[Path]:
    return sorted(
        p for module in ("app", "engine") for p in (ROOT / module / "src" / "main").rglob("*.kt")
    )


# ---------------------------------------------------------------- 1. строки

def load_strings(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        fail(f"нет файла {path.relative_to(ROOT)}")
        return result
    for node in ET.parse(path).getroot().findall("string"):
        name = node.get("name")
        if name in result:
            fail(f"{path.relative_to(ROOT)}: строка {name} объявлена дважды")
        result[name] = "".join(node.itertext())
    return result


def placeholders(text: str) -> list[str]:
    return sorted(re.findall(r"%\d+\$[sd]|%[sd]", text))


res = ROOT / "app" / "src" / "main" / "res"
en = load_strings(res / "values" / "strings.xml")
ru = load_strings(res / "values-ru" / "strings.xml")
for name in sorted(set(en) - set(ru)):
    fail(f"строка {name} есть в en, но нет в ru")
for name in sorted(set(ru) - set(en)):
    fail(f"строка {name} есть в ru, но нет в en")
for name in sorted(set(en) & set(ru)):
    if placeholders(en[name]) != placeholders(ru[name]):
        fail(f"строка {name}: подстановки в en {placeholders(en[name])} и в ru {placeholders(ru[name])} различаются")
    if not ru[name].strip() or not en[name].strip():
        fail(f"строка {name}: пустой текст")

# ---------------------------------------------------------------- 2. ссылки на строки

used: set[str] = set()
for path in kotlin_files():
    for match in re.finditer(r"\bR\.string\.(\w+)", path.read_text(encoding="utf-8")):
        used.add(match.group(1))
        if match.group(1) not in en:
            fail(f"{path.relative_to(ROOT)}: R.string.{match.group(1)} не объявлена в strings.xml")
for path in list((ROOT / "app" / "src" / "main").rglob("*.xml")):
    if "values" in path.parts[-2]:
        continue
    for match in re.finditer(r"@string/(\w+)", path.read_text(encoding="utf-8")):
        used.add(match.group(1))
        if match.group(1) not in en:
            fail(f"{path.relative_to(ROOT)}: @string/{match.group(1)} не объявлена")

# ---------------------------------------------------------------- 3. импорты проекта

DECL = re.compile(
    r"^[ \t]*(?:@\w+(?:\([^)]*\))?[ \t]*)*"
    r"(?:(?:public|internal|private|protected|inline|data|sealed|enum|abstract|open|value|annotation|const|"
    r"lateinit|suspend|operator|infix|tailrec|external|fun)[ \t]+)*"
    r"(class|object|interface|fun|val|var|typealias)[ \t]+(?:<[^>]+>[ \t]+)?([\w.<>?,* ]*?)(\w+)[ \t]*(?=[(:=<{ \n]|$)",
    re.M,
)
declared: dict[str, set[str]] = defaultdict(set)
for path in kotlin_files():
    text = path.read_text(encoding="utf-8")
    package = re.search(r"^package ([\w.]+)", text, re.M)
    if not package:
        continue
    for match in DECL.finditer(text):
        declared[package.group(1)].add(match.group(3))
    # Объявления внутри enum/sealed/object тоже можно импортировать (`import ...Destination.Home`), но такие импорты
    # начинаются с имени вложенного класса: проверяем только первый сегмент после пакета.

for path in kotlin_files():
    text = path.read_text(encoding="utf-8")
    for match in re.finditer(r"^import (com\.mclauncher\.[\w.]+?)(?: as \w+)?$", text, re.M):
        full = match.group(1)
        if full == "com.mclauncher.app.R":  # генерируется Android Gradle Plugin, в исходниках его нет
            continue
        parts = full.split(".")
        # Ищем самый длинный префикс-пакет, в котором объявлено следующее имя.
        found = any(
            ".".join(parts[:i]) in declared and parts[i] in declared[".".join(parts[:i])]
            for i in range(2, len(parts))
        )
        if not found:
            fail(f"{path.relative_to(ROOT)}: import {full} не найден в проекте")

# ---------------------------------------------------------------- 4. ключи в ленивых списках

LAZY_CALL = re.compile(r"\b(items|itemsIndexed|item)\(")


def call_arguments(text: str, open_paren: int) -> str:
    depth = 0
    for i in range(open_paren, len(text)):
        if text[i] == "(":
            depth += 1
        elif text[i] == ")":
            depth -= 1
            if depth == 0:
                return text[open_paren + 1 : i]
    return text[open_paren + 1 :]


for path in kotlin_files():
    text = path.read_text(encoding="utf-8")
    if "androidx.compose.foundation.lazy" not in text:
        continue
    for match in LAZY_CALL.finditer(text):
        args = call_arguments(text, match.end() - 1)
        line = text.count("\n", 0, match.start()) + 1
        if not re.search(r"\bkey\s*=", args):
            fail(f"{path.relative_to(ROOT)}:{line}: {match.group(1)}(...) в ленивом списке без key")

# ---------------------------------------------------------------- 5. скобки


def strip_noise(text: str) -> str:
    """Убирает строки, символы и комментарии, чтобы скобки внутри них не мешали подсчёту."""
    out = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if text.startswith("//", i):
            while i < n and text[i] != "\n":
                i += 1
        elif text.startswith("/*", i):
            depth = 1
            i += 2
            while i < n and depth:
                if text.startswith("/*", i):
                    depth += 1
                    i += 2
                elif text.startswith("*/", i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
        elif text.startswith('"""', i):
            i += 3
            while i < n and not text.startswith('"""', i):
                i += 1
            i += 3
        elif c == '"':
            i += 1
            while i < n and text[i] != '"':
                i += 2 if text[i] == "\\" else 1
            i += 1
        elif c == "'":
            i += 1
            while i < n and text[i] != "'":
                i += 2 if text[i] == "\\" else 1
            i += 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


for path in kotlin_files():
    clean = strip_noise(path.read_text(encoding="utf-8"))
    for open_c, close_c in ("()", "[]", "{}"):
        if clean.count(open_c) != clean.count(close_c):
            fail(f"{path.relative_to(ROOT)}: скобки {open_c}{close_c} не сбалансированы ({clean.count(open_c)} / {clean.count(close_c)})")

# ---------------------------------------------------------------- 6. повторные объявления верхнего уровня

# Компилятор Kotlin ругается на два одноимённых `val`/`class`/`object` на верхнем уровне одного файла («Conflicting
# declarations») — так однажды сломалась сборка из-за второй `private const val MEGABYTE`. Функции не проверяются:
# перегрузки законны. Между файлами сравниваются только непубличные... точнее, только объявления без `private`.
TOP_DECL = re.compile(
    r"^(?P<mods>(?:(?:private|internal|public|const|data|sealed|enum|annotation|value|fun|open|abstract|inline)\s+)*)"
    r"(?P<kind>val|var|class|object|interface|typealias)\s+(?:<[^>]+>\s+)?(?P<name>[\w.]+)",
    re.M,
)
PACKAGE = re.compile(r"^package\s+([\w.]+)", re.M)
public_decls: dict[tuple[str, str, str], Path] = {}
for path in kotlin_files():
    clean = strip_noise(path.read_text(encoding="utf-8"))
    package = (PACKAGE.search(clean) or [None, ""])[1]
    seen_in_file: dict[tuple[str, str], int] = {}
    for m in TOP_DECL.finditer(clean):
        kind = "property" if m["kind"] in ("val", "var") else "type"
        key = (kind, m["name"])
        seen_in_file[key] = seen_in_file.get(key, 0) + 1
        if seen_in_file[key] == 2:
            fail(f"{path.relative_to(ROOT)}: «{m['name']}» объявлено на верхнем уровне больше одного раза (Conflicting declarations)")
        if "private" not in m["mods"].split():
            other = public_decls.setdefault((package, kind, m["name"]), path)
            if other != path:
                fail(f"{path.relative_to(ROOT)}: «{m['name']}» уже объявлено в {other.relative_to(ROOT)} (пакет {package})")

# ---------------------------------------------------------------- 7. библиотеки рендереров

# Рендереры скачиваются на устройстве по манифесту (app/src/main/assets/renderers/renderers-manifest.txt, пишет
# scripts/fetch_core.py). Всё, что требует RendererProfile, должно в нём быть, иначе выбор рендерера закончится «рендерер не
# скачан» на устройстве, а не ошибкой сборки. Сверяем имена файлов по исходникам (точнее — JVM-тест RendererManifestTest).
profile_path = ROOT / "engine/src/main/java/com/mclauncher/engine/launch/RendererProfile.kt"
manifest_path = ROOT / "app/src/main/assets/renderers/renderers-manifest.txt"
if profile_path.is_file():
    if not manifest_path.is_file():
        fail("нет app/src/main/assets/renderers/renderers-manifest.txt: приложению нечего скачивать (python3 -I scripts/fetch_core.py --renderer-manifest)")
    else:
        profile_text = profile_path.read_text(encoding="utf-8")
        manifest_text = manifest_path.read_text(encoding="utf-8")
        wanted: set[str] = set()
        for m in re.finditer(r'(?:library|eglLibrary)\s*=\s*"(lib[\w.+-]+\.so)"', profile_text):
            wanted.add(m[1])
        for m in re.finditer(r"extraLibraries\s*=\s*listOf\(([^)]*)\)", profile_text):
            wanted.update(re.findall(r'"(lib[\w.+-]+\.so)"', m[1]))
        ids = set(re.findall(r'^\s+id\s*=\s*"([a-z0-9_]+)"', profile_text, re.M))
        provided: set[str] = set()
        manifest_ids: set[str] = set()
        for line in manifest_text.splitlines():
            parts = line.split()
            if len(parts) == 2 and parts[0] == "renderer":
                manifest_ids.add(parts[1])
            elif len(parts) == 6 and parts[0] == "download":
                provided.update(parts[5].split(","))
        if not wanted:
            fail("RendererProfile.kt: не найдено ни одной библиотеки рендерера (изменился формат файла? поправьте проверку)")
        for name in sorted(wanted - provided):
            fail(f"RendererProfile.kt требует {name}, а в renderers-manifest.txt её нет")
        for rid in sorted(ids - manifest_ids):
            fail(f"RendererProfile.kt: рендерера «{rid}» нет в renderers-manifest.txt")

# ---------------------------------------------------------------- 8. регулярные выражения для Android

# На телефоне `Regex` работает на ICU, а наши JVM-тесты — на java.util.regex. Он прощает то, что ICU не прощает:
# одиночную `}` и `{`, не являющуюся квантификатором (`{3}`, `{2,}`, `{1,4}`). Тогда тесты зелёные, а на устройстве
# `PatternSyntaxException` при первом же обращении. Ловим это по тексту: литералы в `Regex("...")` и `Regex("""...""")`.
QUANTIFIER = re.compile(r"\{\d+(?:,\d*)?\}")


def icu_problem(pattern: str) -> str | None:
    i, in_class = 0, False
    while i < len(pattern):
        ch = pattern[i]
        if ch == "\\":
            i += 2
            continue
        if in_class:
            if ch == "]":
                in_class = False
        elif ch == "[":
            in_class = True
        elif ch == "{":
            m = QUANTIFIER.match(pattern, i)
            if not m:
                return f"`{{` в позиции {i} не начинает квантификатор — нужно `\\{{`"
            i = m.end()
            continue
        elif ch == "}":
            return f"`}}` в позиции {i} без пары — нужно `\\}}`"
        i += 1
    return None


for path in kotlin_files():
    text = path.read_text(encoding="utf-8")
    for m in re.finditer(r'Regex\(\s*(?:"""(.*?)"""|"((?:[^"\\\n]|\\.)*)")', text, re.S):
        raw, quoted = m.group(1), m.group(2)
        # В обычной строке Kotlin `\\` — один обратный слеш; в сырой (`"""`) — как написано.
        pattern = raw if raw is not None else quoted.replace("\\\\", "\\")
        problem = icu_problem(pattern)
        if problem:
            line = text.count("\n", 0, m.start()) + 1
            fail(f"{path.relative_to(ROOT)}:{line}: регулярное выражение не примет Android (ICU): {problem}")

# ---------------------------------------------------------------- 9. вложенные комментарии Kotlin

# В Kotlin комментарии вкладываются: `/*` внутри KDoc (например, в пути `lib/<abi>/*.so`) открывает ещё один и не
# закрывается — «unclosed comment». JVM-раннер ловит это только в файлах без Android; здесь — во всех. Разбор по символам:
# строки и символы пропускаются, вложенный `/*` внутри комментария — замечание.
def nested_comment_lines(text: str) -> list[int]:
    found: list[int] = []
    i, n, line, depth = 0, len(text), 1, 0
    while i < n:
        c = text[i]
        two = text[i:i + 2]
        if c == "\n":
            line += 1
            i += 1
        elif depth > 0:
            if two == "/*":
                found.append(line)
                depth += 1
                i += 2
            elif two == "*/":
                depth -= 1
                i += 2
            else:
                i += 1
        elif two == "/*":
            depth = 1
            i += 2
        elif two == "//":
            while i < n and text[i] != "\n":
                i += 1
        elif text.startswith('"""', i):
            end = text.find('"""', i + 3)
            end = n if end < 0 else end + 3
            line += text.count("\n", i, end)
            i = end
        elif c == '"' or c == "'":
            i += 1
            while i < n and text[i] != c and text[i] != "\n":
                i += 2 if text[i] == "\\" else 1
            i += 1
        else:
            i += 1
    return found

for path in sorted(ROOT.rglob("*.kt")):
    if any(part in {"build", ".gradle"} for part in path.parts):
        continue
    for ln in nested_comment_lines(path.read_text(encoding="utf-8")):
        fail(f"{path.relative_to(ROOT)}:{ln}: `/*` внутри комментария открывает вложенный (в Kotlin они вкладываются) и не закрывается")

# ---------------------------------------------------------------- 10. скрипты, которые зовёт workflow

# workflow лежит в репозитории отдельно от zip и меняется вручную; скрипты, которые он вызывает, едут с проектом. Если
# workflow зовёт скрипт, которого в проекте нет, CI упадёт на этом шаге — ловим это здесь.
_workflow = ROOT / ".github" / "workflows" / "build.yml"
if _workflow.is_file():
    for _name in sorted(set(re.findall(r"scripts/([A-Za-z0-9_]+\.(?:py|sh))", _workflow.read_text(encoding="utf-8")))):
        if not (ROOT / "scripts" / _name).is_file():
            fail(f".github/workflows/build.yml вызывает scripts/{_name}, а такого файла нет")

# ---------------------------------------------------------------- итог

unused = sorted(set(en) - used)
if errors:
    print("Замечания:")
    for message in errors:
        print("  -", message)
    sys.exit(1)
print(f"OK: строк {len(en)} (en) / {len(ru)} (ru), Kotlin-файлов {len(kotlin_files())}")
if unused:
    print(f"Справка: строки, на которые нет ссылок в коде ({len(unused)}): {', '.join(unused)}")
