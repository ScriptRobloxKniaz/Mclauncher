package com.mclauncher.app.ui.navigation

import android.net.Uri
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.AnimatedContentTransitionScope.SlideDirection
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.BackgroundPreset
import com.mclauncher.app.data.settings.BackgroundSelection
import com.mclauncher.app.data.versions.VersionLibraryState
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.ui.about.AboutScreen
import com.mclauncher.app.ui.accounts.AccountsScreen
import com.mclauncher.app.ui.assistant.AssistantScreen
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.common.CollectUiEvents
import com.mclauncher.app.ui.home.HomeScreen
import com.mclauncher.app.ui.placeholder.PlaceholderScreen
import com.mclauncher.app.ui.play.PlayScreen
import com.mclauncher.app.ui.settings.CoreControls
import com.mclauncher.app.ui.settings.CoreViewModel
import com.mclauncher.app.ui.settings.GraphicsControls
import com.mclauncher.app.ui.settings.GraphicsViewModel
import com.mclauncher.app.ui.settings.SettingsScreen
import com.mclauncher.app.ui.settings.VideoControls
import com.mclauncher.app.ui.skins.SkinsScreen
import com.mclauncher.app.ui.versions.VersionsScreen

/** Длительность перехода между вкладками: короткая, чтобы меню отзывалось сразу. */
private const val TAB_FADE_MS = 180
private const val FULLSCREEN_MS = 260

/**
 * Переход на экран из бокового меню или с главного.
 *
 * Вкладки и вторичные экраны ([Placement.SIDEBAR], [Placement.SECONDARY]) открываются **поверх главной**: всё, что
 * лежало выше неё, закрывается и уничтожается вместе со своей ViewModel. Состояние ушедших экранов не копится
 * (раньше `saveState/restoreState` держал в памяти каждую вкладку) — цена вопроса: положение прокрутки вкладки
 * после возврата сбрасывается. Полноэкранные экраны кладутся поверх текущего, и «назад» возвращает на него.
 */
fun NavController.navigateTo(destination: Destination) {
    if (currentDestination?.route == destination.route) return
    navigate(destination.route) {
        launchSingleTop = true
        if (destination.placement != Placement.FULLSCREEN) {
            popUpTo(Destination.Home.route) { inclusive = false }
        }
    }
}

@Composable
fun LauncherNavHost(
    navController: NavHostController,
    activeAccount: ActiveAccountState,
    library: VersionLibraryState?,
    launchPhase: LaunchPhase,
    onPlay: (versionId: String?) -> Unit,
    onSelectVersion: (String) -> Unit,
    backgroundSelection: BackgroundSelection,
    customBackgroundPreview: ImageBitmap?,
    videoControls: VideoControls,
    onSelectPreset: (BackgroundPreset) -> Unit,
    onPickCustomBackground: (Uri) -> Unit,
    modifier: Modifier = Modifier,
) {
    val navigate: (Destination) -> Unit = remember(navController) { { destination -> navController.navigateTo(destination) } }

    NavHost(
        navController = navController,
        startDestination = Destination.Home.route,
        modifier = modifier,
        enterTransition = { enter() },
        exitTransition = { exit() },
        popEnterTransition = { enter() },
        popExitTransition = { exit() },
    ) {
        composable(Destination.Home.route) {
            HomeScreen(
                activeAccount = activeAccount,
                library = library,
                launchPhase = launchPhase,
                onPlay = onPlay,
                onSelectVersion = onSelectVersion,
                backgroundSelection = backgroundSelection,
                customBackgroundPreview = customBackgroundPreview,
                videoActive = videoControls.settings.active,
                onSelectPreset = onSelectPreset,
                onPickCustomBackground = onPickCustomBackground,
                onPickCustomVideo = videoControls.onPick,
                onNavigate = navigate,
            )
        }
        composable(Destination.Play.route) {
            PlayScreen(
                activeAccount = activeAccount,
                library = library,
                launchPhase = launchPhase,
                onPlay = onPlay,
                onSelectVersion = onSelectVersion,
                onNavigate = navigate,
            )
        }
        composable(Destination.Mods.route) {
            PlaceholderScreen(
                destination = Destination.Mods,
                message = stringResource(R.string.placeholder_mods),
            )
        }
        composable(Destination.ResourcePacks.route) {
            PlaceholderScreen(
                destination = Destination.ResourcePacks,
                message = stringResource(R.string.placeholder_resourcepacks),
            )
        }
        composable(Destination.Shaders.route) {
            PlaceholderScreen(
                destination = Destination.Shaders,
                message = stringResource(R.string.placeholder_shaders),
            )
        }
        composable(Destination.Settings.route) {
            val coreViewModel: CoreViewModel = viewModel()
            val coreState by coreViewModel.state.collectAsStateWithLifecycle()
            val graphicsViewModel: GraphicsViewModel = viewModel()
            val graphicsState by graphicsViewModel.state.collectAsStateWithLifecycle()
            CollectUiEvents(graphicsViewModel.events)

            val core = remember(coreState, coreViewModel) {
                CoreControls(
                    state = coreState,
                    onInstall = coreViewModel::install,
                    onCancel = coreViewModel::cancel,
                    onRefresh = coreViewModel::refresh,
                )
            }
            val graphics = remember(graphicsState, graphicsViewModel) {
                GraphicsControls(
                    settings = graphicsState,
                    onRendererChange = graphicsViewModel::setRenderer,
                    onUseZinkChange = graphicsViewModel::setUseZink,
                    onGlVersionChange = graphicsViewModel::setGlVersion,
                )
            }
            SettingsScreen(video = videoControls, core = core, graphics = graphics)
        }
        composable(Destination.Assistant.route) {
            AssistantScreen()
        }
        composable(Destination.About.route) {
            AboutScreen()
        }
        composable(Destination.Accounts.route) {
            AccountsScreen(onOpenSkins = { navigate(Destination.Skins) })
        }
        composable(Destination.Skins.route) {
            SkinsScreen(onOpenAccounts = { navigate(Destination.Accounts) })
        }
        composable(Destination.Versions.route) {
            VersionsScreen(onBack = { navController.popBackStack() })
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Анимации переходов
//  - между вкладками: только короткое растворение. Сдвиг целого экрана с вложенной сеткой и полупрозрачными карточками
//    заставлял GPU каждый кадр перерисовывать оба экрана — на слабых телефонах это и было заметным лагом;
//  - полноэкранные экраны (версии): въезжают справа, при возврате уезжают вправо; экран под ними мягко гаснет.
// ---------------------------------------------------------------------------------------------

private fun AnimatedContentTransitionScope<NavBackStackEntry>.isFullscreen(entry: NavBackStackEntry): Boolean =
    Destination.fromRoute(entry.destination.route)?.placement == Placement.FULLSCREEN

private fun AnimatedContentTransitionScope<NavBackStackEntry>.enter(): EnterTransition = when {
    isFullscreen(targetState) ->
        slideIntoContainer(SlideDirection.Left, tween(FULLSCREEN_MS)) + fadeIn(tween(FULLSCREEN_MS))

    else -> fadeIn(tween(TAB_FADE_MS, delayMillis = 40))
}

private fun AnimatedContentTransitionScope<NavBackStackEntry>.exit(): ExitTransition = when {
    isFullscreen(initialState) ->
        slideOutOfContainer(SlideDirection.Right, tween(FULLSCREEN_MS)) + fadeOut(tween(FULLSCREEN_MS))

    else -> fadeOut(tween(TAB_FADE_MS - 60))
}
