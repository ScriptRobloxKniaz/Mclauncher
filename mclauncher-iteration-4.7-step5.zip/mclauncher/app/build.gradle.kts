import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
    alias(libs.plugins.room)
}

// Секреты читаются из local.properties, а при его отсутствии — из переменных окружения.
// В репозиторий они не попадают (local.properties в .gitignore).
val localProps = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) file.inputStream().use { load(it) }
}

fun secret(name: String): String =
    (localProps.getProperty(name) ?: System.getenv(name) ?: "").trim()

android {
    namespace = "com.mclauncher.app"
    compileSdk = 37 // свежие androidx-библиотеки (BOM 2026.09) требуют compileSdk 37; targetSdk при этом остаётся 35

    defaultConfig {
        applicationId = "com.mclauncher.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"

        // Пустая строка, если ключ не задан: UI должен показать «вход через Microsoft не настроен».
        buildConfigField("String", "MS_CLIENT_ID", "\"${secret("MS_CLIENT_ID")}\"")

        // Ядро игры собрано только под arm64 (решение владельца проекта; см. docs/ENGINE.md).
        ndk {
            abiFilters += "arm64-v8a"
        }
    }

    // Нативные библиотеки распаковываются в папку приложения при установке (а не читаются из APK): оттуда запускается
    // libunpack200.so, и по этому пути их ищет ядро (EngineLayout.nativeLibraryDir).
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    // Архивы рантаймов Java уже сжаты: хранить их в APK без повторного сжатия быстрее и не больше по размеру.
    androidResources {
        noCompress += "xz"
    }

    buildTypes {
        release {
            // Пока выключено: shrinker легко ломает JNI/рефлексию.
            // Включим после итерации 4, когда появятся правила для Pojav.
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    // Байткод Java 11 (как в ТЗ). Сам Gradle/AGP 9 запускается на JDK 17+.
    // jvmTarget у Kotlin по умолчанию берётся отсюда.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    // Схемы Room для будущих миграций
    room {
        schemaDirectory("$projectDir/schemas")
    }
}

dependencies {
    // Ядро игры (Pojav/Zalith): раскладка компонентов, сборка команды запуска JVM
    implementation(project(":engine"))

    // Compose + Material 3
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.core)
    implementation(libs.androidx.compose.animation)

    // AndroidX
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.documentfile) // SAF: работа с деревом документов

    // Видео-фон (.mp4): ExoPlayer играет по кругу, PlayerView показывает картинку без элементов управления
    implementation(libs.androidx.media3.exoplayer)
    implementation(libs.androidx.media3.ui)

    // Фоновая установка игрового ядра (служба переднего плана с уведомлением)
    implementation(libs.androidx.work.runtime)

    // Room (профили и аккаунты)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // DataStore (настройки)
    implementation(libs.androidx.datastore.preferences)

    // Coroutines
    implementation(libs.kotlinx.coroutines.android)

    // JSON: описания версий Mojang разбираются вручную через JsonElement (без плагина компилятора)
    implementation(libs.kotlinx.serialization.json)

    testImplementation(libs.junit)

    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
