// Модуль ядра игры. Чистая логика на Kotlin без Android-классов: раскладка компонентов, выбор LWJGL и Java, сборка
// команды запуска JVM и установка компонентов из ассетов (распаковка tar.xz, проверка SHA-256). Файлы ядра
// (src/main/assets/core, src/main/jniLibs) кладёт scripts/fetch_core.py --install; в git их нет. Нативная часть
// (ndk-build) и процесс игры добавятся позже в 4.7b — см. docs/ENGINE.md.
plugins {
    alias(libs.plugins.android.library)
}

android {
    namespace = "com.mclauncher.engine"
    compileSdk = 37 // как у :app (см. комментарий там)

    defaultConfig {
        minSdk = 26
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    // Распаковка .tar.xz рантаймов Java: commons-compress читает tar, xz снимает сжатие
    implementation(libs.commons.compress)
    implementation(libs.xz)

    testImplementation(libs.junit)
}
