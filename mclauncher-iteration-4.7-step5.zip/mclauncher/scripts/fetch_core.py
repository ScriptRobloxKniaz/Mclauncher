#!/usr/bin/env python3
"""Ядро игры (ZalithLauncher 2) из закреплённой ревизии — этапы 4.7a и 4.7b.

Два режима.

1. Проверка (без аргументов) — этап 4.7a:
     python3 -I scripts/fetch_core.py
   Скачивает из GitHub ТОЛЬКО дерево файлов закреплённого коммита (без содержимого — несколько мегабайт, а не ~900 МБ)
   и проверяет, что на месте все файлы, на которые опирается модуль :engine (см. REQUIRED и docs/ENGINE.md).
   Ничего не копирует. Код возврата: 0 — всё на месте; 1 — чего-то нет или ревизия недоступна.

2. Установка — этап 4.7b:
     python3 -I scripts/fetch_core.py --install [--java 8,17,21] [--engine-dir engine]
   Забирает ТОЛЬКО нужные файлы (частичный клон + sparse checkout: около 110 МБ вместо ~900 МБ) и раскладывает их
   в модуль :engine, откуда Gradle упакует их в APK:
     engine/src/main/assets/core/…          компоненты, рантаймы Java, лицензии и core-manifest.txt
     engine/src/main/jniLibs/arm64-v8a/…    libopenal.so, libunpack200.so
   `core-manifest.txt` пишется здесь же: список файлов с размерами и SHA-256 — по нему приложение на устройстве
   распаковывает и проверяет компоненты (см. CoreManifest в :engine). Эти файлы НЕ хранятся в git (.gitignore).

Скрипт ходит только на хост из ALLOWED_REPOS и только по закреплённому SHA из engine/UPSTREAM.
"""
import argparse
import hashlib
import os
import posixpath
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UPSTREAM_FILE = ROOT / "engine" / "UPSTREAM"

# Читаем адрес из файла проекта, но ходим только на известный хост: ошибка в файле не должна уводить на чужой сервер.
ALLOWED_REPOS = {"https://github.com/ZalithLauncher/ZalithLauncher2.git"}

# Относительно корня репозитория апстрима. Каждый путь проверен по ревизии из engine/UPSTREAM.
APP = "ZalithLauncher/src/main"
LIBS = "ZalithLauncher/libs"
REQUIRED = [
    "LICENSE",
    # Нативная часть (ndk-build)
    f"{APP}/jni/Android.mk",
    f"{APP}/jni/Application.mk",
    f"{APP}/jni/jre_launcher.c",
    f"{APP}/jni/egl_bridge.c",
    # Java-классы моста: имена пакетов зашиты в JNI-символы libpojavexec.so
    f"{APP}/java/com/movtery/zalithlauncher/bridge/ZLBridge.java",
    f"{APP}/java/com/movtery/zalithlauncher/bridge/LoggerBridge.java",
    f"{APP}/java/org/lwjgl/glfw/CallbackBridge.java",
    # Эталон сборки команды запуска (портирован в :engine)
    f"{APP}/java/com/movtery/zalithlauncher/game/launch/LaunchArgs.kt",
    f"{APP}/java/com/movtery/zalithlauncher/game/launch/Launcher.kt",
    # Наборы LWJGL: пропатченные jar'ы (нативы лежат в AAR ниже)
    f"{APP}/assets/app_runtime/lwjgl/3.3.3/lwjgl.jar",
    f"{APP}/assets/app_runtime/lwjgl/3.4.1/lwjgl.jar",
    f"{LIBS}/lwjgl-3.3.3-natives-release.aar",
    f"{LIBS}/lwjgl-3.4.1-natives-release.aar",
    # Компоненты запуска
    f"{APP}/assets/components/launcher/MioLaunchWrapper.jar",
    f"{APP}/assets/components/launcher/MioLibPatcher.jar",
    f"{APP}/assets/components/auth_libs/authlib-injector.jar",
    # Рантаймы Java: общий архив и архив под архитектуру
    *[f"{APP}/assets/runtimes/jre-{v}/{name}" for v in (8, 17, 21, 25) for name in ("universal.tar.xz", "bin-arm64.tar.xz")],
    # Звук и распаковщик .pack (Java 8)
    f"{LIBS}/openal-soft-release.aar",
    f"{APP}/jniLibs/arm64-v8a/libunpack200.so",
]

SHA_RE = re.compile(r"^[0-9a-f]{40}$")

# ------------------------------------------------------------------------------------------------ режим установки

# Версии LWJGL, которые есть в ядре (см. LwjglVersion в :engine).
LWJGL_VERSIONS = ("3.3.3", "3.4.1")
# Файлы компонента запуска, нужные для старта игры. Остальные (forge_installer, HMCL, nide8auth, caciocavallo)
# не берём: они нужны отдельным возможностям, а их лицензии не подтверждены (THIRD_PARTY_NOTICES.md).
LAUNCHER_FILES = ("MioLaunchWrapper.jar", "MioLibPatcher.jar")
SUPPORTED_JAVA = (8, 17, 21, 25)
DEFAULT_JAVA = (8, 17, 21)

# Только ABI, для которого рантаймы и нативы проверены по архивам; остальные добавляются осознанно.
ABI_TO_RUNTIME_PACK = {"arm64-v8a": "arm64"}

# Путь в манифесте: короткие сегменты без пробелов и «..» — манифест построчный, пробел разделяет поля.
SAFE_REL = re.compile(r"^[A-Za-z0-9._+\-]+(/[A-Za-z0-9._+\-]+)*$")

MANIFEST_NAME = "core-manifest.txt"
MANIFEST_FORMAT = 1


class FetchError(Exception):
    pass


def read_pin() -> dict:
    pin = {}
    for line in UPSTREAM_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        pin[key.strip()] = value.strip()
    return pin


def checked_pin() -> tuple:
    try:
        pin = read_pin()
    except OSError as e:
        raise FetchError(f"Cannot read {UPSTREAM_FILE}: {e}")
    repo, commit = pin.get("repo", ""), pin.get("commit", "")
    if repo not in ALLOWED_REPOS:
        raise FetchError(f"Unexpected repo in engine/UPSTREAM: {repo!r}")
    if not SHA_RE.match(commit):
        raise FetchError(f"engine/UPSTREAM: 'commit' must be a full 40-character SHA, got {commit!r}")
    print(f"Upstream: {repo}\nCommit:   {commit} ({pin.get('commit_date', '?')})")
    return repo, commit


def git(args, cwd):
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0")
    result = subprocess.run(
        ["git", *args], cwd=cwd, env=env, capture_output=True, text=True, timeout=1800, check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed ({result.returncode}): {result.stderr.strip()}")
    return result.stdout


def run_check() -> int:
    try:
        repo, commit = checked_pin()
    except FetchError as e:
        print(e)
        return 1

    with tempfile.TemporaryDirectory() as tmp:
        try:
            git(["init", "-q"], tmp)
            git(["remote", "add", "origin", repo], tmp)
            # blob:none — только деревья и коммит, без содержимого файлов.
            git(["fetch", "-q", "--depth", "1", "--filter=blob:none", "origin", commit], tmp)
            listing = git(["ls-tree", "-r", "--name-only", "FETCH_HEAD"], tmp)
        except (RuntimeError, subprocess.TimeoutExpired, OSError) as e:
            print(f"Cannot fetch the pinned revision: {e}")
            return 1

    present = set(listing.splitlines())
    print(f"Files in the pinned tree: {len(present)}")
    missing = [path for path in REQUIRED if path not in present]
    for path in REQUIRED:
        print(("  ok       " if path in present else "  MISSING  ") + path)
    if missing:
        print(f"\n{len(missing)} required path(s) are missing: the layout of the upstream changed. See docs/ENGINE.md.")
        return 1
    print(f"\nAll {len(REQUIRED)} required paths are present.")
    return 0


def sparse_paths(javas, abi) -> list:
    """Что нужно из апстрима для установки (пути относительно корня его репозитория)."""
    paths = ["LICENSE", f"{APP}/jniLibs/{abi}/libunpack200.so", f"{LIBS}/openal-soft-release.aar"]
    paths += [f"{APP}/assets/components/launcher/{name}" for name in LAUNCHER_FILES]
    for v in LWJGL_VERSIONS:
        paths.append(f"{APP}/assets/app_runtime/lwjgl/{v}/")
        paths.append(f"{LIBS}/lwjgl-{v}-natives-release.aar")
    pack = ABI_TO_RUNTIME_PACK[abi]
    for j in javas:
        paths.append(f"{APP}/assets/runtimes/jre-{j}/universal.tar.xz")
        paths.append(f"{APP}/assets/runtimes/jre-{j}/bin-{pack}.tar.xz")
    return paths


def checkout_sparse(repo, commit, paths, dest: Path):
    """Частичный клон: дерево без содержимого, затем проверка только нужных путей — Git докачивает лишь их."""
    dest.mkdir(parents=True, exist_ok=True)
    git(["init", "-q"], dest)
    git(["remote", "add", "origin", repo], dest)
    git(["fetch", "-q", "--depth", "1", "--filter=blob:none", "origin", commit], dest)
    git(["config", "core.sparseCheckout", "true"], dest)
    # Старый способ (файл шаблонов) работает во всех версиях Git, в отличие от `sparse-checkout set --no-cone`.
    info = dest / ".git" / "info"
    info.mkdir(parents=True, exist_ok=True)
    (info / "sparse-checkout").write_text("".join("/" + p + "\n" for p in paths), encoding="utf-8")
    git(["checkout", "-q", "FETCH_HEAD"], dest)
    head = git(["rev-parse", "HEAD"], dest).strip()
    if head != commit:
        raise FetchError(f"Checked out {head}, expected the pinned {commit}")


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def copy_file(src: Path, dst: Path):
    if not src.is_file():
        raise FetchError(f"Missing in the checkout: {src}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)


def extract_from_zip(archive: Path, prefix: str, dst_dir: Path, *, required: bool) -> list:
    """Копирует из zip/AAR плоские файлы `prefix/<имя>` в `dst_dir`. Имена со вложенными папками не допускаются."""
    names = []
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            if info.is_dir() or not info.filename.startswith(prefix):
                continue
            name = info.filename[len(prefix):]
            if not name or "/" in name or name.startswith(".") or not SAFE_REL.match(name):
                raise FetchError(f"Unexpected entry {info.filename!r} in {archive.name}")
            dst_dir.mkdir(parents=True, exist_ok=True)
            with z.open(info) as src, (dst_dir / name).open("wb") as out:
                shutil.copyfileobj(src, out)
            names.append(name)
    if required and not names:
        raise FetchError(f"{archive.name} has no files under {prefix!r}: the AAR layout changed")
    return sorted(names)


def check_runtime_archives(universal: Path, binpack: Path, major: int):
    """Проверка архивов рантайма теми же правилами, что и на устройстве, и поиск файлов, без которых JVM не стартует."""
    seen = set()
    for archive in (universal, binpack):
        with tarfile.open(archive, "r:xz") as t:
            for m in t:
                name = posixpath.normpath(m.name)
                if name.startswith("/") or ".." in name.split("/"):
                    raise FetchError(f"{archive.name}: unsafe entry name {m.name!r}")
                if m.issym():
                    target = posixpath.normpath(posixpath.join(posixpath.dirname(name), m.linkname))
                    if posixpath.isabs(m.linkname) or target.startswith(".."):
                        raise FetchError(f"{archive.name}: symlink {m.name!r} -> {m.linkname!r} leaves the runtime")
                elif m.islnk() or m.isdev() or m.isfifo():
                    raise FetchError(f"{archive.name}: unsupported entry type for {m.name!r}")
                seen.add(name)
    for needed in ("bin/java", "release"):
        if needed not in seen:  # имена уже нормализованы: «./bin/java» стало «bin/java»
            raise FetchError(f"jre-{major}: '{needed}' is missing from the archives")
    if not any(n.endswith("/libjvm.so") for n in seen):
        raise FetchError(f"jre-{major}: libjvm.so is missing from the archives")


class Component:
    def __init__(self, cid: str, kind: str, dest: str):
        self.cid, self.kind, self.dest = cid, kind, dest
        self.files = []  # (путь внутри компонента, размер, sha256)

    def scan(self, base: Path):
        for path in sorted(p for p in base.rglob("*") if p.is_file()):
            rel = path.relative_to(base).as_posix()
            if not SAFE_REL.match(rel):
                raise FetchError(f"{self.cid}: file name {rel!r} cannot be written to the manifest")
            self.files.append((rel, path.stat().st_size, sha256_of(path)))
        if not self.files:
            raise FetchError(f"{self.cid}: no files were collected")

    def content_id(self) -> str:
        h = hashlib.sha256()
        h.update(f"{self.cid}\n{self.kind}\n{self.dest}\n".encode())
        for rel, size, digest in self.files:
            h.update(f"{rel} {size} {digest}\n".encode())
        return h.hexdigest()


def write_manifest(core_dir: Path, abi: str, commit: str, components: list):
    lines = [
        "# Манифест ядра. Создан scripts/fetch_core.py; руками не править.",
        f"mcl-core {MANIFEST_FORMAT}",
        f"abi {abi}",
        f"upstream {commit}",
    ]
    for c in components:
        lines.append(f"component {c.cid} {c.kind} {c.dest} {c.content_id()}")
        for rel, size, digest in c.files:
            lines.append(f"file {c.cid} {rel} {size} {digest}")
    (core_dir / MANIFEST_NAME).write_text("\n".join(lines) + "\n", encoding="utf-8")


def stage_core(checkout: Path, staging: Path, abi: str, javas, commit: str) -> list:
    """Раскладывает файлы из клона в `staging/assets/core` и `staging/jniLibs/<abi>`."""
    src_main = checkout / APP
    core = staging / "assets" / "core"
    jni = staging / "jniLibs" / abi
    components = []

    # 1. Компонент запуска.
    comp = Component("launcher", "dir", "components/launcher")
    for name in LAUNCHER_FILES:
        copy_file(src_main / "assets/components/launcher" / name, core / comp.dest / name)
    comp.scan(core / comp.dest)
    components.append(comp)

    # 2. LWJGL: jar'ы из assets апстрима + нативы из его AAR.
    for v in LWJGL_VERSIONS:
        comp = Component(f"lwjgl-{v}", "dir", f"components/lwjgl/{v}")
        dest = core / comp.dest
        jars = [p for p in sorted((src_main / "assets/app_runtime/lwjgl" / v).iterdir()) if p.suffix == ".jar"]
        if not any(p.name == "lwjgl.jar" for p in jars):
            raise FetchError(f"lwjgl {v}: lwjgl.jar is missing")
        for p in jars:
            copy_file(p, dest / p.name)
        aar = checkout / LIBS / f"lwjgl-{v}-natives-release.aar"
        natives = extract_from_zip(aar, f"assets/app_runtime/lwjgl/{v}/natives/{abi}/", dest / "natives" / abi, required=True)
        if "liblwjgl.so" not in natives:
            raise FetchError(f"lwjgl {v}: liblwjgl.so is missing from the natives of {abi}")
        extract_from_zip(aar, "assets/licenses/", core / "licenses" / f"lwjgl-natives-{v}", required=False)
        comp.scan(dest)
        components.append(comp)

    # 3. Рантаймы Java: архивы остаются архивами, распаковываются на устройстве.
    pack = ABI_TO_RUNTIME_PACK[abi]
    for j in javas:
        comp = Component(f"jre-{j}", "runtime", f"runtimes/jre-{j}")
        src = src_main / "assets/runtimes" / f"jre-{j}"
        universal, binpack = src / "universal.tar.xz", src / f"bin-{pack}.tar.xz"
        copy_file(universal, core / comp.dest / "universal.tar.xz")
        copy_file(binpack, core / comp.dest / f"bin-{pack}.tar.xz")
        check_runtime_archives(universal, binpack, j)
        comp.scan(core / comp.dest)
        components.append(comp)

    # 4. Нативные библиотеки приложения: Android положит их в nativeLibraryDir.
    copy_file(src_main / "jniLibs" / abi / "libunpack200.so", jni / "libunpack200.so")
    openal = extract_from_zip(checkout / LIBS / "openal-soft-release.aar", f"jni/{abi}/", jni, required=True)
    if "libopenal.so" not in openal:
        raise FetchError(f"openal-soft: libopenal.so is missing for {abi}")
    extract_from_zip(checkout / LIBS / "openal-soft-release.aar", "assets/licenses/", core / "licenses" / "openal-soft", required=False)

    # 5. Лицензия апстрима (GPL-3.0 с условиями по разделу 7) — рядом с бинарными файлами.
    copy_file(checkout / "LICENSE", core / "licenses" / "ZalithLauncher2-LICENSE.txt")

    write_manifest(core, abi, commit, components)
    return components


def run_install(args) -> int:
    abi = args.abi
    if abi not in ABI_TO_RUNTIME_PACK:
        print(f"ABI {abi!r} is not supported yet: {sorted(ABI_TO_RUNTIME_PACK)}")
        return 1
    try:
        javas = tuple(sorted({int(x) for x in args.java.split(",") if x.strip()}))
    except ValueError:
        print(f"--java must be a comma-separated list of numbers, got {args.java!r}")
        return 1
    bad = [j for j in javas if j not in SUPPORTED_JAVA]
    if bad or not javas:
        print(f"--java: unsupported {bad or 'empty list'}; the core ships {list(SUPPORTED_JAVA)}")
        return 1

    engine_dir = Path(args.engine_dir).resolve()
    if not (engine_dir / "build.gradle.kts").is_file():
        print(f"{engine_dir} does not look like the :engine module (no build.gradle.kts)")
        return 1

    try:
        repo, commit = checked_pin()
        main_dir = engine_dir / "src" / "main"
        work = Path(tempfile.mkdtemp(prefix=".core-work-", dir=engine_dir))
        try:
            clone, staging = work / "clone", work / "staging"
            print(f"Fetching files for Java {list(javas)}, ABI {abi} (partial clone)…")
            checkout_sparse(repo, commit, sparse_paths(javas, abi), clone)
            components = stage_core(clone, staging, abi, javas, commit)

            # Подмена одним шагом: сначала целиком готовый результат, потом замена каталога ядра.
            new_core, old_core = staging / "assets" / "core", main_dir / "assets" / "core"
            (main_dir / "assets").mkdir(parents=True, exist_ok=True)
            if old_core.exists():
                shutil.rmtree(old_core)
            os.replace(new_core, old_core)
            jni_dst = main_dir / "jniLibs" / abi
            jni_dst.mkdir(parents=True, exist_ok=True)
            for f in sorted((staging / "jniLibs" / abi).iterdir()):
                os.replace(f, jni_dst / f.name)
        finally:
            shutil.rmtree(work, ignore_errors=True)
    except FetchError as e:
        print(f"ERROR: {e}")
        return 1
    except (RuntimeError, subprocess.TimeoutExpired, OSError, tarfile.TarError, zipfile.BadZipFile) as e:
        print(f"ERROR: {type(e).__name__}: {e}")
        return 1

    total = sum(size for c in components for _, size, _ in c.files)
    print(f"\nInstalled into {main_dir}:")
    for c in components:
        print(f"  {c.cid:<14} {c.kind:<8} {len(c.files):>3} files  {sum(s for _, s, _ in c.files) / 1e6:>7.1f} MB  -> {c.dest}")
    print(f"  assets total {total / 1e6:.1f} MB (the APK grows by about this much); manifest: assets/core/{MANIFEST_NAME}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Check or fetch the pinned game core (ZalithLauncher 2).")
    parser.add_argument("--install", action="store_true", help="fetch core files into the :engine module")
    parser.add_argument("--abi", default="arm64-v8a", help="device ABI (only arm64-v8a for now)")
    parser.add_argument("--java", default=",".join(str(j) for j in DEFAULT_JAVA), help="Java runtimes to bundle, e.g. 8,17,21")
    parser.add_argument("--engine-dir", default=str(ROOT / "engine"), help="the :engine module directory")
    args = parser.parse_args()
    return run_install(args) if args.install else run_check()


if __name__ == "__main__":
    sys.exit(main())
