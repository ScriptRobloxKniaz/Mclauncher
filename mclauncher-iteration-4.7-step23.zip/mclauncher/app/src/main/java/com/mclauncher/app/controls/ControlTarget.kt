package com.mclauncher.app.controls

/** Что делает кнопка управления, когда её нажали. */
enum class TargetKind {
    /** Клавиша клавиатуры (код GLFW). */
    KEY,

    /** Кнопка мыши (код GLFW). */
    MOUSE,

    /** Один шаг колёсика мыши: [ControlTarget.code] — направление (+1 вверх, −1 вниз). Нужен для выбора предмета в панели. */
    SCROLL,

    /** Действие самого лаунчера, не игры (сейчас — показать/скрыть экранную клавиатуру). */
    ACTION,
}

/** Раздел в окне выбора действия для кнопки. */
enum class TargetGroup { MOVEMENT, MOUSE, FUNCTION, SPECIAL, LETTERS, DIGITS, ACTIONS }

/**
 * Одно действие из каталога [ControlTargets].
 *
 * @property id стабильный идентификатор для файла раскладки (`key.w`, `mouse.left`): менять нельзя, иначе сохранённые раскладки сломаются;
 * @property label подпись по умолчанию (короткая, влезает на кнопку);
 * @property code код клавиши/кнопки GLFW или направление прокрутки.
 */
data class ControlTarget(
    val id: String,
    val kind: TargetKind,
    val code: Int,
    val label: String,
    val group: TargetGroup,
)

/** Коды клавиш GLFW. Значения сверены с классом `org.lwjgl.glfw.GLFW` из ядра игры (3.3.3). */
object GlfwKeys {
    const val SPACE = 32
    const val APOSTROPHE = 39
    const val COMMA = 44
    const val MINUS = 45
    const val PERIOD = 46
    const val SLASH = 47
    const val SEMICOLON = 59
    const val EQUAL = 61
    const val GRAVE_ACCENT = 96
    const val ESCAPE = 256
    const val ENTER = 257
    const val TAB = 258
    const val BACKSPACE = 259
    const val INSERT = 260
    const val DELETE = 261
    const val RIGHT = 262
    const val LEFT = 263
    const val DOWN = 264
    const val UP = 265
    const val PAGE_UP = 266
    const val PAGE_DOWN = 267
    const val HOME = 268
    const val END = 269
    const val CAPS_LOCK = 280
    const val F1 = 290
    const val LEFT_SHIFT = 340
    const val LEFT_CONTROL = 341
    const val LEFT_ALT = 342

    const val W = 87
    const val A = 65
    const val S = 83
    const val D = 68
    const val E = 69
    const val Q = 81
    const val T = 84
    const val F = 70

    /** Клавиша `F<n>`, n от 1 до 12: коды идут подряд, F1 = 290. */
    fun function(n: Int): Int {
        require(n in 1..12) { "F$n" }
        return F1 + n - 1
    }
}

/** Кнопки мыши GLFW. */
object GlfwMouse {
    const val LEFT = 0
    const val RIGHT = 1
    const val MIDDLE = 2
}

/** Каталог действий, которые можно повесить на кнопку. Порядок — порядок в окне выбора. */
object ControlTargets {

    const val IME = "action.ime"

    val all: List<ControlTarget> = buildList {
        fun key(id: String, code: Int, label: String, group: TargetGroup) = add(ControlTarget("key.$id", TargetKind.KEY, code, label, group))

        key("w", GlfwKeys.W, "W", TargetGroup.MOVEMENT)
        key("a", GlfwKeys.A, "A", TargetGroup.MOVEMENT)
        key("s", GlfwKeys.S, "S", TargetGroup.MOVEMENT)
        key("d", GlfwKeys.D, "D", TargetGroup.MOVEMENT)
        key("space", GlfwKeys.SPACE, "␣", TargetGroup.MOVEMENT)
        key("lshift", GlfwKeys.LEFT_SHIFT, "⇧", TargetGroup.MOVEMENT)
        key("lctrl", GlfwKeys.LEFT_CONTROL, "Ctrl", TargetGroup.MOVEMENT)
        key("up", GlfwKeys.UP, "↑", TargetGroup.MOVEMENT)
        key("down", GlfwKeys.DOWN, "↓", TargetGroup.MOVEMENT)
        key("left", GlfwKeys.LEFT, "←", TargetGroup.MOVEMENT)
        key("right", GlfwKeys.RIGHT, "→", TargetGroup.MOVEMENT)

        add(ControlTarget("mouse.left", TargetKind.MOUSE, GlfwMouse.LEFT, "ЛКМ", TargetGroup.MOUSE))
        add(ControlTarget("mouse.right", TargetKind.MOUSE, GlfwMouse.RIGHT, "ПКМ", TargetGroup.MOUSE))
        add(ControlTarget("mouse.middle", TargetKind.MOUSE, GlfwMouse.MIDDLE, "СКМ", TargetGroup.MOUSE))
        add(ControlTarget("scroll.up", TargetKind.SCROLL, 1, "◄", TargetGroup.MOUSE))
        add(ControlTarget("scroll.down", TargetKind.SCROLL, -1, "►", TargetGroup.MOUSE))

        for (n in 1..12) key("f$n", GlfwKeys.function(n), "F$n", TargetGroup.FUNCTION)

        key("esc", GlfwKeys.ESCAPE, "Esc", TargetGroup.SPECIAL)
        key("tab", GlfwKeys.TAB, "Tab", TargetGroup.SPECIAL)
        key("enter", GlfwKeys.ENTER, "Enter", TargetGroup.SPECIAL)
        key("backspace", GlfwKeys.BACKSPACE, "⌫", TargetGroup.SPECIAL)
        key("lalt", GlfwKeys.LEFT_ALT, "Alt", TargetGroup.SPECIAL)
        key("caps", GlfwKeys.CAPS_LOCK, "Caps", TargetGroup.SPECIAL)
        key("insert", GlfwKeys.INSERT, "Ins", TargetGroup.SPECIAL)
        key("delete", GlfwKeys.DELETE, "Del", TargetGroup.SPECIAL)
        key("home", GlfwKeys.HOME, "Home", TargetGroup.SPECIAL)
        key("end", GlfwKeys.END, "End", TargetGroup.SPECIAL)
        key("pageup", GlfwKeys.PAGE_UP, "PgUp", TargetGroup.SPECIAL)
        key("pagedown", GlfwKeys.PAGE_DOWN, "PgDn", TargetGroup.SPECIAL)
        key("slash", GlfwKeys.SLASH, "/", TargetGroup.SPECIAL)
        key("comma", GlfwKeys.COMMA, ",", TargetGroup.SPECIAL)
        key("period", GlfwKeys.PERIOD, ".", TargetGroup.SPECIAL)
        key("minus", GlfwKeys.MINUS, "-", TargetGroup.SPECIAL)
        key("equal", GlfwKeys.EQUAL, "=", TargetGroup.SPECIAL)
        key("semicolon", GlfwKeys.SEMICOLON, ";", TargetGroup.SPECIAL)
        key("apostrophe", GlfwKeys.APOSTROPHE, "'", TargetGroup.SPECIAL)
        key("grave", GlfwKeys.GRAVE_ACCENT, "`", TargetGroup.SPECIAL)

        for (c in 'A'..'Z') {
            val id = c.lowercaseChar().toString()
            // W, A, S, D уже в разделе движения: второй раз их не добавляем.
            if (none { it.id == "key.$id" }) key(id, c.code, c.toString(), TargetGroup.LETTERS)
        }
        for (c in '0'..'9') key(c.toString(), c.code, c.toString(), TargetGroup.DIGITS)

        add(ControlTarget(IME, TargetKind.ACTION, 0, "IME", TargetGroup.ACTIONS))
    }

    private val byId: Map<String, ControlTarget> = all.associateBy { it.id }

    fun find(id: String): ControlTarget? = byId[id]

    fun inGroup(group: TargetGroup): List<ControlTarget> = all.filter { it.group == group }
}
