package com.mclauncher.app.controls

/** Куда уходят действия кнопок. В игре это мост `CallbackBridge`, в тестах — запись вызовов. */
interface ControlSink {
    fun key(glfwKey: Int, down: Boolean)
    fun mouseButton(button: Int, down: Boolean)
    fun scroll(steps: Int)
    fun toggleKeyboard()
}

/**
 * Превращает нажатия на кнопки в действия для [ControlSink] и следит, чтобы ничего не «залипло».
 *
 * - HOLD: клавиша нажата, пока палец на кнопке.
 * - TOGGLE: первое касание нажимает и держит, второе отпускает.
 * - Две кнопки с одним действием (например, две «W») не отпускают клавишу, пока нажата хотя бы одна.
 * - Прокрутка и действия лаунчера срабатывают один раз при касании и ничего не удерживают.
 * - [releaseAll] отпускает всё: при скрытии управления, сворачивании игры и входе в редактор.
 *
 * Все вызовы — из одного потока (главного).
 */
class ControlPressTracker(
    private val sink: ControlSink,
    private val find: (String) -> ControlTarget? = ControlTargets::find,
) {
    /** Какое действие держит каждая кнопка (по id кнопки). */
    private val heldBy = LinkedHashMap<String, ControlTarget>()

    /** Сколько кнопок сейчас держат каждое действие (по id действия). */
    private val holders = HashMap<String, Int>()

    /** Идентификаторы кнопок, которые сейчас «нажаты» (для подсветки). */
    val heldIds: Set<String> get() = heldBy.keys.toSet()

    fun press(button: ControlButton) {
        val target = find(button.targetId) ?: return
        when (target.kind) {
            TargetKind.SCROLL -> sink.scroll(target.code)
            TargetKind.ACTION -> if (target.id == ControlTargets.IME) sink.toggleKeyboard()
            TargetKind.KEY, TargetKind.MOUSE -> {
                if (button.mode == PressMode.TOGGLE && button.id in heldBy) disengage(button.id) else engage(button.id, target)
            }
        }
    }

    fun release(button: ControlButton) {
        if (button.mode == PressMode.HOLD) disengage(button.id)
    }

    fun releaseAll() {
        for (id in heldBy.keys.toList()) disengage(id)
    }

    private fun engage(buttonId: String, target: ControlTarget) {
        if (buttonId in heldBy) return
        heldBy[buttonId] = target
        val count = (holders[target.id] ?: 0) + 1
        holders[target.id] = count
        if (count == 1) send(target, down = true)
    }

    private fun disengage(buttonId: String) {
        val target = heldBy.remove(buttonId) ?: return
        val count = (holders[target.id] ?: 1) - 1
        if (count <= 0) {
            holders.remove(target.id)
            send(target, down = false)
        } else {
            holders[target.id] = count
        }
    }

    private fun send(target: ControlTarget, down: Boolean) {
        when (target.kind) {
            TargetKind.KEY -> sink.key(target.code, down)
            TargetKind.MOUSE -> sink.mouseButton(target.code, down)
            TargetKind.SCROLL, TargetKind.ACTION -> Unit
        }
    }
}
