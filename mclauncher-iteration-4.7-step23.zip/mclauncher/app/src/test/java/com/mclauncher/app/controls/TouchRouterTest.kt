package com.mclauncher.app.controls

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TouchRouterTest {

    private val events = ArrayList<String>()
    private var grabbing = true
    private var cursor = 500f to 300f

    private val sink = object : ControlSink {
        override fun key(glfwKey: Int, down: Boolean) { events += "key $glfwKey ${if (down) "down" else "up"}" }
        override fun mouseButton(button: Int, down: Boolean) { events += "mouse $button ${if (down) "down" else "up"}" }
        override fun scroll(steps: Int) { events += "scroll $steps" }
        override fun toggleKeyboard() { events += "ime" }
    }
    private val output = object : LookOutput {
        override fun moveCursor(x: Float, y: Float) { cursor = x to y; events += "look ${x.toInt()},${y.toInt()}" }
        override fun leftButton(down: Boolean) { events += if (down) "left down" else "left up" }
    }

    // Кнопка W занимает 0..100 × 0..100, кнопка Shift (переключатель) — 200..300 × 0..100.
    private val w = ControlButton("w", "W", "key.w", 0f, 0f, 50, 50)
    private val shift = ControlButton("shift", "S", "key.lshift", 0f, 0f, 50, 50, mode = PressMode.TOGGLE)
    private val buttons = listOf(w, shift)

    private fun buttonAt(x: Float, y: Float): ControlButton? = when {
        x in 0f..100f && y in 0f..100f -> w
        x in 200f..300f && y in 0f..100f -> shift
        else -> null
    }

    private val tracker = ControlPressTracker(sink)
    private val look = LookPad(output, { grabbing }, { cursor })
    private val router = TouchRouter(tracker, look, ::buttonAt)

    @Test
    fun aFingerOnAButtonPressesItAndReleasesItOnLift() {
        router.down(0, 50f, 50f, 0)
        router.up(0, 50f, 50f, 100)

        assertEquals(listOf("key 87 down", "key 87 up"), events)
        assertFalse(router.isLooking)
    }

    @Test
    fun aFingerOffTheButtonsIsTheCamera() {
        router.down(0, 400f, 400f, 0)
        router.move(0, 430f, 400f, 20)

        assertEquals(listOf("look 530,300"), events)
        assertTrue(router.isLooking)
    }

    @Test
    fun oneFingerCanHoldAButtonWhileAnotherTurnsTheCamera() {
        router.down(0, 50f, 50f, 0)
        router.down(1, 400f, 400f, 0)
        router.move(1, 420f, 400f, 20)
        router.up(0, 50f, 50f, 50)
        router.move(1, 440f, 400f, 60)

        assertEquals(listOf("key 87 down", "look 520,300", "key 87 up", "look 540,300"), events)
    }

    @Test
    fun aFingerThatSlidesOffTheButtonStillOwnsIt() {
        router.down(0, 50f, 50f, 0)
        router.move(0, 700f, 700f, 20)
        router.up(0, 700f, 700f, 40)

        assertEquals("the button is released, and the move did not turn the camera", listOf("key 87 down", "key 87 up"), events)
    }

    @Test
    fun aFingerThatSlidesOntoAButtonDoesNotPressIt() {
        router.down(0, 400f, 400f, 0)
        router.move(0, 50f, 50f, 20)

        assertFalse(events.any { it.startsWith("key") })
    }

    @Test
    fun aSecondFreeFingerIsIgnored() {
        router.down(0, 400f, 400f, 0)
        router.down(1, 600f, 600f, 0)
        router.move(1, 650f, 600f, 20)
        router.up(1, 650f, 600f, 30)

        assertTrue("the camera finger was not disturbed", events.isEmpty())
        assertTrue(router.isLooking)
    }

    @Test
    fun afterTheCameraFingerLeavesTheNextFreeFingerTakesOver() {
        router.down(0, 400f, 400f, 0)
        router.up(0, 400f, 400f, 10)
        router.down(1, 600f, 600f, 20)

        assertTrue(router.isLooking)
    }

    @Test
    fun theCameraGetsPixelsOfTheGameWindowNotOfTheView() {
        router.scaleX = 2f
        router.scaleY = 2f

        router.down(0, 400f, 400f, 0)
        router.move(0, 410f, 400f, 20)

        assertEquals(listOf("look 520,300"), events)
    }

    @Test
    fun aToggleButtonStaysDownAfterTheFingerLeaves() {
        router.down(0, 250f, 50f, 0)
        router.up(0, 250f, 50f, 10)

        assertEquals(listOf("key 340 down"), events)
        assertEquals(setOf("shift"), router.heldIds)
    }

    @Test
    fun cancelAllReleasesButtonsTogglesAndTheCamera() {
        router.down(0, 50f, 50f, 0)
        router.down(1, 250f, 50f, 0)
        router.up(1, 250f, 50f, 5)
        router.down(2, 400f, 400f, 0)
        router.poll(LookPad.LONG_PRESS_MILLIS)
        events.clear()

        router.cancelAll()

        assertEquals(setOf("key 87 up", "key 340 up", "left up"), events.toSet())
        assertEquals(3, events.size)
        assertFalse(router.isLooking)
        assertTrue(router.heldIds.isEmpty())
    }

    @Test
    fun liftingAnUnknownFingerDoesNothing() {
        router.up(7, 1f, 1f, 0)
        router.move(7, 1f, 1f, 0)

        assertTrue(events.isEmpty())
    }

    @Test
    fun aRepeatedDownForTheSameFingerIsIgnored() {
        router.down(0, 50f, 50f, 0)
        router.down(0, 50f, 50f, 1)

        assertEquals(listOf("key 87 down"), events)
    }

    @Test
    fun inAMenuAFingerOnABlankPlaceClicksThere() {
        grabbing = false

        router.down(0, 400f, 400f, 0)
        router.up(0, 400f, 400f, 100)

        assertEquals(listOf("look 400,400", "left down", "look 400,400", "left up"), events)
    }

    @Test
    fun theLongPressIsDeliveredThroughThePoll() {
        router.down(0, 400f, 400f, 0)
        router.poll(LookPad.LONG_PRESS_MILLIS)

        assertEquals(listOf("left down"), events)
    }

    @Test
    fun buttonsListIsOnlyUsedThroughTheHitTest() {
        // Проверка самого теста: кнопки лежат там, где их ищет buttonAt.
        assertEquals(2, buttons.size)
    }
}
