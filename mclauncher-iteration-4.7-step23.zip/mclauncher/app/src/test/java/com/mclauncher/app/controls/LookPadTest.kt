package com.mclauncher.app.controls

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LookPadTest {

    private val events = ArrayList<String>()
    private var grabbing = false
    private var cursor = 500f to 300f

    private val output = object : LookOutput {
        override fun moveCursor(x: Float, y: Float) {
            cursor = x to y
            events += "move ${x.toInt()},${y.toInt()}"
        }

        override fun leftButton(down: Boolean) {
            events += if (down) "left down" else "left up"
        }
    }

    private fun pad(sensitivity: Float = 1f) = LookPad(output, { grabbing }, { cursor }, sensitivity)

    // ---------------------------------------------------------------- меню (курсор виден)

    @Test
    fun inAMenuTheFingerPutsTheCursorUnderItAndHoldsTheLeftButton() {
        val pad = pad()

        pad.down(100f, 200f, 0)
        pad.move(150f, 220f, 50)
        pad.up(160f, 230f, 100)

        assertEquals(listOf("move 100,200", "left down", "move 150,220", "move 160,230", "left up"), events)
    }

    @Test
    fun inAMenuALongTouchDoesNotRepeatTheClick() {
        val pad = pad()
        pad.down(100f, 200f, 0)
        events.clear()

        pad.poll(5_000)

        assertTrue(events.isEmpty())
    }

    // ---------------------------------------------------------------- мир (мышь захвачена)

    @Test
    fun inTheWorldMovingTheFingerTurnsTheCameraByTheDistance() {
        grabbing = true
        val pad = pad()

        pad.down(100f, 100f, 0)
        pad.move(130f, 90f, 20)
        pad.move(150f, 90f, 40)

        assertEquals(listOf("move 530,290", "move 550,290"), events)
    }

    @Test
    fun theSensitivityScalesTheCameraTurn() {
        grabbing = true
        val pad = pad(sensitivity = 2f)

        pad.down(100f, 100f, 0)
        pad.move(110f, 100f, 20)

        assertEquals(listOf("move 520,300"), events)
    }

    @Test
    fun aQuickTapInTheWorldIsOneClick() {
        grabbing = true
        val pad = pad()

        pad.down(100f, 100f, 1_000)
        pad.up(101f, 100f, 1_100)

        assertEquals(listOf("left down", "left up"), events)
    }

    @Test
    fun aSlowTapIsNotAClick() {
        grabbing = true
        val pad = pad()

        pad.down(100f, 100f, 1_000)
        pad.up(100f, 100f, 1_000 + LookPad.TAP_MAX_MILLIS + 1)

        assertTrue(events.isEmpty())
    }

    @Test
    fun aTouchThatMovedFarIsNotAClickEvenIfItWasQuick() {
        grabbing = true
        val pad = pad()

        pad.down(100f, 100f, 0)
        pad.move(160f, 100f, 50)
        events.clear()
        pad.up(160f, 100f, 100)

        assertTrue(events.isEmpty())
    }

    @Test
    fun aLongStillTouchHoldsTheLeftButtonUntilTheFingerLeaves() {
        grabbing = true
        val pad = pad()

        pad.down(100f, 100f, 0)
        pad.poll(LookPad.LONG_PRESS_MILLIS - 1)
        assertTrue("too early", events.isEmpty())
        pad.poll(LookPad.LONG_PRESS_MILLIS)
        pad.poll(LookPad.LONG_PRESS_MILLIS + 100)
        pad.up(100f, 100f, 900)

        assertEquals("pressed once, released once, no extra click on lift", listOf("left down", "left up"), events)
    }

    @Test
    fun aTouchThatMovedNeverBecomesALongPress() {
        grabbing = true
        val pad = pad()

        pad.down(100f, 100f, 0)
        pad.move(150f, 100f, 100)
        events.clear()
        pad.poll(5_000)

        assertTrue(events.isEmpty())
    }

    @Test
    fun smallJitterKeepsTheTouchStill() {
        grabbing = true
        val pad = pad()

        pad.down(100f, 100f, 0)
        pad.move(105f, 103f, 100)
        events.clear()
        pad.poll(LookPad.LONG_PRESS_MILLIS)

        assertEquals(listOf("left down"), events)
    }

    // ---------------------------------------------------------------- отмена

    @Test
    fun cancelReleasesAHeldButtonOnlyOnce() {
        grabbing = true
        val pad = pad()
        pad.down(100f, 100f, 0)
        pad.poll(LookPad.LONG_PRESS_MILLIS)
        events.clear()

        pad.cancel()
        pad.cancel()

        assertEquals(listOf("left up"), events)
    }

    @Test
    fun cancelInAMenuReleasesTheButtonToo() {
        val pad = pad()
        pad.down(100f, 100f, 0)
        events.clear()

        pad.cancel()

        assertEquals(listOf("left up"), events)
    }

    @Test
    fun eventsWithoutAFingerDoNothing() {
        val pad = pad()

        pad.move(1f, 1f, 0)
        pad.up(1f, 1f, 0)
        pad.poll(10_000)
        pad.cancel()

        assertTrue(events.isEmpty())
    }

    @Test
    fun aNewTouchWhileOneIsActiveFirstReleasesTheOld() {
        val pad = pad()
        pad.down(100f, 100f, 0)
        events.clear()

        pad.down(300f, 300f, 10)

        assertEquals(listOf("left up", "move 300,300", "left down"), events)
    }

    @Test
    fun theMenuClosingMidTouchReleasesTheButtonOnLift() {
        val pad = pad()
        pad.down(100f, 100f, 0)
        grabbing = true // нажали «Назад в игру»: игра захватила мышь
        pad.move(110f, 100f, 50)
        events.clear()

        pad.up(110f, 100f, 100)

        assertEquals(listOf("move 110,100", "left up"), events)
    }
}
