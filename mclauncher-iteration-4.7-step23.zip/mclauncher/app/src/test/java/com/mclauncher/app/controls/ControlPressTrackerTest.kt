package com.mclauncher.app.controls

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ControlPressTrackerTest {

    private class Recorder : ControlSink {
        val events = ArrayList<String>()
        override fun key(glfwKey: Int, down: Boolean) { events += "key $glfwKey ${if (down) "down" else "up"}" }
        override fun mouseButton(button: Int, down: Boolean) { events += "mouse $button ${if (down) "down" else "up"}" }
        override fun scroll(steps: Int) { events += "scroll $steps" }
        override fun toggleKeyboard() { events += "ime" }
    }

    private val sink = Recorder()
    private val tracker = ControlPressTracker(sink)

    private fun b(id: String, target: String, mode: PressMode = PressMode.HOLD) =
        ControlButton(id, id, target, 0f, 0f, 50, 50, mode = mode)

    @Test
    fun aHeldKeyIsDownUntilTheFingerLeaves() {
        val w = b("1", "key.w")

        tracker.press(w)
        assertEquals(listOf("key 87 down"), sink.events)
        assertEquals(setOf("1"), tracker.heldIds)

        tracker.release(w)
        assertEquals(listOf("key 87 down", "key 87 up"), sink.events)
        assertTrue(tracker.heldIds.isEmpty())
    }

    @Test
    fun aToggleKeyStaysDownUntilTheSecondTap() {
        val shift = b("1", "key.lshift", PressMode.TOGGLE)

        tracker.press(shift)
        tracker.release(shift)
        assertEquals(listOf("key 340 down"), sink.events)
        assertEquals(setOf("1"), tracker.heldIds)

        tracker.press(shift)
        tracker.release(shift)
        assertEquals(listOf("key 340 down", "key 340 up"), sink.events)
        assertTrue(tracker.heldIds.isEmpty())
    }

    @Test
    fun twoButtonsWithTheSameKeyKeepItDownUntilBothAreReleased() {
        val first = b("1", "key.w")
        val second = b("2", "key.w")

        tracker.press(first)
        tracker.press(second)
        tracker.release(first)
        assertEquals("still held by the second button", listOf("key 87 down"), sink.events)

        tracker.release(second)
        assertEquals(listOf("key 87 down", "key 87 up"), sink.events)
    }

    @Test
    fun mouseButtonsAreSentAsMouse() {
        val attack = b("1", "mouse.left")

        tracker.press(attack)
        tracker.release(attack)

        assertEquals(listOf("mouse 0 down", "mouse 0 up"), sink.events)
    }

    @Test
    fun scrollAndKeyboardFireOnceAndHoldNothing() {
        val next = b("1", "scroll.down")
        val prev = b("2", "scroll.up")
        val ime = b("3", ControlTargets.IME)

        tracker.press(next)
        tracker.release(next)
        tracker.press(prev)
        tracker.release(prev)
        tracker.press(ime)
        tracker.release(ime)

        assertEquals(listOf("scroll -1", "scroll 1", "ime"), sink.events)
        assertTrue(tracker.heldIds.isEmpty())
    }

    @Test
    fun releaseAllLetsGoOfEverythingExactlyOnce() {
        tracker.press(b("1", "key.w"))
        tracker.press(b("2", "key.lshift", PressMode.TOGGLE))
        tracker.press(b("3", "mouse.left"))
        sink.events.clear()

        tracker.releaseAll()
        tracker.releaseAll()

        assertEquals(setOf("key 87 up", "key 340 up", "mouse 0 up"), sink.events.toSet())
        assertEquals(3, sink.events.size)
        assertTrue(tracker.heldIds.isEmpty())
    }

    @Test
    fun releasingWhatWasNeverPressedDoesNothing() {
        tracker.release(b("1", "key.w"))

        assertTrue(sink.events.isEmpty())
    }

    @Test
    fun aRepeatedPressOfAHeldButtonDoesNotSendTwice() {
        val w = b("1", "key.w")

        tracker.press(w)
        tracker.press(w)

        assertEquals(listOf("key 87 down"), sink.events)
    }

    @Test
    fun anUnknownTargetIsIgnored() {
        tracker.press(b("1", "key.nonsense"))

        assertTrue(sink.events.isEmpty())
        assertTrue(tracker.heldIds.isEmpty())
    }

    @Test
    fun aToggleButtonDoesNotReleaseOnFingerUp() {
        val ctrl = b("1", "key.lctrl", PressMode.TOGGLE)

        tracker.press(ctrl)
        tracker.release(ctrl)
        tracker.release(ctrl)

        assertEquals(listOf("key 341 down"), sink.events)
    }
}
