package com.mclauncher.app.controls

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ControlLayoutTest {

    private val screenW = 800f
    private val screenH = 360f

    private fun button(id: String = "b1", x: Float = 0.1f, y: Float = 0.1f, w: Int = 50, h: Int = 50, target: String = "key.w") =
        ControlButton(id, "W", target, x, y, w, h)

    // ---------------------------------------------------------------- каталог

    @Test
    fun targetIdsAreUniqueAndFound() {
        val ids = ControlTargets.all.map { it.id }

        assertEquals("ids must be unique", ids.size, ids.toSet().size)
        assertTrue(ids.all { ControlTargets.find(it) != null })
        assertNull(ControlTargets.find("key.nonsense"))
    }

    @Test
    fun theKeyCodesMatchGlfw() {
        // Значения сверены с org.lwjgl.glfw.GLFW из ядра игры.
        assertEquals(87, ControlTargets.find("key.w")!!.code)
        assertEquals(292, ControlTargets.find("key.f3")!!.code)
        assertEquals(294, ControlTargets.find("key.f5")!!.code)
        assertEquals(301, ControlTargets.find("key.f12")!!.code)
        assertEquals(256, ControlTargets.find("key.esc")!!.code)
        assertEquals(340, ControlTargets.find("key.lshift")!!.code)
        assertEquals(84, ControlTargets.find("key.t")!!.code)
        assertEquals(48, ControlTargets.find("key.0")!!.code)
        assertEquals(0, ControlTargets.find("mouse.left")!!.code)
        assertEquals(1, ControlTargets.find("mouse.right")!!.code)
    }

    @Test
    fun everyLetterAndDigitIsAvailable() {
        for (c in 'a'..'z') assertNotNull("letter $c", ControlTargets.find("key.$c"))
        for (c in '0'..'9') assertNotNull("digit $c", ControlTargets.find("key.$c"))
        for (n in 1..12) assertNotNull("F$n", ControlTargets.find("key.f$n"))
    }

    @Test
    fun everyGroupHasTargets() {
        for (group in TargetGroup.values()) assertTrue("$group", ControlTargets.inGroup(group).isNotEmpty())
    }

    // ---------------------------------------------------------------- раскладка по умолчанию

    @Test
    fun theDefaultLayoutIsValid() {
        val layout = ControlLayout.default()

        assertTrue(layout.buttons.size in 10..ControlLayout.MAX_BUTTONS)
        assertEquals("unique ids", layout.buttons.size, layout.buttons.map { it.id }.toSet().size)
        for (b in layout.buttons) {
            assertNotNull("target of ${b.id}", ControlTargets.find(b.targetId))
            assertTrue(b.x in 0f..1f && b.y in 0f..1f)
            assertTrue(b.widthDp in ControlButton.MIN_SIZE_DP..ControlButton.MAX_SIZE_DP)
        }
    }

    @Test
    fun theDefaultLayoutHasTheEssentialControls() {
        val targets = ControlLayout.default().buttons.map { it.targetId }.toSet()

        for (needed in listOf("key.w", "key.a", "key.s", "key.d", "key.space", "key.lshift", "key.e", "key.esc", "key.t", "mouse.left", "mouse.right")) {
            assertTrue(needed, needed in targets)
        }
    }

    @Test
    fun theDefaultLayoutFitsAPhoneScreenWithoutSliding() {
        // Типичный ландшафт 800×360 dp: кнопки не должны перекрываться и выходить за экран.
        val layout = ControlLayout.default()
        val rects = layout.buttons.map { b ->
            val c = b.clampedTo(screenW, screenH)
            assertEquals("${b.id} must already fit", b.x, c.x, 0.0001f)
            assertEquals("${b.id} must already fit", b.y, c.y, 0.0001f)
            listOf(b.x * screenW, b.y * screenH, b.x * screenW + b.widthDp, b.y * screenH + b.heightDp)
        }
        for (i in rects.indices) for (j in i + 1 until rects.size) {
            val a = rects[i]
            val b = rects[j]
            val overlap = a[0] < b[2] && b[0] < a[2] && a[1] < b[3] && b[1] < a[3]
            assertFalse("${layout.buttons[i].label} overlaps ${layout.buttons[j].label}", overlap)
        }
    }

    // ---------------------------------------------------------------- правки

    @Test
    fun dragMovesByTheRightFractionAndStaysOnScreen() {
        val layout = ControlLayout(listOf(button(x = 0.5f, y = 0.5f)))

        val moved = layout.dragged("b1", dxDp = 80f, dyDp = -36f, screenWidthDp = screenW, screenHeightDp = screenH)
        assertEquals(0.6f, moved.find("b1")!!.x, 0.0001f)
        assertEquals(0.4f, moved.find("b1")!!.y, 0.0001f)

        val outside = layout.dragged("b1", dxDp = 10_000f, dyDp = 10_000f, screenWidthDp = screenW, screenHeightDp = screenH).find("b1")!!
        assertEquals(1f - 50f / screenW, outside.x, 0.0001f)
        assertEquals(1f - 50f / screenH, outside.y, 0.0001f)

        val negative = layout.dragged("b1", -10_000f, -10_000f, screenW, screenH).find("b1")!!
        assertEquals(0f, negative.x, 0f)
        assertEquals(0f, negative.y, 0f)
    }

    @Test
    fun resizeKeepsTheButtonInsideAndInsideTheLimits() {
        val layout = ControlLayout(listOf(button(x = 0.95f, y = 0.9f, w = 40, h = 40)))

        val big = layout.changed("b1", screenW, screenH) { it.copy(widthDp = 500, heightDp = 500) }.find("b1")!!
        assertEquals(ControlButton.MAX_SIZE_DP, big.widthDp)
        assertTrue("grown button must be pulled back inside", big.x * screenW + big.widthDp <= screenW + 0.01f)
        assertTrue(big.y * screenH + big.heightDp <= screenH + 0.01f)

        val small = layout.changed("b1", screenW, screenH) { it.copy(widthDp = 1, heightDp = 1) }.find("b1")!!
        assertEquals(ControlButton.MIN_SIZE_DP, small.widthDp)
    }

    @Test
    fun aVeryLongLabelAndBadOpacityAreCut() {
        val layout = ControlLayout(listOf(button()))

        val changed = layout.changed("b1", screenW, screenH) { it.copy(label = "x".repeat(50), opacity = 5f) }.find("b1")!!

        assertEquals(ControlButton.MAX_LABEL_LENGTH, changed.label.length)
        assertEquals(ControlButton.MAX_OPACITY, changed.opacity, 0f)
    }

    @Test
    fun changingAMissingButtonChangesNothing() {
        val layout = ControlLayout(listOf(button()))

        assertEquals(layout, layout.changed("nope", screenW, screenH) { it.copy(label = "z") })
        assertEquals(layout, layout.dragged("nope", 5f, 5f, screenW, screenH))
    }

    @Test
    fun addingGivesAFreshIdAndTheDefaultLabel() {
        val layout = ControlLayout(listOf(button("b1"), button("b2")))

        val (next, added) = layout.withNewButton("key.f3", screenW, screenH)!!

        assertEquals(3, next.buttons.size)
        assertEquals("F3", added.label)
        assertEquals(3, next.buttons.map { it.id }.toSet().size)
        assertEquals("key.f3", added.targetId)
    }

    @Test
    fun anIdIsNeverReusedWhileTaken() {
        val layout = ControlLayout(listOf(button("b2")))

        val (_, added) = layout.withNewButton("key.q", screenW, screenH)!!

        assertTrue(added.id != "b2")
    }

    @Test
    fun addingAnUnknownActionOrBeyondTheLimitIsRefused() {
        assertNull(ControlLayout.EMPTY.withNewButton("key.nonsense", screenW, screenH))

        val full = ControlLayout((1..ControlLayout.MAX_BUTTONS).map { button("b$it") })
        assertNull(full.withNewButton("key.w", screenW, screenH))
        assertNull(full.withDuplicate("b1", screenW, screenH))
    }

    @Test
    fun duplicateKeepsTheSettingsButMovesTheCopy() {
        val layout = ControlLayout(listOf(button("b1", x = 0.2f, y = 0.2f).copy(shape = ButtonShape.CIRCLE, mode = PressMode.TOGGLE)))

        val (next, copy) = layout.withDuplicate("b1", screenW, screenH)!!

        assertEquals(2, next.buttons.size)
        assertTrue(copy.id != "b1")
        assertEquals(ButtonShape.CIRCLE, copy.shape)
        assertEquals(PressMode.TOGGLE, copy.mode)
        assertTrue(copy.x > 0.2f && copy.y > 0.2f)
        assertNull(layout.withDuplicate("nope", screenW, screenH))
    }

    @Test
    fun removeDropsOnlyThatButton() {
        val layout = ControlLayout(listOf(button("b1"), button("b2")))

        assertEquals(listOf("b2"), layout.without("b1").buttons.map { it.id })
        assertEquals(layout, layout.without("nope"))
    }

    @Test
    fun clampWorksBeforeTheScreenSizeIsKnown() {
        val b = button(x = 2f, y = -1f).clampedTo(0f, 0f)

        assertEquals(1f, b.x, 0f)
        assertEquals(0f, b.y, 0f)
    }

    @Test
    fun aButtonWiderThanTheScreenSitsAtZero() {
        val b = button(x = 0.5f, w = 160).clampedTo(100f, 100f)

        assertEquals(0f, b.x, 0f)
    }
}
