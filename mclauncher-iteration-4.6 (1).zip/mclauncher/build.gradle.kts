// Корневой build-файл: только объявление плагинов (apply false).
// Версии лежат в gradle/libs.versions.toml.
//
// AGP 9+ имеет встроенную поддержку Kotlin, поэтому плагин
// org.jetbrains.kotlin.android здесь намеренно НЕ подключается.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.room) apply false
}
