package com.mclauncher.app.data.skin

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SkinPixelsTest {

    private val opaque = 0xFF000000.toInt()

    /** Пиксель, в котором записаны его координаты: по значению видно, откуда он взялся. */
    private fun px(x: Int, y: Int) = opaque or (y shl 8) or x

    private fun legacySkin(): IntArray {
        val pixels = IntArray(64 * 32)
        for (y in 0 until 32) for (x in 0 until 64) pixels[y * 64 + x] = px(x, y)
        return pixels
    }

    private fun IntArray.at(x: Int, y: Int) = this[y * 64 + x]

    // ---- Старый формат 64×32 → 64×64 -------------------------------------------------------

    @Test
    fun `modern skin is copied unchanged`() {
        val modern = IntArray(64 * 64) { it + 1 }
        val result = SkinPixels.toModern(modern, 64, 64)
        assertEquals(modern.toList(), result.toList())
        assertTrue("result must be a copy", result !== modern)
    }

    @Test
    fun `legacy skin keeps its top half`() {
        val source = legacySkin()
        val result = SkinPixels.toModern(source, 64, 32)
        assertEquals(64 * 64, result.size)
        for (i in source.indices) assertEquals(source[i], result[i])
    }

    @Test
    fun `left leg is the mirrored right leg`() {
        val src = legacySkin()
        val out = SkinPixels.toModern(src, 64, 32)
        // Значения ожидаются выписанными вручную: левая нога — зеркало правой, правая и левая грани меняются местами.
        assertEquals(src.at(7, 16), out.at(20, 48)) // верх: самый левый столбец копии = самый правый оригинала
        assertEquals(src.at(4, 16), out.at(23, 48))
        assertEquals(src.at(11, 16), out.at(24, 48)) // низ
        assertEquals(src.at(7, 20), out.at(20, 52)) // перед
        assertEquals(src.at(4, 20), out.at(23, 52))
        assertEquals(src.at(15, 20), out.at(28, 52)) // зад
        assertEquals(src.at(11, 20), out.at(16, 52)) // правая грань копии = левая грань оригинала
        assertEquals(src.at(3, 20), out.at(24, 52)) // левая грань копии = правая грань оригинала
        assertEquals(src.at(7, 31), out.at(20, 63)) // строки не переворачиваются
    }

    @Test
    fun `left arm is the mirrored right arm`() {
        val src = legacySkin()
        val out = SkinPixels.toModern(src, 64, 32)
        assertEquals(src.at(47, 16), out.at(36, 48)) // верх
        assertEquals(src.at(51, 16), out.at(40, 48)) // низ
        assertEquals(src.at(47, 20), out.at(36, 52)) // перед
        assertEquals(src.at(55, 20), out.at(44, 52)) // зад
        assertEquals(src.at(51, 20), out.at(32, 52)) // правая грань копии = левая грань оригинала
        assertEquals(src.at(43, 20), out.at(40, 52)) // левая грань копии = правая грань оригинала
        assertEquals(src.at(44, 31), out.at(39, 63))
    }

    @Test
    fun `legacy conversion fills exactly the left limb faces and nothing else`() {
        val out = SkinPixels.toModern(legacySkin(), 64, 32)
        val filled = mutableSetOf<Pair<Int, Int>>()
        for (box in listOf(SkinLayout.LEFT_LEG, SkinLayout.leftArm(SkinModel.WIDE))) {
            for (face in box.faces) {
                for (y in face.y until face.bottom) for (x in face.x until face.right) filled += x to y
            }
        }
        for (y in 32 until 64) {
            for (x in 0 until 64) {
                if ((x to y) in filled) {
                    assertNotEquals("($x,$y) must be filled", 0, out.at(x, y))
                } else {
                    assertEquals("($x,$y) must stay empty", 0, out.at(x, y))
                }
            }
        }
    }

    @Test(expected = IllegalArgumentException::class)
    fun `unsupported size is rejected`() {
        SkinPixels.toModern(IntArray(128 * 128), 128, 128)
    }

    @Test(expected = IllegalArgumentException::class)
    fun `too small array is rejected`() {
        SkinPixels.toModern(IntArray(10), 64, 64)
    }

    // ---- Определение модели рук ------------------------------------------------------------

    private fun opaqueSkin() = IntArray(64 * 64) { opaque or 0x336699 }

    private fun IntArray.clear(rect: PixelRect) {
        for (y in rect.y until rect.bottom) for (x in rect.x until rect.right) this[y * 64 + x] = 0
    }

    @Test
    fun `fully opaque skin is wide`() {
        assertEquals(SkinModel.WIDE, SkinPixels.detectModel(opaqueSkin(), 64, 64))
    }

    @Test
    fun `skin with empty slim regions is slim`() {
        val pixels = opaqueSkin()
        SkinLayout.SLIM_UNUSED_REGIONS.forEach { pixels.clear(it) }
        assertEquals(SkinModel.SLIM, SkinPixels.detectModel(pixels, 64, 64))
    }

    @Test
    fun `one stray pixel in any slim region makes the skin wide`() {
        for (region in SkinLayout.SLIM_UNUSED_REGIONS) {
            val pixels = opaqueSkin()
            SkinLayout.SLIM_UNUSED_REGIONS.forEach { pixels.clear(it) }
            pixels[region.y * 64 + region.x] = opaque or 0x00FF00
            assertEquals("region $region", SkinModel.WIDE, SkinPixels.detectModel(pixels, 64, 64))
        }
    }

    @Test
    fun `slim only on one arm is treated as wide`() {
        val pixels = opaqueSkin()
        pixels.clear(SkinLayout.SLIM_UNUSED_REGIONS[0])
        pixels.clear(SkinLayout.SLIM_UNUSED_REGIONS[1])
        assertEquals(SkinModel.WIDE, SkinPixels.detectModel(pixels, 64, 64))
    }

    @Test
    fun `semi transparent pixel counts as used`() {
        val pixels = opaqueSkin()
        SkinLayout.SLIM_UNUSED_REGIONS.forEach { pixels.clear(it) }
        val region = SkinLayout.SLIM_UNUSED_REGIONS.first()
        pixels[region.y * 64 + region.x] = 0x01000000 // альфа = 1 из 255
        assertEquals(SkinModel.WIDE, SkinPixels.detectModel(pixels, 64, 64))
    }

    @Test
    fun `legacy and malformed input is always wide`() {
        assertEquals(SkinModel.WIDE, SkinPixels.detectModel(IntArray(64 * 32), 64, 32))
        assertEquals(SkinModel.WIDE, SkinPixels.detectModel(IntArray(10), 64, 64))
        assertEquals(SkinModel.WIDE, SkinPixels.detectModel(IntArray(128 * 128), 128, 128))
    }
}
