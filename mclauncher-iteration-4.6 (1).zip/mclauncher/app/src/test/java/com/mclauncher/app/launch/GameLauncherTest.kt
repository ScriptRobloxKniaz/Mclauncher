package com.mclauncher.app.launch

import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.account.AccountType
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class GameLauncherTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val account = Account(
        id = 1,
        type = AccountType.OFFLINE,
        username = "Steve",
        uuid = "5627dd98-e6be-3c21-b8a8-e92344183641",
        isActive = true,
        createdAt = 0L,
    )

    private class FakeEngine(
        private val block: suspend (LaunchRequest) -> LaunchResult = { LaunchResult.Started(placeholder = false) },
    ) : GameEngine {
        var calls = 0
        var lastRequest: LaunchRequest? = null

        override suspend fun launch(request: LaunchRequest): LaunchResult {
            calls++
            lastRequest = request
            return block(request)
        }
    }

    /** [installed] — какие версии «есть на диске»: тесты ниже ходят с версией `demo`. */
    private fun launcher(
        engine: GameEngine,
        root: File = File(tmp.root, ".minecraft"),
        installed: Set<String> = setOf("demo"),
    ) = GameLauncher(engine, GameDirectories(root), isVersionInstalled = { it in installed }, ioDispatcher = Dispatchers.IO)

    @Test
    fun withoutAccountFailsAndDoesNotTouchEngine() = runBlocking {
        val engine = FakeEngine()
        val result = launcher(engine).launch(account = null, versionId = "demo")

        assertEquals(LaunchResult.Failed(LaunchFailure.NoAccount), result)
        assertEquals(0, engine.calls)
    }

    @Test
    fun withoutVersionFailsAndDoesNotTouchEngine() = runBlocking {
        val engine = FakeEngine()
        val launcher = launcher(engine)

        val result = launcher.launch(account, versionId = null)

        assertEquals(LaunchResult.Failed(LaunchFailure.NoVersion), result)
        assertEquals(0, engine.calls)
        assertEquals(LaunchPhase.IDLE, launcher.phase.value)
    }

    @Test
    fun versionThatIsNotInstalledFailsWithItsId() = runBlocking {
        val engine = FakeEngine()
        val launcher = launcher(engine, installed = setOf("1.21.1"))

        val result = launcher.launch(account, versionId = "1.20.4")

        assertEquals(LaunchResult.Failed(LaunchFailure.VersionNotInstalled("1.20.4")), result)
        assertEquals(0, engine.calls)
        assertEquals(LaunchPhase.IDLE, launcher.phase.value)
    }

    @Test
    fun missingAccountIsReportedBeforeMissingVersion() = runBlocking {
        val result = launcher(FakeEngine()).launch(account = null, versionId = null)

        assertEquals(LaunchResult.Failed(LaunchFailure.NoAccount), result)
    }

    @Test
    fun installedVersionIsLaunched() = runBlocking {
        val engine = FakeEngine()

        val result = launcher(engine, installed = setOf("1.21.1")).launch(account, versionId = "1.21.1")

        assertEquals(LaunchResult.Started(placeholder = false), result)
        assertEquals("1.21.1", engine.lastRequest?.versionId)
    }

    @Test
    fun successCreatesGameDirectoriesAndPassesRequestToEngine() = runBlocking {
        val engine = FakeEngine()
        val root = File(tmp.root, ".minecraft")

        val result = launcher(engine, root).launch(account, versionId = "demo", ramMb = 3072)

        assertEquals(LaunchResult.Started(placeholder = false), result)
        listOf("versions", "libraries", "assets", "mods", "resourcepacks", "shaderpacks", "saves", "config", "logs")
            .forEach { name -> assertTrue("$name must exist", File(root, name).isDirectory) }
        assertEquals(1, engine.calls)
        assertEquals("demo", engine.lastRequest?.versionId)
        assertEquals(3072, engine.lastRequest?.ramMb)
        assertEquals(account, engine.lastRequest?.account)
    }

    @Test
    fun repeatedPreparationIsHarmless() = runBlocking {
        val launcher = launcher(FakeEngine())
        repeat(3) {
            assertEquals(LaunchResult.Started(placeholder = false), launcher.launch(account, "demo"))
        }
    }

    @Test
    fun gameDirThatIsAFileFailsWithGameDirUnavailable() = runBlocking {
        val blocker = tmp.newFile(".minecraft") // на месте папки лежит обычный файл
        val engine = FakeEngine()

        val result = launcher(engine, blocker).launch(account, "demo")

        assertTrue(result is LaunchResult.Failed)
        assertTrue((result as LaunchResult.Failed).failure is LaunchFailure.GameDirUnavailable)
        assertEquals(0, engine.calls)
    }

    @Test
    fun engineFailureIsPropagated() = runBlocking {
        val failed = LaunchResult.Failed(LaunchFailure.EngineUnavailable)
        val result = launcher(FakeEngine { failed }).launch(account, "demo")
        assertEquals(failed, result)
    }

    @Test
    fun engineExceptionIsMappedToEngineError() = runBlocking {
        val result = launcher(FakeEngine { error("boom") }).launch(account, "demo")
        assertEquals(LaunchResult.Failed(LaunchFailure.EngineError("boom")), result)
    }

    @Test
    fun missingNativeLibraryIsMappedToEngineUnavailable() = runBlocking {
        val result = launcher(FakeEngine { throw UnsatisfiedLinkError("libpojavexec.so") }).launch(account, "demo")
        assertEquals(LaunchResult.Failed(LaunchFailure.EngineUnavailable), result)
    }

    @Test
    fun phaseReturnsToIdleAfterSuccessAndAfterFailure() = runBlocking {
        val ok = launcher(FakeEngine())
        ok.launch(account, "demo")
        assertEquals(LaunchPhase.IDLE, ok.phase.value)

        val bad = launcher(FakeEngine { error("boom") })
        bad.launch(account, "demo")
        assertEquals(LaunchPhase.IDLE, bad.phase.value)
    }

    @Test
    fun secondLaunchWhileFirstIsRunningIsRejected() = runBlocking {
        val gate = CompletableDeferred<Unit>()
        val engine = FakeEngine {
            gate.await()
            LaunchResult.Started(placeholder = false)
        }
        val launcher = launcher(engine)

        val first = async(Dispatchers.Default) { launcher.launch(account, "demo") }
        withTimeout(5_000) { launcher.phase.first { it == LaunchPhase.LAUNCHING } }

        val second = launcher.launch(account, "demo")
        assertEquals(LaunchResult.Failed(LaunchFailure.AlreadyLaunching), second)

        gate.complete(Unit)
        assertEquals(LaunchResult.Started(placeholder = false), first.await())
        assertEquals(1, engine.calls)
        assertEquals(LaunchPhase.IDLE, launcher.phase.value)
    }

    @Test
    fun stubEngineReportsPlaceholder() = runBlocking {
        val result = launcher(StubGameEngine(simulatedWorkMs = 0)).launch(account, "demo")
        assertEquals(LaunchResult.Started(placeholder = true), result)
    }
}
