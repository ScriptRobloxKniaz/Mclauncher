package com.mclauncher.app.data.versions

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RulesTest {

    private val arm64 = OsEnvironment.LINUX_ARM64
    private val windows10 = OsEnvironment(name = "windows", arch = "x86_64", version = "10.0.19045")

    private fun rule(action: RuleAction, os: OsRule? = null, features: Map<String, Boolean> = emptyMap()) =
        Rule(action, os, features)

    private fun os(name: String? = null, arch: String? = null, version: String? = null) = OsRule(name, arch, version)

    @Test
    fun noRulesMeansAllowed() {
        assertTrue(RuleEvaluator.isAllowed(emptyList(), arm64))
    }

    @Test
    fun allowRuleForOtherOsDoesNotApply() {
        val rules = listOf(rule(RuleAction.ALLOW, os(name = "osx")))
        assertFalse(RuleEvaluator.isAllowed(rules, arm64))
    }

    @Test
    fun allowRuleForThisOsApplies() {
        val rules = listOf(rule(RuleAction.ALLOW, os(name = "linux")))
        assertTrue(RuleEvaluator.isAllowed(rules, arm64))
    }

    @Test
    fun lastMatchingRuleWins() {
        // «Разрешить всем, кроме Linux»
        val rules = listOf(rule(RuleAction.ALLOW), rule(RuleAction.DISALLOW, os(name = "linux")))
        assertFalse(RuleEvaluator.isAllowed(rules, arm64))
        assertTrue(RuleEvaluator.isAllowed(rules, windows10))

        // Порядок важен: если запрет стоит раньше, общее разрешение его перекрывает.
        val reversed = listOf(rule(RuleAction.DISALLOW, os(name = "linux")), rule(RuleAction.ALLOW))
        assertTrue(RuleEvaluator.isAllowed(reversed, arm64))
    }

    @Test
    fun noMatchingRuleMeansDisallowed() {
        val rules = listOf(rule(RuleAction.DISALLOW, os(name = "osx")))
        assertFalse(RuleEvaluator.isAllowed(rules, arm64)) // ни одно не подошло — нельзя
    }

    @Test
    fun archIsComparedAfterNormalization() {
        val aarch64 = listOf(rule(RuleAction.ALLOW, os(name = "linux", arch = "aarch64")))
        val arm64Rule = listOf(rule(RuleAction.ALLOW, os(name = "linux", arch = "arm64")))
        assertTrue(RuleEvaluator.isAllowed(aarch64, arm64))
        assertTrue(RuleEvaluator.isAllowed(arm64Rule, arm64))
    }

    @Test
    fun x86RuleDoesNotMatchArm64() {
        val rules = listOf(rule(RuleAction.ALLOW, os(arch = "x86")))
        assertFalse(RuleEvaluator.isAllowed(rules, arm64))
        assertTrue(RuleEvaluator.isAllowed(rules, OsEnvironment("linux", "x86")))
    }

    @Test
    fun osNameIsCaseInsensitive() {
        assertTrue(RuleEvaluator.isAllowed(listOf(rule(RuleAction.ALLOW, os(name = "Linux"))), arm64))
    }

    @Test
    fun osVersionIsARegexAndNeedsAVersion() {
        val rules = listOf(rule(RuleAction.ALLOW, os(name = "windows", version = "^10\\.")))
        assertTrue(RuleEvaluator.isAllowed(rules, windows10))
        assertFalse(RuleEvaluator.isAllowed(rules, windows10.copy(version = "6.1")))
        // У Android версии ОС нет — правило с версией не подходит.
        assertFalse(RuleEvaluator.isAllowed(listOf(rule(RuleAction.ALLOW, os(version = "^10\\."))), arm64))
    }

    @Test
    fun brokenVersionRegexDoesNotCrashAndDoesNotMatch() {
        val rules = listOf(rule(RuleAction.ALLOW, os(name = "windows", version = "([unclosed")))
        assertFalse(RuleEvaluator.isAllowed(rules, windows10))
    }

    @Test
    fun featureRulesNeedTheFeatureToBeEnabled() {
        val demo = listOf(rule(RuleAction.ALLOW, features = mapOf("is_demo_user" to true)))
        assertFalse(RuleEvaluator.isAllowed(demo, arm64))
        assertTrue(RuleEvaluator.isAllowed(demo, arm64, features = setOf("is_demo_user")))

        val notDemo = listOf(rule(RuleAction.ALLOW, features = mapOf("is_demo_user" to false)))
        assertTrue(RuleEvaluator.isAllowed(notDemo, arm64))
        assertFalse(RuleEvaluator.isAllowed(notDemo, arm64, features = setOf("is_demo_user")))
    }

    @Test
    fun normalizeArchKnownNames() {
        assertEquals("arm64", normalizeArch("aarch64"))
        assertEquals("arm64", normalizeArch("arm64-v8a"))
        assertEquals("arm64", normalizeArch(" ARM64 "))
        assertEquals("x86_64", normalizeArch("amd64"))
        assertEquals("x86_64", normalizeArch("x86_64"))
        assertEquals("x86", normalizeArch("i686"))
        assertEquals("arm", normalizeArch("armeabi-v7a"))
        assertEquals("riscv64", normalizeArch("RISCV64"))
    }

    @Test
    fun androidEnvironmentUsesTheFirstSupportedAbi() {
        val env = OsEnvironment.android(listOf("arm64-v8a", "armeabi-v7a"))
        assertEquals(OsEnvironment("linux", "arm64"), env)
        assertEquals("", OsEnvironment.android(emptyList()).arch)
    }
}
