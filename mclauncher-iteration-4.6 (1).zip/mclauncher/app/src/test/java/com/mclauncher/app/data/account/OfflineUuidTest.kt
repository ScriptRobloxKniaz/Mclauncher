package com.mclauncher.app.data.account

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class OfflineUuidTest {

    /**
     * Эталонные значения посчитаны независимо по алгоритму ванильной игры
     * (MD5 от "OfflinePlayer:<ник>", затем version=3 / variant=IETF).
     * UUID для «Notch» — общеизвестный.
     */
    @Test
    fun matchesVanillaOfflineUuids() {
        assertEquals("b50ad385-829d-3141-a216-7e7d7539ba7f", OfflineUuid.forName("Notch").toString())
        assertEquals("5627dd98-e6be-3c21-b8a8-e92344183641", OfflineUuid.forName("Steve").toString())
        assertEquals("a818c0db-482a-3778-81ff-d3df54c7a926", OfflineUuid.forName("Alex_01").toString())
    }

    @Test
    fun nameCaseMatters() {
        assertNotEquals(OfflineUuid.forName("Steve"), OfflineUuid.forName("steve"))
        assertEquals("53909932-f794-33c0-9329-948045a4c1ce", OfflineUuid.forName("steve").toString())
    }

    @Test
    fun isStable() {
        assertEquals(OfflineUuid.forName("Steve"), OfflineUuid.forName("Steve"))
    }
}
