package com.mclauncher.app.data.versions

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InstallManagerTest {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val entry = ManifestEntry("1.21.1", VersionType.RELEASE, "https://meta.test/1.21.1.json", null, null)
    private val installed = InstalledVersion("1.21.1", VersionType.RELEASE, "Main", "17", 21, null, 0L)

    @After
    fun tearDown() {
        scope.cancel()
    }

    private suspend fun InstallManager.await(predicate: (InstallState) -> Boolean): InstallState =
        withTimeout(10_000) { state.first(predicate) }

    @Test
    fun startsInIdle() {
        val manager = InstallManager({ _, _ -> InstallResult.Installed(installed) }, scope)

        assertEquals(InstallState.Idle, manager.state.value)
    }

    @Test
    fun onlyOneInstallRunsAtATime() = runBlocking {
        val gate = CompletableDeferred<InstallResult>()
        val manager = InstallManager({ _, _ -> gate.await() }, scope)

        assertTrue(manager.start(entry))
        assertFalse(manager.start(entry))
        assertEquals(InstallState.Running("1.21.1", progress = null), manager.state.value)

        gate.complete(InstallResult.Installed(installed))
        assertEquals(InstallState.Done("1.21.1"), manager.await { it is InstallState.Done })
    }

    @Test
    fun progressIsPublishedWhileRunning() = runBlocking {
        val gate = CompletableDeferred<InstallResult>()
        val progress = InstallProgress(InstallPhase.DOWNLOADING, filesDone = 1, filesTotal = 4, bytesDone = 10, bytesTotal = 100)
        val manager = InstallManager({ _, onProgress -> onProgress(progress); gate.await() }, scope)

        manager.start(entry)

        val state = manager.await { it is InstallState.Running && it.progress != null } as InstallState.Running
        assertEquals(progress, state.progress)
        gate.complete(InstallResult.Installed(installed))
        Unit
    }

    @Test
    fun lateProgressDoesNotOverwriteTheOutcome() = runBlocking {
        var report: ((InstallProgress) -> Unit)? = null
        val manager = InstallManager(
            { _, onProgress -> report = onProgress; InstallResult.Installed(installed) },
            scope,
        )

        manager.start(entry)
        manager.await { it is InstallState.Done }
        report!!(InstallProgress(InstallPhase.DOWNLOADING))

        assertEquals(InstallState.Done("1.21.1"), manager.state.value)
    }

    @Test
    fun failureIsKeptUntilAcknowledged() = runBlocking {
        val error = InstallError.Network("no route")
        val manager = InstallManager({ _, _ -> InstallResult.Failed(error) }, scope)

        manager.start(entry)

        assertEquals(InstallState.Failed("1.21.1", error), manager.await { it is InstallState.Failed })
        manager.acknowledge()
        assertEquals(InstallState.Idle, manager.state.value)
    }

    @Test
    fun acknowledgeDoesNotStopARunningInstall() = runBlocking {
        val gate = CompletableDeferred<InstallResult>()
        val manager = InstallManager({ _, _ -> gate.await() }, scope)
        manager.start(entry)

        manager.acknowledge()

        assertTrue(manager.state.value is InstallState.Running)
        gate.complete(InstallResult.Installed(installed))
        Unit
    }

    @Test
    fun cancelReturnsToIdleAndAllowsANewStart() = runBlocking {
        val started = CompletableDeferred<Unit>()
        val manager = InstallManager({ _, _ -> started.complete(Unit); awaitCancellation() }, scope)
        manager.start(entry)
        withTimeout(10_000) { started.await() }

        manager.cancel()

        assertEquals(InstallState.Idle, manager.await { it is InstallState.Idle })
        assertTrue(manager.start(entry))
        manager.cancel()
    }

    @Test
    fun anotherInstallCanStartAfterTheLastOneEnded() = runBlocking {
        val manager = InstallManager({ _, _ -> InstallResult.Installed(installed) }, scope)
        manager.start(entry)
        manager.await { it is InstallState.Done }

        assertTrue(manager.start(entry.copy(id = "1.20.4")))
    }
}
