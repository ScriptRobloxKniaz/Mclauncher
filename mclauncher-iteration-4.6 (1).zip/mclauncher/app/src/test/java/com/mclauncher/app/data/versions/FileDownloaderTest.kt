package com.mclauncher.app.data.versions

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.concurrent.atomic.AtomicLong

class FileDownloaderTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val http = FakeHttpSource()
    private val url = "https://data.test/file.bin"
    private val content = "hello, minecraft".toByteArray()

    private fun downloader(maxAttempts: Int = 3) =
        FileDownloader(http, ioDispatcher = Dispatchers.IO, maxAttempts = maxAttempts, retryDelayMs = { 0L })

    private fun task(
        target: File = File(tmp.root, "out/file.bin"),
        bytes: ByteArray = content,
        sha1: String? = sha1Hex(bytes),
        size: Long = bytes.size.toLong(),
        verifyExisting: Boolean = true,
    ) = DownloadTask(url, target, sha1, size, FileKind.LIBRARY, verifyExisting)

    private fun failure(block: suspend () -> Unit): DownloadException =
        assertThrows(DownloadException::class.java) { runBlocking { block() } }

    @Test
    fun downloadsVerifiesAndLeavesNoTemporaryFile() = runBlocking {
        http.serve(url, content)
        val received = AtomicLong()
        val t = task()
        downloader().download(t) { received.addAndGet(it) }

        assertEquals(content.toList(), t.target.readBytes().toList())
        assertFalse(File(t.target.path + ".part").exists())
        assertEquals(content.size.toLong(), received.get())
        assertEquals(1, http.requestCount(url))
    }

    @Test
    fun hashMismatchIsRetriedThenFailsAndLeavesNothing() {
        http.serve(url, "tampered contents".toByteArray())
        val received = AtomicLong()
        val t = task(size = 0) // размер неизвестен — ловит именно хэш
        val e = failure { downloader().download(t) { received.addAndGet(it) } }

        assertEquals(DownloadException.Reason.HASH, e.reason)
        assertEquals(3, http.requestCount(url))
        assertFalse(t.target.exists())
        assertFalse(File(t.target.path + ".part").exists())
        assertEquals("rolled-back progress must net out to zero", 0L, received.get())
    }

    @Test
    fun sizeMismatchIsReported() {
        http.serve(url, content)
        val e = failure { downloader(maxAttempts = 1).download(task(size = content.size + 5L)) }
        assertEquals(DownloadException.Reason.SIZE, e.reason)
        assertFalse(task().target.exists())
    }

    @Test
    fun serverErrorIsRetriedAndThenSucceeds() = runBlocking {
        http.serveSequence(url, FakeHttpSource.Reply.Status(503), FakeHttpSource.Reply.Ok(content))
        val t = task()
        downloader().download(t)
        assertEquals(2, http.requestCount(url))
        assertTrue(t.target.isFile)
    }

    @Test
    fun networkFailureIsRetried() = runBlocking {
        http.serveSequence(url, FakeHttpSource.Reply.Fail(), FakeHttpSource.Reply.Fail(), FakeHttpSource.Reply.Ok(content))
        downloader().download(task())
        assertEquals(3, http.requestCount(url))
    }

    @Test
    fun givesUpAfterMaxAttempts() {
        http.serveSequence(url, FakeHttpSource.Reply.Fail("no route"))
        val e = failure { downloader(maxAttempts = 2).download(task()) }
        assertEquals(DownloadException.Reason.NETWORK, e.reason)
        assertEquals(2, http.requestCount(url))
    }

    @Test
    fun notFoundIsNotRetried() {
        // Адрес не заведён в FakeHttpSource — он отвечает 404.
        val e = failure { downloader().download(task()) }
        assertEquals(DownloadException.Reason.HTTP, e.reason)
        assertEquals(404, e.status)
        assertFalse(e.isRetryable)
        assertEquals(1, http.requestCount(url))
    }

    @Test
    fun retryableStatuses() {
        fun retryable(status: Int) = DownloadException(DownloadException.Reason.HTTP, "x", status = status).isRetryable
        assertTrue(retryable(500))
        assertTrue(retryable(503))
        assertTrue(retryable(429))
        assertTrue(retryable(408))
        assertFalse(retryable(404))
        assertFalse(retryable(403))
        assertFalse(DownloadException(DownloadException.Reason.STORAGE, "x").isRetryable)
    }

    @Test
    fun existingGoodFileIsNotDownloadedAgain() = runBlocking {
        val t = task()
        t.target.parentFile.mkdirs()
        t.target.writeBytes(content)
        assertTrue(downloader().isUpToDate(t))
        downloader().download(t)
        assertEquals(0, http.totalRequests)
    }

    @Test
    fun corruptedExistingFileIsReplaced() = runBlocking {
        http.serve(url, content)
        val t = task()
        t.target.parentFile.mkdirs()
        t.target.writeBytes("xxxxxxxxxxxxxxxx".toByteArray()) // того же размера, другое содержимое
        assertFalse(downloader().isUpToDate(t))
        downloader().download(t)
        assertEquals(content.toList(), t.target.readBytes().toList())
        assertEquals(1, http.requestCount(url))
    }

    @Test
    fun existingFileOfTheWrongSizeIsNotUpToDate() {
        val t = task()
        t.target.parentFile.mkdirs()
        t.target.writeBytes(content.copyOf(3))
        assertFalse(downloader().isUpToDate(t))
    }

    @Test
    fun assetsTrustTheirSizeWhenHashChecksAreSkipped() {
        val t = task(verifyExisting = false)
        t.target.parentFile.mkdirs()
        t.target.writeBytes("xxxxxxxxxxxxxxxx".toByteArray())
        assertTrue(downloader().isUpToDate(t))
    }

    @Test
    fun emptyFileWithUnknownSizeAndHashIsNotUpToDate() {
        val t = task(sha1 = null, size = 0)
        t.target.parentFile.mkdirs()
        t.target.writeBytes(ByteArray(0))
        assertFalse(downloader().isUpToDate(t))
    }

    @Test
    fun unknownSizeAndHashAcceptsAnyBody() = runBlocking {
        http.serve(url, content)
        val t = task(sha1 = null, size = 0)
        downloader().download(t)
        assertTrue(t.target.isFile)
    }

    @Test
    fun cannotCreateParentFolderIsAStorageError() {
        val blocker = tmp.newFile("blocker") // на месте папки лежит файл
        val t = task(target = File(blocker, "sub/file.bin"))
        http.serve(url, content)
        val e = failure { downloader().download(t) }
        assertEquals(DownloadException.Reason.STORAGE, e.reason)
        assertEquals(1, http.requestCount(url)) // повторять бессмысленно
    }

    @Test
    fun cancellationRemovesThePartialFile() = runBlocking {
        http.serveSequence(url, FakeHttpSource.Reply.Slow(chunks = 2000, chunkSize = 64, pauseMs = 2))
        val t = task(sha1 = null, size = 0)
        val started = CompletableDeferred<Unit>()
        val job = launch(Dispatchers.Default) {
            downloader().download(t) { if (!started.isCompleted) started.complete(Unit) }
        }
        withTimeout(10_000) { started.await() }
        job.cancelAndJoin()

        assertTrue(job.isCancelled)
        assertFalse(t.target.exists())
        assertFalse(File(t.target.path + ".part").exists())
        assertNotNull(t.target.parentFile)
    }
}
