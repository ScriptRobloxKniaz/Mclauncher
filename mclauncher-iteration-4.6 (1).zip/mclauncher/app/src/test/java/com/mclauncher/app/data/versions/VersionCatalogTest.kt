package com.mclauncher.app.data.versions

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class VersionCatalogTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val http = FakeHttpSource()
    private val url = VersionCatalog.DEFAULT_MANIFEST_URL
    private val cacheFile by lazy { File(tmp.root, "cache/version_manifest.json") }
    private val catalog by lazy { VersionCatalog(http, cacheFile) }

    private fun loaded(result: CatalogResult): CatalogResult.Loaded =
        result as? CatalogResult.Loaded ?: error("Expected Loaded but got $result")

    private fun failure(result: CatalogResult): InstallError =
        (result as? CatalogResult.Failed)?.error ?: error("Expected Failed but got $result")

    @Test
    fun loadsFromTheNetworkAndSavesACopy() = runBlocking {
        http.serve(url, Fixtures.text("manifest.json"))

        val result = loaded(catalog.load())

        assertFalse(result.fromCache)
        assertEquals("1.21.1", result.manifest.latestRelease)
        assertTrue(result.manifest.versions.any { it.id == "1.8.9" })
        assertTrue(cacheFile.isFile)
        assertEquals(0, cacheFile.parentFile.listFiles { f -> f.name.endsWith(".tmp") }?.size)
    }

    @Test
    fun showsTheSavedListWhenOffline() = runBlocking {
        http.serve(url, Fixtures.text("manifest.json"))
        catalog.load()
        http.serveSequence(url, FakeHttpSource.Reply.Fail("airplane mode"))

        val result = loaded(catalog.load())

        assertTrue(result.fromCache)
        assertEquals("1.21.1", result.manifest.latestRelease)
    }

    @Test
    fun showsTheSavedListWhenTheServerIsDown() = runBlocking {
        http.serve(url, Fixtures.text("manifest.json"))
        catalog.load()
        http.serveSequence(url, FakeHttpSource.Reply.Status(503))

        assertTrue(loaded(catalog.load()).fromCache)
    }

    @Test
    fun failsWithANetworkErrorWhenThereIsNoCopy() = runBlocking {
        http.serveSequence(url, FakeHttpSource.Reply.Fail("unreachable"))

        assertTrue(failure(catalog.load()) is InstallError.Network)
    }

    @Test
    fun reportsServerStatusWhenThereIsNoCopy() = runBlocking {
        http.serveSequence(url, FakeHttpSource.Reply.Status(503))

        assertEquals(InstallError.Server(503), failure(catalog.load()))
    }

    @Test
    fun brokenResponseIsBadDataAndDoesNotReplaceTheCopy() = runBlocking {
        http.serve(url, Fixtures.text("manifest.json"))
        catalog.load()
        val good = cacheFile.readText()
        http.serve(url, "<html>captive portal</html>")

        val result = loaded(catalog.load())

        assertTrue(result.fromCache)
        assertEquals(good, cacheFile.readText()) // мусор в кэш не попал
    }

    @Test
    fun brokenResponseWithoutACopyIsBadData() = runBlocking {
        http.serve(url, "not json at all")

        assertTrue(failure(catalog.load()) is InstallError.BadData)
    }

    @Test
    fun brokenCopyIsIgnored() = runBlocking {
        cacheFile.parentFile.mkdirs()
        cacheFile.writeText("{ broken")
        http.serveSequence(url, FakeHttpSource.Reply.Fail("unreachable"))

        assertTrue(failure(catalog.load()) is InstallError.Network)
    }

    @Test
    fun unwritableCacheDoesNotBreakLoading() = runBlocking {
        // Вместо файла кэша — папка: запись невозможна, но список из сети всё равно показывается.
        cacheFile.mkdirs()
        http.serve(url, Fixtures.text("manifest.json"))

        val result = loaded(catalog.load())

        assertFalse(result.fromCache)
        assertTrue(result.manifest.versions.isNotEmpty())
    }
}
