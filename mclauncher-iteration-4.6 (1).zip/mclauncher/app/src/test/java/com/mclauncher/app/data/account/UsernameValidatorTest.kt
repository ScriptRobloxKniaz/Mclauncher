package com.mclauncher.app.data.account

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class UsernameValidatorTest {

    @Test
    fun acceptsValidNames() {
        listOf("Steve", "Alex_01", "abc", "A_B_C_D_E_F_G_H_", "__x__", "123").forEach { name ->
            assertNull("«$name» должен подходить", UsernameValidator.validate(name))
        }
    }

    @Test
    fun rejectsEmpty() {
        assertEquals(NameError.EMPTY, UsernameValidator.validate(""))
    }

    @Test
    fun rejectsTooShort() {
        assertEquals(NameError.TOO_SHORT, UsernameValidator.validate("ab"))
        assertEquals(NameError.TOO_SHORT, UsernameValidator.validate("a"))
    }

    @Test
    fun rejectsTooLong() {
        assertEquals(NameError.TOO_LONG, UsernameValidator.validate("a".repeat(17)))
        assertNull(UsernameValidator.validate("a".repeat(16)))
    }

    @Test
    fun rejectsInvalidCharacters() {
        listOf("Ste ve", "Стив_", "Steve!", "a-b-c", "Steve\n", " Steve").forEach { name ->
            assertEquals("«$name»", NameError.INVALID_CHARS, UsernameValidator.validate(name))
        }
    }

    @Test
    fun invalidCharsAreReportedBeforeLengthProblems() {
        // Короткий и с плохим символом: пользователю важнее сначала убрать символ.
        assertEquals(NameError.INVALID_CHARS, UsernameValidator.validate("a!"))
    }
}
