package com.mclauncher.app.data.skin

import java.io.ByteArrayOutputStream
import org.junit.Assert.assertEquals
import org.junit.Test

class SkinValidatorTest {

    private val signature = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)

    /** Подпись PNG + заголовок IHDR (без данных): всего, что читает валидатор. */
    private fun pngHeader(width: Int, height: Int, chunkType: String = "IHDR", chunkLength: Int = 13): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(signature)
        out.write(int(chunkLength))
        out.write(chunkType.toByteArray(Charsets.US_ASCII))
        out.write(int(width))
        out.write(int(height))
        out.write(byteArrayOf(8, 6, 0, 0, 0)) // глубина 8 бит, RGBA, без сжатия-фильтра-чересстрочности
        out.write(int(0)) // CRC валидатор не проверяет
        return out.toByteArray()
    }

    private fun int(value: Int) = byteArrayOf(
        (value ushr 24).toByte(),
        (value ushr 16).toByte(),
        (value ushr 8).toByte(),
        value.toByte(),
    )

    private fun padded(bytes: ByteArray, totalSize: Int) = bytes.copyOf(totalSize)

    private fun assertInvalid(expected: SkinError, bytes: ByteArray) {
        assertEquals(SkinValidator.Result.Invalid(expected), SkinValidator.validate(bytes))
    }

    @Test
    fun `accepts 64x64 and legacy 64x32`() {
        assertEquals(SkinValidator.Result.Valid(64, 64), SkinValidator.validate(pngHeader(64, 64)))
        assertEquals(SkinValidator.Result.Valid(64, 32), SkinValidator.validate(pngHeader(64, 32)))
    }

    @Test
    fun `rejects other sizes`() {
        assertInvalid(SkinError.WRONG_SIZE, pngHeader(128, 128))
        assertInvalid(SkinError.WRONG_SIZE, pngHeader(64, 128))
        assertInvalid(SkinError.WRONG_SIZE, pngHeader(32, 64))
        assertInvalid(SkinError.WRONG_SIZE, pngHeader(64, 16))
        assertInvalid(SkinError.WRONG_SIZE, pngHeader(0, 0))
    }

    @Test
    fun `reads width as big endian`() {
        // 320 = 0x0140: при чтении «задом наперёд» младший байт 0x40 дал бы подходящие 64.
        assertInvalid(SkinError.WRONG_SIZE, pngHeader(320, 64))
        assertInvalid(SkinError.WRONG_SIZE, pngHeader(64, 320))
    }

    @Test
    fun `huge or negative sizes do not crash`() {
        assertInvalid(SkinError.WRONG_SIZE, pngHeader(Int.MAX_VALUE, Int.MAX_VALUE))
        assertInvalid(SkinError.WRONG_SIZE, pngHeader(Int.MIN_VALUE + 64, 64))
    }

    @Test
    fun `rejects empty and truncated input`() {
        assertInvalid(SkinError.NOT_PNG, ByteArray(0))
        assertInvalid(SkinError.NOT_PNG, pngHeader(64, 64).copyOf(23))
        assertInvalid(SkinError.NOT_PNG, signature)
    }

    @Test
    fun `rejects other image formats`() {
        val jpeg = padded(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte()), 64)
        assertInvalid(SkinError.NOT_PNG, jpeg)
        val gif = padded("GIF89a".toByteArray(Charsets.US_ASCII), 64)
        assertInvalid(SkinError.NOT_PNG, gif)
    }

    @Test
    fun `rejects png whose first chunk is not IHDR`() {
        assertInvalid(SkinError.NOT_PNG, pngHeader(64, 64, chunkType = "IDAT"))
        assertInvalid(SkinError.NOT_PNG, pngHeader(64, 64, chunkLength = 12))
    }

    @Test
    fun `file at the size limit is accepted and one byte over is too large`() {
        val header = pngHeader(64, 64)
        assertEquals(
            SkinValidator.Result.Valid(64, 64),
            SkinValidator.validate(padded(header, SkinValidator.MAX_BYTES)),
        )
        assertInvalid(SkinError.TOO_LARGE, padded(header, SkinValidator.MAX_BYTES + 1))
    }

    @Test
    fun `a large non-png is reported as not a png rather than too large`() {
        val bigJpeg = padded(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte()), SkinValidator.MAX_BYTES + 1)
        assertInvalid(SkinError.NOT_PNG, bigJpeg)
    }
}
