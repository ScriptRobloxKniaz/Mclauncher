package com.mclauncher.app.data.versions

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class VersionParserTest {

    private fun <T : Any> required(value: T?): T = requireNotNull(value) { "expected a non-null value" }

    // ---- Манифест -------------------------------------------------------------------------

    @Test
    fun manifestKeepsValidEntriesAndSkipsBrokenOnes() {
        val manifest = VersionParser.parseManifest(Fixtures.text("manifest.json"))
        assertEquals("1.21.1", manifest.latestRelease)
        assertEquals("24w36a", manifest.latestSnapshot)
        assertEquals(
            listOf("24w36a", "1.21.1", "1.8.9", "b1.7.3", "a1.0.4", "future-1"),
            manifest.versions.map { it.id },
        )
    }

    @Test
    fun manifestTypesAreMappedAndUnknownTypesAreOther() {
        val byId = VersionParser.parseManifest(Fixtures.text("manifest.json")).versions.associateBy { it.id }
        assertEquals(VersionType.SNAPSHOT, byId.getValue("24w36a").type)
        assertEquals(VersionType.RELEASE, byId.getValue("1.21.1").type)
        assertEquals(VersionType.OLD_BETA, byId.getValue("b1.7.3").type)
        assertEquals(VersionType.OLD_ALPHA, byId.getValue("a1.0.4").type)
        assertEquals(VersionType.OTHER, byId.getValue("future-1").type)
        assertNull(byId.getValue("future-1").sha1)
        assertEquals("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb", byId.getValue("1.21.1").sha1)
    }

    @Test
    fun manifestErrors() {
        assertThrows(VersionParseException::class.java) { VersionParser.parseManifest("not json") }
        assertThrows(VersionParseException::class.java) { VersionParser.parseManifest("[1,2]") }
        assertThrows(VersionParseException::class.java) { VersionParser.parseManifest("{\"latest\":{}}") }
    }

    // ---- Современная версия ---------------------------------------------------------------

    private val modern by lazy { VersionParser.parseVersion(Fixtures.text("version_modern.json")) }

    @Test
    fun modernVersionBasics() {
        assertEquals("1.21.1", modern.id)
        assertEquals(VersionType.RELEASE, modern.type)
        assertEquals("net.minecraft.client.main.Main", modern.mainClass)
        assertEquals("17", modern.assets)
        assertEquals("17", modern.assetIndex.id)
        assertEquals(458000L, modern.assetIndex.size)
        assertEquals(700000000L, modern.assetIndex.totalSize)
        assertEquals(26000000L, modern.client.size)
        assertEquals("2222222222222222222222222222222222222222", modern.client.sha1)
        assertEquals(21, modern.java.majorVersion)
        assertEquals("java-runtime-delta", modern.java.component)
        assertNull(modern.inheritsFrom)
        assertEquals("2024-08-08T12:00:00+00:00", modern.releaseTime)
    }

    @Test
    fun modernLibrariesKeepNamesPathsAndRules() {
        assertEquals(7, modern.libraries.size)
        val gson = modern.libraries.first { it.name.startsWith("com.google.code.gson") }
        assertEquals("com/google/code/gson/gson/2.10.1/gson-2.10.1.jar", gson.artifact?.path)
        assertEquals(283367L, gson.artifact?.size)
        assertTrue(gson.rules.isEmpty())

        val arm = modern.libraries.first { it.name.endsWith("natives-linux-arm64") }
        assertEquals(1, arm.rules.size)
        assertEquals(RuleAction.ALLOW, arm.rules[0].action)
        assertEquals(OsRule(name = "linux", arch = "arm64", version = null), arm.rules[0].os)
    }

    @Test
    fun modernArgumentsAreSplitIntoStringsAndConditionalGroups() {
        assertFalse(modern.arguments.legacy)
        val game = modern.arguments.game
        assertEquals(listOf("--username"), game[0].values)
        assertTrue(game[0].rules.isEmpty())

        val demo = game.first { it.values == listOf("--demo") }
        assertEquals(mapOf("is_demo_user" to true), demo.rules.single().features)

        val resolution = game.first { "--width" in it.values }
        assertEquals(listOf("--width", "\${resolution_width}", "--height", "\${resolution_height}"), resolution.values)

        val windowsOnly = modern.arguments.jvm.first { it.values == listOf("-Dos.name=Windows 10", "-Dos.version=10.0") }
        assertEquals("^10\\.", windowsOnly.rules.single().os?.version)
        assertTrue(modern.arguments.jvm.any { it.values == listOf("-cp") })
    }

    @Test
    fun modernLoggingConfig() {
        val logging = required(modern.logging)
        assertEquals("client-1.12.xml", logging.fileId)
        assertEquals("-Dlog4j.configurationFile=\${path}", logging.argument)
        assertEquals("bd65e7d2e3c237be76cfbef4c2405033d7f91521", logging.file.sha1)
    }

    // ---- Старая версия --------------------------------------------------------------------

    private val legacy by lazy { VersionParser.parseVersion(Fixtures.text("version_legacy.json")) }

    @Test
    fun legacyArgumentsAreSplitOnWhitespace() {
        assertTrue(legacy.arguments.legacy)
        assertTrue(legacy.arguments.jvm.isEmpty())
        val flat = legacy.arguments.game.flatMap { it.values }
        assertEquals("--username", flat[0])
        assertEquals("\${auth_player_name}", flat[1])
        assertTrue(legacy.arguments.game.all { it.rules.isEmpty() })
    }

    @Test
    fun legacyHasNoJavaRequirementSoItIsJava8() {
        assertEquals(JavaRequirement(component = null, majorVersion = 8), legacy.java)
        assertNull(legacy.logging)
        assertEquals("1.8", legacy.assets)
    }

    @Test
    fun libraryWithoutDownloadsGetsAMavenPathAndUrl() {
        val jopt = legacy.libraries.first { it.name.startsWith("net.sf.jopt-simple") }
        val artifact = required(jopt.artifact)
        assertEquals("net/sf/jopt-simple/jopt-simple/4.6/jopt-simple-4.6.jar", artifact.path)
        assertEquals("https://libraries.minecraft.net/net/sf/jopt-simple/jopt-simple/4.6/jopt-simple-4.6.jar", artifact.url)
        assertNull(artifact.sha1)
    }

    @Test
    fun nativeLibrariesKeepClassifiersAndExtractRules() {
        val lwjgl = legacy.libraries.first { it.name.startsWith("org.lwjgl.lwjgl:lwjgl-platform") }
        assertEquals("natives-linux", lwjgl.natives["linux"])
        assertEquals(listOf("META-INF/"), lwjgl.extractExcludes)
        assertTrue("natives-linux" in lwjgl.classifiers)
        assertNotNull(lwjgl.artifact)

        // Библиотека только с нативными классификаторами не получает «обычного» файла.
        val twitch = legacy.libraries.first { it.name.startsWith("tv.twitch") }
        assertNull(twitch.artifact)
        assertEquals("natives-windows-\${arch}", twitch.natives["windows"])
    }

    // ---- Индекс ассетов -------------------------------------------------------------------

    @Test
    fun assetIndexSkipsBrokenEntries() {
        val index = VersionParser.parseAssetIndex(Fixtures.text("asset_index.json"))
        assertEquals(4, index.objects.size)
        assertFalse(index.virtual)
        assertFalse(index.mapToResources)
        val icon = index.objects.first { it.name == "icons/icon_16x16.png" }
        assertEquals("bdf48ef6b5d0d23bbb02e17d04865216179f510a", icon.hash)
        assertEquals(3665L, icon.size)
        assertEquals(3665L + 5362L + 20000L + 20000L, index.totalSize)
    }

    @Test
    fun assetIndexFlags() {
        val index = VersionParser.parseAssetIndex("{\"virtual\":true,\"map_to_resources\":true,\"objects\":{}}")
        assertTrue(index.virtual)
        assertTrue(index.mapToResources)
        assertThrows(VersionParseException::class.java) { VersionParser.parseAssetIndex("{}") }
    }

    // ---- Ошибки ---------------------------------------------------------------------------

    private fun minimalVersion(
        mainClass: String? = "\"mainClass\":\"a.B\",",
        assetIndex: String? = "\"assetIndex\":{\"id\":\"1\",\"url\":\"https://x/1.json\"},",
        client: String? = "\"downloads\":{\"client\":{\"url\":\"https://x/c.jar\"}},",
        args: String? = "\"minecraftArguments\":\"--a b\",",
    ) = "{\"id\":\"t\"," + listOfNotNull(mainClass, assetIndex, client, args).joinToString("") + "\"libraries\":[]}"

    @Test
    fun minimalVersionParses() {
        val version = VersionParser.parseVersion(minimalVersion())
        assertEquals("t", version.id)
        assertEquals("1", version.assets) // `assets` нет — берётся id индекса
        assertTrue(version.libraries.isEmpty())
    }

    @Test
    fun missingRequiredPartsAreReported() {
        assertThrows(VersionParseException::class.java) { VersionParser.parseVersion(minimalVersion(mainClass = null)) }
        assertThrows(VersionParseException::class.java) { VersionParser.parseVersion(minimalVersion(assetIndex = null)) }
        assertThrows(VersionParseException::class.java) { VersionParser.parseVersion(minimalVersion(client = null)) }
        assertThrows(VersionParseException::class.java) { VersionParser.parseVersion(minimalVersion(args = null)) }
        assertThrows(VersionParseException::class.java) { VersionParser.parseVersion("{}") }
        assertThrows(VersionParseException::class.java) { VersionParser.parseVersion("<html>") }
    }

    @Test
    fun unknownRuleActionIsDroppedInsteadOfApplied() {
        val json = minimalVersion().replace(
            "\"libraries\":[]",
            "\"libraries\":[{\"name\":\"a:b:1\",\"rules\":[{\"action\":\"maybe\"},{\"action\":\"allow\",\"os\":{\"name\":\"linux\"}}]}]",
        )
        val rules = VersionParser.parseVersion(json).libraries.single().rules
        assertEquals(1, rules.size)
        assertEquals(RuleAction.ALLOW, rules[0].action)
    }

    @Test
    fun inheritsFromIsReadForModLoaderProfiles() {
        val json = minimalVersion().replace("\"id\":\"t\",", "\"id\":\"t\",\"inheritsFrom\":\"1.20.1\",")
        assertEquals("1.20.1", VersionParser.parseVersion(json).inheritsFrom)
    }
}
