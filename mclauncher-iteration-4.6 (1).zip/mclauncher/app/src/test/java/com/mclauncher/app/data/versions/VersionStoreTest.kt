package com.mclauncher.app.data.versions

import com.mclauncher.app.launch.GameDirectories
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class VersionStoreTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val dirs by lazy { GameDirectories(File(tmp.root, ".minecraft")) }
    private val layout by lazy { VersionLayout(dirs) }
    private val store by lazy { VersionStore(layout) }

    private fun version(id: String, releaseTime: String? = null) =
        InstalledVersion(id, VersionType.RELEASE, "net.minecraft.client.main.Main", "17", 21, releaseTime, 1_000L)

    /** Папка версии как после настоящей установки. */
    private fun install(id: String, releaseTime: String? = null) {
        layout.versionDir(id).mkdirs()
        layout.versionJson(id).writeText("{}")
        layout.clientJar(id).writeText("jar")
        store.writeMarker(version(id, releaseTime))
    }

    @Test
    fun versionWithoutMarkerIsNotInstalled() {
        layout.versionDir("1.21.1").mkdirs()
        layout.versionJson("1.21.1").writeText("{}")
        layout.clientJar("1.21.1").writeText("jar")

        assertFalse(store.isInstalled("1.21.1"))
        assertNull(store.get("1.21.1"))
    }

    @Test
    fun versionWithMarkerAndFilesIsInstalledAndReadable() {
        install("1.21.1", "2024-08-08T12:00:00+00:00")

        assertTrue(store.isInstalled("1.21.1"))
        val read = store.get("1.21.1")
        assertNotNull(read)
        assertEquals(version("1.21.1", "2024-08-08T12:00:00+00:00"), read)
    }

    @Test
    fun missingJarOrDescriptionMeansNotInstalled() {
        install("a")
        layout.clientJar("a").delete()
        install("b")
        layout.versionJson("b").delete()

        assertFalse(store.isInstalled("a"))
        assertFalse(store.isInstalled("b"))
    }

    @Test
    fun corruptMarkerMeansNotInstalled() {
        install("1.21.1")
        layout.marker("1.21.1").writeText("{{ not json")

        assertTrue(layout.marker("1.21.1").isFile)
        assertNull(store.get("1.21.1"))
        assertTrue(store.list().isEmpty())
    }

    @Test
    fun markerThatNamesAnotherVersionIsIgnored() {
        install("1.21.1")
        install("1.20.4")
        layout.marker("1.21.1").writeText(layout.marker("1.20.4").readText()) // скопировали чужую метку

        assertNull(store.get("1.21.1"))
        assertNotNull(store.get("1.20.4"))
    }

    @Test
    fun listIsNewestFirstAndSkipsFoldersWithoutMarkers() {
        install("1.8.9", "2015-12-09T00:00:00+00:00")
        install("1.21.1", "2024-08-08T12:00:00+00:00")
        install("1.16.5", "2021-01-14T00:00:00+00:00")
        layout.versionDir("empty-folder").mkdirs()

        assertEquals(listOf("1.21.1", "1.16.5", "1.8.9"), store.list().map { it.id })
    }

    @Test
    fun listOfMissingVersionsFolderIsEmpty() {
        assertTrue(store.list().isEmpty())
    }

    @Test
    fun deleteRemovesTheVersionFolderOnly() {
        install("1.21.1")
        val sharedLibrary = File(dirs.libraries, "com/example/lib.jar").apply { parentFile.mkdirs(); writeText("x") }

        assertTrue(store.delete("1.21.1"))

        assertFalse(layout.versionDir("1.21.1").exists())
        assertFalse(store.isInstalled("1.21.1"))
        assertTrue(sharedLibrary.exists()) // библиотеки общие для версий
    }

    @Test
    fun deletingAMissingVersionIsFine() {
        assertTrue(store.delete("never-installed"))
    }

    @Test
    fun unsafeIdsAreNeverTouched() {
        val outside = File(tmp.root, ".minecraft/keep.txt").apply { parentFile.mkdirs(); writeText("x") }

        for (id in listOf("..", ".", "a/b", "a\\b", "", " x")) {
            assertFalse("isInstalled($id)", store.isInstalled(id))
            assertNull(store.get(id))
            assertFalse("delete($id)", store.delete(id))
        }
        assertTrue(outside.exists())
    }

    @Test
    fun markerIsReplacedAtomicallyWithoutLeavingTemporaryFiles() {
        install("1.21.1")
        store.writeMarker(version("1.21.1", "2024-08-08T12:00:00+00:00").copy(installedAt = 2_000L))

        assertEquals(2_000L, store.get("1.21.1")?.installedAt)
        assertEquals(0, layout.versionDir("1.21.1").listFiles { f -> f.name.endsWith(".tmp") }?.size)
    }
}
