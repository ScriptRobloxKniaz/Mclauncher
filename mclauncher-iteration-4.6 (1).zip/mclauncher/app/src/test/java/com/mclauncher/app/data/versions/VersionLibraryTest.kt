package com.mclauncher.app.data.versions

import com.mclauncher.app.launch.GameDirectories
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException

class VersionLibraryTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private class FakeSetting(initial: String? = null) : SelectedVersionSetting {
        private val flow = MutableStateFlow(initial)
        var failWrites = false
        var writes = 0

        override val selectedId: Flow<String?> = flow

        override suspend fun setSelectedId(id: String?) {
            writes++
            if (failWrites) throw IOException("disk full")
            flow.value = id
        }
    }

    private val dirs by lazy { GameDirectories(File(tmp.root, ".minecraft")) }
    private val layout by lazy { VersionLayout(dirs) }
    private val store by lazy { VersionStore(layout) }

    private fun install(id: String, releaseTime: String = "2024-01-01T00:00:00+00:00"): InstalledVersion {
        layout.versionDir(id).mkdirs()
        layout.versionJson(id).writeText("{}")
        layout.clientJar(id).writeText("jar")
        return InstalledVersion(id, VersionType.RELEASE, "Main", "17", 21, releaseTime, 1L)
            .also { store.writeMarker(it) }
    }

    private suspend fun VersionLibrary.current(): VersionLibraryState? = state.first()

    @Test
    fun stateIsNullUntilTheFirstRefresh() = runBlocking {
        val library = VersionLibrary(store, FakeSetting())

        assertNull(library.current())
        library.refresh()
        assertEquals(VersionLibraryState(emptyList(), null), library.current())
    }

    @Test
    fun selectedIsOnlyAnInstalledVersion() = runBlocking {
        install("1.21.1")
        val library = VersionLibrary(store, FakeSetting(initial = "1.21.1"))
        library.refresh()
        assertEquals("1.21.1", library.current()?.selected?.id)

        val stale = VersionLibrary(store, FakeSetting(initial = "1.8.9")) // выбрана версия, которой нет на диске
        stale.refresh()
        assertNull(stale.current()?.selected)
        assertEquals("1.8.9", stale.current()?.selectedId)
    }

    @Test
    fun selectWorksOnlyForInstalledVersions() = runBlocking {
        install("1.21.1")
        val setting = FakeSetting()
        val library = VersionLibrary(store, setting)
        library.refresh()

        assertFalse(library.select("1.20.4"))
        assertNull(setting.selectedId.first())

        assertTrue(library.select("1.21.1"))
        assertEquals("1.21.1", library.current()?.selected?.id)
    }

    @Test
    fun selectReportsAFailedWrite() = runBlocking {
        install("1.21.1")
        val setting = FakeSetting().apply { failWrites = true }
        val library = VersionLibrary(store, setting)
        library.refresh()

        assertFalse(library.select("1.21.1"))
        assertNull(library.current()?.selected)
    }

    @Test
    fun firstInstalledVersionBecomesSelected() = runBlocking {
        val setting = FakeSetting()
        val library = VersionLibrary(store, setting)
        library.refresh()

        val version = install("1.21.1")
        library.onInstallResult(InstallResult.Installed(version))

        assertEquals("1.21.1", library.current()?.selected?.id)
    }

    @Test
    fun laterInstallDoesNotStealTheSelection() = runBlocking {
        val first = install("1.21.1")
        val setting = FakeSetting(initial = first.id)
        val library = VersionLibrary(store, setting)
        library.refresh()

        val second = install("1.20.4", releaseTime = "2023-12-01T00:00:00+00:00")
        library.onInstallResult(InstallResult.Installed(second))

        assertEquals(listOf("1.21.1", "1.20.4"), library.current()?.installed?.map { it.id })
        assertEquals("1.21.1", library.current()?.selected?.id)
        assertEquals(0, setting.writes)
    }

    @Test
    fun installReplacesAStaleSelection() = runBlocking {
        val setting = FakeSetting(initial = "1.8.9") // на диске такой версии нет
        val library = VersionLibrary(store, setting)
        library.refresh()

        val version = install("1.21.1")
        library.onInstallResult(InstallResult.Installed(version))

        assertEquals("1.21.1", library.current()?.selected?.id)
    }

    @Test
    fun failedInstallChangesNothing() = runBlocking {
        val setting = FakeSetting()
        val library = VersionLibrary(store, setting)
        library.refresh()

        library.onInstallResult(InstallResult.Failed(InstallError.Network("x")))

        assertEquals(VersionLibraryState(emptyList(), null), library.current())
        assertEquals(0, setting.writes)
    }

    @Test
    fun failedSelectionWriteAfterInstallStillListsTheVersion() = runBlocking {
        val setting = FakeSetting().apply { failWrites = true }
        val library = VersionLibrary(store, setting)
        library.refresh()

        val version = install("1.21.1")
        library.onInstallResult(InstallResult.Installed(version))

        assertEquals(listOf("1.21.1"), library.current()?.installed?.map { it.id })
        assertNull(library.current()?.selected)
    }

    @Test
    fun deletingTheSelectedVersionClearsTheSelection() = runBlocking {
        install("1.21.1")
        install("1.20.4", releaseTime = "2023-12-01T00:00:00+00:00")
        val setting = FakeSetting(initial = "1.21.1")
        val library = VersionLibrary(store, setting)
        library.refresh()

        assertTrue(library.delete("1.21.1"))

        assertEquals(listOf("1.20.4"), library.current()?.installed?.map { it.id })
        assertNull(setting.selectedId.first())
        assertNull(library.current()?.selected)
    }

    @Test
    fun deletingAnotherVersionKeepsTheSelection() = runBlocking {
        install("1.21.1")
        install("1.20.4", releaseTime = "2023-12-01T00:00:00+00:00")
        val setting = FakeSetting(initial = "1.21.1")
        val library = VersionLibrary(store, setting)
        library.refresh()

        assertTrue(library.delete("1.20.4"))

        assertEquals("1.21.1", library.current()?.selected?.id)
        assertEquals(0, setting.writes)
    }

    @Test
    fun deleteOfUnsafeIdFailsAndTouchesNothing() = runBlocking {
        install("1.21.1")
        val library = VersionLibrary(store, FakeSetting(initial = "1.21.1"))
        library.refresh()

        assertFalse(library.delete("../versions"))

        assertEquals("1.21.1", library.current()?.selected?.id)
    }

    @Test
    fun refreshPicksUpChangesMadeOutsideTheLibrary() = runBlocking {
        val library = VersionLibrary(store, FakeSetting())
        library.refresh()
        install("1.21.1")
        assertTrue(library.current()?.installed.orEmpty().isEmpty())

        library.refresh()

        assertEquals(listOf("1.21.1"), library.current()?.installed?.map { it.id })
    }
}
