package com.mclauncher.app.data.versions

import com.mclauncher.app.launch.GameDirectories
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/**
 * Проверка разбора и планирования на НАСТОЯЩИХ файлах Mojang.
 *
 * Образцы в `src/test/resources/fixtures` написаны вручную по памяти, поэтому они доказывают только, что код
 * согласован с моим представлением о формате. Этот тест убирает «по памяти»: он берёт файлы, скачанные
 * `scripts/fetch_fixtures.py`, и проверяет парсер и планировщик на них.
 *
 * Пока файлов нет, тест **пропускается** (не падает и не считается пройденным). Как получить файлы и запустить —
 * в docs/VERSION_INSTALLER.md. Папку можно задать переменной окружения `MC_REAL_FIXTURES`.
 */
class RealFixturesTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val root: File? = listOfNotNull(
        System.getenv("MC_REAL_FIXTURES")?.takeIf { it.isNotBlank() },
        "src/test/resources/real", // рабочая папка Gradle-тестов — app/
        "app/src/test/resources/real",
    ).map(::File).firstOrNull { File(it, "manifest.json").isFile }

    private fun fixtures(): File {
        assumeTrue("Нет настоящих файлов Mojang: выполните scripts/fetch_fixtures.py", root != null)
        return checkNotNull(root)
    }

    private fun versionFiles(): List<File> {
        val files = File(fixtures(), "versions").listFiles { f -> f.extension == "json" }?.sortedBy { it.name }.orEmpty()
        assumeTrue("Нет файлов версий в ${fixtures()}/versions", files.isNotEmpty())
        return files
    }

    private fun planner(): InstallPlanner {
        val dirs = GameDirectories(File(tmp.root, ".minecraft"))
        return InstallPlanner(VersionLayout(dirs), OsEnvironment.LINUX_ARM64)
    }

    @Test
    fun realManifestParses() {
        val manifest = VersionParser.parseManifest(File(fixtures(), "manifest.json").readText())

        println("manifest: ${manifest.versions.size} versions, latest release ${manifest.latestRelease}, snapshot ${manifest.latestSnapshot}")
        assertTrue("too few versions: ${manifest.versions.size}", manifest.versions.size > 100)
        assertEquals("duplicate ids", manifest.versions.size, manifest.versions.map { it.id }.toSet().size)
        assertTrue(manifest.versions.all { it.url.startsWith("https://") })
        assertTrue("SHA-1 must be present in version_manifest_v2", manifest.versions.all { SafePaths.isSha1(it.sha1) })

        val latest = manifest.versions.firstOrNull { it.id == manifest.latestRelease }
        assertTrue("latest release is not in the list: ${manifest.latestRelease}", latest != null)
        assertEquals(VersionType.RELEASE, latest?.type)

        val types = manifest.versions.map { it.type }.toSet()
        assertTrue("unknown version types appeared: $types", VersionType.OTHER !in types)
        assertTrue(VersionType.RELEASE in types && VersionType.SNAPSHOT in types)
    }

    @Test
    fun everyRealVersionParsesAndPlans() {
        val planner = planner()
        val gameRoot = File(tmp.root, ".minecraft").canonicalPath

        for (file in versionFiles()) {
            val version = VersionParser.parseVersion(file.readText())
            val where = "version ${version.id} (${file.name})"

            assertEquals("$where: id differs from file name", file.nameWithoutExtension, version.id)
            assertTrue("$where: main class", version.mainClass.isNotBlank())
            assertTrue("$where: client url", version.client.url.startsWith("https://"))
            assertTrue("$where: client sha1", SafePaths.isSha1(version.client.sha1))
            assertTrue("$where: client size", version.client.size > 0)
            assertTrue("$where: no libraries", version.libraries.isNotEmpty())
            assertTrue("$where: asset index url", version.assetIndex.url.startsWith("https://"))
            assertTrue("$where: java major", version.java.majorVersion >= 8)

            val tasks = planner.coreTasks(version)
            assertEquals("$where: first task must be the client jar", FileKind.CLIENT_JAR, tasks.first().kind)
            assertEquals("$where: duplicate targets", tasks.size, tasks.map { it.target.path }.toSet().size)
            for (task in tasks) {
                assertTrue("$where: ${task.url} is not https", task.url.startsWith("https://"))
                assertTrue("$where: ${task.target} is outside the game folder", task.target.canonicalPath.startsWith(gameRoot))
            }
            // У самых старых описаний у части библиотек нет SHA-1: это не ошибка разбора, загрузчик проверит их по размеру.
            val withoutHash = tasks.count { it.sha1 == null }
            if (withoutHash > 0) println("$where: $withoutHash of ${tasks.size} files have no SHA-1 (checked by size only)")

            // Для Android: чужие платформы и нативные jar не скачиваются.
            val names = planner.selectLibraries(version).map { it.name }
            assertTrue("$where: windows/macos natives selected: $names", names.none { "natives-windows" in it || "natives-macos" in it })
            assertTrue("$where: native jars were not dropped: $names", names.none { n -> n.split(':').getOrNull(3)?.startsWith("natives") == true })

            println("${version.id}: ${version.libraries.size} libraries in JSON -> ${tasks.size - 1 - (if (version.logging != null) 1 else 0)} to download, java ${version.java.majorVersion}, assets ${version.assetIndex.id}, legacy args ${version.arguments.legacy}")
        }
    }

    @Test
    fun realAssetIndexesParseAndPlan() {
        val planner = planner()
        var checked = 0
        for (file in versionFiles()) {
            val version = VersionParser.parseVersion(file.readText())
            val indexFile = File(fixtures(), "assets/${version.assetIndex.id}.json")
            if (!indexFile.isFile) continue

            val index = VersionParser.parseAssetIndex(indexFile.readText())
            val tasks = planner.assetTasks(index)

            assertTrue("${version.id}: empty asset index", index.objects.isNotEmpty())
            assertTrue("${version.id}: bad hash", index.objects.all { SafePaths.isSha1(it.hash) })
            assertEquals("${version.id}: tasks must be one per distinct hash", index.objects.map { it.hash.lowercase() }.toSet().size, tasks.size)
            assertTrue("${version.id}: asset sizes", tasks.all { it.size >= 0 })
            println("${version.id}: assets '${version.assetIndex.id}' ${index.objects.size} objects (${tasks.size} files, virtual=${index.virtual}, mapToResources=${index.mapToResources})")
            checked++
        }
        assumeTrue("Нет ни одного индекса ассетов в ${fixtures()}/assets", checked > 0)
    }
}
