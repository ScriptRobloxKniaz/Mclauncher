package com.mclauncher.app.data.versions

import com.mclauncher.app.data.net.HttpBody
import com.mclauncher.app.data.net.HttpSource
import com.mclauncher.app.data.net.HttpStatusException
import kotlinx.coroutines.delay
import java.io.ByteArrayInputStream
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/** Читает образец JSON из `src/test/resources/fixtures`. */
object Fixtures {
    fun text(name: String): String {
        val stream = Fixtures::class.java.getResourceAsStream("/fixtures/$name")
            ?: error("Missing test fixture: $name")
        return stream.use { String(it.readBytes(), Charsets.UTF_8) }
    }
}

fun sha1Hex(bytes: ByteArray): String =
    MessageDigest.getInstance("SHA-1").digest(bytes).joinToString("") { "%02x".format(it) }

/**
 * Поддельный сервер для проверок без сети. Каждый адрес отвечает заранее заданным образом; если ответов
 * несколько, они выдаются по очереди, а последний повторяется (так проверяются повторные попытки).
 */
class FakeHttpSource(private val latencyMs: Long = 0L) : HttpSource {

    sealed interface Reply {
        class Ok(val bytes: ByteArray, val declaredLength: Long? = null) : Reply
        class Status(val code: Int) : Reply
        class Fail(val message: String = "connection reset") : Reply

        /** Тело отдаётся кусочками с паузами — чтобы успеть отменить загрузку посреди файла. */
        class Slow(val chunks: Int, val chunkSize: Int, val pauseMs: Long) : Reply
    }

    private val replies = ConcurrentHashMap<String, List<Reply>>()
    private val counts = ConcurrentHashMap<String, AtomicInteger>()
    private val log = Collections.synchronizedList(ArrayList<String>())
    private val inFlight = AtomicInteger()

    @Volatile
    var maxInFlight = 0
        private set

    fun serve(url: String, bytes: ByteArray) = serveSequence(url, Reply.Ok(bytes))
    fun serve(url: String, text: String) = serve(url, text.toByteArray(Charsets.UTF_8))
    fun serveSequence(url: String, vararg sequence: Reply) {
        replies[url] = sequence.toList()
    }

    fun requestCount(url: String): Int = counts[url]?.get() ?: 0
    val totalRequests: Int get() = counts.values.sumOf { it.get() }
    val requestedUrls: List<String> get() = synchronized(log) { log.toList() }

    override suspend fun <T> get(url: String, consume: suspend (HttpBody) -> T): T {
        val attempt = counts.getOrPut(url) { AtomicInteger() }.incrementAndGet()
        log += url
        val sequence = replies[url] ?: listOf(Reply.Status(404))
        val reply = sequence[minOf(attempt, sequence.size) - 1]

        val now = inFlight.incrementAndGet()
        synchronized(this) { if (now > maxInFlight) maxInFlight = now }
        try {
            if (latencyMs > 0) delay(latencyMs)
            return when (reply) {
                is Reply.Ok -> consume(HttpBody(reply.declaredLength ?: reply.bytes.size.toLong(), ByteArrayInputStream(reply.bytes)))
                is Reply.Status -> throw HttpStatusException(reply.code, url)
                is Reply.Fail -> throw IOException(reply.message)
                is Reply.Slow -> consume(HttpBody(-1, SlowStream(reply)))
            }
        } finally {
            inFlight.decrementAndGet()
        }
    }

    private class SlowStream(private val reply: Reply.Slow) : InputStream() {
        private var sent = 0
        override fun read(): Int = throw UnsupportedOperationException()
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (sent >= reply.chunks) return -1
            Thread.sleep(reply.pauseMs)
            sent++
            val n = minOf(len, reply.chunkSize)
            java.util.Arrays.fill(b, off, off + n, 7)
            return n
        }
    }
}
