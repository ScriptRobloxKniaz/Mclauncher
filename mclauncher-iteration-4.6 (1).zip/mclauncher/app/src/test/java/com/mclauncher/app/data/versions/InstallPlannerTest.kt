package com.mclauncher.app.data.versions

import com.mclauncher.app.launch.GameDirectories
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class InstallPlannerTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val modernText = Fixtures.text("version_modern.json")
    private val modern by lazy { VersionParser.parseVersion(modernText) }

    private fun layout(): VersionLayout = VersionLayout(GameDirectories(File(tmp.root, ".minecraft")))

    private fun planner(
        env: OsEnvironment = OsEnvironment.LINUX_ARM64,
        includeNativeJars: Boolean = false,
        libraryFilter: (Library) -> Boolean = { true },
        allowInsecureHttp: Boolean = false,
    ) = InstallPlanner(layout(), env, includeNativeJars, libraryFilter, allowInsecureHttp = allowInsecureHttp)

    private fun names(libraries: List<Library>) = libraries.map { it.name }

    // ---- Отбор библиотек ------------------------------------------------------------------

    @Test
    fun onAndroidArm64NativeJarsAndForeignPlatformsAreLeftOut() {
        val selected = names(planner().selectLibraries(modern))
        assertEquals(listOf("com.google.code.gson:gson:2.10.1", "org.lwjgl:lwjgl:3.3.3"), selected)
    }

    @Test
    fun nativeJarsCanBeIncludedAndStillObeyRules() {
        val selected = names(planner(includeNativeJars = true).selectLibraries(modern))
        assertTrue("org.lwjgl:lwjgl:3.3.3:natives-linux" in selected)
        assertTrue("org.lwjgl:lwjgl:3.3.3:natives-linux-arm64" in selected)
        assertFalse("org.lwjgl:lwjgl:3.3.3:natives-windows" in selected)
        assertFalse("ca.weblite:java-objc-bridge:1.1" in selected)
    }

    @Test
    fun arm64NativesRuleDoesNotApplyToX86() {
        val x86 = OsEnvironment(name = "linux", arch = "x86_64")
        val selected = names(planner(env = x86, includeNativeJars = true).selectLibraries(modern))
        assertTrue("org.lwjgl:lwjgl:3.3.3:natives-linux" in selected)
        assertFalse("org.lwjgl:lwjgl:3.3.3:natives-linux-arm64" in selected)
    }

    @Test
    fun otherSystemsGetTheirOwnLibraries() {
        val windows = OsEnvironment(name = "windows", arch = "x86_64", version = "10.0")
        val selected = names(planner(env = windows).selectLibraries(modern))
        // «Разрешить всем, кроме Linux» на Windows разрешено.
        assertTrue("net.java.jinput:jinput-platform:2.0.5" in selected)
        assertFalse("ca.weblite:java-objc-bridge:1.1" in selected)
    }

    @Test
    fun libraryFilterLetsTheEngineReplaceLibraries() {
        val selected = names(planner(libraryFilter = { !it.name.startsWith("org.lwjgl") }).selectLibraries(modern))
        assertEquals(listOf("com.google.code.gson:gson:2.10.1"), selected)
    }

    @Test
    fun legacyNativeLibrariesWithoutPlainJarAreSkipped() {
        val legacy = VersionParser.parseVersion(Fixtures.text("version_legacy.json"))
        val selected = names(planner().selectLibraries(legacy))
        assertEquals(
            listOf("com.mojang:netty:1.8.8", "net.sf.jopt-simple:jopt-simple:4.6", "org.lwjgl.lwjgl:lwjgl-platform:2.9.4-nightly-20150209"),
            selected,
        )
    }

    // ---- Задачи загрузки ------------------------------------------------------------------

    @Test
    fun coreTasksCoverClientJarLibrariesAndLogConfig() {
        val tasks = planner().coreTasks(modern)
        assertEquals(
            listOf(FileKind.CLIENT_JAR, FileKind.LIBRARY, FileKind.LIBRARY, FileKind.LOGGING),
            tasks.map { it.kind },
        )
        val root = tmp.root.resolve(".minecraft")
        assertEquals(root.resolve("versions/1.21.1/1.21.1.jar"), tasks[0].target)
        assertEquals(root.resolve("libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar"), tasks[1].target)
        assertEquals(root.resolve("assets/log_configs/client-1.12.xml"), tasks[3].target)
        assertEquals(26000000L, tasks[0].size)
        assertEquals("2222222222222222222222222222222222222222", tasks[0].sha1)
        assertTrue(tasks.all { it.url.startsWith("https://") })
    }

    @Test
    fun duplicateLibraryPathsAreDownloadedOnce() {
        val doubled = modern.copy(libraries = modern.libraries + modern.libraries)
        assertEquals(4, planner().coreTasks(doubled).size)
    }

    @Test
    fun invalidHashesAreDroppedNotTrusted() {
        val broken = VersionParser.parseVersion(modernText.replace("4444444444444444444444444444444444444444", "zz"))
        val gson = planner().coreTasks(broken).first { it.kind == FileKind.LIBRARY }
        assertNull(gson.sha1)
    }

    @Test
    fun versionJsonAndAssetIndexTasks() {
        val entry = ManifestEntry(
            id = "1.21.1",
            type = VersionType.RELEASE,
            url = "https://piston-meta.mojang.com/x/1.21.1.json",
            sha1 = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
            releaseTime = null,
        )
        val jsonTask = planner().versionJsonTask(entry)
        assertEquals(tmp.root.resolve(".minecraft/versions/1.21.1/1.21.1.json"), jsonTask.target)
        assertEquals(FileKind.VERSION_JSON, jsonTask.kind)
        assertEquals("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb", jsonTask.sha1)

        val indexTask = planner().assetIndexTask(modern)
        assertEquals(tmp.root.resolve(".minecraft/assets/indexes/17.json"), indexTask.target)
        assertEquals(458000L, indexTask.size)
    }

    @Test
    fun assetTasksAreDeduplicatedByHashAndStoredByHash() {
        val index = VersionParser.parseAssetIndex(Fixtures.text("asset_index.json"))
        val tasks = planner().assetTasks(index)
        assertEquals(3, tasks.size) // два имени с одним хэшем (в разном регистре) — один файл
        val icon = tasks.first { it.sha1 == "bdf48ef6b5d0d23bbb02e17d04865216179f510a" }
        assertEquals("https://resources.download.minecraft.net/bd/bdf48ef6b5d0d23bbb02e17d04865216179f510a", icon.url)
        assertEquals(tmp.root.resolve(".minecraft/assets/objects/bd/bdf48ef6b5d0d23bbb02e17d04865216179f510a"), icon.target)
        assertFalse(icon.verifyExisting)
        assertEquals(FileKind.ASSET_OBJECT, icon.kind)
    }

    // ---- Недоверенные данные --------------------------------------------------------------

    @Test
    fun unsafeLibraryPathIsRejected() {
        val evil = VersionParser.parseVersion(
            modernText.replace("com/google/code/gson/gson/2.10.1/gson-2.10.1.jar", "../../evil.jar"),
        )
        assertThrows(PlanException::class.java) { planner().coreTasks(evil) }
    }

    @Test
    fun absoluteAndBackslashPathsAreRejected() {
        for (path in listOf("/etc/passwd", "a\\b.jar", "a//b.jar", "a/./b.jar", "C:/x.jar", "")) {
            val evil = VersionParser.parseVersion(
                modernText.replace("com/google/code/gson/gson/2.10.1/gson-2.10.1.jar", path),
            )
            assertThrows("path '$path'", PlanException::class.java) { planner().coreTasks(evil) }
        }
    }

    @Test
    fun libraryWithoutPathIsRejected() {
        val noPath = VersionParser.parseVersion(
            modernText.replace("\"path\": \"com/google/code/gson/gson/2.10.1/gson-2.10.1.jar\",", ""),
        )
        assertThrows(PlanException::class.java) { planner().coreTasks(noPath) }
    }

    @Test
    fun plainHttpIsRefusedUnlessExplicitlyAllowed() {
        val http = VersionParser.parseVersion(
            modernText.replace("https://libraries.minecraft.net/com/google", "http://libraries.minecraft.net/com/google"),
        )
        assertThrows(PlanException::class.java) { planner().coreTasks(http) }
        assertEquals(4, planner(allowInsecureHttp = true).coreTasks(http).size)
    }

    @Test
    fun unsafeVersionAndAssetIndexIdsAreRejected() {
        val entry = ManifestEntry("../x", VersionType.RELEASE, "https://a/b.json", null, null)
        assertThrows(PlanException::class.java) { planner().versionJsonTask(entry) }

        val badIndex = VersionParser.parseVersion(modernText.replace("\"id\": \"17\",", "\"id\": \"../x\","))
        assertThrows(PlanException::class.java) { planner().assetIndexTask(badIndex) }
    }

    @Test
    fun badAssetHashIsRejected() {
        val index = AssetIndex(listOf(AssetObject("a", "../../etc", 1)), virtual = false, mapToResources = false)
        assertThrows(PlanException::class.java) { planner().assetTasks(index) }
    }
}
