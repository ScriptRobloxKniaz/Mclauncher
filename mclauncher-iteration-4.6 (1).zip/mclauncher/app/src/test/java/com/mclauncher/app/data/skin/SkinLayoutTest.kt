package com.mclauncher.app.data.skin

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Проверка раскладки текстуры двумя независимыми способами: числа ниже выписаны вручную по привычной
 * схеме скина 64×64, а в коде они считаются по формуле развёртки коробки. Совпадение — признак, что
 * не ошиблись ни тут, ни там.
 */
class SkinLayoutTest {

    private fun rect(x: Int, y: Int, w: Int, h: Int) = PixelRect(x, y, w, h)

    @Test
    fun `first layer faces match the known skin layout`() {
        assertEquals(rect(8, 8, 8, 8), SkinLayout.HEAD.face(Face.FRONT))
        assertEquals(rect(24, 8, 8, 8), SkinLayout.HEAD.face(Face.BACK))
        assertEquals(rect(20, 20, 8, 12), SkinLayout.BODY.face(Face.FRONT))
        assertEquals(rect(32, 20, 8, 12), SkinLayout.BODY.face(Face.BACK))
        assertEquals(rect(4, 20, 4, 12), SkinLayout.RIGHT_LEG.face(Face.FRONT))
        assertEquals(rect(12, 20, 4, 12), SkinLayout.RIGHT_LEG.face(Face.BACK))
        assertEquals(rect(20, 52, 4, 12), SkinLayout.LEFT_LEG.face(Face.FRONT))
        assertEquals(rect(28, 52, 4, 12), SkinLayout.LEFT_LEG.face(Face.BACK))
    }

    @Test
    fun `wide arm faces match the known skin layout`() {
        val right = SkinLayout.rightArm(SkinModel.WIDE)
        assertEquals(rect(44, 20, 4, 12), right.face(Face.FRONT))
        assertEquals(rect(52, 20, 4, 12), right.face(Face.BACK))
        val left = SkinLayout.leftArm(SkinModel.WIDE)
        assertEquals(rect(36, 52, 4, 12), left.face(Face.FRONT))
        assertEquals(rect(44, 52, 4, 12), left.face(Face.BACK))
    }

    @Test
    fun `slim arm faces are one pixel narrower and the back face shifts left`() {
        val right = SkinLayout.rightArm(SkinModel.SLIM)
        assertEquals(rect(44, 20, 3, 12), right.face(Face.FRONT))
        assertEquals(rect(51, 20, 3, 12), right.face(Face.BACK))
        val left = SkinLayout.leftArm(SkinModel.SLIM)
        assertEquals(rect(36, 52, 3, 12), left.face(Face.FRONT))
        assertEquals(rect(43, 52, 3, 12), left.face(Face.BACK))
    }

    @Test
    fun `second layer faces match the known skin layout`() {
        assertEquals(rect(40, 8, 8, 8), SkinLayout.HAT.face(Face.FRONT))
        assertEquals(rect(56, 8, 8, 8), SkinLayout.HAT.face(Face.BACK))
        assertEquals(rect(20, 36, 8, 12), SkinLayout.JACKET.face(Face.FRONT))
        assertEquals(rect(4, 36, 4, 12), SkinLayout.RIGHT_PANTS.face(Face.FRONT))
        assertEquals(rect(12, 36, 4, 12), SkinLayout.RIGHT_PANTS.face(Face.BACK))
        assertEquals(rect(4, 52, 4, 12), SkinLayout.LEFT_PANTS.face(Face.FRONT))
        assertEquals(rect(12, 52, 4, 12), SkinLayout.LEFT_PANTS.face(Face.BACK))
        assertEquals(rect(44, 36, 4, 12), SkinLayout.rightSleeve(SkinModel.WIDE).face(Face.FRONT))
        assertEquals(rect(52, 36, 4, 12), SkinLayout.rightSleeve(SkinModel.WIDE).face(Face.BACK))
        assertEquals(rect(52, 52, 4, 12), SkinLayout.leftSleeve(SkinModel.WIDE).face(Face.FRONT))
        assertEquals(rect(60, 52, 4, 12), SkinLayout.leftSleeve(SkinModel.WIDE).face(Face.BACK))
        assertEquals(rect(59, 52, 3, 12), SkinLayout.leftSleeve(SkinModel.SLIM).face(Face.BACK))
    }

    private fun allBoxes(model: SkinModel) = listOf(
        SkinLayout.HEAD, SkinLayout.BODY, SkinLayout.RIGHT_LEG, SkinLayout.LEFT_LEG,
        SkinLayout.rightArm(model), SkinLayout.leftArm(model),
        SkinLayout.HAT, SkinLayout.JACKET, SkinLayout.RIGHT_PANTS, SkinLayout.LEFT_PANTS,
        SkinLayout.rightSleeve(model), SkinLayout.leftSleeve(model),
    )

    @Test
    fun `no two faces of the texture overlap and all lie inside 64x64`() {
        for (model in SkinModel.entries) {
            val faces = allBoxes(model).flatMap { it.faces }
            assertEquals(12 * 6, faces.size)
            for (f in faces) {
                assertTrue("$f outside the texture", f.x >= 0 && f.y >= 0 && f.right <= 64 && f.bottom <= 64)
            }
            for (i in faces.indices) {
                for (j in i + 1 until faces.size) {
                    assertFalse("${faces[i]} overlaps ${faces[j]} ($model)", faces[i].intersects(faces[j]))
                }
            }
        }
    }

    private fun pixels(rect: PixelRect): Set<Pair<Int, Int>> =
        (rect.y until rect.bottom).flatMap { y -> (rect.x until rect.right).map { x -> x to y } }.toSet()

    private fun covered(box: SkinBox): Set<Pair<Int, Int>> = box.faces.flatMap { pixels(it) }.toSet()

    @Test
    fun `slim unused regions are exactly what wide arms cover and slim arms do not`() {
        val expected = mutableSetOf<Pair<Int, Int>>()
        for ((wide, slim) in listOf(
            SkinLayout.rightArm(SkinModel.WIDE) to SkinLayout.rightArm(SkinModel.SLIM),
            SkinLayout.leftArm(SkinModel.WIDE) to SkinLayout.leftArm(SkinModel.SLIM),
        )) {
            val wideCovered = covered(wide)
            val slimCovered = covered(slim)
            assertTrue("a slim arm must use only what a wide arm uses", wideCovered.containsAll(slimCovered))
            expected += wideCovered - slimCovered
        }
        val actual = SkinLayout.SLIM_UNUSED_REGIONS.flatMap { pixels(it) }.toSet()
        assertEquals(expected, actual)
        assertEquals(2 * 4 * 2 + 2 * 12 * 2, actual.size) // по две области на руку: 2×4 и 2×12
    }

    @Test
    fun `preview base parts do not overlap, stay in the grid and have the expected silhouette area`() {
        for (side in ViewSide.entries) {
            for (model in SkinModel.entries) {
                val base = SkinLayout.previewParts(side, model).filter { !it.isOverlay }
                assertEquals(6, base.size)
                val dest = base.map { PixelRect(it.destX, it.destY, it.source.width, it.source.height) }
                for (d in dest) {
                    assertTrue(
                        "$d outside the preview grid",
                        d.x >= 0 && d.y >= 0 && d.right <= SkinLayout.PREVIEW_WIDTH && d.bottom <= SkinLayout.PREVIEW_HEIGHT,
                    )
                }
                for (i in dest.indices) {
                    for (j in i + 1 until dest.size) {
                        assertFalse("${dest[i]} overlaps ${dest[j]} ($side, $model)", dest[i].intersects(dest[j]))
                    }
                }
                // Голова 8×8 + тело 8×12 + две руки + две ноги 4×12.
                val expectedArea = 64 + 96 + 2 * SkinLayout.armWidth(model) * 12 + 2 * 48
                assertEquals(expectedArea, dest.sumOf { it.width * it.height })
            }
        }
    }

    @Test
    fun `preview overlay parts sit exactly over their base parts`() {
        for (side in ViewSide.entries) {
            for (model in SkinModel.entries) {
                val parts = SkinLayout.previewParts(side, model)
                val base = parts.filter { !it.isOverlay }
                val overlay = parts.filter { it.isOverlay }
                // Первый слой нарисован раньше второго.
                assertEquals(parts.take(6), base)
                assertEquals(
                    base.map { Triple(it.destX, it.destY, it.source.width to it.source.height) },
                    overlay.map { Triple(it.destX, it.destY, it.source.width to it.source.height) },
                )
            }
        }
    }

    @Test
    fun `front view puts the right arm on the viewer's left and the back view swaps the arms`() {
        fun part(side: ViewSide, model: SkinModel, x: Int) =
            SkinLayout.previewParts(side, model).first { !it.isOverlay && it.destX == x && it.destY == 8 && it.source.height == 12 && it.source.width != 8 }

        // Спереди, широкие руки: слева правая рука, справа левая.
        assertEquals(rect(44, 20, 4, 12), part(ViewSide.FRONT, SkinModel.WIDE, 0).source)
        assertEquals(rect(36, 52, 4, 12), part(ViewSide.FRONT, SkinModel.WIDE, 12).source)
        // Сзади — наоборот.
        assertEquals(rect(44, 52, 4, 12), part(ViewSide.BACK, SkinModel.WIDE, 0).source)
        assertEquals(rect(52, 20, 4, 12), part(ViewSide.BACK, SkinModel.WIDE, 12).source)
        // Тонкие руки прижаты к телу: левая рука (со стороны зрителя) начинается на пиксель правее.
        assertEquals(rect(44, 20, 3, 12), part(ViewSide.FRONT, SkinModel.SLIM, 1).source)
        assertEquals(rect(43, 52, 3, 12), part(ViewSide.BACK, SkinModel.SLIM, 1).source)
        assertEquals(rect(51, 20, 3, 12), part(ViewSide.BACK, SkinModel.SLIM, 12).source)
    }

    @Test
    fun `only 64x64 and 64x32 are supported sizes`() {
        assertTrue(SkinLayout.isSupportedSize(64, 64))
        assertTrue(SkinLayout.isSupportedSize(64, 32))
        assertFalse(SkinLayout.isSupportedSize(32, 32))
        assertFalse(SkinLayout.isSupportedSize(128, 64))
        assertFalse(SkinLayout.isSupportedSize(64, 33))
    }
}
