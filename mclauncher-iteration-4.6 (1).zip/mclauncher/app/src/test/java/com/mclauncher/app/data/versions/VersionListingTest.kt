package com.mclauncher.app.data.versions

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VersionListingTest {

    private fun entry(id: String, type: VersionType) = ManifestEntry(id, type, "https://meta.test/$id.json", null, null)

    private fun installed(id: String) = InstalledVersion(id, VersionType.RELEASE, "Main", "17", 21, null, 0L)

    private val manifest = VersionManifest(
        latestRelease = "1.21.1",
        latestSnapshot = "24w33a",
        versions = listOf(
            entry("24w33a", VersionType.SNAPSHOT),
            entry("1.21.1", VersionType.RELEASE),
            entry("1.20.4", VersionType.RELEASE),
            entry("1.8.9", VersionType.RELEASE),
            entry("b1.7.3", VersionType.OLD_BETA),
            entry("a1.2.6", VersionType.OLD_ALPHA),
            entry("2.0-weird", VersionType.OTHER),
        ),
    )

    private fun ids(entries: List<ManifestEntry>) = entries.map { it.id }

    @Test
    fun releasesTabShowsOnlyReleasesInManifestOrder() {
        val listing = buildListing(manifest, emptyList(), VersionFilter.RELEASES, "")

        assertEquals(listOf("1.21.1", "1.20.4", "1.8.9"), ids(listing.available))
    }

    @Test
    fun snapshotsTabAlsoKeepsUnknownTypes() {
        val listing = buildListing(manifest, emptyList(), VersionFilter.SNAPSHOTS, "")

        assertEquals(listOf("24w33a", "2.0-weird"), ids(listing.available))
    }

    @Test
    fun oldTabShowsBetasAndAlphas() {
        val listing = buildListing(manifest, emptyList(), VersionFilter.OLD, "")

        assertEquals(listOf("b1.7.3", "a1.2.6"), ids(listing.available))
    }

    @Test
    fun everyManifestVersionIsReachableThroughSomeTab() {
        val shown = VersionFilter.entries.flatMap { ids(buildListing(manifest, emptyList(), it, "").available) }

        assertEquals(manifest.versions.map { it.id }.sorted(), shown.sorted())
    }

    @Test
    fun installedVersionsMoveOutOfAvailable() {
        val listing = buildListing(manifest, listOf(installed("1.20.4")), VersionFilter.RELEASES, "")

        assertEquals(listOf("1.20.4"), listing.installed.map { it.id })
        assertEquals(listOf("1.21.1", "1.8.9"), ids(listing.available))
    }

    @Test
    fun installedAreVisibleOnEveryTabAndWithoutAManifest() {
        val installed = listOf(installed("1.21.1"), installed("custom-build"))

        for (filter in VersionFilter.entries) {
            val listing = buildListing(manifest = null, installed = installed, filter = filter, query = "")
            assertEquals(listOf("1.21.1", "custom-build"), listing.installed.map { it.id })
            assertTrue(listing.available.isEmpty())
        }
    }

    @Test
    fun searchIgnoresCaseAndSurroundingSpaces() {
        val listing = buildListing(manifest, listOf(installed("1.20.4")), VersionFilter.RELEASES, "  1.2 ")

        assertEquals(listOf("1.20.4"), listing.installed.map { it.id })
        assertEquals(listOf("1.21.1"), ids(listing.available))

        assertEquals(listOf("24w33a"), ids(buildListing(manifest, emptyList(), VersionFilter.SNAPSHOTS, "24W").available))
    }

    @Test
    fun searchThatMatchesNothingGivesEmptyLists() {
        val listing = buildListing(manifest, listOf(installed("1.21.1")), VersionFilter.RELEASES, "zzz")

        assertEquals(VersionListing.EMPTY, listing)
    }

    @Test
    fun blankQueryDoesNotFilter() {
        assertEquals(3, buildListing(manifest, emptyList(), VersionFilter.RELEASES, "   ").available.size)
    }

    @Test
    fun noManifestMeansNothingAvailable() {
        assertFalse(buildListing(null, emptyList(), VersionFilter.RELEASES, "").available.isNotEmpty())
    }
}
