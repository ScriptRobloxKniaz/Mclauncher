package com.mclauncher.app.ui.components

import androidx.annotation.StringRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.BackgroundPreset
import kotlin.math.floor
import kotlin.math.sin

@get:StringRes
val BackgroundPreset.labelRes: Int
    get() = when (this) {
        BackgroundPreset.MEADOW -> R.string.background_preset_meadow
        BackgroundPreset.DUSK -> R.string.background_preset_dusk
        BackgroundPreset.DEEP -> R.string.background_preset_deep
    }

private class PresetPalette(
    val skyTop: Color,
    val skyBottom: Color,
    val sun: Color,
    /** Слои «рельефа» от дальнего к ближнему. */
    val layers: List<Color>,
)

private fun BackgroundPreset.palette(): PresetPalette = when (this) {
    BackgroundPreset.MEADOW -> PresetPalette(
        skyTop = Color(0xFF5BA8E0),
        skyBottom = Color(0xFFCDEBFF),
        sun = Color(0xFFFFF3B0),
        layers = listOf(Color(0xFF6DB85A), Color(0xFF4A9440), Color(0xFF2F6E2C), Color(0xFF1C4A1F)),
    )

    BackgroundPreset.DUSK -> PresetPalette(
        skyTop = Color(0xFF2B1B4A),
        skyBottom = Color(0xFFF2845C),
        sun = Color(0xFFFFD08A),
        layers = listOf(Color(0xFF5A3A78), Color(0xFF41295D), Color(0xFF2D1B44), Color(0xFF1B1030)),
    )

    BackgroundPreset.DEEP -> PresetPalette(
        skyTop = Color(0xFF04293A),
        skyBottom = Color(0xFF14909A),
        sun = Color(0xFFB8F2E6),
        layers = listOf(Color(0xFF0F6E78), Color(0xFF0A525C), Color(0xFF06383F), Color(0xFF03242A)),
    )
}

/**
 * Фон-пресет, нарисованный кодом: градиентное небо и «блочные» холмы.
 * Полностью оригинальный рисунок, без чужих текстур — картинок в ресурсах нет.
 */
@Composable
fun PresetBackground(preset: BackgroundPreset, modifier: Modifier = Modifier) {
    val palette = remember(preset) { preset.palette() }

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(palette.skyTop, palette.skyBottom)))

        val columns = 26
        val block = size.width / columns

        // Квадратное «солнце»
        val sunSize = block * 3.5f
        drawRect(
            color = palette.sun,
            topLeft = Offset(size.width * 0.74f, size.height * 0.16f),
            size = Size(sunSize, sunSize),
        )

        palette.layers.forEachIndexed { layer, color ->
            val baseline = (size.height * (0.52f + layer * 0.12f) / block).toInt() * block
            for (column in 0 until columns) {
                val wave = sin((column + layer * 7) * 0.45f + layer) * 2f +
                    sin((column + layer * 3) * 0.17f) * 3f
                val top = baseline + floor(wave) * block
                drawRect(
                    color = color,
                    topLeft = Offset(column * block, top),
                    // +1 px: без щелей между колонками при дробной ширине
                    size = Size(block + 1f, size.height - top),
                )
            }
        }
    }
}
