package com.mclauncher.app

import android.app.Application
import android.os.Build
import com.mclauncher.app.data.account.AccountRepository
import com.mclauncher.app.data.background.BackgroundImageStore
import com.mclauncher.app.data.db.LauncherDatabase
import com.mclauncher.app.data.net.HttpSource
import com.mclauncher.app.data.net.UrlConnectionHttpSource
import com.mclauncher.app.data.settings.SettingsRepository
import com.mclauncher.app.data.skin.SkinRepository
import com.mclauncher.app.data.skin.SkinStore
import com.mclauncher.app.data.versions.InstallManager
import com.mclauncher.app.data.versions.OsEnvironment
import com.mclauncher.app.data.versions.VersionCatalog
import com.mclauncher.app.data.versions.VersionInstaller
import com.mclauncher.app.data.versions.VersionLayout
import com.mclauncher.app.data.versions.VersionLibrary
import com.mclauncher.app.data.versions.VersionStore
import com.mclauncher.app.launch.GameDirectories
import com.mclauncher.app.launch.GameEngine
import com.mclauncher.app.launch.GameLauncher
import com.mclauncher.app.launch.StubGameEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import java.io.File

/**
 * Точка входа процесса и «ручной DI»: тяжёлые объекты создаются лениво и живут,
 * пока жив процесс. База открывается при первом запросе, и Room делает это вне главного потока.
 */
class LauncherApp : Application() {
    val settings: SettingsRepository by lazy { SettingsRepository(this) }
    val backgroundStore: BackgroundImageStore by lazy { BackgroundImageStore(this) }

    private val database: LauncherDatabase by lazy { LauncherDatabase.create(this) }
    val accountRepository: AccountRepository by lazy { AccountRepository(database) }

    private val skinStore: SkinStore by lazy { SkinStore(this) }
    val skinRepository: SkinRepository by lazy { SkinRepository(this, accountRepository, skinStore) }

    /** Папка `.minecraft` (app-specific хранилище). Создаётся при запуске игры и при импорте модов. */
    val gameDirectories: GameDirectories by lazy { GameDirectories.forContext(this) }

    // --- Установка версий игры (итерация 4.6) ---

    /** Живёт, пока жив процесс: установка версии не должна обрываться при уходе с экрана. */
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Единственная точка выхода в сеть для загрузок. Идентификатор клиента не содержит данных об устройстве. */
    val httpSource: HttpSource by lazy { UrlConnectionHttpSource(userAgent = "MCLauncher/${BuildConfig.VERSION_NAME}") }

    private val versionLayout: VersionLayout by lazy { VersionLayout(gameDirectories) }
    val versionStore: VersionStore by lazy { VersionStore(versionLayout) }

    /** Список версий Mojang; последняя удачная копия лежит в кэше приложения (его можно очистить без вреда). */
    val versionCatalog: VersionCatalog by lazy { VersionCatalog(httpSource, File(cacheDir, "version_manifest_v2.json")) }

    /** Что установлено и что выбрано для кнопки «Играть». */
    val versionLibrary: VersionLibrary by lazy { VersionLibrary(versionStore, settings) }

    private val versionInstaller: VersionInstaller by lazy {
        VersionInstaller(
            directories = gameDirectories,
            http = httpSource,
            // Для правил библиотек Android — это «linux» с архитектурой устройства.
            env = OsEnvironment.android(Build.SUPPORTED_ABIS.toList()),
            layout = versionLayout,
            store = versionStore,
        )
    }

    val installManager: InstallManager by lazy {
        InstallManager(
            install = { entry, onProgress ->
                versionInstaller.install(entry, onProgress).also { versionLibrary.onInstallResult(it) }
            },
            scope = appScope,
        )
    }

    /**
     * Ядро игры. СЕЙЧАС — заглушка: игра не стартует. Когда PojavLauncher будет подключён,
     * здесь появится `PojavGameEngine`; остальной код менять не придётся.
     */
    val gameEngine: GameEngine by lazy { StubGameEngine() }
    val gameLauncher: GameLauncher by lazy {
        GameLauncher(gameEngine, gameDirectories, isVersionInstalled = versionStore::isInstalled)
    }
}
