package com.mclauncher.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {

    @Query("SELECT * FROM accounts ORDER BY createdAt ASC, id ASC")
    fun observeAll(): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE isActive = 1 LIMIT 1")
    fun observeActive(): Flow<AccountEntity?>

    @Query("SELECT * FROM accounts WHERE id = :id")
    suspend fun get(id: Long): AccountEntity?

    @Query("SELECT COUNT(*) FROM accounts WHERE isActive = 1")
    suspend fun activeCount(): Int

    /** Самый новый аккаунт — кандидат на активный после удаления активного. */
    @Query("SELECT id FROM accounts ORDER BY createdAt DESC, id DESC LIMIT 1")
    suspend fun newestId(): Long?

    /**
     * Сколько аккаунтов с таким типом и UUID уже есть (0 или 1): явная проверка дубликата перед вставкой.
     * [typeName] — это `AccountType.name`: Room хранит enum именно как текст-имя константы.
     */
    @Query("SELECT COUNT(*) FROM accounts WHERE type = :typeName AND uuid = :uuid")
    suspend fun countByUuid(typeName: String, uuid: String): Int

    /** Бросает SQLiteConstraintException, если такой аккаунт (тип + UUID) уже есть. */
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: AccountEntity): Long

    @Query("UPDATE accounts SET isActive = 0 WHERE isActive = 1")
    suspend fun clearActive()

    @Query("UPDATE accounts SET isActive = 1 WHERE id = :id")
    suspend fun markActive(id: Long)

    @Query("DELETE FROM accounts WHERE id = :id")
    suspend fun delete(id: Long)

    /**
     * Ставит или снимает скин. [modelName] — `SkinModel.name` (или `null`, чтобы снять скин):
     * как и в [countByUuid], enum передаётся текстом. Возвращает число изменённых строк (0 — аккаунта нет).
     */
    @Query("UPDATE accounts SET skinModel = :modelName, skinUpdatedAt = :updatedAt WHERE id = :id")
    suspend fun setSkin(id: Long, modelName: String?, updatedAt: Long): Int

    /** Меняет только модель рук и только у аккаунта, у которого скин уже есть. */
    @Query("UPDATE accounts SET skinModel = :modelName WHERE id = :id AND skinModel IS NOT NULL")
    suspend fun setSkinModel(id: Long, modelName: String): Int
}
