package com.mclauncher.app.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.mclauncher.app.R
import com.mclauncher.app.ui.components.LauncherIcons

/**
 * Все экраны приложения. [inBottomBar] = true — экран есть в нижней панели / боковом rail.
 * Порядок вкладок задаёт и направление анимации переходов.
 */
enum class Destination(
    val route: String,
    @StringRes val labelRes: Int,
    val icon: ImageVector,
    val inBottomBar: Boolean = true,
) {
    Home("home", R.string.nav_home, Icons.Filled.Home),
    Accounts("accounts", R.string.nav_accounts, Icons.Filled.Person),
    Skins("skins", R.string.nav_skins, Icons.Filled.Face),
    Mods("mods", R.string.nav_mods, Icons.Filled.Build),
    Settings("settings", R.string.nav_settings, Icons.Filled.Settings),

    /** ИИ-помощник сборок: полноэкранный, без нижней панели. */
    Assistant("assistant", R.string.assistant_title, LauncherIcons.Sparkle, inBottomBar = false),

    /** Версии игры: установка, выбор, удаление. Полноэкранный, открывается с главной. */
    Versions("versions", R.string.versions_title, LauncherIcons.Versions, inBottomBar = false);

    companion object {
        val tabs: List<Destination> = entries.filter { it.inBottomBar }

        fun fromRoute(route: String?): Destination? = entries.firstOrNull { it.route == route }
    }
}
