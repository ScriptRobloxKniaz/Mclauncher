package com.mclauncher.app.data.versions

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.put
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/** Версия, установка которой завершена: все файлы скачаны и проверены. */
data class InstalledVersion(
    val id: String,
    val type: VersionType,
    val mainClass: String,
    val assetsId: String,
    val javaMajor: Int,
    val releaseTime: String?,
    val installedAt: Long,
)

/**
 * Что установлено в `.minecraft/versions`. Признак «установлена» — файл-метка `mclauncher-install.json`: он пишется
 * **последним**, после того как скачаны и проверены все файлы. Версия, которую оборвали на середине, метки не имеет
 * и в списке установленных не появится; повторная установка докачает недостающее.
 *
 * Работа с диском: вызывать вне главного потока.
 */
class VersionStore(private val layout: VersionLayout) {

    /** Быстрая проверка перед запуском: метка и основные файлы на месте. Хэши заново не считаются. */
    fun isInstalled(id: String): Boolean =
        SafePaths.isSafeName(id) &&
            layout.marker(id).isFile &&
            layout.versionJson(id).isFile &&
            layout.clientJar(id).isFile

    fun get(id: String): InstalledVersion? {
        if (!isInstalled(id)) return null
        return readMarker(layout.marker(id))?.takeIf { it.id == id }
    }

    /** Установленные версии: сначала самые новые по дате выхода. Повреждённые метки пропускаются. */
    fun list(): List<InstalledVersion> {
        val dirs = layout.versionsRoot().listFiles { file -> file.isDirectory } ?: return emptyList()
        return dirs.mapNotNull { dir -> if (SafePaths.isSafeName(dir.name)) get(dir.name) else null }
            .sortedWith(compareByDescending<InstalledVersion> { it.releaseTime.orEmpty() }.thenBy { it.id })
    }

    /**
     * Удаляет папку версии (описание, jar, метку). Общие библиотеки и ассеты остаются: ими могут пользоваться
     * другие версии. Возвращает `false`, если удалить не удалось.
     */
    fun delete(id: String): Boolean {
        if (!SafePaths.isSafeName(id)) return false
        val dir = layout.versionDir(id)
        return !dir.exists() || dir.deleteRecursively()
    }

    /** Записывает метку установки через временный файл. */
    @Throws(IOException::class)
    fun writeMarker(version: InstalledVersion) {
        val target = layout.marker(version.id)
        target.parentFile?.mkdirs()
        val temp = File(target.path + ".tmp")
        val json = buildJsonObject {
            put("schema", SCHEMA)
            put("id", version.id)
            put("type", version.type.id)
            put("mainClass", version.mainClass)
            put("assets", version.assetsId)
            put("java", version.javaMajor)
            version.releaseTime?.let { put("releaseTime", it) }
            put("installedAt", version.installedAt)
        }
        try {
            temp.writeText(json.toString())
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        } finally {
            temp.delete()
        }
    }

    private fun readMarker(file: File): InstalledVersion? = try {
        val o = Json.parseToJsonElement(file.readText()) as? JsonObject
        if (o == null) {
            null
        } else {
            InstalledVersion(
                id = o.string("id") ?: return null,
                type = VersionType.fromId(o.string("type")),
                mainClass = o.string("mainClass") ?: return null,
                assetsId = o.string("assets") ?: return null,
                javaMajor = (o["java"] as? JsonPrimitive)?.intOrNull ?: 8,
                releaseTime = o.string("releaseTime"),
                installedAt = (o["installedAt"] as? JsonPrimitive)?.content?.toLongOrNull() ?: 0L,
            )
        }
    } catch (e: IOException) {
        null
    } catch (e: IllegalArgumentException) {
        null // повреждённая метка: считаем версию не установленной
    }

    private fun JsonObject.string(key: String): String? =
        (this[key] as? JsonPrimitive)?.takeIf { it.isString }?.content

    private companion object {
        const val SCHEMA = 1
    }
}
