package com.mclauncher.app.ui.components

import androidx.compose.ui.graphics.ImageBitmap
import com.mclauncher.app.data.settings.BackgroundPreset

/** То, что реально рисуется на заднем плане (результат разбора [com.mclauncher.app.data.settings.BackgroundSelection]). */
sealed interface BackgroundContent {

    data class Preset(val preset: BackgroundPreset) : BackgroundContent

    /** Загруженная картинка пользователя. Сравнивается по ссылке на bitmap. */
    data class Image(val bitmap: ImageBitmap) : BackgroundContent
}
