package com.mclauncher.app.ui.assistant

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.mclauncher.app.R
import com.mclauncher.app.ui.navigation.Destination
import com.mclauncher.app.ui.placeholder.PlaceholderScreen

/**
 * Заглушка ИИ-помощника сборок. Настоящий чат и подбор модов появятся
 * отдельной итерацией после импорта модов и сборок (итерация 7).
 */
@Composable
fun AssistantScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxSize()) {
        PlaceholderScreen(
            destination = Destination.Assistant,
            message = stringResource(R.string.placeholder_assistant),
        )
        IconButton(
            onClick = onBack,
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = stringResource(R.string.action_back),
            )
        }
    }
}
