package com.mclauncher.app.data.account

import android.database.sqlite.SQLiteConstraintException
import androidx.room.withTransaction
import com.mclauncher.app.data.db.AccountEntity
import com.mclauncher.app.data.db.LauncherDatabase
import com.mclauncher.app.data.skin.SkinModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Единственная точка работы с аккаунтами. Все изменения идут транзакциями, чтобы
 * «активным» всегда был ровно один аккаунт (если аккаунты вообще есть).
 *
 * Методы могут бросить `android.database.sqlite.SQLiteException` (диск, повреждённая база) —
 * вызывающий код обязан её обработать и показать понятное сообщение.
 */
class AccountRepository(
    private val database: LauncherDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val dao = database.accountDao()

    val accounts: Flow<List<Account>> = dao.observeAll().map { list -> list.map { it.toDomain() } }

    val activeAccount: Flow<Account?> = dao.observeActive().map { it?.toDomain() }

    /** Создаёт оффлайн-аккаунт. Первый созданный аккаунт автоматически становится активным. */
    suspend fun createOffline(rawName: String): CreateAccountResult {
        val name = rawName.trim()
        UsernameValidator.validate(name)?.let { return CreateAccountResult.Rejected(it) }

        val entity = AccountEntity(
            type = AccountType.OFFLINE,
            username = name,
            uuid = OfflineUuid.forName(name).toString(),
            createdAt = clock(),
        )
        return try {
            database.withTransaction {
                // Явная проверка внутри транзакции — не зависим от типа исключения при нарушении
                // уникального индекса. Сам индекс остаётся страховкой на случай гонки.
                if (dao.countByUuid(entity.type.name, entity.uuid) > 0) {
                    CreateAccountResult.Rejected(NameError.DUPLICATE)
                } else {
                    val id = dao.insert(entity)
                    if (dao.activeCount() == 0) dao.markActive(id)
                    CreateAccountResult.Created(checkNotNull(dao.get(id)).toDomain())
                }
            }
        } catch (e: SQLiteConstraintException) {
            CreateAccountResult.Rejected(NameError.DUPLICATE)
        }
    }

    /** Делает аккаунт активным. Если его удалили за это время — ничего не происходит. */
    suspend fun setActive(id: Long) {
        database.withTransaction<Unit> {
            if (dao.get(id) != null) {
                dao.clearActive()
                dao.markActive(id)
            }
        }
    }

    /**
     * Запоминает скин аккаунта ([model] = null — снять скин). Одна команда UPDATE атомарна сама по себе.
     * Возвращает `false`, если такого аккаунта уже нет.
     */
    suspend fun setSkin(id: Long, model: SkinModel?): Boolean {
        val updatedAt = if (model == null) 0L else clock()
        return dao.setSkin(id, model?.name, updatedAt) > 0
    }

    /** Меняет модель рук у сохранённого скина. `false` — аккаунта нет или у него нет скина. */
    suspend fun setSkinModel(id: Long, model: SkinModel): Boolean =
        dao.setSkinModel(id, model.name) > 0

    /** Удаляет аккаунт; если он был активным, активным становится самый новый из оставшихся. */
    suspend fun delete(id: Long) {
        database.withTransaction<Unit> {
            val target = dao.get(id)
            if (target != null) {
                dao.delete(id)
                if (target.isActive) {
                    dao.newestId()?.let { dao.markActive(it) }
                }
            }
        }
    }
}
