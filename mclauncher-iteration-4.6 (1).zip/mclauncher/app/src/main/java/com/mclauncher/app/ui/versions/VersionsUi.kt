package com.mclauncher.app.ui.versions

import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.mclauncher.app.R
import com.mclauncher.app.data.versions.InstallError
import com.mclauncher.app.data.versions.InstallPhase
import com.mclauncher.app.data.versions.InstallProgress
import com.mclauncher.app.data.versions.UnsupportedReason
import com.mclauncher.app.data.versions.VersionFilter
import com.mclauncher.app.data.versions.VersionType

private const val MEGABYTE = 1024L * 1024L

@get:StringRes
val VersionType.labelRes: Int
    get() = when (this) {
        VersionType.RELEASE -> R.string.versions_type_release
        VersionType.SNAPSHOT -> R.string.versions_type_snapshot
        VersionType.OLD_BETA -> R.string.versions_type_beta
        VersionType.OLD_ALPHA -> R.string.versions_type_alpha
        VersionType.OTHER -> R.string.versions_type_other
    }

@get:StringRes
val VersionFilter.labelRes: Int
    get() = when (this) {
        VersionFilter.RELEASES -> R.string.versions_filter_releases
        VersionFilter.SNAPSHOTS -> R.string.versions_filter_snapshots
        VersionFilter.OLD -> R.string.versions_filter_old
    }

/** Дата выхода для списка: из `2024-08-08T12:00:00+00:00` берём `2024-08-08`; если формат другой — не показываем. */
fun releaseDate(releaseTime: String?): String? =
    releaseTime?.take(10)?.takeIf { it.length == 10 && it[4] == '-' && it[7] == '-' }

/** Мегабайты с округлением вверх: «нужно 1 МБ» честнее, чем «нужно 0 МБ». */
fun bytesToMegabytes(bytes: Long): Long = (bytes.coerceAtLeast(0) + MEGABYTE - 1) / MEGABYTE

/** Понятное объяснение причины, почему версия не установилась. Технические подробности — в [installErrorDetail]. */
@Composable
fun installErrorMessage(error: InstallError): String = when (error) {
    is InstallError.Network -> stringResource(R.string.install_error_network)
    is InstallError.Server -> stringResource(R.string.install_error_server, error.status)
    is InstallError.BadData -> stringResource(R.string.install_error_bad_data)
    is InstallError.NotEnoughSpace -> stringResource(
        R.string.install_error_space,
        bytesToMegabytes(error.neededBytes),
        bytesToMegabytes(error.freeBytes),
    )
    is InstallError.Storage -> stringResource(R.string.install_error_storage)
    is InstallError.Unsupported -> when (error.reason) {
        UnsupportedReason.MOD_LOADER_PROFILE -> stringResource(R.string.install_error_mod_loader)
        UnsupportedReason.LEGACY_ASSETS -> stringResource(R.string.install_error_legacy)
    }
}

/** Строка «Подробности» для поддержки; `null`, если сказать больше нечего. */
fun installErrorDetail(error: InstallError): String? {
    val raw = when (error) {
        is InstallError.Network -> error.detail
        is InstallError.BadData -> error.detail
        is InstallError.Storage -> error.detail
        else -> null
    }
    return raw?.takeIf { it.isNotBlank() }
}

/** Подпись стадии установки под полосой прогресса. */
@Composable
fun installPhaseLabel(progress: InstallProgress?): String = when (progress?.phase) {
    null, InstallPhase.PREPARING -> stringResource(R.string.versions_phase_preparing)
    InstallPhase.VERSION_FILE -> stringResource(R.string.versions_phase_info)
    InstallPhase.ASSET_INDEX -> stringResource(R.string.versions_phase_assets)
    InstallPhase.DOWNLOADING ->
        stringResource(R.string.versions_phase_downloading, progress?.filesDone ?: 0, progress?.filesTotal ?: 0)
    InstallPhase.FINISHING -> stringResource(R.string.versions_phase_finishing)
}
