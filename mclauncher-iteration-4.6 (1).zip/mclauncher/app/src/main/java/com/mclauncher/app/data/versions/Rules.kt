package com.mclauncher.app.data.versions

/**
 * Система, под которую отбираются библиотеки и аргументы.
 *
 * Android для описаний Mojang — это «linux»: нативные части игры (LWJGL и т. п.) подменяет движок
 * (этап 4.7), но Java-библиотеки и правила у них общие. [arch] хранится в нормализованном виде
 * (см. [normalizeArch]).
 */
data class OsEnvironment(
    val name: String,
    val arch: String,
    /** Версия ОС; нужна только правилам с `os.version` (в основном Windows). У Android её нет. */
    val version: String? = null,
) {
    companion object {
        /** По списку ABI устройства (`Build.SUPPORTED_ABIS`): берётся основной, первый. */
        fun android(supportedAbis: List<String>): OsEnvironment =
            OsEnvironment(name = "linux", arch = normalizeArch(supportedAbis.firstOrNull().orEmpty()))

        val LINUX_ARM64 = OsEnvironment(name = "linux", arch = "arm64")
    }
}

/**
 * Приводит разные написания архитектуры к одному: `aarch64`, `arm64-v8a` → `arm64`;
 * `amd64`, `x86_64` → `x86_64`; `i386`, `i686`, `x86` → `x86`; `armeabi-v7a`, `armv7l` → `arm`.
 * Незнакомое возвращается как есть, в нижнем регистре.
 */
fun normalizeArch(raw: String): String = when (val value = raw.trim().lowercase()) {
    "aarch64", "arm64", "arm64-v8a", "armv8", "armv8l" -> "arm64"
    "amd64", "x86_64", "x64" -> "x86_64"
    "x86", "i386", "i486", "i586", "i686" -> "x86"
    "arm", "armeabi", "armeabi-v7a", "armv7", "armv7l", "armv7a" -> "arm"
    else -> value
}

/** Вычисление правил `rules` из описаний версий (библиотеки и аргументы). */
object RuleEvaluator {

    /**
     * Разрешено ли, если правил нет — да. Иначе действует **последнее подошедшее** правило;
     * если не подошло ни одно — нет. Так считает и официальный лаунчер.
     * [features] — включённые возможности (`is_demo_user`, `has_custom_resolution` и т. п.).
     */
    fun isAllowed(rules: List<Rule>, env: OsEnvironment, features: Set<String> = emptySet()): Boolean {
        if (rules.isEmpty()) return true
        var allowed = false
        for (rule in rules) {
            if (applies(rule, env, features)) allowed = rule.action == RuleAction.ALLOW
        }
        return allowed
    }

    private fun applies(rule: Rule, env: OsEnvironment, features: Set<String>): Boolean {
        val os = rule.os
        if (os != null && !matchesOs(os, env)) return false
        return rule.features.all { (name, expected) -> (name in features) == expected }
    }

    private fun matchesOs(os: OsRule, env: OsEnvironment): Boolean {
        if (os.name != null && !os.name.equals(env.name, ignoreCase = true)) return false
        if (os.arch != null && normalizeArch(os.arch) != env.arch) return false
        if (os.version != null) {
            val version = env.version ?: return false
            val matches = try {
                Regex(os.version).containsMatchIn(version)
            } catch (e: IllegalArgumentException) {
                false // испорченное выражение: считаем, что правило не подходит
            }
            if (!matches) return false
        }
        return true
    }
}
