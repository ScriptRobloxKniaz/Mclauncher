package com.mclauncher.app.ui.common

import android.widget.Toast
import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.flow.Flow

/** Одноразовое сообщение пользователю (показывается тостом). Текст всегда из strings.xml. */
data class UiEvent(@StringRes val messageRes: Int)

/** Показывает сообщения из [events] тостами, пока экран на месте. */
@Composable
fun CollectUiEvents(events: Flow<UiEvent>) {
    val context = LocalContext.current
    LaunchedEffect(events) {
        events.collect { event ->
            Toast.makeText(context, event.messageRes, Toast.LENGTH_LONG).show()
        }
    }
}
