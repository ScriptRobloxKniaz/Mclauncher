package com.mclauncher.app.data.skin

/**
 * Быстрая проверка файла скина по байтам, без декодирования картинки: подпись PNG, заголовок IHDR,
 * размер файла и размеры в пикселях. Так огромная или поддельная картинка не попадает в память.
 * Работает без Android — покрыто JVM-тестами.
 */
object SkinValidator {

    /** Скин 64×64 весит единицы килобайт; мегабайт — с большим запасом. */
    const val MAX_BYTES = 1024 * 1024

    private val PNG_SIGNATURE = byteArrayOf(
        0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
    )

    /** "IHDR" в ASCII. */
    private val IHDR = byteArrayOf(0x49, 0x48, 0x44, 0x52)

    private const val IHDR_LENGTH = 13
    private const val HEADER_END = 24 // подпись 8 + длина 4 + тип 4 + ширина 4 + высота 4

    sealed interface Result {
        data class Valid(val width: Int, val height: Int) : Result
        data class Invalid(val error: SkinError) : Result
    }

    /**
     * Читать можно не больше [MAX_BYTES] + 1 байта: если байтов больше лимита, файл отклоняется
     * как [SkinError.TOO_LARGE] (после проверки, что это вообще PNG).
     */
    fun validate(bytes: ByteArray): Result {
        if (bytes.size < HEADER_END) return Result.Invalid(SkinError.NOT_PNG)
        for (i in PNG_SIGNATURE.indices) {
            if (bytes[i] != PNG_SIGNATURE[i]) return Result.Invalid(SkinError.NOT_PNG)
        }
        // Первым чанком PNG всегда идёт IHDR длиной 13 байт.
        if (readInt(bytes, 8) != IHDR_LENGTH) return Result.Invalid(SkinError.NOT_PNG)
        for (i in IHDR.indices) {
            if (bytes[12 + i] != IHDR[i]) return Result.Invalid(SkinError.NOT_PNG)
        }
        if (bytes.size > MAX_BYTES) return Result.Invalid(SkinError.TOO_LARGE)

        val width = readInt(bytes, 16)
        val height = readInt(bytes, 20)
        return if (SkinLayout.isSupportedSize(width, height)) {
            Result.Valid(width, height)
        } else {
            Result.Invalid(SkinError.WRONG_SIZE)
        }
    }

    /** Целое число, 4 байта, старший байт первым (так записаны числа в PNG). */
    private fun readInt(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xFF) shl 24) or
            ((bytes[offset + 1].toInt() and 0xFF) shl 16) or
            ((bytes[offset + 2].toInt() and 0xFF) shl 8) or
            (bytes[offset + 3].toInt() and 0xFF)
}
