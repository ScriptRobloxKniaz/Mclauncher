package com.mclauncher.app.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.mclauncher.app.data.versions.SelectedVersionSetting
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "launcher_settings")

/**
 * Настройки лаунчера в DataStore: выбор фона и выбранная версия игры;
 * RAM, версия Java и прочее добавятся в итерации 8.
 *
 * Запись может бросить [IOException] — вызывающий код обязан её обработать.
 */
class SettingsRepository(context: Context) : SelectedVersionSetting {

    private val dataStore = context.applicationContext.settingsDataStore

    val background: Flow<BackgroundSelection> = dataStore.data
        .catch { e ->
            // Повреждённый файл настроек не должен ронять приложение: читаем значения по умолчанию.
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs -> prefs.toBackgroundSelection() }
        .distinctUntilChanged()

    suspend fun setBackgroundPreset(preset: BackgroundPreset) {
        dataStore.edit { prefs ->
            prefs[Keys.BackgroundType] = TYPE_PRESET
            prefs[Keys.BackgroundPreset] = preset.id
            prefs.remove(Keys.BackgroundStamp)
        }
    }

    suspend fun setBackgroundCustom(stamp: Long) {
        dataStore.edit { prefs ->
            prefs[Keys.BackgroundType] = TYPE_CUSTOM
            prefs[Keys.BackgroundStamp] = stamp
        }
    }

    override val selectedId: Flow<String?> = dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs -> prefs[Keys.SelectedVersion] }
        .distinctUntilChanged()

    override suspend fun setSelectedId(id: String?) {
        dataStore.edit { prefs ->
            if (id == null) prefs.remove(Keys.SelectedVersion) else prefs[Keys.SelectedVersion] = id
        }
    }

    private fun Preferences.toBackgroundSelection(): BackgroundSelection {
        val stamp = this[Keys.BackgroundStamp]
        return if (this[Keys.BackgroundType] == TYPE_CUSTOM && stamp != null) {
            BackgroundSelection.Custom(stamp)
        } else {
            BackgroundSelection.Preset(BackgroundPreset.fromId(this[Keys.BackgroundPreset]))
        }
    }

    private object Keys {
        val BackgroundType = stringPreferencesKey("background_type")
        val BackgroundPreset = stringPreferencesKey("background_preset")
        val BackgroundStamp = longPreferencesKey("background_stamp")
        val SelectedVersion = stringPreferencesKey("selected_version_id")
    }

    private companion object {
        const val TYPE_PRESET = "preset"
        const val TYPE_CUSTOM = "custom"
    }
}
