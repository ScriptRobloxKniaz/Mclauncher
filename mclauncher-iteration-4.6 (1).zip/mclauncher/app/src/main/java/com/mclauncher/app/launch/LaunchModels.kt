package com.mclauncher.app.launch

import com.mclauncher.app.data.account.Account

const val DEFAULT_RAM_MB = 2048

/** Всё, что нужно движку, чтобы запустить игру. */
data class LaunchRequest(
    val account: Account,
    /** Идентификатор установленной версии из `.minecraft/versions` (её устанавливает и выбирает экран «Версии»). */
    val versionId: String,
    val ramMb: Int,
    val directories: GameDirectories,
)

/** Почему запуск не удался. Тексты для пользователя подбирает UI-слой (строки ru/en). */
sealed interface LaunchFailure {
    /** Нет активного аккаунта. */
    data object NoAccount : LaunchFailure

    /** Ни одна версия не выбрана (или ещё ни одна не установлена). */
    data object NoVersion : LaunchFailure

    /** Версия выбрана, но на диске её нет или установка не была завершена: нужно установить заново. */
    data class VersionNotInstalled(val versionId: String) : LaunchFailure

    /** Не удалось создать папку игры или записать в неё. [detail] — для логов и поддержки. */
    data class GameDirUnavailable(val detail: String?) : LaunchFailure

    /** Движок недоступен: нет нативных библиотек или среды Java. */
    data object EngineUnavailable : LaunchFailure

    /** Предыдущий запуск ещё идёт. */
    data object AlreadyLaunching : LaunchFailure

    /** Движок сообщил об ошибке. */
    data class EngineError(val detail: String?) : LaunchFailure
}

sealed interface LaunchResult {

    /**
     * Игра запущена. [placeholder] = true означает заглушку: все проверки пройдены, но
     * настоящее ядро ещё не подключено и игра на самом деле НЕ стартовала.
     */
    data class Started(val placeholder: Boolean) : LaunchResult

    data class Failed(val failure: LaunchFailure) : LaunchResult
}

/** Стадия запуска для индикатора на кнопке «Играть». */
enum class LaunchPhase { IDLE, PREPARING, LAUNCHING }
