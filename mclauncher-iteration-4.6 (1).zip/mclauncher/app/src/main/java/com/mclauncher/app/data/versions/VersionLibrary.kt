package com.mclauncher.app.data.versions

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.IOException

/** Где хранится выбор версии для кнопки «Играть». В приложении это DataStore, в тестах — обычная переменная. */
interface SelectedVersionSetting {
    /** Идентификатор выбранной версии; `null`, если ничего не выбрано. */
    val selectedId: Flow<String?>

    /** Запись может бросить [IOException]. */
    suspend fun setSelectedId(id: String?)
}

/**
 * Установленные версии и выбранная из них.
 *
 * [selected] — только установленная версия: если выбор указывает на то, чего на диске нет (удалили вручную,
 * переустановили приложение), версия считается не выбранной, а лишнюю запись настроек никто не читает.
 */
data class VersionLibraryState(
    val installed: List<InstalledVersion>,
    val selectedId: String?,
) {
    val selected: InstalledVersion? get() = installed.firstOrNull { it.id == selectedId }
}

/**
 * Единое место, где приложение узнаёт, что установлено и что выбрано. Список читается с диска вне главного потока
 * ([refresh]) и обновляется после установки и удаления. Ошибки записи выбора не бросаются наружу: операции
 * возвращают `false`, а UI показывает понятное сообщение.
 */
class VersionLibrary(
    private val store: VersionStore,
    private val setting: SelectedVersionSetting,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) {
    private val installed = MutableStateFlow<List<InstalledVersion>?>(null)

    /** `null`, пока список с диска ещё не прочитан, — чтобы экран не мигал «ничего не установлено». */
    val state: Flow<VersionLibraryState?> = combine(installed, setting.selectedId) { list, selectedId ->
        list?.let { VersionLibraryState(it, selectedId) }
    }

    suspend fun refresh() {
        installed.value = withContext(ioDispatcher) { store.list() }
    }

    /** Делает установленную версию выбранной. `false`, если она не установлена или настройки не сохранились. */
    suspend fun select(id: String): Boolean {
        if (!isInstalled(id)) return false
        return writeSelection(id)
    }

    /** Удаляет версию с диска. Если она была выбрана, выбор сбрасывается. `false`, если удалить не удалось. */
    suspend fun delete(id: String): Boolean {
        val deleted = withContext(ioDispatcher) { store.delete(id) }
        refresh()
        if (deleted && setting.selectedId.first() == id) writeSelection(null)
        return deleted
    }

    /**
     * Вызывается после каждой установки. Если установка удалась, обновляет список и — когда ничего не выбрано —
     * сразу делает новую версию выбранной: игроку не нужно искать кнопку «Выбрать».
     */
    suspend fun onInstallResult(result: InstallResult) {
        if (result !is InstallResult.Installed) return
        refresh()
        val current = setting.selectedId.first()
        val currentIsValid = current != null && isInstalled(current)
        if (!currentIsValid) writeSelection(result.version.id)
    }

    private fun isInstalled(id: String): Boolean = installed.value.orEmpty().any { it.id == id }

    private suspend fun writeSelection(id: String?): Boolean = try {
        setting.setSelectedId(id)
        true
    } catch (e: CancellationException) {
        throw e
    } catch (e: IOException) {
        false
    }
}
