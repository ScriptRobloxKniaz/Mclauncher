package com.mclauncher.app.data.account

import com.mclauncher.app.data.skin.SkinInfo

/**
 * Тип аккаунта. Сейчас можно создать только [OFFLINE]; [MICROSOFT] и [ELY_BY] заложены заранее,
 * чтобы позже не менять схему базы. Токены онлайн-аккаунтов в Room НЕ хранятся
 * (для них будет отдельное зашифрованное хранилище).
 */
enum class AccountType { OFFLINE, MICROSOFT, ELY_BY }

/** Аккаунт для UI и логики запуска (не зависит от Room). */
data class Account(
    val id: Long,
    val type: AccountType,
    val username: String,
    /** UUID с дефисами. */
    val uuid: String,
    val isActive: Boolean,
    val createdAt: Long,
    /** Скин, выбранный в лаунчере; `null` — не выбран. Для онлайн-аккаунтов пока не используется. */
    val skin: SkinInfo? = null,
)

/** Почему никнейм не принят. */
enum class NameError { EMPTY, TOO_SHORT, TOO_LONG, INVALID_CHARS, DUPLICATE }

sealed interface CreateAccountResult {
    data class Created(val account: Account) : CreateAccountResult
    data class Rejected(val error: NameError) : CreateAccountResult
}
