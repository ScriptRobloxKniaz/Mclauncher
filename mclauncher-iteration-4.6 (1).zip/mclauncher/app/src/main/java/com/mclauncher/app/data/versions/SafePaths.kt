package com.mclauncher.app.data.versions

import java.io.File

/**
 * Проверки данных, которые пришли из сети и становятся частью пути к файлу или адреса.
 * Описание версии и индекс ассетов — это недоверенный ввод: путь вроде `../../x` не должен вывести
 * запись за пределы папки игры.
 */
object SafePaths {

    private val SHA1 = Regex("^[0-9a-fA-F]{40}$")

    fun isSha1(value: String?): Boolean = value != null && SHA1.matches(value)

    /**
     * Годится ли строка как имя одной папки или файла: нет разделителей, «.» и «..», управляющих символов.
     * Пробелы внутри допустимы — у Mojang есть версии вроде «1.14 Pre-Release 1».
     */
    fun isSafeName(name: String): Boolean =
        name.isNotEmpty() &&
            name.length <= 128 &&
            name == name.trim() &&
            name != "." && name != ".." &&
            name.none { it == '/' || it == '\\' || it == ':' || it.isISOControl() }

    /**
     * Относительный путь через `/` внутри [base] или `null`, если путь небезопасен: пустой, абсолютный,
     * с обратной косой чертой, двоеточием, пустыми сегментами, «.» или «..».
     */
    fun resolveInside(base: File, relative: String): File? {
        if (relative.isEmpty() || relative.length > 512) return null
        if (relative.startsWith("/") || relative.any { it == '\\' || it == ':' || it.isISOControl() }) return null
        if (relative.split('/').any { it.isEmpty() || it == "." || it == ".." }) return null
        return File(base, relative)
    }
}
