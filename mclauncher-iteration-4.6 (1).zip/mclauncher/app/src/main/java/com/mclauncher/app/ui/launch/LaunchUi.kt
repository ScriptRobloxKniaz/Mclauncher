package com.mclauncher.app.ui.launch

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.launch.LaunchFailure
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.launch.LaunchResult

/** Подпись на кнопке «Играть» в зависимости от стадии запуска. */
@get:StringRes
val LaunchPhase.playLabelRes: Int
    get() = when (this) {
        LaunchPhase.IDLE -> R.string.play
        LaunchPhase.PREPARING -> R.string.play_busy_preparing
        LaunchPhase.LAUNCHING -> R.string.play_busy_launching
    }

/** Понятное пользователю объяснение причины. */
@get:StringRes
private val LaunchFailure.messageRes: Int
    get() = when (this) {
        LaunchFailure.NoAccount -> R.string.launch_error_no_account
        LaunchFailure.NoVersion -> R.string.launch_error_no_version
        is LaunchFailure.VersionNotInstalled -> R.string.launch_error_version_missing
        is LaunchFailure.GameDirUnavailable -> R.string.launch_error_game_dir
        LaunchFailure.EngineUnavailable -> R.string.launch_error_engine_unavailable
        LaunchFailure.AlreadyLaunching -> R.string.launch_error_already
        is LaunchFailure.EngineError -> R.string.launch_error_engine
    }

/** Техническая деталь для поддержки (если есть). Показывается мелким текстом. */
private val LaunchFailure.technicalDetail: String?
    get() {
        val raw = when (this) {
            is LaunchFailure.GameDirUnavailable -> detail
            is LaunchFailure.EngineError -> detail
            is LaunchFailure.VersionNotInstalled -> versionId
            else -> null
        }
        return raw?.takeIf { it.isNotBlank() }
    }

/**
 * Итог запуска: либо ошибка с причиной, либо честное сообщение, что это заглушка
 * (все проверки пройдены, но ядро ещё не подключено и игра не стартовала).
 */
@Composable
fun LaunchResultDialog(
    result: LaunchResult,
    onDismiss: () -> Unit,
) {
    val titleRes: Int
    val messageRes: Int
    val detail: String?
    when (result) {
        is LaunchResult.Started -> {
            titleRes = R.string.launch_stub_title
            messageRes = R.string.launch_stub_message
            detail = null
        }

        is LaunchResult.Failed -> {
            titleRes = R.string.launch_failed_title
            messageRes = result.failure.messageRes
            detail = result.failure.technicalDetail
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(titleRes)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(messageRes))
                if (detail != null) {
                    Text(
                        text = stringResource(R.string.launch_details, detail),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_ok)) }
        },
    )
}
