package com.mclauncher.app.ui.home

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.ui.common.SelectedVersionState
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.versions.labelRes

/**
 * Плашка выбранной версии под кнопкой «Играть»: версия, которая запустится. Если версии нет — подсказка
 * «Выберите версию». Нажатие открывает экран версий.
 */
@Composable
fun VersionChip(
    state: SelectedVersionState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    when (state) {
        // Резервируем высоту, чтобы макет не «прыгал», когда список версий прочитается с диска.
        SelectedVersionState.Loading -> Spacer(modifier.height(ChipHeight))

        SelectedVersionState.None -> ChipSurface(
            onClick = onClick,
            container = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.94f),
            modifier = modifier,
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(22.dp),
            )
            Text(
                text = stringResource(R.string.home_choose_version),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
        }

        is SelectedVersionState.Selected -> ChipSurface(
            onClick = onClick,
            container = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f),
            modifier = modifier,
        ) {
            Icon(
                imageVector = LauncherIcons.Versions,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp),
            )
            Column(modifier = Modifier.widthIn(max = 200.dp)) {
                Text(
                    text = state.version.id,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = stringResource(state.version.type.labelRes),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}
