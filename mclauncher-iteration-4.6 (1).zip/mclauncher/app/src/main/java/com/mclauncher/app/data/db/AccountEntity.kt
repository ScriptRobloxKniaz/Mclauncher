package com.mclauncher.app.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.account.AccountType
import com.mclauncher.app.data.skin.SkinInfo
import com.mclauncher.app.data.skin.SkinModel

/**
 * Строка таблицы аккаунтов. Активным должен быть не более одного аккаунта (`isActive`);
 * переключение делается только в транзакции — см. AccountRepository.
 * Enum-поля ([type], [skinModel]) Room сохраняет как текст (имя константы), поэтому константы
 * нельзя переименовывать без миграции.
 *
 * Скин: [skinModel] = null — скина нет; иначе файл лежит в хранилище скинов, а [skinUpdatedAt] — время замены.
 * Поля скина добавлены в версии 2 (см. MIGRATION_1_2) — текст колонок там должен совпадать с этим классом.
 */
@Entity(
    tableName = "accounts",
    indices = [Index(value = ["type", "uuid"], unique = true)],
)
data class AccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: AccountType,
    val username: String,
    val uuid: String,
    val isActive: Boolean = false,
    val createdAt: Long,
    val skinModel: SkinModel? = null,
    @ColumnInfo(defaultValue = "0") val skinUpdatedAt: Long = 0,
) {
    fun toDomain() = Account(
        id = id,
        type = type,
        username = username,
        uuid = uuid,
        isActive = isActive,
        createdAt = createdAt,
        skin = skinModel?.let { SkinInfo(model = it, updatedAt = skinUpdatedAt) },
    )
}
