package com.mclauncher.app.data.skin

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.account.AccountRepository
import java.io.ByteArrayOutputStream
import java.io.IOException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed interface SkinLoadResult {
    /** У аккаунта нет скина. */
    data object NoSkin : SkinLoadResult

    /** В базе скин есть, а файл пропал или не читается. */
    data object Missing : SkinLoadResult

    /** Текстура приведена к 64×64 (старые 64×32 уже преобразованы). */
    data class Loaded(val bitmap: Bitmap) : SkinLoadResult
}

/**
 * Импорт, хранение и загрузка скинов. Файл читается из SAF-адреса, проверяется, копируется в
 * хранилище приложения — после этого права на исходный адрес больше не нужны.
 *
 * Методы переключаются на фоновый поток сами. [AccountRepository] может бросить
 * `SQLiteException` — вызывающий код обязан её обработать.
 */
class SkinRepository(
    private val context: Context,
    private val accounts: AccountRepository,
    private val store: SkinStore,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) {

    /** Читает PNG по [uri], проверяет и сохраняет как скин аккаунта [accountId]. Модель рук определяется автоматически. */
    suspend fun importFrom(accountId: Long, uri: Uri): SkinImportResult = withContext(ioDispatcher) {
        val bytes = readLimited(uri)
            ?: return@withContext SkinImportResult.Rejected(SkinError.UNREADABLE)

        val valid = when (val check = SkinValidator.validate(bytes)) {
            is SkinValidator.Result.Invalid -> return@withContext SkinImportResult.Rejected(check.error)
            is SkinValidator.Result.Valid -> check
        }

        val decoded = decode(bytes)
        if (decoded == null || decoded.width != valid.width || decoded.height != valid.height) {
            return@withContext SkinImportResult.Rejected(SkinError.UNREADABLE)
        }
        val model = SkinPixels.detectModel(decoded.pixels, decoded.width, decoded.height)

        try {
            store.write(accountId, bytes)
        } catch (e: IOException) {
            Log.w(TAG, "Failed to store skin", e)
            return@withContext SkinImportResult.Rejected(SkinError.STORAGE)
        }

        if (accounts.setSkin(accountId, model)) {
            SkinImportResult.Saved(model)
        } else {
            // Аккаунт удалили, пока шёл импорт: файл остался бы сиротой.
            store.delete(accountId)
            SkinImportResult.Rejected(SkinError.ACCOUNT_MISSING)
        }
    }

    /** Меняет модель рук у уже сохранённого скина. */
    suspend fun setModel(accountId: Long, model: SkinModel) {
        accounts.setSkinModel(accountId, model)
    }

    /** Снимает скин с аккаунта и удаляет файл. */
    suspend fun remove(accountId: Long) {
        accounts.setSkin(accountId, null)
        withContext(ioDispatcher) { store.delete(accountId) }
    }

    /** Удаляет только файл — для случая, когда сам аккаунт уже удалён. */
    suspend fun discardFile(accountId: Long) {
        withContext(ioDispatcher) { store.delete(accountId) }
    }

    /** Загружает скин аккаунта для показа. Не бросает исключений из-за плохого файла — возвращает [SkinLoadResult.Missing]. */
    suspend fun load(account: Account): SkinLoadResult = withContext(ioDispatcher) {
        if (account.skin == null) return@withContext SkinLoadResult.NoSkin

        val bytes = store.read(account.id) ?: return@withContext SkinLoadResult.Missing
        val decoded = decode(bytes)
        if (decoded == null || !SkinLayout.isSupportedSize(decoded.width, decoded.height)) {
            return@withContext SkinLoadResult.Missing
        }
        val modern = SkinPixels.toModern(decoded.pixels, decoded.width, decoded.height)
        SkinLoadResult.Loaded(
            Bitmap.createBitmap(modern, SkinLayout.TEXTURE_WIDTH, SkinLayout.TEXTURE_HEIGHT, Bitmap.Config.ARGB_8888),
        )
    }

    // ---- Внутреннее -----------------------------------------------------------------------

    /**
     * Читает не больше [SkinValidator.MAX_BYTES] + 1 байта: этого хватает, чтобы валидатор увидел
     * превышение лимита, а огромный файл не оказался целиком в памяти.
     */
    private fun readLimited(uri: Uri): ByteArray? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(BUFFER_SIZE)
                val limit = SkinValidator.MAX_BYTES + 1
                var total = 0
                while (total < limit) {
                    val read = input.read(buffer, 0, minOf(buffer.size, limit - total))
                    if (read < 0) break
                    out.write(buffer, 0, read)
                    total += read
                }
                out.toByteArray()
            }
        } catch (e: IOException) {
            Log.w(TAG, "Failed to read skin from $uri", e)
            null
        } catch (e: SecurityException) {
            // Провайдер отозвал доступ к файлу.
            Log.w(TAG, "No access to skin $uri", e)
            null
        }
    }

    private class Decoded(val width: Int, val height: Int, val pixels: IntArray)

    private fun decode(bytes: ByteArray): Decoded? {
        val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) ?: return null
        return try {
            val width = bitmap.width
            val height = bitmap.height
            val pixels = IntArray(width * height)
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
            Decoded(width, height, pixels)
        } finally {
            bitmap.recycle()
        }
    }

    private companion object {
        const val TAG = "SkinRepository"
        const val BUFFER_SIZE = 8 * 1024
    }
}
