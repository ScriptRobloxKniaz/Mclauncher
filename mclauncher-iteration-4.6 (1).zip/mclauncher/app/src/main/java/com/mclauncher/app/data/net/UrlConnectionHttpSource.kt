package com.mclauncher.app.data.net

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * [HttpSource] на стандартном `HttpURLConnection`: без внешних зависимостей. На Android он работает поверх OkHttp
 * платформы и сам обрабатывает HTTPS и перенаправления внутри одного протокола.
 *
 * Сжатие отключено (`Accept-Encoding: identity`): файлы игры уже сжаты, а так длина тела совпадает с длиной на сервере.
 * Отмену корутины блокирующее чтение само не замечает — потребитель проверяет её между порциями данных,
 * поэтому задержка отмены не больше [readTimeoutMs].
 */
class UrlConnectionHttpSource(
    private val userAgent: String,
    private val connectTimeoutMs: Int = 15_000,
    private val readTimeoutMs: Int = 20_000,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) : HttpSource {

    override suspend fun <T> get(url: String, consume: suspend (HttpBody) -> T): T =
        withContext(ioDispatcher) {
            val connection = URL(url).openConnection() as? HttpURLConnection
                ?: throw IOException("Not an HTTP(S) URL: $url")
            try {
                connection.requestMethod = "GET"
                connection.connectTimeout = connectTimeoutMs
                connection.readTimeout = readTimeoutMs
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", userAgent)
                connection.setRequestProperty("Accept-Encoding", "identity")

                val status = connection.responseCode
                if (status !in 200..299) throw HttpStatusException(status, url)
                connection.inputStream.use { stream ->
                    consume(HttpBody(connection.contentLengthLong, stream))
                }
            } finally {
                connection.disconnect()
            }
        }
}
