package com.mclauncher.app.ui.skins

import android.app.Application
import android.database.sqlite.SQLiteException
import android.net.Uri
import android.util.Log
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mclauncher.app.LauncherApp
import com.mclauncher.app.R
import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.skin.SkinImportResult
import com.mclauncher.app.data.skin.SkinLoadResult
import com.mclauncher.app.data.skin.SkinModel
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.common.UiEvent
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Что показывать в окне превью. */
sealed interface SkinPreviewState {
    /** Скин не выбран — рисуется силуэт. */
    data object Empty : SkinPreviewState

    /** В базе скин есть, а файл пропал или повреждён. */
    data object Missing : SkinPreviewState

    data class Ready(val bitmap: ImageBitmap) : SkinPreviewState
}

data class SkinsUiState(
    val account: ActiveAccountState = ActiveAccountState.Loading,
    val preview: SkinPreviewState = SkinPreviewState.Empty,
    /** Идёт импорт или удаление — кнопки заблокированы. */
    val busy: Boolean = false,
)

/** Экран «Скины» работает со скином активного аккаунта. */
@OptIn(ExperimentalCoroutinesApi::class)
class SkinsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as LauncherApp
    private val accounts = app.accountRepository
    private val skins = app.skinRepository

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events: Flow<UiEvent> = _events.receiveAsFlow()

    private val busy = MutableStateFlow(false)

    private val content: Flow<SkinsUiState> = accounts.activeAccount
        .distinctUntilChanged()
        // mapLatest отменяет загрузку превью, если аккаунт или скин сменились, пока она шла.
        .mapLatest { account ->
            if (account == null) {
                SkinsUiState(account = ActiveAccountState.None)
            } else {
                SkinsUiState(account = ActiveAccountState.Selected(account), preview = loadPreview(account))
            }
        }
        .catch { e ->
            if (e is SQLiteException) {
                Log.w(TAG, "Failed to read active account", e)
                _events.trySend(UiEvent(R.string.error_accounts_db))
                emit(SkinsUiState(account = ActiveAccountState.None))
            } else {
                throw e
            }
        }

    val uiState: StateFlow<SkinsUiState> = combine(content, busy) { state, isBusy -> state.copy(busy = isBusy) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SkinsUiState())

    /** Пользователь выбрал файл в системном окне. Адрес читается один раз, поэтому права на него дальше не нужны. */
    fun onSkinPicked(uri: Uri) {
        val account = selectedAccount() ?: return
        runExclusive {
            when (val result = skins.importFrom(account.id, uri)) {
                is SkinImportResult.Saved -> _events.trySend(UiEvent(R.string.skins_saved))
                is SkinImportResult.Rejected -> _events.trySend(UiEvent(result.error.messageRes))
            }
        }
    }

    fun setModel(model: SkinModel) {
        val account = selectedAccount() ?: return
        if (account.skin?.model == model) return
        runExclusive { skins.setModel(account.id, model) }
    }

    fun removeSkin() {
        val account = selectedAccount() ?: return
        if (account.skin == null) return
        runExclusive { skins.remove(account.id) }
    }

    private fun selectedAccount(): Account? = (uiState.value.account as? ActiveAccountState.Selected)?.account

    private suspend fun loadPreview(account: Account): SkinPreviewState = when (val result = skins.load(account)) {
        SkinLoadResult.NoSkin -> SkinPreviewState.Empty
        SkinLoadResult.Missing -> SkinPreviewState.Missing
        is SkinLoadResult.Loaded -> SkinPreviewState.Ready(result.bitmap.asImageBitmap())
    }

    /** Выполняет [block], пока другая операция не идёт; ошибки базы превращает в понятное сообщение. */
    private fun runExclusive(block: suspend () -> Unit) {
        if (busy.value) return
        busy.value = true
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: SQLiteException) {
                Log.w(TAG, "Skin operation failed", e)
                _events.trySend(UiEvent(R.string.error_accounts_db))
            } finally {
                busy.value = false
            }
        }
    }

    private companion object {
        const val TAG = "SkinsViewModel"
    }
}
