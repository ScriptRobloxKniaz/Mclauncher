package com.mclauncher.app.data.account

/**
 * Правила никнейма Minecraft: Java Edition — от 3 до 16 символов, только латиница, цифры и «_».
 * Чистая функция без Android-зависимостей, поэтому легко тестируется.
 */
object UsernameValidator {

    const val MIN_LENGTH = 3
    const val MAX_LENGTH = 16

    /** @return причина отказа или `null`, если ник подходит. Пробелы по краям не обрезаются — это делает вызывающий код. */
    fun validate(name: String): NameError? = when {
        name.isEmpty() -> NameError.EMPTY
        !containsOnlyAllowedChars(name) -> NameError.INVALID_CHARS
        name.length < MIN_LENGTH -> NameError.TOO_SHORT
        name.length > MAX_LENGTH -> NameError.TOO_LONG
        else -> null
    }

    fun containsOnlyAllowedChars(name: String): Boolean =
        name.all { it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' || it == '_' }
}
