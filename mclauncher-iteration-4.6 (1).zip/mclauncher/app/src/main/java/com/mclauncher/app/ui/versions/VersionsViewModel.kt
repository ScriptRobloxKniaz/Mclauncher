package com.mclauncher.app.ui.versions

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mclauncher.app.LauncherApp
import com.mclauncher.app.R
import com.mclauncher.app.data.versions.CatalogResult
import com.mclauncher.app.data.versions.InstallError
import com.mclauncher.app.data.versions.InstallState
import com.mclauncher.app.data.versions.ManifestEntry
import com.mclauncher.app.data.versions.VersionFilter
import com.mclauncher.app.data.versions.VersionListing
import com.mclauncher.app.data.versions.VersionManifest
import com.mclauncher.app.data.versions.buildListing
import com.mclauncher.app.ui.common.UiEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Состояние списка версий Mojang на экране. */
sealed interface CatalogUi {
    data object Loading : CatalogUi

    /** [fromCache] = true: показан сохранённый ранее список, потому что сеть недоступна. */
    data class Loaded(val manifest: VersionManifest, val fromCache: Boolean) : CatalogUi

    data class Failed(val error: InstallError) : CatalogUi
}

data class VersionsUiState(
    val catalog: CatalogUi = CatalogUi.Loading,
    /** Идёт (пере)загрузка списка из сети. */
    val refreshing: Boolean = true,
    val filter: VersionFilter = VersionFilter.RELEASES,
    /** false, пока список установленных версий не прочитан с диска. */
    val installedLoaded: Boolean = false,
    val listing: VersionListing = VersionListing.EMPTY,
    val selectedId: String? = null,
    val latestRelease: String? = null,
    val install: InstallState = InstallState.Idle,
)

/**
 * Экран «Версии»: список из манифеста Mojang, установка, выбор и удаление.
 *
 * Сама установка живёт в [com.mclauncher.app.data.versions.InstallManager] на уровне приложения, поэтому уход с
 * экрана её не прерывает; эта ViewModel только показывает её состояние и отдаёт команды.
 */
class VersionsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as LauncherApp
    private val catalog = app.versionCatalog
    private val library = app.versionLibrary
    private val manager = app.installManager

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events: Flow<UiEvent> = _events.receiveAsFlow()

    /** То, что меняет только этот экран: список из сети и фильтр. */
    private data class Local(
        val catalog: CatalogUi = CatalogUi.Loading,
        val refreshing: Boolean = true,
        val filter: VersionFilter = VersionFilter.RELEASES,
    )

    private val local = MutableStateFlow(Local())
    private var reloadJob: Job? = null

    private val _query = MutableStateFlow("")

    /**
     * Строка поиска — отдельный поток, который обновляется сразу: поле ввода не должно ждать, пока пересчитается
     * весь список (иначе при быстром наборе символы теряются). Сам список пересчитывается в [uiState].
     */
    val query: StateFlow<String> = _query.asStateFlow()

    val uiState: StateFlow<VersionsUiState> = combine(local, _query, library.state, manager.state) { l, query, lib, install ->
        val manifest = (l.catalog as? CatalogUi.Loaded)?.manifest
        VersionsUiState(
            catalog = l.catalog,
            refreshing = l.refreshing,
            filter = l.filter,
            installedLoaded = lib != null,
            listing = buildListing(manifest, lib?.installed.orEmpty(), l.filter, query),
            selectedId = lib?.selected?.id,
            latestRelease = manifest?.latestRelease,
            install = install,
        )
    }
        // Фильтрация сотен версий — не в главном потоке.
        .flowOn(Dispatchers.Default)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = VersionsUiState(),
        )

    init {
        viewModelScope.launch { library.refresh() }
        reload()

        // Установка завершилась (возможно, пока экран был закрыт): сообщаем и возвращаем менеджер в покой.
        viewModelScope.launch {
            manager.state.collect { state ->
                if (state is InstallState.Done) {
                    _events.trySend(UiEvent(R.string.versions_installed_toast))
                    manager.acknowledge()
                }
            }
        }
    }

    fun reload() {
        if (reloadJob?.isActive == true) return
        local.update { it.copy(refreshing = true) }
        reloadJob = viewModelScope.launch {
            val result = catalog.load()
            local.update {
                it.copy(
                    refreshing = false,
                    catalog = when (result) {
                        is CatalogResult.Loaded -> CatalogUi.Loaded(result.manifest, result.fromCache)
                        is CatalogResult.Failed -> CatalogUi.Failed(result.error)
                    },
                )
            }
        }
    }

    fun setFilter(filter: VersionFilter) = local.update { it.copy(filter = filter) }

    fun setQuery(query: String) {
        _query.value = query.take(MAX_QUERY)
    }

    fun install(entry: ManifestEntry) {
        if (!manager.start(entry)) _events.trySend(UiEvent(R.string.versions_busy_toast))
    }

    fun cancelInstall() = manager.cancel()

    /** Пользователь прочитал сообщение об ошибке установки. */
    fun dismissInstallError() = manager.acknowledge()

    fun select(id: String) {
        viewModelScope.launch {
            if (!library.select(id)) _events.trySend(UiEvent(R.string.versions_error_select))
        }
    }

    fun delete(id: String) {
        // Версию, которая скачивается прямо сейчас, трогать нельзя: сначала отмена.
        if ((manager.state.value as? InstallState.Running)?.versionId == id) return
        viewModelScope.launch {
            if (!library.delete(id)) _events.trySend(UiEvent(R.string.versions_error_delete))
        }
    }

    private companion object {
        const val MAX_QUERY = 40
    }
}
