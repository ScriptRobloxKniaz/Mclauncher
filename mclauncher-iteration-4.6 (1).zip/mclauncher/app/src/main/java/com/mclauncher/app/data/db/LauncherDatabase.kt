package com.mclauncher.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * База лаунчера. Профили/версии игры добавятся сюда позже (этапы 4.6 и 7).
 *
 * ВАЖНО: fallbackToDestructiveMigration() намеренно НЕ используется — при смене схемы
 * нужно писать Migration (см. Migrations.kt) и добавлять её в ALL_MIGRATIONS, иначе пользователи
 * потеряют аккаунты. Схемы экспортируются в app/schemas (их нужно коммитить).
 *
 * История версий: 1 — аккаунты; 2 — скин аккаунта (skinModel, skinUpdatedAt).
 */
@Database(
    entities = [AccountEntity::class],
    version = 2,
    exportSchema = true,
)
abstract class LauncherDatabase : RoomDatabase() {

    abstract fun accountDao(): AccountDao

    companion object {
        private const val NAME = "launcher.db"

        fun create(context: Context): LauncherDatabase =
            Room.databaseBuilder(context.applicationContext, LauncherDatabase::class.java, NAME)
                .addMigrations(*ALL_MIGRATIONS)
                .build()
    }
}
