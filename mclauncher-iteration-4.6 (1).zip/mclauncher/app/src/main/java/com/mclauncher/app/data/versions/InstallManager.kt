package com.mclauncher.app.data.versions

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface InstallState {
    data object Idle : InstallState
    data class Running(val versionId: String, val progress: InstallProgress?) : InstallState
    data class Failed(val versionId: String, val error: InstallError) : InstallState
    data class Done(val versionId: String) : InstallState
}

/**
 * Держит одну установку за раз и переживает уход с экрана: живёт в процессе приложения, а не во ViewModel.
 *
 * Ограничение: это не сервис переднего плана. Если система убьёт процесс (приложение долго в фоне), установка
 * остановится; уже скачанные файлы сохранятся, и при повторном запуске установка продолжится с того же места.
 */
class InstallManager(
    private val install: suspend (ManifestEntry, (InstallProgress) -> Unit) -> InstallResult,
    private val scope: CoroutineScope,
) {
    private val _state = MutableStateFlow<InstallState>(InstallState.Idle)
    val state: StateFlow<InstallState> = _state.asStateFlow()

    private var job: Job? = null

    /** Запускает установку. `false`, если другая установка ещё идёт. */
    @Synchronized
    fun start(entry: ManifestEntry): Boolean {
        if (_state.value is InstallState.Running) return false
        _state.value = InstallState.Running(entry.id, progress = null)
        job = scope.launch {
            try {
                when (val result = install(entry) { progress -> publish(entry.id, progress) }) {
                    is InstallResult.Installed -> _state.value = InstallState.Done(entry.id)
                    is InstallResult.Failed -> _state.value = InstallState.Failed(entry.id, result.error)
                }
            } catch (e: CancellationException) {
                _state.value = InstallState.Idle
                throw e
            }
        }
        return true
    }

    @Synchronized
    fun cancel() {
        job?.cancel()
    }

    /** Пользователь увидел итог — возвращаемся в покой. Идущую установку не трогает. */
    fun acknowledge() {
        _state.value = when (val s = _state.value) {
            is InstallState.Failed, is InstallState.Done -> InstallState.Idle
            else -> s
        }
    }

    private fun publish(versionId: String, progress: InstallProgress) {
        // Прогресс приходит из разных потоков и может опоздать к концу: итог не затираем.
        _state.value.let { if (it is InstallState.Running && it.versionId == versionId) _state.value = it.copy(progress = progress) }
    }
}
