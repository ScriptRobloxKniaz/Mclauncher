package com.mclauncher.app.data.net

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream

/** Тело успешного ответа. [contentLength] = -1, если сервер его не сообщил. */
class HttpBody(val contentLength: Long, val stream: InputStream)

/** Сервер ответил кодом не из диапазона 2xx. */
class HttpStatusException(val status: Int, val url: String) : IOException("HTTP $status: $url")

/**
 * Единственная точка выхода в сеть для загрузок. Интерфейс нужен, чтобы всё, что скачивает файлы,
 * проверялось на JVM без настоящей сети. Реализация по умолчанию — [UrlConnectionHttpSource].
 *
 * Контракт: [consume] вызывается только для кода 2xx, тело читается внутри него (после возврата поток закрыт);
 * сбои сети — [IOException], не-2xx — [HttpStatusException]; отмена корутины не глотается.
 */
interface HttpSource {
    suspend fun <T> get(url: String, consume: suspend (HttpBody) -> T): T
}

/** Скачивает небольшой текстовый ответ (JSON) целиком; ответ больше [maxBytes] считается ошибкой. */
suspend fun HttpSource.getText(url: String, maxBytes: Int = 32 * 1024 * 1024): String =
    get(url) { body ->
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        while (true) {
            currentCoroutineContext().ensureActive()
            val n = body.stream.read(buffer)
            if (n < 0) break
            if (out.size() + n > maxBytes) throw IOException("Response is larger than $maxBytes bytes: $url")
            out.write(buffer, 0, n)
        }
        out.toString(Charsets.UTF_8.name())
    }
