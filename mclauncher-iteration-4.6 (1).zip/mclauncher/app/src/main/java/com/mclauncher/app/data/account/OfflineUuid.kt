package com.mclauncher.app.data.account

import java.util.UUID

/**
 * UUID оффлайн-игрока — ровно так его считает сама игра (`OfflinePlayer:<ник>`, UUID версии 3).
 * Благодаря этому миры, инвентарь и права на серверах в offline-режиме привязаны к нику и совпадают
 * с тем, что получилось бы при запуске ванильного клиента.
 * Регистр важен: «Steve» и «steve» — разные игроки.
 */
object OfflineUuid {

    fun forName(name: String): UUID =
        UUID.nameUUIDFromBytes("OfflinePlayer:$name".toByteArray(Charsets.UTF_8))
}
