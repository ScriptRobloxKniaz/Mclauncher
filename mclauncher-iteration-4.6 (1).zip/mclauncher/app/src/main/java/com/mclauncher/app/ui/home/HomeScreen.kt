package com.mclauncher.app.ui.home

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.BackgroundPreset
import com.mclauncher.app.data.settings.BackgroundSelection
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.common.SelectedVersionState
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.components.PlayButton
import com.mclauncher.app.ui.launch.playLabelRes
import com.mclauncher.app.ui.navigation.Destination

/**
 * Главный экран: кнопка «Играть» (стадии запуска показывает сама кнопка, итог — диалог в корне UI),
 * плашки аккаунта и выбранной версии, вторичные кнопки и вход в ИИ-помощника.
 */
@Composable
fun HomeScreen(
    activeAccount: ActiveAccountState,
    selectedVersion: SelectedVersionState,
    launchPhase: LaunchPhase,
    onPlay: () -> Unit,
    backgroundSelection: BackgroundSelection,
    customBackgroundPreview: ImageBitmap?,
    onSelectPreset: (BackgroundPreset) -> Unit,
    onPickCustomBackground: (Uri) -> Unit,
    onNavigate: (Destination) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var showBackgroundSheet by rememberSaveable { mutableStateOf(false) }

    // SAF: системный выбор картинки. Права на чтение действуют на один этот вызов — этого достаточно,
    // потому что картинка сразу копируется в хранилище приложения.
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            showBackgroundSheet = false
            onPickCustomBackground(uri)
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        // На низких экранах (телефон в landscape) делаем элементы компактнее.
        val compact = maxHeight < 440.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            HomeHeader(
                activeAccount = activeAccount,
                onOpenAccounts = { onNavigate(Destination.Accounts) },
                onChangeBackground = { showBackgroundSheet = true },
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                PlayButton(
                    label = stringResource(launchPhase.playLabelRes),
                    busy = launchPhase != LaunchPhase.IDLE,
                    onClick = {
                        when {
                            // Без аккаунта играть нельзя: объясняем и сразу ведём на экран аккаунтов.
                            activeAccount == ActiveAccountState.None -> {
                                Toast.makeText(context, R.string.play_need_account, Toast.LENGTH_SHORT).show()
                                onNavigate(Destination.Accounts)
                            }

                            // Без версии тоже нельзя: ведём на экран версий, где её можно установить.
                            selectedVersion == SelectedVersionState.None && activeAccount is ActiveAccountState.Selected -> {
                                Toast.makeText(context, R.string.play_need_version, Toast.LENGTH_SHORT).show()
                                onNavigate(Destination.Versions)
                            }

                            activeAccount is ActiveAccountState.Selected &&
                                selectedVersion is SelectedVersionState.Selected -> onPlay()

                            // Данные ещё читаются с диска — повторное нажатие сработает через мгновение.
                        }
                    },
                    height = if (compact) 88.dp else 116.dp,
                )
                VersionChip(state = selectedVersion, onClick = { onNavigate(Destination.Versions) })
            }

            Column(
                modifier = Modifier.widthIn(max = 560.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    val quickModifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                    val minHeight = if (compact) 68.dp else 84.dp
                    QuickAction(
                        icon = Destination.Accounts.icon,
                        label = stringResource(R.string.quick_accounts),
                        onClick = { onNavigate(Destination.Accounts) },
                        modifier = quickModifier,
                        minHeight = minHeight,
                    )
                    QuickAction(
                        icon = Destination.Skins.icon,
                        label = stringResource(R.string.quick_skins),
                        onClick = { onNavigate(Destination.Skins) },
                        modifier = quickModifier,
                        minHeight = minHeight,
                    )
                    QuickAction(
                        icon = Destination.Mods.icon,
                        label = stringResource(R.string.quick_mods),
                        onClick = { onNavigate(Destination.Mods) },
                        modifier = quickModifier,
                        minHeight = minHeight,
                    )
                    QuickAction(
                        icon = Destination.Settings.icon,
                        label = stringResource(R.string.quick_settings),
                        onClick = { onNavigate(Destination.Settings) },
                        modifier = quickModifier,
                        minHeight = minHeight,
                    )
                }
                AssistantCard(onClick = { onNavigate(Destination.Assistant) })
            }
        }
    }

    if (showBackgroundSheet) {
        BackgroundSheet(
            selection = backgroundSelection,
            customPreview = customBackgroundPreview,
            onSelectPreset = onSelectPreset,
            onPickFromGallery = { imagePicker.launch(arrayOf("image/*")) },
            onDismiss = { showBackgroundSheet = false },
        )
    }
}

@Composable
private fun HomeHeader(
    activeAccount: ActiveAccountState,
    onOpenAccounts: () -> Unit,
    onChangeBackground: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = stringResource(R.string.app_name),
                // Заголовок лежит прямо на картинке, поэтому белый с тенью — читается на любом фоне.
                style = MaterialTheme.typography.headlineSmall.merge(
                    TextStyle(
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        shadow = Shadow(color = Color(0x99000000), offset = Offset(0f, 2f), blurRadius = 8f),
                    ),
                ),
            )
            AccountChip(state = activeAccount, onClick = onOpenAccounts)
        }
        FilledTonalIconButton(
            onClick = onChangeBackground,
            colors = IconButtonDefaults.filledTonalIconButtonColors(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
            ),
        ) {
            Icon(
                imageVector = LauncherIcons.Image,
                contentDescription = stringResource(R.string.background_change),
            )
        }
    }
}
