package com.mclauncher.app.data.versions

import com.mclauncher.app.launch.GameDirectories
import java.io.File

/**
 * Где в `.minecraft` лежат файлы версии. Раскладка такая же, как у официального лаунчера, чтобы ядро игры
 * и пользовательские инструменты находили файлы там, где ждут:
 *
 * ```
 * versions/<id>/<id>.json, <id>.jar, mclauncher-install.json
 * libraries/<путь Maven>
 * assets/indexes/<имя набора>.json, assets/objects/<2 символа хэша>/<хэш>, assets/log_configs/<файл>
 * ```
 *
 * Методы, которые принимают данные из сети (путь библиотеки, хэш, имя файла), возвращают `null`, если значение
 * небезопасно, — вызывающий код превращает это в ошибку «повреждённые данные».
 */
class VersionLayout(private val directories: GameDirectories) {

    val root: File get() = directories.root

    private val versionsDir get() = directories.versions

    fun versionDir(id: String): File = File(versionsDir, id)
    fun versionJson(id: String): File = File(versionDir(id), "$id.json")
    fun clientJar(id: String): File = File(versionDir(id), "$id.jar")
    fun marker(id: String): File = File(versionDir(id), MARKER_NAME)

    fun versionsRoot(): File = versionsDir

    fun library(path: String): File? = SafePaths.resolveInside(directories.libraries, path)

    fun assetIndex(id: String): File? =
        if (SafePaths.isSafeName(id)) File(File(directories.assets, "indexes"), "$id.json") else null

    fun assetObject(hash: String): File? =
        if (SafePaths.isSha1(hash)) File(File(File(directories.assets, "objects"), hash.substring(0, 2)), hash) else null

    fun logConfig(fileId: String): File? =
        if (SafePaths.isSafeName(fileId)) File(File(directories.assets, "log_configs"), fileId) else null

    companion object {
        const val MARKER_NAME = "mclauncher-install.json"
    }
}
