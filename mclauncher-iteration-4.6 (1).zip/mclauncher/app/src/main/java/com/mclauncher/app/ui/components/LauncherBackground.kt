package com.mclauncher.app.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale

/**
 * Задний план всего приложения: пресет или картинка пользователя + затемняющая вуаль [scrim],
 * которая делает текст читаемым поверх любой картинки.
 */
@Composable
fun LauncherBackground(
    content: BackgroundContent,
    scrim: Color,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxSize()) {
        Crossfade(
            targetState = content,
            animationSpec = tween(durationMillis = 500),
            label = "launcherBackground",
        ) { target ->
            when (target) {
                is BackgroundContent.Preset -> PresetBackground(target.preset)
                is BackgroundContent.Image -> Image(
                    bitmap = target.bitmap,
                    contentDescription = null, // декоративный элемент
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(scrim),
        )
    }
}
