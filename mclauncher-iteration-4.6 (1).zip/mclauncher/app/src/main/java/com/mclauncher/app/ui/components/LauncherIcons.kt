package com.mclauncher.app.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Иконки, которых нет в material-icons-core. Нарисованы вручную,
 * чтобы не тащить тяжёлый material-icons-extended.
 */
object LauncherIcons {

    /** Четырёхлучевая «искра» — значок ИИ-помощника. */
    val Sparkle: ImageVector by lazy {
        ImageVector.Builder(
            name = "Sparkle",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f)
                lineTo(14.4f, 9.6f)
                lineTo(22f, 12f)
                lineTo(14.4f, 14.4f)
                lineTo(12f, 22f)
                lineTo(9.6f, 14.4f)
                lineTo(2f, 12f)
                lineTo(9.6f, 9.6f)
                close()
            }
        }.build()
    }

    /** Рамка с горами — «выбрать картинку/фон». */
    val Image: ImageVector by lazy {
        ImageVector.Builder(
            name = "Image",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            // Рамка: внешний прямоугольник минус внутренний (even-odd).
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
                moveTo(3f, 4f)
                lineTo(21f, 4f)
                lineTo(21f, 20f)
                lineTo(3f, 20f)
                close()
                moveTo(5f, 6f)
                lineTo(5f, 18f)
                lineTo(19f, 18f)
                lineTo(19f, 6f)
                close()
            }
            // Горы
            path(fill = SolidColor(Color.Black)) {
                moveTo(6.5f, 16.5f)
                lineTo(10f, 11f)
                lineTo(12.8f, 14.6f)
                lineTo(14.8f, 12.2f)
                lineTo(17.5f, 16.5f)
                close()
            }
        }.build()
    }

    /** Три строки с маркерами — список версий игры. */
    val Versions: ImageVector by lazy {
        ImageVector.Builder(
            name = "Versions",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(fill = SolidColor(Color.Black)) {
                for (top in listOf(4f, 10f, 16f)) {
                    // маркер
                    moveTo(3f, top)
                    lineTo(7f, top)
                    lineTo(7f, top + 4f)
                    lineTo(3f, top + 4f)
                    close()
                    // строка
                    moveTo(9f, top)
                    lineTo(21f, top)
                    lineTo(21f, top + 4f)
                    lineTo(9f, top + 4f)
                    close()
                }
            }
        }.build()
    }
}
