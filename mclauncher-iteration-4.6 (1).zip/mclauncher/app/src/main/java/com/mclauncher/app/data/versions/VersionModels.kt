package com.mclauncher.app.data.versions

/*
 * Модели описаний версий игры в том виде, в каком их отдаёт Mojang. Всё здесь — чистый Kotlin без Android:
 * разбор и планирование проверяются обычными JVM-тестами.
 *
 * ВАЖНО: формат полей написан по памяти и по общему устройству этих файлов; реальные образцы из этой среды
 * получить нельзя (хосты Mojang закрыты). Поэтому есть скрипт scripts/fetch_fixtures.py и тест
 * RealFixturesTest, которые проверяют разбор на настоящих файлах — см. docs/VERSION_INSTALLER.md.
 */

/** Тип версии из манифеста. [OTHER] — любой незнакомый, чтобы новый тип у Mojang не ломал список. */
enum class VersionType(val id: String) {
    RELEASE("release"),
    SNAPSHOT("snapshot"),
    OLD_BETA("old_beta"),
    OLD_ALPHA("old_alpha"),
    OTHER("");

    companion object {
        fun fromId(id: String?): VersionType = entries.firstOrNull { it != OTHER && it.id == id } ?: OTHER
    }
}

/** Строка `version_manifest_v2.json`: где лежит описание версии и его контрольная сумма. */
data class ManifestEntry(
    val id: String,
    val type: VersionType,
    val url: String,
    val sha1: String?,
    /** Дата выхода в формате ISO-8601 как в манифесте; сравнивать как строки нельзя, показывать — можно. */
    val releaseTime: String?,
)

data class VersionManifest(
    val latestRelease: String?,
    val latestSnapshot: String?,
    val versions: List<ManifestEntry>,
)

/**
 * Файл, который нужно скачать. [path] — относительный путь внутри хранилища (у библиотек);
 * [sha1] и [size] у очень старых описаний могут отсутствовать (тогда [size] ≤ 0).
 */
data class RemoteFile(
    val url: String,
    val sha1: String?,
    val size: Long,
    val path: String? = null,
)

enum class RuleAction { ALLOW, DISALLOW }

/** Условие по системе. Пустое поле — «любое». [version] — регулярное выражение. */
data class OsRule(val name: String?, val arch: String?, val version: String?)

/** Правило: действие применяется, если подходит система и совпадают все указанные признаки. */
data class Rule(
    val action: RuleAction,
    val os: OsRule?,
    val features: Map<String, Boolean>,
)

/**
 * Библиотека версии.
 *  - [artifact] — обычный jar, который идёт в classpath;
 *  - [natives] — «ОС → имя классификатора» у старых версий, [classifiers] — файлы этих классификаторов;
 *  - [extractExcludes] — что не распаковывать из нативного jar (например, `META-INF/`).
 */
data class Library(
    val name: String,
    val artifact: RemoteFile?,
    val classifiers: Map<String, RemoteFile>,
    val natives: Map<String, String>,
    val extractExcludes: List<String>,
    val rules: List<Rule>,
)

/** Аргумент запуска: [values] подставляются, только если [rules] разрешают. Шаблоны вида `${name}` не раскрываются здесь. */
data class Argument(val values: List<String>, val rules: List<Rule>)

/**
 * Аргументы JVM и игры. [legacy] = true — версия старого формата (`minecraftArguments`): в ней нет
 * аргументов JVM, их подставляет движок.
 */
data class LaunchArguments(
    val game: List<Argument>,
    val jvm: List<Argument>,
    val legacy: Boolean,
)

data class AssetIndexRef(
    val id: String,
    val url: String,
    val sha1: String?,
    val size: Long,
    /** Размер всех файлов ассетов вместе; 0, если не указан. */
    val totalSize: Long,
)

data class LoggingConfig(
    val argument: String,
    val file: RemoteFile,
    val fileId: String,
)

/** Нужная версия Java. У версий без этого поля это Java 8. */
data class JavaRequirement(val component: String?, val majorVersion: Int)

data class GameVersion(
    val id: String,
    val type: VersionType,
    val mainClass: String,
    /** Имя набора ассетов (`assets` в JSON): например `19`, `legacy`, `pre-1.6`. */
    val assets: String,
    val assetIndex: AssetIndexRef,
    val client: RemoteFile,
    val java: JavaRequirement,
    val libraries: List<Library>,
    val arguments: LaunchArguments,
    val logging: LoggingConfig?,
    /** Только у версий модлоадеров (Fabric, Forge): их установка — этап 7. */
    val inheritsFrom: String?,
    val releaseTime: String?,
)

data class AssetObject(val name: String, val hash: String, val size: Long)

data class AssetIndex(
    val objects: List<AssetObject>,
    /** Самые старые версии читают ассеты не по хэшам, а по именам из папки `virtual`. */
    val virtual: Boolean,
    /** Самые старые версии читают ассеты из папки `resources` внутри `.minecraft`. */
    val mapToResources: Boolean,
) {
    val totalSize: Long get() = objects.sumOf { it.size.coerceAtLeast(0) }
}
