package com.mclauncher.app.launch

import kotlinx.coroutines.delay

/**
 * Граница между лаунчером и ядром игры.
 *
 * Лаунчер (UI, аккаунты, папки, проверки) знает только этот интерфейс. Настоящая реализация
 * (`PojavGameEngine`) будет обёрткой над PojavLauncher: подготовка Java-рантайма и нативных библиотек,
 * запуск игрового процесса/Activity с передачей [LaunchRequest] через Intent. Писать JVM-эмулятор
 * или графический транслятор не нужно — они приходят из готового ядра.
 *
 * Контракт реализации:
 *  - тяжёлая работа — не в главном потоке (функция suspend, переключайте диспетчер сами);
 *  - ожидаемые сбои возвращать как [LaunchResult.Failed], а не бросать исключения;
 *  - [kotlinx.coroutines.CancellationException] не глотать.
 */
interface GameEngine {
    suspend fun launch(request: LaunchRequest): LaunchResult
}

/**
 * Временная заглушка вместо ядра: имитирует подготовку и всегда «успешно запускается»,
 * честно помечая результат как `placeholder = true`. Игра при этом НЕ стартует.
 */
class StubGameEngine(private val simulatedWorkMs: Long = 1_200L) : GameEngine {

    override suspend fun launch(request: LaunchRequest): LaunchResult {
        delay(simulatedWorkMs)
        return LaunchResult.Started(placeholder = true)
    }
}
