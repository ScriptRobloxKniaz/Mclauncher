package com.mclauncher.app.ui.common

import com.mclauncher.app.data.versions.InstalledVersion
import com.mclauncher.app.data.versions.VersionLibraryState

/**
 * Состояние «выбранной версии» для главного экрана. Как и у аккаунта, загрузка отдельно от «версии нет»,
 * чтобы подсказка «Выберите версию» не мигала, пока список читается с диска.
 */
sealed interface SelectedVersionState {
    data object Loading : SelectedVersionState
    data object None : SelectedVersionState
    data class Selected(val version: InstalledVersion) : SelectedVersionState
}

/** `null` — список с диска ещё не прочитан. Выбранной считается только реально установленная версия. */
fun VersionLibraryState?.toSelectedVersionState(): SelectedVersionState {
    if (this == null) return SelectedVersionState.Loading
    val chosen = selected ?: return SelectedVersionState.None
    return SelectedVersionState.Selected(chosen)
}
