package com.mclauncher.app.data.versions

/** Вкладки фильтра на экране версий. */
enum class VersionFilter {
    RELEASES,
    SNAPSHOTS,

    /** Старые беты и альфы (до релиза 1.0). */
    OLD;

    fun accepts(type: VersionType): Boolean = when (this) {
        RELEASES -> type == VersionType.RELEASE
        // Незнакомые типы, которые Mojang может добавить, показываем рядом со снапшотами — так они не пропадут.
        SNAPSHOTS -> type == VersionType.SNAPSHOT || type == VersionType.OTHER
        OLD -> type == VersionType.OLD_BETA || type == VersionType.OLD_ALPHA
    }
}

/** Что показать на экране версий: установленные и доступные для установки. */
data class VersionListing(
    val installed: List<InstalledVersion>,
    val available: List<ManifestEntry>,
) {
    companion object {
        val EMPTY = VersionListing(emptyList(), emptyList())
    }
}

/**
 * Собирает списки для экрана. Установленные видны всегда (даже без сети и вне зависимости от фильтра) и сужаются
 * только поиском; доступные — это версии из манифеста выбранного типа без уже установленных. Порядок сохраняется:
 * манифест Mojang отдаёт новые версии первыми, [installed] уже отсортирован магазином версий.
 */
fun buildListing(
    manifest: VersionManifest?,
    installed: List<InstalledVersion>,
    filter: VersionFilter,
    query: String,
): VersionListing {
    val needle = query.trim().lowercase()
    fun matches(id: String) = needle.isEmpty() || id.lowercase().contains(needle)

    val installedIds = installed.mapTo(HashSet()) { it.id }
    return VersionListing(
        installed = installed.filter { matches(it.id) },
        available = manifest?.versions.orEmpty().filter {
            it.id !in installedIds && filter.accepts(it.type) && matches(it.id)
        },
    )
}
