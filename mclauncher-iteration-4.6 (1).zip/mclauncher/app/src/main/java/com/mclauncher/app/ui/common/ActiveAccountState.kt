package com.mclauncher.app.ui.common

import com.mclauncher.app.data.account.Account

/** Состояние «текущего аккаунта» для главного экрана: загрузка отдельно от «аккаунта нет», чтобы не мигала подсказка. */
sealed interface ActiveAccountState {
    data object Loading : ActiveAccountState
    data object None : ActiveAccountState
    data class Selected(val account: Account) : ActiveAccountState
}
