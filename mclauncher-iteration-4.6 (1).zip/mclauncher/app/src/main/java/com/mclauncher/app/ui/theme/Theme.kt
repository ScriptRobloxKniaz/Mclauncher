package com.mclauncher.app.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// «Травяная» палитра: узнаваемо, но без копирования чужого брендинга.
private val DarkColors = darkColorScheme(
    primary = Color(0xFF8BD36B),
    onPrimary = Color(0xFF0F3A00),
    primaryContainer = Color(0xFF2F6B27),
    onPrimaryContainer = Color(0xFFB4F093),
    secondary = Color(0xFFBBCBB0),
    onSecondary = Color(0xFF263421),
    tertiary = Color(0xFFA0CFD3),
    background = Color(0xFF101411),
    onBackground = Color(0xFFE0E4DB),
    surface = Color(0xFF101411),
    onSurface = Color(0xFFE0E4DB),
    surfaceVariant = Color(0xFF424940),
    onSurfaceVariant = Color(0xFFC2C9BD),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF2F6B27),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFB4F093),
    onPrimaryContainer = Color(0xFF042100),
    secondary = Color(0xFF54624A),
    onSecondary = Color(0xFFFFFFFF),
    tertiary = Color(0xFF39666A),
    background = Color(0xFFF8FAF2),
    onBackground = Color(0xFF191D17),
    surface = Color(0xFFF8FAF2),
    onSurface = Color(0xFF191D17),
    surfaceVariant = Color(0xFFDEE5D8),
    onSurfaceVariant = Color(0xFF424940),
)

@Composable
fun MCLauncherTheme(
    // Пока всегда тёмная (см. MainActivity). Светлая схема готова для настройки темы в итерации 8.
    darkTheme: Boolean = true,
    // По умолчанию выключено, чтобы сохранить собственную палитру лаунчера.
    // Позже можно вынести в настройки.
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content,
    )
}
