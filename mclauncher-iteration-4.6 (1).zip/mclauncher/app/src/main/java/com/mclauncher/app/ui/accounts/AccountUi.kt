package com.mclauncher.app.ui.accounts

import androidx.annotation.StringRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.account.AccountType
import com.mclauncher.app.data.account.NameError
import com.mclauncher.app.data.skin.Face
import com.mclauncher.app.data.skin.SkinLayout
import kotlin.math.roundToInt

/** Онлайн-аккаунт — любой, кроме оффлайн. */
val AccountType.isOnline: Boolean
    get() = this != AccountType.OFFLINE

/** Подпись типа аккаунта; для онлайн-типов сразу видно, что это онлайн. */
@get:StringRes
val AccountType.labelRes: Int
    get() = when (this) {
        AccountType.OFFLINE -> R.string.account_type_offline
        AccountType.MICROSOFT -> R.string.account_type_microsoft
        AccountType.ELY_BY -> R.string.account_type_ely_by
    }

/** Понятный пользователю текст причины отказа. */
@get:StringRes
val NameError.messageRes: Int
    get() = when (this) {
        NameError.EMPTY -> R.string.name_error_empty
        NameError.TOO_SHORT -> R.string.name_error_too_short
        NameError.TOO_LONG -> R.string.name_error_too_long
        NameError.INVALID_CHARS -> R.string.name_error_invalid_chars
        NameError.DUPLICATE -> R.string.name_error_duplicate
    }

/**
 * Аватар аккаунта: если у аккаунта есть скин ([skin] — его текстура 64×64, см. `rememberSkinBitmap`),
 * то это «голова» скина (лицо и шляпа) в скруглённом квадрате; иначе — круг с первой буквой ника.
 */
@Composable
fun AccountAvatar(
    username: String,
    type: AccountType,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    skin: ImageBitmap? = null,
) {
    val colors = MaterialTheme.colorScheme
    val (container, content) = if (type.isOnline) {
        colors.tertiaryContainer to colors.onTertiaryContainer
    } else {
        colors.secondaryContainer to colors.onSecondaryContainer
    }
    Box(
        modifier = modifier
            .size(size)
            .clip(if (skin != null) RoundedCornerShape(size / 5) else CircleShape)
            .background(container),
        contentAlignment = Alignment.Center,
    ) {
        if (skin != null) {
            SkinHead(skin = skin, modifier = Modifier.fillMaxSize())
        } else {
            Text(
                text = username.firstOrNull()?.uppercase().orEmpty(),
                color = content,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

/** Лицо скина 8×8 и поверх него шляпа, растянутые на всю область без размытия. */
@Composable
private fun SkinHead(skin: ImageBitmap, modifier: Modifier = Modifier) {
    val face = SkinLayout.HEAD.face(Face.FRONT)
    val hat = SkinLayout.HAT.face(Face.FRONT)
    Canvas(modifier = modifier) {
        val target = IntSize(size.width.roundToInt(), size.height.roundToInt())
        for (part in listOf(face, hat)) {
            drawImage(
                image = skin,
                srcOffset = IntOffset(part.x, part.y),
                srcSize = IntSize(part.width, part.height),
                dstSize = target,
                filterQuality = FilterQuality.None,
            )
        }
    }
}
