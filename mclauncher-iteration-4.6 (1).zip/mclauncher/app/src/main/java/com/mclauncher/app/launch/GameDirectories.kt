package com.mclauncher.app.launch

import android.content.Context
import java.io.File
import java.io.IOException

/**
 * Папка игры `.minecraft` и её подпапки.
 *
 * Лежит в app-specific хранилище (`Android/data/<пакет>/files/.minecraft`): оно не требует разрешений
 * и работает со scoped storage на Android 11+. Моды, сборки и ресурспаки пользователя попадают сюда
 * копированием из SAF (итерация 7), а не прямым доступом к чужим папкам.
 *
 * Класс не зависит от Android (принимает [root]) — поэтому проверяется обычными JVM-тестами.
 */
class GameDirectories(val root: File) {

    val versions = File(root, "versions")
    val libraries = File(root, "libraries")
    val assets = File(root, "assets")
    val mods = File(root, "mods")
    val resourcePacks = File(root, "resourcepacks")
    val shaderPacks = File(root, "shaderpacks")
    val saves = File(root, "saves")
    val config = File(root, "config")
    val logs = File(root, "logs")

    /**
     * Создаёт недостающие папки (повторный вызов безопасен).
     * Работа с диском: вызывать вне главного потока.
     *
     * @throws IOException если папку нельзя создать или в неё нельзя писать
     */
    fun ensureCreated() {
        listOf(root, versions, libraries, assets, mods, resourcePacks, shaderPacks, saves, config, logs)
            .forEach { dir ->
                if (!dir.isDirectory && !dir.mkdirs() && !dir.isDirectory) {
                    throw IOException("Cannot create directory: ${dir.path}")
                }
            }
        if (!root.canWrite()) throw IOException("Game directory is not writable: ${root.path}")
    }

    companion object {
        const val DIR_NAME = ".minecraft"

        /** Внешнее app-specific хранилище, а если оно недоступно (нет карты/не смонтировано) — внутреннее. */
        fun forContext(context: Context): GameDirectories {
            val base = context.getExternalFilesDir(null) ?: context.filesDir
            return GameDirectories(File(base, DIR_NAME))
        }
    }
}
