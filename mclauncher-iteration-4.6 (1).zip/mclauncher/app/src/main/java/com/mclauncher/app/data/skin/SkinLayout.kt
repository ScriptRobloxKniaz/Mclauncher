package com.mclauncher.app.data.skin

/** Прямоугольник на текстуре скина, в пикселях. */
data class PixelRect(val x: Int, val y: Int, val width: Int, val height: Int) {
    val right: Int get() = x + width
    val bottom: Int get() = y + height

    fun intersects(other: PixelRect): Boolean =
        x < other.right && other.x < right && y < other.bottom && other.y < bottom
}

/** Грани «коробки» части тела. */
enum class Face { TOP, BOTTOM, RIGHT, FRONT, LEFT, BACK }

/**
 * Часть тела как коробка размером [width]×[height]×[depth] с «развёрткой», начинающейся в ([u], [v]).
 * Развёртка у всех частей скина одинакова (так устроены коробки в модели игрока):
 *
 * ```
 *           u+d        u+d+w
 *   v      ┌─────┬─────┐
 *          │ TOP │ BOT │            d = depth, w = width, h = height
 *   v+d ┌──┼─────┼─────┼─────┐
 *       │R │FRONT│ LEFT│BACK │
 *       └──┴─────┴─────┴─────┘
 *      u   u+d   u+d+w  u+2d+w
 * ```
 *
 * «Правый/левый» — со стороны самого персонажа, а не зрителя.
 */
data class SkinBox(
    val u: Int,
    val v: Int,
    val width: Int,
    val height: Int,
    val depth: Int,
) {
    fun face(face: Face): PixelRect = when (face) {
        Face.TOP -> PixelRect(u + depth, v, width, depth)
        Face.BOTTOM -> PixelRect(u + depth + width, v, width, depth)
        Face.RIGHT -> PixelRect(u, v + depth, depth, height)
        Face.FRONT -> PixelRect(u + depth, v + depth, width, height)
        Face.LEFT -> PixelRect(u + depth + width, v + depth, depth, height)
        Face.BACK -> PixelRect(u + depth + width + depth, v + depth, width, height)
    }

    /** Все шесть граней — то, что занимает коробка на текстуре. */
    val faces: List<PixelRect> get() = Face.entries.map(::face)
}

enum class ViewSide { FRONT, BACK }

/**
 * Кусок текстуры, который рисуется в превью в клетке ([destX], [destY]) сетки 16×32 «пикселей скина».
 * Размер на экране равен размеру [source]. [isOverlay] — второй слой (шляпа, куртка, рукава, штаны).
 */
data class PreviewPart(
    val source: PixelRect,
    val destX: Int,
    val destY: Int,
    val isOverlay: Boolean,
)

/**
 * Раскладка текстуры скина 64×64. Координаты не записаны числами, а получаются из коробок
 * ([SkinBox]) — так их проще проверить и сложнее ошибиться.
 */
object SkinLayout {
    const val TEXTURE_WIDTH = 64
    const val TEXTURE_HEIGHT = 64

    /** Старый формат скина: только верхняя половина текстуры. */
    const val LEGACY_TEXTURE_HEIGHT = 32

    /** Размер сетки превью: игрок 16 пикселей в ширину (с руками) и 32 в высоту. */
    const val PREVIEW_WIDTH = 16
    const val PREVIEW_HEIGHT = 32

    fun isSupportedSize(width: Int, height: Int): Boolean =
        width == TEXTURE_WIDTH && (height == TEXTURE_HEIGHT || height == LEGACY_TEXTURE_HEIGHT)

    fun armWidth(model: SkinModel): Int = if (model == SkinModel.SLIM) 3 else 4

    // ---- Первый слой ----------------------------------------------------------------------
    val HEAD = SkinBox(u = 0, v = 0, width = 8, height = 8, depth = 8)
    val BODY = SkinBox(u = 16, v = 16, width = 8, height = 12, depth = 4)
    val RIGHT_LEG = SkinBox(u = 0, v = 16, width = 4, height = 12, depth = 4)
    val LEFT_LEG = SkinBox(u = 16, v = 48, width = 4, height = 12, depth = 4)
    fun rightArm(model: SkinModel) = SkinBox(u = 40, v = 16, width = armWidth(model), height = 12, depth = 4)
    fun leftArm(model: SkinModel) = SkinBox(u = 32, v = 48, width = armWidth(model), height = 12, depth = 4)

    // ---- Второй слой (в старых скинах только шляпа) -----------------------------------------
    val HAT = SkinBox(u = 32, v = 0, width = 8, height = 8, depth = 8)
    val JACKET = SkinBox(u = 16, v = 32, width = 8, height = 12, depth = 4)
    val RIGHT_PANTS = SkinBox(u = 0, v = 32, width = 4, height = 12, depth = 4)
    val LEFT_PANTS = SkinBox(u = 0, v = 48, width = 4, height = 12, depth = 4)
    fun rightSleeve(model: SkinModel) = SkinBox(u = 40, v = 32, width = armWidth(model), height = 12, depth = 4)
    fun leftSleeve(model: SkinModel) = SkinBox(u = 48, v = 48, width = armWidth(model), height = 12, depth = 4)

    /**
     * Участки текстуры, которые есть у широких рук, но которых нет у тонких (у тонких рук грани уже на
     * пиксель, и всё лишнее остаётся пустым). Если все четыре участка полностью прозрачны — скин тонкий.
     * Тест `SkinLayoutTest` выводит эти участки из коробок, чтобы числа здесь нельзя было записать неверно.
     */
    val SLIM_UNUSED_REGIONS: List<PixelRect> = listOf(
        PixelRect(x = 50, y = 16, width = 2, height = 4), // правая рука: верх/низ
        PixelRect(x = 54, y = 20, width = 2, height = 12), // правая рука: стороны
        PixelRect(x = 42, y = 48, width = 2, height = 4), // левая рука: верх/низ
        PixelRect(x = 46, y = 52, width = 2, height = 12), // левая рука: стороны
    )

    private class Slot(val base: SkinBox, val overlay: SkinBox, val destX: Int, val destY: Int)

    /**
     * Что и куда рисовать для вида спереди/сзади: сначала весь первый слой, затем весь второй.
     * Сзади правая рука оказывается справа от зрителя, левая — слева.
     */
    fun previewParts(side: ViewSide, model: SkinModel): List<PreviewPart> {
        val armW = armWidth(model)
        val face = if (side == ViewSide.FRONT) Face.FRONT else Face.BACK

        // destX у рук и ног здесь условный (0): настоящий x выставляет at() в зависимости от вида.
        val headSlot = Slot(HEAD, HAT, destX = 4, destY = 0)
        val bodySlot = Slot(BODY, JACKET, destX = 4, destY = 8)
        val rightArmSlot = Slot(rightArm(model), rightSleeve(model), destX = 0, destY = 8)
        val leftArmSlot = Slot(leftArm(model), leftSleeve(model), destX = 0, destY = 8)
        val rightLegSlot = Slot(RIGHT_LEG, RIGHT_PANTS, destX = 0, destY = 20)
        val leftLegSlot = Slot(LEFT_LEG, LEFT_PANTS, destX = 0, destY = 20)

        // Руки прижаты к телу (тело занимает клетки 4..11), поэтому тонкая рука начинается на пиксель правее.
        val viewerLeftArmX = 4 - armW
        val viewerRightArmX = 12

        val slots = if (side == ViewSide.FRONT) {
            listOf(
                headSlot, bodySlot,
                rightArmSlot.at(viewerLeftArmX), leftArmSlot.at(viewerRightArmX),
                rightLegSlot.at(4), leftLegSlot.at(8),
            )
        } else {
            listOf(
                headSlot, bodySlot,
                leftArmSlot.at(viewerLeftArmX), rightArmSlot.at(viewerRightArmX),
                leftLegSlot.at(4), rightLegSlot.at(8),
            )
        }

        return slots.map { PreviewPart(it.base.face(face), it.destX, it.destY, isOverlay = false) } +
            slots.map { PreviewPart(it.overlay.face(face), it.destX, it.destY, isOverlay = true) }
    }

    private fun Slot.at(x: Int) = Slot(base, overlay, x, destY)
}
