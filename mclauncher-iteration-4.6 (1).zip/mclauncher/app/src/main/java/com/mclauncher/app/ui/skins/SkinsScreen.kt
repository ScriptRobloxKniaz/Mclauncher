package com.mclauncher.app.ui.skins

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Face
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mclauncher.app.R
import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.skin.SkinModel
import com.mclauncher.app.ui.accounts.isOnline
import com.mclauncher.app.ui.accounts.labelRes
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.common.CollectUiEvents
import com.mclauncher.app.ui.components.LauncherIcons

/**
 * Экран «Скины»: PNG выбирается через системное окно (SAF), показывается мини-рендер спереди и сзади,
 * модель рук определяется автоматически и переключается вручную.
 */
@Composable
fun SkinsScreen(
    onOpenAccounts: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: SkinsViewModel = viewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    // Храним id аккаунта, для которого открыт диалог: при смене аккаунта диалог сам исчезает.
    var confirmRemoveForId by rememberSaveable { mutableStateOf<Long?>(null) }

    CollectUiEvents(viewModel.events)

    // Системный выбор файла. Адрес читается сразу и один раз, поэтому постоянные права на него не нужны.
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.onSkinPicked(uri)
    }

    Box(modifier = modifier.fillMaxSize()) {
        when (val account = state.account) {
            ActiveAccountState.Loading -> Unit
            ActiveAccountState.None -> NoAccount(onOpenAccounts = onOpenAccounts)
            is ActiveAccountState.Selected -> SkinsContent(
                account = account.account,
                preview = state.preview,
                busy = state.busy,
                // Не только PNG: так в списке видны и файлы с неверным типом, а неподходящий формат
                // получит понятное сообщение, а не «пустой» выбор.
                onPick = { picker.launch(arrayOf("image/*")) },
                onModelChange = viewModel::setModel,
                onRemove = { confirmRemoveForId = account.account.id },
            )
        }
    }

    val selected = (state.account as? ActiveAccountState.Selected)?.account
    if (selected != null && selected.id == confirmRemoveForId) {
        RemoveSkinDialog(
            account = selected,
            onConfirm = {
                confirmRemoveForId = null
                viewModel.removeSkin()
            },
            onDismiss = { confirmRemoveForId = null },
        )
    }
}

@Composable
private fun SkinsContent(
    account: Account,
    preview: SkinPreviewState,
    busy: Boolean,
    onPick: () -> Unit,
    onModelChange: (SkinModel) -> Unit,
    onRemove: () -> Unit,
) {
    BoxWithConstraints(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        // Широкий экран (телефон в landscape, планшет): превью слева, управление справа.
        val sideBySide = maxWidth >= 600.dp && maxWidth > maxHeight
        val hasSkin = account.skin != null
        val model = account.skin?.model ?: SkinModel.WIDE
        val bitmap = (preview as? SkinPreviewState.Ready)?.bitmap

        if (sideBySide) {
            Row(
                modifier = Modifier
                    .widthIn(max = 920.dp)
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                PreviewCard(
                    skin = bitmap,
                    model = model,
                    hasSkin = hasSkin,
                    viewHeight = (maxHeight - 96.dp).coerceIn(160.dp, 320.dp),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                )
                SkinControls(
                    account = account,
                    preview = preview,
                    busy = busy,
                    onPick = onPick,
                    onModelChange = onModelChange,
                    onRemove = onRemove,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState()),
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                PreviewCard(
                    skin = bitmap,
                    model = model,
                    hasSkin = hasSkin,
                    viewHeight = 240.dp,
                    modifier = Modifier.fillMaxWidth(),
                )
                SkinControls(
                    account = account,
                    preview = preview,
                    busy = busy,
                    onPick = onPick,
                    onModelChange = onModelChange,
                    onRemove = onRemove,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun PreviewCard(
    skin: ImageBitmap?,
    model: SkinModel,
    hasSkin: Boolean,
    viewHeight: Dp,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
        tonalElevation = 2.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        ) {
            SkinPreview(skin = skin, model = model, viewHeight = viewHeight)
            if (!hasSkin) {
                Text(
                    text = stringResource(R.string.skins_empty_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun SkinControls(
    account: Account,
    preview: SkinPreviewState,
    busy: Boolean,
    onPick: () -> Unit,
    onModelChange: (SkinModel) -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val hasSkin = account.skin != null
    val model = account.skin?.model ?: SkinModel.WIDE

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = stringResource(R.string.skins_title),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
        )
        Column {
            Text(
                text = stringResource(R.string.skins_for_account, account.username),
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                text = stringResource(account.type.labelRes),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (account.type.isOnline) {
            // У онлайн-аккаунта скин хранится на серверах Mojang — менять его локально бессмысленно.
            NoteCard(text = stringResource(R.string.skins_online_note))
        } else {
            if (preview is SkinPreviewState.Missing) {
                Text(
                    text = stringResource(R.string.skins_missing_file),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            Text(
                text = stringResource(R.string.skins_model_title),
                style = MaterialTheme.typography.titleSmall,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SkinModel.entries.forEach { option ->
                    FilterChip(
                        selected = model == option,
                        onClick = { onModelChange(option) },
                        enabled = hasSkin && !busy,
                        label = { Text(stringResource(option.labelRes)) },
                    )
                }
            }
            Text(
                text = stringResource(R.string.skins_model_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Button(
                onClick = onPick,
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(LauncherIcons.Image, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(8.dp))
                Text(stringResource(R.string.skins_pick))
            }
            OutlinedButton(
                onClick = onRemove,
                enabled = hasSkin && !busy,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Filled.Delete, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(8.dp))
                Text(stringResource(R.string.skins_remove))
            }
            if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

            Text(
                text = stringResource(R.string.skins_format_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            NoteCard(text = stringResource(R.string.skins_offline_note))
        }
    }
}

@Composable
private fun NoteCard(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(14.dp),
        )
    }
}

@Composable
private fun NoAccount(onOpenAccounts: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f),
            tonalElevation = 2.dp,
            modifier = Modifier.widthIn(max = 420.dp),
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Face,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(48.dp),
                )
                Text(
                    text = stringResource(R.string.skins_no_account_title),
                    style = MaterialTheme.typography.headlineSmall,
                    textAlign = TextAlign.Center,
                )
                Text(
                    text = stringResource(R.string.skins_no_account_message),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
                Button(onClick = onOpenAccounts) { Text(stringResource(R.string.skins_open_accounts)) }
            }
        }
    }
}

@Composable
private fun RemoveSkinDialog(
    account: Account,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.skins_remove_title)) },
        text = { Text(stringResource(R.string.skins_remove_message, account.username)) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(
                    text = stringResource(R.string.skins_remove),
                    color = MaterialTheme.colorScheme.error,
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}
