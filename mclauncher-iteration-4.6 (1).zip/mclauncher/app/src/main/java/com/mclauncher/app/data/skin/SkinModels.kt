package com.mclauncher.app.data.skin

/**
 * Модель рук игрока: [WIDE] — классическая (руки 4 пикселя, «Steve»), [SLIM] — тонкая (3 пикселя, «Alex»).
 * Имя константы хранится в базе как текст — переименовывать нельзя без миграции.
 */
enum class SkinModel { WIDE, SLIM }

/** Скин, сохранённый для аккаунта. [updatedAt] меняется при каждой замене файла — по нему обновляется превью. */
data class SkinInfo(
    val model: SkinModel,
    val updatedAt: Long,
)

/** Почему скин не принят или не сохранён. Тексты — в strings.xml (см. `SkinError.messageRes`). */
enum class SkinError {
    /** Файл не PNG (или повреждён так, что даже заголовка нет). */
    NOT_PNG,

    /** PNG, но размер не 64×64 и не 64×32. */
    WRONG_SIZE,

    /** Файл больше [SkinValidator.MAX_BYTES]. */
    TOO_LARGE,

    /** Не удалось прочитать или декодировать файл. */
    UNREADABLE,

    /** Не удалось записать скин в хранилище приложения (диск, права). */
    STORAGE,

    /** Аккаунт удалили, пока скин импортировался. */
    ACCOUNT_MISSING,
}

sealed interface SkinImportResult {
    data class Saved(val model: SkinModel) : SkinImportResult
    data class Rejected(val error: SkinError) : SkinImportResult
}
