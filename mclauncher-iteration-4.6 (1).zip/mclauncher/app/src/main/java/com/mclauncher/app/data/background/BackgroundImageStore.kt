package com.mclauncher.app.data.background

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import androidx.annotation.RequiresApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Свой фон пользователя.
 *
 * Картинку из галереи (SAF, ACTION_OPEN_DOCUMENT) мы один раз читаем, уменьшаем
 * и сохраняем копией в приватную папку приложения. Поэтому:
 *  - не нужны постоянные URI-разрешения и нет их лимита;
 *  - фон не пропадёт, если файл удалят из галереи;
 *  - при каждом запуске читается уже уменьшенный JPEG, а не оригинал на 12 Мп.
 *
 * Все методы работают на Dispatchers.IO и бросают [IOException] или [SecurityException].
 * На Android 8.0–8.1 EXIF-поворот не применяется (ImageDecoder есть только с Android 9).
 */
class BackgroundImageStore(context: Context) {

    private val appContext = context.applicationContext
    private val dir get() = File(appContext.filesDir, "backgrounds")
    private val file get() = File(dir, FILE_NAME)

    /** Читает картинку по [uri], уменьшает до [MAX_SIDE] px и атомарно заменяет сохранённый фон. */
    suspend fun importFrom(uri: Uri) {
        withContext(Dispatchers.IO) {
            val bitmap = decodeScaled(uri)
            try {
                dir.mkdirs()
                val tmp = File(dir, "$FILE_NAME.tmp")
                tmp.outputStream().use { out ->
                    if (!bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)) {
                        throw IOException("Failed to compress the background image")
                    }
                }
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
            } finally {
                bitmap.recycle()
            }
        }
    }

    /** Загружает сохранённый фон; бросает [IOException], если файла нет или он повреждён. */
    suspend fun load(): Bitmap = withContext(Dispatchers.IO) {
        BitmapFactory.decodeFile(file.path) ?: throw IOException("Background file is missing or corrupted")
    }

    suspend fun delete() {
        withContext(Dispatchers.IO) { file.delete() }
    }

    private fun decodeScaled(uri: Uri): Bitmap =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) decodeWithImageDecoder(uri) else decodeWithBitmapFactory(uri)

    @RequiresApi(Build.VERSION_CODES.P)
    private fun decodeWithImageDecoder(uri: Uri): Bitmap {
        val source = ImageDecoder.createSource(appContext.contentResolver, uri)
        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            val width = info.size.width
            val height = info.size.height
            val longest = max(width, height)
            if (longest > MAX_SIDE) {
                val scale = MAX_SIDE.toFloat() / longest
                decoder.setTargetSize(
                    (width * scale).roundToInt().coerceAtLeast(1),
                    (height * scale).roundToInt().coerceAtLeast(1),
                )
            }
            // Программный буфер: его можно сжать в JPEG (аппаратный — нельзя).
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    }

    private fun decodeWithBitmapFactory(uri: Uri): Bitmap {
        val resolver = appContext.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsStream = resolver.openInputStream(uri) ?: throw FileNotFoundException(uri.toString())
        boundsStream.use { BitmapFactory.decodeStream(it, null, bounds) }

        val longest = max(bounds.outWidth, bounds.outHeight)
        if (longest <= 0) throw IOException("The file is not a decodable image")

        var sample = 1
        while (longest / (sample * 2) >= MAX_SIDE) sample *= 2

        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val stream = resolver.openInputStream(uri) ?: throw FileNotFoundException(uri.toString())
        return stream.use { BitmapFactory.decodeStream(it, null, options) }
            ?: throw IOException("Failed to decode the image")
    }

    private companion object {
        const val FILE_NAME = "custom.jpg"
        const val MAX_SIDE = 2048
        const val JPEG_QUALITY = 90
    }
}
