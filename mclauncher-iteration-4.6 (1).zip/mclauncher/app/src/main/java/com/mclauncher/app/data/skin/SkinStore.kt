package com.mclauncher.app.data.skin

import android.content.Context
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Файлы скинов во внутреннем хранилище приложения: `files/skins/<id аккаунта>.png`.
 * Хранится исходный PNG пользователя без перекодирования — так полупрозрачные пиксели не теряют цвет.
 *
 * Все методы блокирующие: вызывать только вне главного потока.
 */
class SkinStore(private val context: Context) {

    private val directory: File get() = File(context.filesDir, DIRECTORY)

    fun fileFor(accountId: Long): File = File(directory, "$accountId.png")

    /** Записывает скин через временный файл, чтобы при сбое не остался обрезанный PNG. */
    @Throws(IOException::class)
    fun write(accountId: Long, bytes: ByteArray) {
        val dir = directory
        if (!dir.isDirectory && !dir.mkdirs() && !dir.isDirectory) {
            throw IOException("Cannot create ${dir.path}")
        }
        val target = fileFor(accountId)
        val temp = File(dir, "$accountId.png.tmp")
        try {
            temp.writeBytes(bytes)
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        } finally {
            temp.delete() // после успешного переноса файла уже нет — delete() просто вернёт false
        }
    }

    /** Байты скина или `null`, если файла нет или его не удалось прочитать. */
    fun read(accountId: Long): ByteArray? {
        val file = fileFor(accountId)
        return try {
            if (file.isFile) file.readBytes() else null
        } catch (e: IOException) {
            null
        }
    }

    fun delete(accountId: Long) {
        fileFor(accountId).delete()
    }

    private companion object {
        const val DIRECTORY = "skins"
    }
}
