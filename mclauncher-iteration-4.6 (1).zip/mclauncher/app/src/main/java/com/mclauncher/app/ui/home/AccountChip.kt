package com.mclauncher.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.account.Account
import com.mclauncher.app.ui.accounts.AccountAvatar
import com.mclauncher.app.ui.accounts.isOnline
import com.mclauncher.app.ui.accounts.labelRes
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.skins.rememberSkinBitmap

internal val ChipHeight = 48.dp
private val OnlineDot = Color(0xFF58D26B)
private val OfflineDot = Color(0xFFF2B84B)

/**
 * Плашка текущего аккаунта на главном экране: ник и тип (online/offline).
 * Если аккаунта нет — подсказка «Добавить аккаунт». Нажатие открывает экран аккаунтов.
 */
@Composable
fun AccountChip(
    state: ActiveAccountState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    when (state) {
        // Резервируем высоту, чтобы макет не «прыгал», когда база ответит.
        ActiveAccountState.Loading -> Spacer(modifier.height(ChipHeight))

        ActiveAccountState.None -> ChipSurface(
            onClick = onClick,
            container = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.94f),
            modifier = modifier,
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(22.dp),
            )
            Text(
                text = stringResource(R.string.home_add_account),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
        }

        is ActiveAccountState.Selected -> AccountChipSelected(state.account, onClick, modifier)
    }
}

@Composable
private fun AccountChipSelected(
    account: Account,
    onClick: () -> Unit,
    modifier: Modifier,
) {
    ChipSurface(
        onClick = onClick,
        container = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f),
        modifier = modifier,
    ) {
        AccountAvatar(
            username = account.username,
            type = account.type,
            size = 32.dp,
            skin = rememberSkinBitmap(account),
        )
        Column(modifier = Modifier.widthIn(max = 180.dp)) {
            Text(
                text = account.username,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                Spacer(
                    Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(if (account.type.isOnline) OnlineDot else OfflineDot),
                )
                Text(
                    text = stringResource(account.type.labelRes),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

/** Общая «таблетка» для плашек на главном экране (аккаунт, версия). */
@Composable
internal fun ChipSurface(
    onClick: () -> Unit,
    container: Color,
    modifier: Modifier,
    content: @Composable () -> Unit,
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(ChipHeight),
        shape = RoundedCornerShape(50),
        color = container,
        shadowElevation = 4.dp,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            content()
        }
    }
}
