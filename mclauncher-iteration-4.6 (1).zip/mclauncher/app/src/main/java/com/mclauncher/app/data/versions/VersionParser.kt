package com.mclauncher.app.data.versions

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.longOrNull

/** Файл не похож на ожидаемый JSON Mojang. [message] — для логов, пользователю показывается общий текст. */
class VersionParseException(message: String, cause: Throwable? = null) : Exception(message, cause)

/**
 * Разбор JSON Mojang вручную по дереву `JsonElement`: поля у разных версий игры то есть, то нет, а элементы
 * `arguments` бывают строкой или объектом, поэтому мягкий разбор надёжнее, чем жёсткие классы.
 * Обязательны только поля, без которых версию нельзя установить; всё остальное необязательно.
 *
 * Чистый Kotlin без Android — проверяется JVM-тестами. Формат полей написан по памяти; проверка на настоящих файлах —
 * `scripts/fetch_fixtures.py` и `RealFixturesTest` (см. docs/VERSION_INSTALLER.md).
 */
object VersionParser {

    private const val LIBRARIES_BASE = "https://libraries.minecraft.net/"

    fun parseManifest(text: String): VersionManifest {
        val root = parseObject(text, "version manifest")
        val versions = root.arr("versions") ?: throw VersionParseException("Manifest has no 'versions' array")
        val latest = root.obj("latest")
        return VersionManifest(
            latestRelease = latest?.str("release"),
            latestSnapshot = latest?.str("snapshot"),
            versions = versions.mapNotNull { (it as? JsonObject)?.let(::parseEntry) },
        )
    }

    private fun parseEntry(o: JsonObject): ManifestEntry? {
        val id = o.str("id") ?: return null
        val url = o.str("url") ?: return null
        return ManifestEntry(
            id = id,
            type = VersionType.fromId(o.str("type")),
            url = url,
            sha1 = o.str("sha1"),
            releaseTime = o.str("releaseTime"),
        )
    }

    fun parseVersion(text: String): GameVersion {
        val o = parseObject(text, "version")
        val id = o.str("id") ?: throw VersionParseException("Version has no 'id'")
        val mainClass = o.str("mainClass") ?: throw VersionParseException("Version $id has no 'mainClass'")

        val assetIndexObject = o.obj("assetIndex") ?: throw VersionParseException("Version $id has no 'assetIndex'")
        val assetIndexId = assetIndexObject.str("id") ?: o.str("assets")
            ?: throw VersionParseException("Version $id: asset index has no 'id'")
        val assetIndex = AssetIndexRef(
            id = assetIndexId,
            url = assetIndexObject.str("url") ?: throw VersionParseException("Version $id: asset index has no 'url'"),
            sha1 = assetIndexObject.str("sha1"),
            size = assetIndexObject.long("size") ?: 0L,
            totalSize = assetIndexObject.long("totalSize") ?: 0L,
        )

        val clientObject = o.obj("downloads")?.obj("client")
            ?: throw VersionParseException("Version $id has no client download")
        val client = parseRemoteFile(clientObject)
            ?: throw VersionParseException("Version $id: client download has no 'url'")

        val java = o.obj("javaVersion")?.let {
            JavaRequirement(component = it.str("component"), majorVersion = it.int("majorVersion") ?: 8)
        } ?: JavaRequirement(component = null, majorVersion = 8)

        return GameVersion(
            id = id,
            type = VersionType.fromId(o.str("type")),
            mainClass = mainClass,
            assets = o.str("assets") ?: assetIndexId,
            assetIndex = assetIndex,
            client = client,
            java = java,
            libraries = o.arr("libraries").orEmpty().mapNotNull { (it as? JsonObject)?.let(::parseLibrary) },
            arguments = parseArguments(o, id),
            logging = parseLogging(o.obj("logging")?.obj("client")),
            inheritsFrom = o.str("inheritsFrom"),
            releaseTime = o.str("releaseTime"),
        )
    }

    fun parseAssetIndex(text: String): AssetIndex {
        val o = parseObject(text, "asset index")
        val objects = o.obj("objects") ?: throw VersionParseException("Asset index has no 'objects'")
        return AssetIndex(
            objects = objects.mapNotNull { (name, value) ->
                val item = value as? JsonObject ?: return@mapNotNull null
                val hash = item.str("hash") ?: return@mapNotNull null
                AssetObject(name = name, hash = hash, size = item.long("size") ?: 0L)
            },
            virtual = o.bool("virtual") ?: false,
            mapToResources = o.bool("map_to_resources") ?: false,
        )
    }

    // ---- Части описания версии ------------------------------------------------------------

    private fun parseLibrary(o: JsonObject): Library? {
        val name = o.str("name") ?: return null
        val downloads = o.obj("downloads")
        val natives = o.obj("natives")?.mapNotNull { (os, classifier) ->
            classifier.stringOrNull()?.let { os to it }
        }?.toMap().orEmpty()

        val classifiers = downloads?.obj("classifiers")?.mapNotNull { (key, value) ->
            (value as? JsonObject)?.let(::parseRemoteFile)?.let { key to it }
        }?.toMap().orEmpty()

        var artifact = downloads?.obj("artifact")?.let(::parseRemoteFile)
        // Очень старые описания (например, 1.7.x) не содержат `downloads`: адрес выводится из Maven-имени.
        if (artifact == null && downloads == null && natives.isEmpty()) {
            artifact = derivedArtifact(name, o.str("url"))
        }
        return Library(
            name = name,
            artifact = artifact,
            classifiers = classifiers,
            natives = natives,
            extractExcludes = o.obj("extract")?.arr("exclude").orEmpty().mapNotNull { it.stringOrNull() },
            rules = parseRules(o.arr("rules")),
        )
    }

    /** `group:artifact:version[:classifier][@ext]` → путь Maven и адрес на [LIBRARIES_BASE] или указанном `url`. */
    private fun derivedArtifact(name: String, baseUrl: String?): RemoteFile? {
        val ext = if ('@' in name) name.substringAfter('@') else "jar"
        val parts = name.substringBefore('@').split(':')
        if (parts.size < 3 || parts.any { it.isEmpty() }) return null
        val (group, artifact, version) = parts
        val classifier = parts.getOrNull(3)
        val fileName = buildString {
            append(artifact).append('-').append(version)
            if (classifier != null) append('-').append(classifier)
            append('.').append(ext)
        }
        val path = "${group.replace('.', '/')}/$artifact/$version/$fileName"
        val base = (baseUrl ?: LIBRARIES_BASE).let { if (it.endsWith("/")) it else "$it/" }
        return RemoteFile(url = base + path, sha1 = null, size = 0L, path = path)
    }

    private fun parseRemoteFile(o: JsonObject): RemoteFile? {
        val url = o.str("url")?.takeIf { it.isNotBlank() } ?: return null
        return RemoteFile(url = url, sha1 = o.str("sha1"), size = o.long("size") ?: 0L, path = o.str("path"))
    }

    private fun parseLogging(o: JsonObject?): LoggingConfig? {
        o ?: return null
        val file = o.obj("file") ?: return null
        val remote = parseRemoteFile(file) ?: return null
        val fileId = file.str("id") ?: return null
        val argument = o.str("argument") ?: return null
        return LoggingConfig(argument = argument, file = remote, fileId = fileId)
    }

    private fun parseRules(array: JsonArray?): List<Rule> = array.orEmpty().mapNotNull { element ->
        val o = element as? JsonObject ?: return@mapNotNull null
        val action = when (o.str("action")) {
            "allow" -> RuleAction.ALLOW
            "disallow" -> RuleAction.DISALLOW
            else -> return@mapNotNull null // неизвестное действие: лучше не применять правило, чем применить неверно
        }
        val os = o.obj("os")?.let { OsRule(name = it.str("name"), arch = it.str("arch"), version = it.str("version")) }
        val features = o.obj("features")?.mapNotNull { (key, value) ->
            (value as? JsonPrimitive)?.takeIf { !it.isString }?.booleanOrNull?.let { key to it }
        }?.toMap().orEmpty()
        Rule(action, os, features)
    }

    private fun parseArguments(o: JsonObject, id: String): LaunchArguments {
        val modern = o.obj("arguments")
        if (modern != null) {
            return LaunchArguments(
                game = parseArgumentList(modern.arr("game")),
                jvm = parseArgumentList(modern.arr("jvm")),
                legacy = false,
            )
        }
        val legacy = o.str("minecraftArguments")
            ?: throw VersionParseException("Version $id has neither 'arguments' nor 'minecraftArguments'")
        return LaunchArguments(
            game = legacy.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.map { Argument(listOf(it), emptyList()) },
            jvm = emptyList(),
            legacy = true,
        )
    }

    private fun parseArgumentList(array: JsonArray?): List<Argument> = array.orEmpty().mapNotNull { element ->
        when (element) {
            is JsonPrimitive -> if (element.isString) Argument(listOf(element.content), emptyList()) else null
            is JsonObject -> {
                val values = when (val value = element["value"]) {
                    is JsonPrimitive -> if (value.isString) listOf(value.content) else emptyList()
                    is JsonArray -> value.mapNotNull { it.stringOrNull() }
                    else -> emptyList()
                }
                if (values.isEmpty()) null else Argument(values, parseRules(element.arr("rules")))
            }
            else -> null
        }
    }

    // ---- Помощники над деревом JSON -------------------------------------------------------

    private fun parseObject(text: String, what: String): JsonObject {
        val element = try {
            Json.parseToJsonElement(text)
        } catch (e: IllegalArgumentException) { // SerializationException — его подкласс
            throw VersionParseException("The $what is not valid JSON", e)
        }
        return element as? JsonObject ?: throw VersionParseException("The $what is not a JSON object")
    }

    private fun JsonElement?.stringOrNull(): String? =
        (this as? JsonPrimitive)?.takeIf { it.isString }?.content

    private fun JsonObject.str(key: String): String? = this[key].stringOrNull()

    private fun JsonObject.long(key: String): Long? =
        (this[key] as? JsonPrimitive)?.takeIf { !it.isString }?.longOrNull

    private fun JsonObject.int(key: String): Int? =
        (this[key] as? JsonPrimitive)?.takeIf { !it.isString }?.intOrNull

    private fun JsonObject.bool(key: String): Boolean? =
        (this[key] as? JsonPrimitive)?.takeIf { !it.isString }?.booleanOrNull

    private fun JsonObject.obj(key: String): JsonObject? = this[key] as? JsonObject

    private fun JsonObject.arr(key: String): JsonArray? = this[key] as? JsonArray
}
