package com.mclauncher.app.data.versions

import com.mclauncher.app.data.net.HttpSource
import com.mclauncher.app.data.net.HttpStatusException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

enum class FileKind { VERSION_JSON, CLIENT_JAR, LIBRARY, LOGGING, ASSET_INDEX, ASSET_OBJECT }

/**
 * Один файл для загрузки. [size] ≤ 0 — размер неизвестен. [verifyExisting] = false: уже лежащий файл считается
 * годным по размеру без пересчёта SHA-1 (так проверяются тысячи ассетов, чей хэш и так входит в имя файла).
 */
data class DownloadTask(
    val url: String,
    val target: File,
    val sha1: String?,
    val size: Long,
    val kind: FileKind,
    val verifyExisting: Boolean = true,
)

/** Загрузка не удалась. [reason] определяет, повторять ли попытку и что сказать пользователю. */
class DownloadException(
    val reason: Reason,
    message: String,
    val status: Int? = null,
    cause: Throwable? = null,
) : IOException(message, cause) {

    enum class Reason { HTTP, NETWORK, HASH, SIZE, STORAGE }

    /** Повторять имеет смысл при сбоях сети и сервера, а не при «нет файла» или «нет места». */
    val isRetryable: Boolean
        get() = when (reason) {
            Reason.NETWORK, Reason.HASH, Reason.SIZE -> true
            Reason.HTTP -> status != null && (status >= 500 || status == 408 || status == 429)
            Reason.STORAGE -> false
        }
}

/**
 * Скачивает файлы по одному: во временный `.part`, с проверкой размера и SHA-1, затем переносит на место.
 * Готовый файл никогда не бывает оборванным: оборванная загрузка остаётся только как `.part` и удаляется.
 *
 * Не бросает ничего, кроме [DownloadException] и отмены корутины. Сбой сети и повреждённые данные повторяются
 * до [maxAttempts] раз с нарастающей паузой; при каждой неудачной попытке учтённые байты откатываются
 * отрицательным значением в `onBytes`, чтобы прогресс не уходил за 100%.
 */
class FileDownloader(
    private val http: HttpSource,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val maxAttempts: Int = 3,
    private val retryDelayMs: (attempt: Int) -> Long = { attempt -> 400L shl (attempt - 1) },
) {

    /** Лежит ли уже подходящий файл. Работа с диском — вне главного потока. */
    fun isUpToDate(task: DownloadTask): Boolean {
        val file = task.target
        if (!file.isFile) return false
        val length = file.length()
        if (task.size > 0 && length != task.size) return false
        if (task.size <= 0 && task.sha1 == null && length == 0L) return false
        if (task.verifyExisting && task.sha1 != null) {
            return sha1Of(file)?.equals(task.sha1, ignoreCase = true) == true
        }
        return true
    }

    /**
     * @param assumeMissing вызывающий код уже проверил [isUpToDate] и знает, что файла нет или он не годится
     * @param onBytes сколько байт принято с прошлого вызова; может быть отрицательным при откате неудачной попытки
     */
    suspend fun download(task: DownloadTask, assumeMissing: Boolean = false, onBytes: (Long) -> Unit = {}) {
        withContext(ioDispatcher) {
            if (!assumeMissing && isUpToDate(task)) return@withContext

            val part = File(task.target.path + ".part")
            try {
                var attempt = 0
                while (true) {
                    attempt++
                    val received = LongArray(1)
                    try {
                        fetchOnce(task, part) { n ->
                            received[0] += n
                            onBytes(n)
                        }
                        break
                    } catch (e: DownloadException) {
                        onBytes(-received[0])
                        if (!e.isRetryable || attempt >= maxAttempts) throw e
                        delay(retryDelayMs(attempt))
                    }
                }
                try {
                    Files.move(part.toPath(), task.target.toPath(), StandardCopyOption.REPLACE_EXISTING)
                } catch (e: IOException) {
                    throw DownloadException(DownloadException.Reason.STORAGE, "Cannot move ${part.name} into place", cause = e)
                }
            } finally {
                part.delete() // после успешного переноса файла уже нет — delete() просто вернёт false
            }
        }
    }

    private suspend fun fetchOnce(task: DownloadTask, part: File, report: (Long) -> Unit) {
        try {
            http.get(task.url) { body ->
                val dir = part.parentFile
                if (dir != null && !dir.isDirectory && !dir.mkdirs() && !dir.isDirectory) {
                    throw DownloadException(DownloadException.Reason.STORAGE, "Cannot create ${dir.path}")
                }
                val digest = MessageDigest.getInstance("SHA-1")
                var total = 0L
                val out = try {
                    FileOutputStream(part)
                } catch (e: IOException) {
                    throw DownloadException(DownloadException.Reason.STORAGE, "Cannot write ${part.path}", cause = e)
                }
                out.use {
                    val buffer = ByteArray(BUFFER_SIZE)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = body.stream.read(buffer) // сбой чтения — это сеть
                        if (n < 0) break
                        try {
                            out.write(buffer, 0, n)
                        } catch (e: IOException) {
                            throw DownloadException(DownloadException.Reason.STORAGE, "Cannot write ${part.path}", cause = e)
                        }
                        digest.update(buffer, 0, n)
                        total += n
                        report(n.toLong())
                    }
                }
                verify(task, total, digest.digest())
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: DownloadException) {
            throw e
        } catch (e: HttpStatusException) {
            throw DownloadException(DownloadException.Reason.HTTP, e.message.orEmpty(), status = e.status, cause = e)
        } catch (e: IOException) {
            throw DownloadException(DownloadException.Reason.NETWORK, e.message ?: "Network error", cause = e)
        }
    }

    private fun verify(task: DownloadTask, total: Long, digest: ByteArray) {
        if (task.size > 0 && total != task.size) {
            throw DownloadException(
                DownloadException.Reason.SIZE,
                "Expected ${task.size} bytes but received $total: ${task.url}",
            )
        }
        val expected = task.sha1
        if (expected != null && !hex(digest).equals(expected, ignoreCase = true)) {
            throw DownloadException(DownloadException.Reason.HASH, "SHA-1 mismatch: ${task.url}")
        }
    }

    private fun sha1Of(file: File): String? = try {
        val digest = MessageDigest.getInstance("SHA-1")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(BUFFER_SIZE)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        hex(digest.digest())
    } catch (e: IOException) {
        null
    }

    private fun hex(bytes: ByteArray): String {
        val chars = CharArray(bytes.size * 2)
        for (i in bytes.indices) {
            val v = bytes[i].toInt() and 0xFF
            chars[i * 2] = HEX[v ushr 4]
            chars[i * 2 + 1] = HEX[v and 0x0F]
        }
        return String(chars)
    }

    private companion object {
        const val BUFFER_SIZE = 64 * 1024
        val HEX = "0123456789abcdef".toCharArray()
    }
}
