package com.mclauncher.app.data.db

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * 1 → 2: скин аккаунта — модель рук (`skinModel`, NULL = скина нет) и время последней замены файла.
 * Существующие аккаунты остаются без скина. Текст колонок должен совпадать с [AccountEntity],
 * иначе Room откажется открывать базу.
 */
val MIGRATION_1_2: Migration = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE accounts ADD COLUMN skinModel TEXT")
        db.execSQL("ALTER TABLE accounts ADD COLUMN skinUpdatedAt INTEGER NOT NULL DEFAULT 0")
    }
}

/** Все миграции базы по порядку. Новую миграцию добавлять сюда, а не пересоздавать базу. */
val ALL_MIGRATIONS: Array<Migration> = arrayOf(MIGRATION_1_2)
