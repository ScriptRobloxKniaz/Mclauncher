package com.mclauncher.app.ui.accounts

import android.app.Application
import android.database.sqlite.SQLiteException
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mclauncher.app.LauncherApp
import com.mclauncher.app.R
import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.account.CreateAccountResult
import com.mclauncher.app.data.account.NameError
import com.mclauncher.app.data.account.UsernameValidator
import com.mclauncher.app.ui.common.UiEvent
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AccountsUiState(
    val accounts: List<Account> = emptyList(),
    /** false, пока база ещё не ответила — чтобы не мелькало «аккаунтов нет». */
    val loaded: Boolean = false,
)

/** Состояние диалога «Новый оффлайн-аккаунт». `null` в [AccountsViewModel.addDialog] — диалог закрыт. */
data class AddAccountDialogState(
    val name: String = "",
    val error: NameError? = null,
    val saving: Boolean = false,
)

class AccountsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as LauncherApp).accountRepository
    private val skinRepository = (application as LauncherApp).skinRepository

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events: Flow<UiEvent> = _events.receiveAsFlow()

    val uiState: StateFlow<AccountsUiState> = repository.accounts
        .map { AccountsUiState(accounts = it, loaded = true) }
        .catch { e ->
            if (e is SQLiteException) {
                Log.w(TAG, "Failed to read accounts", e)
                _events.trySend(UiEvent(R.string.error_accounts_db))
                emit(AccountsUiState(loaded = true))
            } else {
                throw e
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AccountsUiState())

    private val _addDialog = MutableStateFlow<AddAccountDialogState?>(null)
    val addDialog: StateFlow<AddAccountDialogState?> = _addDialog.asStateFlow()

    // ---- Диалог добавления ----------------------------------------------------------------

    fun openAddDialog() {
        _addDialog.value = AddAccountDialogState()
    }

    fun dismissAddDialog() {
        _addDialog.value = null
    }

    fun onNameChange(raw: String) {
        // Лишние символы не даём набрать вовсе; недопустимые символы подсвечиваем сразу.
        // Пробел по краям (его любит добавлять автодополнение клавиатуры) не считаем ошибкой:
        // перед сохранением ник обрезается.
        val name = raw.take(UsernameValidator.MAX_LENGTH)
        val error = if (UsernameValidator.containsOnlyAllowedChars(name.trim())) null else NameError.INVALID_CHARS
        _addDialog.update { it?.copy(name = name, error = error) }
    }

    fun confirmAdd() {
        val state = _addDialog.value ?: return
        if (state.saving) return

        // Быстрая проверка без обращения к базе.
        val validationError = UsernameValidator.validate(state.name.trim())
        if (validationError != null) {
            _addDialog.update { it?.copy(error = validationError) }
            return
        }

        _addDialog.update { it?.copy(saving = true, error = null) }
        viewModelScope.launch {
            try {
                when (val result = repository.createOffline(state.name)) {
                    is CreateAccountResult.Created -> _addDialog.value = null
                    is CreateAccountResult.Rejected ->
                        _addDialog.update { it?.copy(error = result.error, saving = false) }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: SQLiteException) {
                Log.w(TAG, "Failed to create account", e)
                _addDialog.update { it?.copy(saving = false) }
                _events.trySend(UiEvent(R.string.error_accounts_db))
            }
        }
    }

    // ---- Список ---------------------------------------------------------------------------

    fun select(account: Account) {
        if (account.isActive) return
        launchDb("select account") { repository.setActive(account.id) }
    }

    fun delete(account: Account) {
        launchDb("delete account") {
            repository.delete(account.id)
            // Файл скина лежит отдельно от базы — убираем и его, чтобы не копились сироты.
            skinRepository.discardFile(account.id)
        }
    }

    private fun launchDb(what: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: SQLiteException) {
                Log.w(TAG, "Failed to $what", e)
                _events.trySend(UiEvent(R.string.error_accounts_db))
            }
        }
    }

    private companion object {
        const val TAG = "AccountsViewModel"
    }
}
