package com.mclauncher.app.ui.skins

import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import com.mclauncher.app.LauncherApp
import com.mclauncher.app.R
import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.skin.SkinError
import com.mclauncher.app.data.skin.SkinLoadResult
import com.mclauncher.app.data.skin.SkinModel

/** Понятный пользователю текст причины, по которой скин не принят. */
@get:StringRes
val SkinError.messageRes: Int
    get() = when (this) {
        SkinError.NOT_PNG -> R.string.skins_error_not_png
        SkinError.WRONG_SIZE -> R.string.skins_error_size
        SkinError.TOO_LARGE -> R.string.skins_error_too_large
        SkinError.UNREADABLE -> R.string.skins_error_unreadable
        SkinError.STORAGE -> R.string.skins_error_storage
        SkinError.ACCOUNT_MISSING -> R.string.skins_error_account_missing
    }

@get:StringRes
val SkinModel.labelRes: Int
    get() = when (this) {
        SkinModel.WIDE -> R.string.skins_model_wide
        SkinModel.SLIM -> R.string.skins_model_slim
    }

/**
 * Текстура скина аккаунта (64×64) для рисования аватара. `null`, пока она грузится, а также если
 * у аккаунта нет скина или файл не читается — тогда вместо головы показывается буква.
 * Загрузка идёт вне главного потока и повторяется только при смене аккаунта или замене файла.
 */
@Composable
fun rememberSkinBitmap(account: Account?): ImageBitmap? {
    val context = LocalContext.current
    val state = produceState<ImageBitmap?>(
        initialValue = null,
        account?.id,
        account?.skin?.updatedAt,
    ) {
        value = null // не показываем голову предыдущего аккаунта, пока грузится новая
        if (account?.skin != null) {
            val repository = (context.applicationContext as LauncherApp).skinRepository
            val result = repository.load(account)
            if (result is SkinLoadResult.Loaded) value = result.bitmap.asImageBitmap()
        }
    }
    return state.value
}
