package com.mclauncher.app.data.skin

/**
 * Операции над пикселями скина. Пиксель — Int в формате ARGB (как у `Bitmap.getPixels`),
 * текстура — массив по строкам. Работает без Android — покрыто JVM-тестами.
 */
object SkinPixels {

    private const val W = SkinLayout.TEXTURE_WIDTH
    private const val H = SkinLayout.TEXTURE_HEIGHT

    /** Пары «коробка старого скина → коробка, которую в новом формате занимает её зеркальная копия». */
    private val legacyMirrorPairs = listOf(
        SkinLayout.RIGHT_LEG to SkinLayout.LEFT_LEG,
        SkinLayout.rightArm(SkinModel.WIDE) to SkinLayout.leftArm(SkinModel.WIDE),
    )

    /**
     * Грани зеркальной копии: «грань копии → из какой грани оригинала она берётся».
     * Зеркало по горизонтали разворачивает коробку: передняя и задняя грани остаются на месте
     * (но сами зеркальны), а правая и левая меняются местами.
     */
    private val mirroredFaces = listOf(
        Face.TOP to Face.TOP,
        Face.BOTTOM to Face.BOTTOM,
        Face.FRONT to Face.FRONT,
        Face.BACK to Face.BACK,
        Face.RIGHT to Face.LEFT,
        Face.LEFT to Face.RIGHT,
    )

    /**
     * Приводит текстуру к формату 64×64.
     *
     * Скины 64×32 (до версии 1.8) не хранят левую руку и левую ногу: игра берёт их как зеркальные копии
     * правых. Здесь делается то же самое, чтобы превью ничем не отличалось от игры. Второй слой
     * (куртка, рукава, штаны) у старых скинов пустой. Возвращает новый массив.
     *
     * Не воспроизводится: служебная обработка прозрачности старых скинов, которую делает сама игра.
     */
    fun toModern(pixels: IntArray, width: Int, height: Int): IntArray {
        require(SkinLayout.isSupportedSize(width, height)) { "Unsupported skin size ${width}x$height" }
        require(pixels.size >= width * height) { "Pixel array is smaller than ${width}x$height" }

        val out = IntArray(W * H)
        System.arraycopy(pixels, 0, out, 0, width * height) // верхние 32 строки (или всё) переносим как есть
        if (height == SkinLayout.TEXTURE_HEIGHT) return out

        for ((source, copy) in legacyMirrorPairs) {
            for ((copyFace, sourceFace) in mirroredFaces) {
                val from = source.face(sourceFace)
                val to = copy.face(copyFace)
                for (dy in 0 until to.height) {
                    for (dx in 0 until to.width) {
                        // Зеркало: самый левый столбец копии — это самый правый столбец оригинала.
                        out[(to.y + dy) * W + to.x + dx] = pixels[(from.y + dy) * W + from.x + (from.width - 1 - dx)]
                    }
                }
            }
        }
        return out
    }

    /**
     * Определяет модель рук. Тонкие руки (3 пикселя) оставляют часть текстуры руки пустой — см.
     * [SkinLayout.SLIM_UNUSED_REGIONS]. Если все эти участки полностью прозрачны — скин тонкий.
     * Для скинов 64×32 всегда [SkinModel.WIDE]: тонких рук в старом формате не было.
     *
     * Это эвристика: редкий тонкий скин с мусором в пустых местах распознается как широкий —
     * поэтому в интерфейсе модель можно переключить вручную.
     */
    fun detectModel(pixels: IntArray, width: Int, height: Int): SkinModel {
        if (width != W || height != H || pixels.size < W * H) return SkinModel.WIDE
        val slim = SkinLayout.SLIM_UNUSED_REGIONS.all { isFullyTransparent(pixels, it) }
        return if (slim) SkinModel.SLIM else SkinModel.WIDE
    }

    private fun isFullyTransparent(pixels: IntArray, rect: PixelRect): Boolean {
        for (y in rect.y until rect.bottom) {
            for (x in rect.x until rect.right) {
                if ((pixels[y * W + x] ushr 24) != 0) return false
            }
        }
        return true
    }
}
