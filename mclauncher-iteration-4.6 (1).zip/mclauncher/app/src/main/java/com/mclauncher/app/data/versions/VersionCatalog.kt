package com.mclauncher.app.data.versions

import com.mclauncher.app.data.net.HttpSource
import com.mclauncher.app.data.net.getText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

sealed interface CatalogResult {
    /** [fromCache] = true: сети нет (или она отвечает ошибкой), показан сохранённый ранее список. */
    data class Loaded(val manifest: VersionManifest, val fromCache: Boolean) : CatalogResult

    data class Failed(val error: InstallError) : CatalogResult
}

/**
 * Список версий Mojang (`version_manifest_v2.json`). Сначала берётся из сети и сохраняется в [cacheFile];
 * если сети нет — показывается последний сохранённый список, чтобы экран версий работал без интернета.
 *
 * Адрес манифеста — константа Mojang; в приложении всё скачивается по HTTPS.
 */
class VersionCatalog(
    private val http: HttpSource,
    private val cacheFile: File,
    private val manifestUrl: String = DEFAULT_MANIFEST_URL,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) {

    suspend fun load(): CatalogResult = withContext(ioDispatcher) {
        val networkError: InstallError = try {
            val text = http.getText(manifestUrl, MAX_BYTES)
            val manifest = VersionParser.parseManifest(text)
            saveCache(text)
            return@withContext CatalogResult.Loaded(manifest, fromCache = false)
        } catch (e: CancellationException) {
            throw e
        } catch (e: com.mclauncher.app.data.net.HttpStatusException) {
            InstallError.Server(e.status)
        } catch (e: IOException) {
            InstallError.Network(e.message)
        } catch (e: VersionParseException) {
            InstallError.BadData(e.message)
        }

        val cached = readCache()
        if (cached != null) CatalogResult.Loaded(cached, fromCache = true) else CatalogResult.Failed(networkError)
    }

    private fun readCache(): VersionManifest? = try {
        if (cacheFile.isFile) VersionParser.parseManifest(cacheFile.readText()) else null
    } catch (e: IOException) {
        null
    } catch (e: VersionParseException) {
        null
    }

    /** Кэш — удобство, а не необходимость: сбой записи не должен ломать загрузку списка. */
    private fun saveCache(text: String) {
        try {
            cacheFile.parentFile?.mkdirs()
            val temp = File(cacheFile.path + ".tmp")
            try {
                temp.writeText(text)
                Files.move(temp.toPath(), cacheFile.toPath(), StandardCopyOption.REPLACE_EXISTING)
            } finally {
                temp.delete()
            }
        } catch (e: IOException) {
            // ignore
        }
    }

    companion object {
        const val DEFAULT_MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
        private const val MAX_BYTES = 16 * 1024 * 1024
    }
}
