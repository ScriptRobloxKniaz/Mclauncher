# Правила R8/ProGuard. Пока пусто: minify выключен (см. app/build.gradle.kts).
# Итерация 4 добавит keep-правила для JNI-классов PojavLauncher.
