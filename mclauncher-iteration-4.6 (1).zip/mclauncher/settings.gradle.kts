pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Итерация 4: сюда, возможно, добавится репозиторий с нативными
        // библиотеками PojavLauncher (JitPack / локальный AAR / git submodule).
    }
}

rootProject.name = "MCLauncher"
include(":app")
