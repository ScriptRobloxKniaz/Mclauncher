# ИИ-помощник сборок (этап 7.5): решение и устройство

Решение владельца проекта от 2026-10-25. Статус: **запланировано, реализуется после этапа 7** (нужны установка
версий 4.6, установка модов 7 и экран настроек 8). Здесь решение зафиксировано, чтобы к нему не возвращаться.

## 1. Решение

Гибрид из двух слоёв.

1. **Базовый слой — поиск по Modrinth.** Работает всегда, без ключей и без ИИ.
2. **Опциональный слой — ИИ.** Появляется, только если пользователь сам ввёл свой ключ. Модель предлагает
   slug модов, а лаунчер **проверяет каждый через Modrinth** и показывает только существующие моды с подходящими версиями.

Жёсткие ограничения:

- Ключ API вводит пользователь в настройках, он хранится только на его устройстве.
- Ключа **нет** в `local.properties`, `BuildConfig`, ресурсах и исходниках. Ключ в APK исключён.
- Прокси-сервера нет, архитектура под него не закладывается. Запросы идут с устройства напрямую к провайдеру.
  Адреса провайдеров — константы в коде; настраиваемого «базового URL» нет. Только HTTPS (открытый HTTP
  запрещён сетевой конфигурацией приложения).

### Состав кода (пакет `ai/`, этап 7.5)

| Часть | Задача |
|---|---|
| `ModrinthApi` | три вызова: поиск, пакетная загрузка проектов, версии проекта |
| `ModSearch` | запрос → `List<ModCard>` для экрана |
| `AiProvider` (интерфейс) | `suspend fun suggestSlugs(task, gameVersion, loader): List<String>`; реализации `ClaudeProvider`, `OpenAiProvider` |
| `SuggestionValidator` | чистит ответ модели и проверяет каждый slug через Modrinth (раздел 3) |
| `SecretStore` | ключ API; общий с этапом 4.5 (токены Microsoft) — пишется один раз |
| `AiSettings` | провайдер и имя модели (не секрет — в DataStore) |
| `AssistantScreen` | поле запроса, «Найти», «Спросить ИИ» (виден только при наличии ключа) |

Версия игры и загрузчик берутся из выбранной установленной версии (этап 4.6): без них поиск и проверка бессмысленны.
Минимальная секция «ИИ-помощник» в настройках появится вместе с 7.5, остальные настройки — этап 8.

## 2. Слой 1: поиск по Modrinth

**Проверено по документации Modrinth (2026-10-25):**

| Что | Как |
|---|---|
| Запрос | `GET https://api.modrinth.com/v2/search` |
| Параметры | `query`, `facets`, `index` (`relevance` по умолчанию; также `downloads`, `follows`, `newest`, `updated`), `offset`, `limit` (по умолчанию 10, максимум 100) |
| Фильтры | `facets` — JSON-массив массивов строк: внутри массива «ИЛИ», между массивами «И». Пример из документации: `[["categories:forge"],["versions:1.17.1"],["project_type:mod"],["license:mit"]]` |
| Загрузчики | передаются как `categories` (`categories:fabric`) |
| Заголовок `User-Agent` | **обязателен** и должен однозначно называть приложение; формат из документации `github_username/project_name/1.56.0 (contact@launcher.com)`. Только имя HTTP-библиотеки (например `okhttp/4.9.3`) повышает риск блокировки |
| Лимит | 300 запросов в минуту с одного IP; заголовки `X-Ratelimit-Limit`, `X-Ratelimit-Remaining`, `X-Ratelimit-Reset` |
| Стабильность | slug и имя автора могут измениться в любой момент — для хранения использовать `project_id` |

Что делает лаунчер:

- Фильтры берутся из установленной версии (этап 4.6): игровая версия (`versions:1.20.1`) и загрузчик (`categories:fabric`).
- Поле поиска с задержкой не меньше 400 мс после последнего символа, короткий кэш ответов в памяти (несколько минут),
  при `429` — ждать `X-Ratelimit-Reset` секунд.
- В карточке: значок, название, автор, описание, число загрузок, последняя версия. Иконки только по `https://`.
- Свой `User-Agent`: `<ваш GitHub-логин>/MCLauncher/<versionName> (<ссылка на репозиторий>)`. **Логин и контакт нужно вписать
  вам** — подставлять чужие данные нельзя.

### Код разбора (проверен: скомпилирован и запущен с kotlinx-serialization-json 1.6.2)

Разбор идёт по дереву `JsonElement`, а не по `@Serializable`-классам: поля отсутствуют или меняются, и
мягкий разбор не роняет экран из-за одного плохого элемента.

```kotlin
data class ModCard(
    val projectId: String,
    val slug: String?,
    val title: String,
    val description: String,
    val author: String,
    val iconUrl: String?,
    val downloads: Long,
    val latestVersion: String?,
)

object ModrinthParser {

    /** Параметр `facets`: внутренние массивы объединяются по ИЛИ, внешние — по И. */
    fun facets(gameVersion: String, loader: String): String = buildJsonArray {
        add(buildJsonArray { add(JsonPrimitive("project_type:mod")) })
        add(buildJsonArray { add(JsonPrimitive("versions:$gameVersion")) })
        add(buildJsonArray { add(JsonPrimitive("categories:$loader")) }) // загрузчики — это categories
    }.toString()

    fun parseSearch(body: String): List<ModCard> {
        val hits = Json.parseToJsonElement(body).jsonObject["hits"]?.jsonArray ?: return emptyList()
        return hits.mapNotNull { element ->
            val hit = element as? JsonObject ?: return@mapNotNull null
            val id = hit.string("project_id") ?: return@mapNotNull null
            val title = hit.string("title") ?: return@mapNotNull null
            ModCard(
                projectId = id,
                slug = hit.string("slug"),
                title = title,
                description = hit.string("description").orEmpty(),
                author = hit.string("author").orEmpty(),
                iconUrl = hit.string("icon_url")?.takeIf { it.startsWith("https://") },
                downloads = (hit["downloads"] as? JsonPrimitive)?.longOrNull ?: 0L,
                latestVersion = hit.string("latest_version"),
            )
        }
    }

    private fun JsonObject.string(key: String): String? {
        val value = this[key]
        return if (value is JsonPrimitive && value !is JsonNull && value.isString) value.content else null
    }
}
```

### Пример клиента на Ktor (**не компилировался**: зависимости Ktor недоступны в среде разработки)

Зависимости для этапа 7.5: `io.ktor:ktor-client-core`, `io.ktor:ktor-client-okhttp`. Последняя версия на
2026-10-26 — **3.6.0** (17 сентября 2026; [страница релизов Ktor](https://ktor.io/docs/releases.html)); какую версию
Kotlin она требует, на странице не сказано, поэтому совместимость с Kotlin 2.4.10 проверит только сборка.
До этого этапа в проекте клиентом является `HttpURLConnection` (этап 4.6): он не требует зависимостей и проверяется
на JVM; его можно заменить на Ktor, когда понадобится.

```kotlin
class ModrinthClient(
    private val userAgent: String,
    private val http: HttpClient = HttpClient(OkHttp) {
        install(HttpTimeout) {
            connectTimeoutMillis = 10_000
            requestTimeoutMillis = 20_000
        }
        defaultRequest { header(HttpHeaders.UserAgent, userAgent) }
        expectSuccess = false // статусы разбираем сами
    },
) {
    sealed interface Result {
        data class Ok(val cards: List<ModCard>) : Result
        data class RateLimited(val retryAfterSeconds: Int) : Result
        data class Failed(val status: Int?) : Result
    }

    suspend fun search(query: String, gameVersion: String, loader: String, limit: Int = 20): Result {
        val response = try {
            http.get("https://api.modrinth.com/v2/search") {
                parameter("query", query)                          // Ktor сам кодирует значения
                parameter("facets", ModrinthParser.facets(gameVersion, loader))
                parameter("index", "relevance")
                parameter("limit", limit.coerceIn(1, 100))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            return Result.Failed(status = null)
        }
        return when (response.status.value) {
            200 -> Result.Ok(ModrinthParser.parseSearch(response.bodyAsText()))
            // В документации Modrinth — X-Ratelimit-Reset; сторонний пересказ API упоминает Retry-After: читаем оба.
            429 -> Result.RateLimited(
                (response.headers["X-Ratelimit-Reset"] ?: response.headers[HttpHeaders.RetryAfter])
                    ?.toIntOrNull() ?: 30,
            )
            else -> Result.Failed(response.status.value)
        }
    }
}
```

## 3. Слой 2: «Спросить ИИ»

Кнопка видна только при сохранённом ключе. Порядок работы:

```
текст пользователя + (игровая версия, загрузчик)
        │
        ▼
   провайдер ИИ ──► ответ-текст (недоверенный!)
        │
        ▼
 1. извлечь JSON-массив строк      ─ отбросить всё, что не похоже на slug, дубли, лишнее сверх 30
 2. существуют ли проекты         ─ GET /v2/projects?ids=["slug1","slug2",…]
 3. это моды и они опубликованы   ─ project_type == "mod", status == "approved"
 4. есть версия под ваши настройки ─ GET /v2/project/{id}/version?game_versions=["1.20.1"]&loaders=["fabric"]&include_changelog=false
        │
        ▼
 карточки «подобрано ИИ» + строка «найдено K из N предложенных»
```

- **Защита от галлюцинаций:** в список попадает только то, что прошло шаги 2–4. Остальное молча отбрасывается, а
  число отброшенных показывается («найдено 7 из 10»), чтобы пользователь видел, что модель ошиблась.
- Документация Modrinth говорит, что `ids` принимает «ID и/или slug» и приводит пример `["AABBCCDD", "EEFFGGHH"]`, но
  **не описывает поведение для несуществующих**. Поэтому ответ нужно сверять по содержимому: оставлять только те
  запрошенные slug, которые вернулись как `slug` или `id` проекта (без учёта регистра). Если весь запрос завершился
  ошибкой `404` — перейти на запросы по одному `GET /v2/project/{slug}`. Проверить на реальном API на этапе реализации.
- Шаг 4 — это запрос на каждый проект (до ~30). Выполнять с ограничением параллелизма (4) — это укладывается в лимит
  300 запросов в минуту. В версии с наибольшей датой публикации, предпочитая `release`, лежат файл, хэши
  (`sha1`, `sha512`) и зависимости (`dependency_type`) — они понадобятся для установки на этапе 7.
- Slug — недоверенные данные: в URL они всегда подставляются с кодированием, длина ограничена.

### Код извлечения slug (проверен: скомпилирован и запущен)

```kotlin
object LlmSlugs {
    // Формат slug в документации Modrinth не описан, поэтому правило консервативное.
    private val plausible = Regex("^[A-Za-z0-9_.-]{1,64}$")

    /**
     * Достаёт массив slug из ответа модели. Ответ — недоверенный текст: ищем первый JSON-массив,
     * берём только строки, нормализуем и отбрасываем всё, что не похоже на slug.
     */
    fun extract(reply: String, max: Int = 30): List<String> {
        val start = reply.indexOf('[')
        val end = reply.lastIndexOf(']')
        if (start < 0 || end <= start) return emptyList()
        val array = try {
            Json.parseToJsonElement(reply.substring(start, end + 1)) as? JsonArray
        } catch (e: SerializationException) {
            null
        } ?: return emptyList()

        val seen = HashSet<String>()
        val out = ArrayList<String>()
        for (item in array) {
            val p = item as? JsonPrimitive ?: continue
            if (!p.isString) continue
            val slug = p.content.trim()
            if (plausible.matches(slug) && seen.add(slug.lowercase())) out += slug
            if (out.size >= max) break
        }
        return out
    }
}
```

### Запрос к ИИ

Системный промт (первое предложение — ваша формулировка, остальное — ограничения формата):

> Ты эксперт по модам Minecraft. Верни JSON-массив slug модов из Modrinth под задачу пользователя.
> Игровая версия: {версия}. Загрузчик: {загрузчик}. Верни только JSON-массив строк, не больше 20 элементов,
> без пояснений. Если не уверен, что мод существует, не включай его.

Текст пользователя идёт отдельным сообщением роли `user` и **не вставляется** в системный промт.

| | Claude | OpenAI |
|---|---|---|
| Адрес | `POST https://api.anthropic.com/v1/messages` | `POST https://api.openai.com/v1/chat/completions` |
| Авторизация | заголовки `x-api-key: <ключ>`, `anthropic-version: 2023-06-01` | заголовок `Authorization: Bearer <ключ>` |
| Тело | `model`, `max_tokens`, `system`, `messages: [{role: "user", content}]` | `model`, `messages: [{role: "system"}, {role: "user"}]` |
| Ответ | текст в `content[0].text` | текст в `choices[0].message.content` |
| Модель | поле в настройках; предложение по умолчанию — `claude-haiku-5-5` (быстрая и недорогая) | поле в настройках; значение по умолчанию подобрать при реализации по актуальной документации |

**Проверено 2026-10-26** по документации платформы Claude (<https://platform.claude.com/docs/en/build-with-claude/working-with-messages>):
поля тела `model`, `max_tokens`, `messages` и верхнеуровневое `system`; ответ — массив `content`, текст в блоке
`"type": "text"`, поле `text`. **Из памяти:** адрес `/v1/messages` и заголовки (на странице их нет) и весь столбец OpenAI —
сверить с документацией провайдеров до написания кода.

Прочее: ограничение `max_tokens` (достаточно около 500), таймаут 30 секунд, один запрос за раз; понятные сообщения
для `401` («ключ не подошёл»), `429`, нет сети и пустого ответа; запрос можно отменить.

**Приватность:** перед первой отправкой показывать окно: «Текст вашего запроса, игровая версия и загрузчик будут
отправлены провайдеру ИИ, которого вы выбрали. Список ваших модов не отправляется». Больше ничего не отправлять.

## 4. Хранение ключа

Требование: ключ шифруется (AES-256, ключ в Android Keystore), живёт только на устройстве и не попадает в
`local.properties` и `BuildConfig`.

**Решение владельца: `EncryptedSharedPreferences`** (AndroidX Security, AES-256 + Android Keystore). Оно принято и
повторено дважды, поэтому реализуется именно так.

**Оговорка, чтобы не было сюрпризов.** Ранее я проверял: библиотека `androidx.security:security-crypto` с версии
1.1.0 **объявлена устаревшей**. Она работает, но исправлений может не быть. Поэтому она подключается только за
интерфейсом `SecretStore` (`get` / `put` / `remove` / `contains`), который пишется один раз на этапе 4.5 и хранит
также токены Microsoft. Если библиотека когда-нибудь перестанет собираться, её заменяет один файл — например, на
DataStore + Tink AEAD с ключом в Keystore (та же защита: AES-256-GCM, ключ в Keystore), остальной код не меняется.

Общие правила для любого варианта:

- Автозагрузка в облако выключена (`android:allowBackup="false"` уже стоит в манифесте); дополнительно описать
  `dataExtractionRules`, чтобы файл хранилища не попадал и в перенос на другое устройство.
- Если расшифровать не удалось (ключ Keystore потерян после смены блокировки или восстановления) — считать, что ключа
  нет, и попросить ввести его заново. Не падать.
- Ключ не пишется в лог и в тексты ошибок; перед отправкой его не копировать в отладочные поля. Если подключается
  логирование HTTP, заголовки `x-api-key` и `Authorization` скрывать (в Ktor — `sanitizeHeader`), а в релизе логирование
  выключать.
- Ключ показывается замаскированным; поле ввода без автозаполнения и автокоррекции.
- Честный предел защиты: на устройстве с root или вредоносным приложением с правом доступности ключ могут перехватить,
  а при каждом запросе он уходит провайдеру по TLS. Поэтому в настройках стоит подсказка: заведите отдельный ключ с
  лимитом расходов.

## 5. Интерфейс

- **Без ключа:** виден только локальный поиск; под полем подсказка «Чтобы включить ИИ, добавьте ключ в настройках».
- **С ключом:** рядом с поиском появляется кнопка «Спросить ИИ».
- **Настройки (этап 8):** выбор провайдера (Claude / OpenAI), поле ключа, поле модели, кнопка «Удалить ключ» с
  подтверждением. Кнопка «Проверить ключ» — по желанию (тратит копейки).
- Заглушка ИИ-помощника на главной (карточка) и экран `AssistantScreen` остаются как есть до этапа 7.5.

## 6. README

В `README.md` добавлено предупреждение: не вшивайте ключ API в сборку (в `local.properties`, `BuildConfig`, ресурсы) —
его извлекают из APK. Ключ вводит пользователь в настройках приложения.

## 7. Что проверено, а что из памяти

**Проверено (2026-10-25 и повторно 2026-10-26):** параметры и ответ `/v2/search`, формат `facets`, ограничения на `limit`; `GET /v2/projects`
принимает `ids` как ID и/или slug; `GET /v2/project/{id|slug}/version` и его параметры `loaders`, `game_versions`,
`include_changelog`; требование `User-Agent`; лимит 300 запросов в минуту и заголовки лимита; код разбора
скомпилирован и запущен (кроме кода на Ktor); в ответе `/projects` у каждого проекта есть `project_type`, `status`,
`game_versions`, `loaders`.
Источник: <https://docs.modrinth.com/api>.

**Из памяти:** протоколы Claude и OpenAI из раздела 3; поведение `/projects` для несуществующих slug (документация
молчит); формат slug; то, что стоит ввести задержку ввода и кэш.

**Не проверено вообще:** код клиента на Ktor. Сами серверы Modrinth и Mojang из среды разработки недоступны
(соединение отклоняется), поэтому ни один запрос к ним не выполнялся — формы ответов взяты из документации.

## 8. Что нужно решить

Хранилище ключа решено (раздел 4). Открыто только одно:

1. Какие модели ИИ предлагать по умолчанию — можно оставить пустое поле «модель» с подсказкой.
