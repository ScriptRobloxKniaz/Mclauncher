#!/usr/bin/env python3
"""Скачивает НАСТОЯЩИЕ описания версий Mojang для проверки разбора (RealFixturesTest).

Зачем: JSON-образцы в app/src/test/resources/fixtures написаны вручную по памяти. Этот скрипт кладёт рядом
настоящие файлы, и RealFixturesTest прогоняет через парсер и планировщик установки именно их. Если Mojang
изменит формат или в моём представлении о нём была ошибка, тест это покажет.

Запуск (нужен только Python 3.8+ и интернет, внешних пакетов нет):

    python3 -I scripts/fetch_fixtures.py
    python3 -I scripts/fetch_fixtures.py --versions 1.21.1,1.20.4,1.8.9
    python3 -I scripts/fetch_fixtures.py --out /путь/к/папке

Файлы попадают в app/src/test/resources/real/ (в git не коммитятся, см. .gitignore): это файлы Mojang,
их не стоит класть в репозиторий. Скрипт скачивает только описания версий и индексы ассетов, но не
саму игру, библиотеки и ассеты.

Безопасность: только HTTPS, только известные хосты Mojang, контрольные суммы из манифеста проверяются,
размер ответа ограничен, имена файлов берутся только из проверенных идентификаторов версий.
"""
import argparse
import hashlib
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
ALLOWED_HOSTS = {
    "piston-meta.mojang.com",
    "launchermeta.mojang.com",
    "piston-data.mojang.com",
}
# Разные эпохи формата: самый новый релиз и снапшот (подставляются из манифеста), затем «ступеньки» истории.
DEFAULT_VERSIONS = ["latest-release", "latest-snapshot", "1.21.1", "1.20.4", "1.16.5", "1.12.2", "1.8.9", "1.7.10", "1.6.4"]
MAX_BYTES = 8 * 1024 * 1024
SAFE_ID = re.compile(r"^[A-Za-z0-9._+-]{1,64}$")
SHA1 = re.compile(r"^[0-9a-f]{40}$")
USER_AGENT = "MCLauncher-fixtures/1.0"


class FetchError(Exception):
    pass


def fetch(url, expected_sha1=None):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in ALLOWED_HOSTS:
        raise FetchError("Отказ: адрес вне списка разрешённых (%s)" % url)
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept-Encoding": "identity"})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read(MAX_BYTES + 1)
    except urllib.error.HTTPError as error:
        raise FetchError("HTTP %d: %s" % (error.code, url))
    except (urllib.error.URLError, OSError) as error:
        raise FetchError("Нет связи (%s): %s" % (error, url))
    if len(data) > MAX_BYTES:
        raise FetchError("Ответ больше %d байт: %s" % (MAX_BYTES, url))
    if expected_sha1:
        actual = hashlib.sha1(data).hexdigest()
        if actual != expected_sha1.lower():
            raise FetchError("Контрольная сумма не совпала для %s (ожидалась %s, получена %s)" % (url, expected_sha1, actual))
    return data


def parse_json(data, what):
    try:
        value = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as error:
        raise FetchError("%s: не JSON (%s)" % (what, error))
    if not isinstance(value, dict):
        raise FetchError("%s: ожидался JSON-объект" % what)
    return value


def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temp = path + ".part"
    with open(temp, "wb") as handle:
        handle.write(data)
    os.replace(temp, path)


def resolve(requested, manifest):
    latest = manifest.get("latest") or {}
    mapping = {"latest-release": latest.get("release"), "latest-snapshot": latest.get("snapshot")}
    resolved = []
    for item in requested:
        item = item.strip()
        if not item:
            continue
        value = mapping.get(item, item)
        if not value:
            print("  пропуск: %s (в манифесте не указан)" % item)
            continue
        if not SAFE_ID.match(value):
            raise FetchError("Небезопасный идентификатор версии: %r" % value)
        if value not in resolved:
            resolved.append(value)
    return resolved


def main(argv):
    default_out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "test", "resources", "real")
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--out", default=os.path.normpath(default_out), help="куда сохранить файлы")
    parser.add_argument("--versions", default=",".join(DEFAULT_VERSIONS), help="идентификаторы через запятую")
    args = parser.parse_args(argv)

    print("Манифест: %s" % MANIFEST_URL)
    manifest_bytes = fetch(MANIFEST_URL)
    manifest = parse_json(manifest_bytes, "манифест")
    entries = {e.get("id"): e for e in manifest.get("versions", []) if isinstance(e, dict)}
    write(os.path.join(args.out, "manifest.json"), manifest_bytes)
    print("  версий в манифесте: %d" % len(entries))

    failures = 0
    for version_id in resolve(args.versions.split(","), manifest):
        entry = entries.get(version_id)
        if entry is None:
            print("  %-12s нет в манифесте" % version_id)
            failures += 1
            continue
        try:
            sha1 = entry.get("sha1")
            version_bytes = fetch(entry["url"], sha1 if isinstance(sha1, str) and SHA1.match(sha1) else None)
            version = parse_json(version_bytes, version_id)
            write(os.path.join(args.out, "versions", version_id + ".json"), version_bytes)

            index = version.get("assetIndex") or {}
            index_id = index.get("id") or version.get("assets")
            if not isinstance(index_id, str) or not SAFE_ID.match(index_id):
                raise FetchError("у версии нет безопасного идентификатора индекса ассетов")
            index_sha1 = index.get("sha1")
            index_bytes = fetch(index["url"], index_sha1 if isinstance(index_sha1, str) and SHA1.match(index_sha1) else None)
            parse_json(index_bytes, "индекс ассетов " + index_id)
            write(os.path.join(args.out, "assets", index_id + ".json"), index_bytes)
            print("  %-12s ok  (индекс ассетов: %s)" % (version_id, index_id))
        except (FetchError, KeyError) as error:
            failures += 1
            print("  %-12s ОШИБКА: %s" % (version_id, error))

    print("Готово: %s" % os.path.normpath(args.out))
    if failures:
        print("Не удалось получить файлов: %d" % failures)
        return 1
    print("Дальше: ./gradlew :app:testDebugUnitTest --tests '*RealFixturesTest'")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except FetchError as error:
        print("ОШИБКА: %s" % error)
        sys.exit(1)
