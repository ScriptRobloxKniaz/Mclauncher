#!/usr/bin/env python3
"""Пишет короткий отчёт о том, почему CI не собрал APK, который запускает игру.

Зачем. Пользователь видит только само приложение: страницу запуска CI с логами он не открывает. Поэтому, если сборка
с нативной частью не удалась, CI собирает запасной APK и кладёт в него этот отчёт (`assets/build-status.txt`). Приложение
прочитает его (`ApkInspector`) и добавит в отчёт «Скопировать отчёт» — так причина сбоя (строки ошибок компилятора или
Gradle) доезжает до разработчика тем же путём, каким приходят остальные отчёты.

Использование (из корня проекта):
  python3 -I scripts/ci_build_status.py --core success --ndk success --native failure --verify skipped \
      --log-dir ci-logs --out app/src/main/assets/build-status.txt
  python3 -I scripts/ci_build_status.py --self-test

Значения --core/--ndk/--native/--verify — `outcome` шагов GitHub Actions: success, failure, skipped, cancelled.
Скрипт ничего не собирает и сети не использует. Код возврата 0, если отчёт записан (даже когда в нём описан сбой).
"""
from __future__ import annotations

import argparse
import re
import sys
import tempfile
from pathlib import Path

# Шаги в порядке выполнения: (ключ, название шага в workflow, файл лога).
STAGES = [
    ("core", "Fetch game core files", "core-fetch.log"),
    ("ndk", "Install NDK", "ndk-install.log"),
    ("native", "Build debug APK with the game core and natives", "native-build.log"),
    ("verify", "Check that the APK contains the game core", "apk-check.log"),
]

MAX_TOTAL_CHARS = 4500  # отчёт попадает в диалог и в «Скопировать отчёт»: длиннее нет смысла
MAX_KEY_LINES = 22
MAX_TAIL_LINES = 14
MAX_LINE_CHARS = 230

# Строки, по которым видно причину сбоя. Порядок важен только для чтения человеком: в отчёт они идут как в логе.
KEY_LINE = re.compile(
    r"(\berror:|\bfatal error:|undefined reference|undefined symbol|ld(\.lld)?: error|\bFAILED\b|"
    r"\* What went wrong|Execution failed for task|Android NDK:|make: \*\*\*|\bCaused by:|"
    r"A problem occurred|Could not (resolve|find|determine|get)|No (variants|matching)|"
    r"\bERROR\b|\bTraceback\b|^\s*(Exception|\w+Error|\w+Exception):|not found|not accepted|"
    r"MISSING|^e: )",
    re.IGNORECASE,
)
ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
# После этих строк Gradle пишет объяснение на следующих строках — берём и их.
FOLLOW_UP = re.compile(r"\* What went wrong|A problem occurred")


def clean(text: str) -> str:
    return ANSI.sub("", text).replace("\r", "")


def shorten(line: str) -> str:
    line = line.rstrip()
    return line if len(line) <= MAX_LINE_CHARS else line[: MAX_LINE_CHARS - 1] + "…"


def key_lines(text: str) -> list[str]:
    """Строки лога, по которым видно причину: ошибки компилятора и линковщика, «What went wrong» Gradle и т. п."""
    lines = clean(text).split("\n")
    picked: list[str] = []
    seen: set[str] = set()
    i = 0
    while i < len(lines) and len(picked) < MAX_KEY_LINES:
        line = lines[i]
        if KEY_LINE.search(line) and line.strip() and line not in seen:
            seen.add(line)
            picked.append(shorten(line))
            if FOLLOW_UP.search(line):
                for follow in lines[i + 1 : i + 5]:
                    if follow.strip() and len(picked) < MAX_KEY_LINES:
                        picked.append(shorten(follow))
                i += 4
        i += 1
    return picked


def tail_lines(text: str) -> list[str]:
    lines = [shorten(x) for x in clean(text).split("\n") if x.strip()]
    return lines[-MAX_TAIL_LINES:]


def failed_stage(outcomes: dict[str, str]) -> str | None:
    """Первый шаг, который не завершился успешно (`skipped` — следствие сбоя предыдущего)."""
    for key, _title, _log in STAGES:
        if outcomes.get(key, "skipped") != "success":
            return key
    return None


def read_log(log_dir: Path, name: str) -> str:
    path = log_dir / name
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def render(outcomes: dict[str, str], log_dir: Path, run: str = "", sha: str = "") -> str:
    stage = failed_stage(outcomes)
    out: list[str] = []
    if stage is None:
        out.append("CI: сборка с ядром и нативной частью прошла успешно.")
        return "\n".join(out) + "\n"

    title = next(t for k, t, _ in STAGES if k == stage)
    log_name = next(f for k, _, f in STAGES if k == stage)
    out.append("CI: сборка, которая запускает игру, НЕ удалась. Это запасной APK: игру он запустить не может.")
    if run or sha:
        out.append(f"Запуск CI: {run or '?'}, коммит: {(sha or '?')[:10]}")
    out.append(f"Не сработал шаг: «{title}» (результат: {outcomes.get(stage, 'skipped')}).")
    out.append("Результаты шагов: " + ", ".join(f"{k}={outcomes.get(k, 'skipped')}" for k, _t, _l in STAGES))
    drift = read_log(log_dir, "workflow-drift.txt").strip()
    if drift:
        out.append("ВНИМАНИЕ: " + drift)

    log = read_log(log_dir, log_name)
    if not log.strip():
        out.append(f"Лога этого шага нет ({log_name}): шаг не запускался или упал до записи лога.")
    else:
        keys = key_lines(log)
        if keys:
            out.append("")
            out.append("Строки с причиной из лога:")
            out.extend(keys)
        # то, что уже показано выше, второй раз не повторяем
        tail = [x for x in tail_lines(log) if x not in keys]
        if tail:
            out.append("")
            out.append("Конец лога:")
            out.extend(tail)

    text = "\n".join(out)
    if len(text) > MAX_TOTAL_CHARS:
        text = text[: MAX_TOTAL_CHARS - 20].rsplit("\n", 1)[0] + "\n… (обрезано)"
    return text + "\n"


# ---------------------------------------------------------------------------------------------------------------------
# Самопроверка: python3 -I scripts/ci_build_status.py --self-test


def self_test() -> int:
    failures: list[str] = []

    def check(name: str, ok: bool) -> None:
        if not ok:
            failures.append(name)

    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        ok = {"core": "success", "ndk": "success", "native": "success", "verify": "success"}
        check("успех: нет сбоя", failed_stage(ok) is None)
        check("успех: текст без «НЕ удалась»", "НЕ удалась" not in render(ok, d))

        check("первый сбой — ndk", failed_stage({**ok, "ndk": "failure", "native": "skipped", "verify": "skipped"}) == "ndk")
        check("skipped после core — это сбой core", failed_stage({"core": "failure", "ndk": "skipped"}) == "core")
        check("отсутствующий ключ = skipped", failed_stage({"core": "success"}) == "ndk")

        gradle = (
            "> Task :engine:buildNdkBuildDebug[arm64-v8a] FAILED\n"
            "\x1b[31m/work/jni/egl_bridge.c:106:24: error: expected ')'\x1b[0m\n"
            "  106 |     sprintf(envval, \"%\"PRIxPTR, (uintptr_t)ptr);\n"
            "ld.lld: error: undefined symbol: android_get_device_api_level\n"
            "* What went wrong:\n"
            "Execution failed for task ':engine:buildNdkBuildDebug[arm64-v8a]'.\n"
            "> Build command failed.\n"
            "BUILD FAILED in 2m 3s\n"
        )
        (d / "native-build.log").write_text(gradle, encoding="utf-8")
        text = render({"core": "success", "ndk": "success", "native": "failure", "verify": "skipped"}, d, run="123", sha="abcdef0123456789")
        check("нативный сбой: шаг назван", "Build debug APK with the game core and natives" in text)
        check("нативный сбой: ошибка компилятора", "egl_bridge.c:106:24: error: expected ')'" in text)
        check("нативный сбой: ошибка линковщика", "undefined symbol: android_get_device_api_level" in text)
        check("нативный сбой: пояснение Gradle идёт за «What went wrong»", "Build command failed." in text)
        check("нативный сбой: ANSI вычищен", "\x1b" not in text)
        check("нативный сбой: коммит укорочен", "abcdef0123" in text and "abcdef01234" not in text)
        check("нативный сбой: есть конец лога", "Конец лога:" in text and "BUILD FAILED" in text)

        check("Kotlin-ошибка попадает в строки с причиной", any(x.startswith("e: ") for x in key_lines("e: file:///A.kt:3:5 Unresolved reference: x\nok\n")))
        (d / "workflow-drift.txt").write_text("workflow ОТЛИЧАЕТСЯ\n", encoding="utf-8")
        check("расхождение workflow попадает в отчёт", "ВНИМАНИЕ: workflow ОТЛИЧАЕТСЯ" in render({"core": "failure"}, d))
        (d / "workflow-drift.txt").unlink()

        text_missing = render({"core": "failure", "ndk": "skipped", "native": "skipped", "verify": "skipped"}, d)
        check("нет лога: сказано прямо", "Лога этого шага нет (core-fetch.log)" in text_missing)

        (d / "native-build.log").write_text("error: x\n" * 5000, encoding="utf-8")
        big = render({"core": "success", "ndk": "success", "native": "failure", "verify": "skipped"}, d)
        check("размер ограничен", len(big) <= MAX_TOTAL_CHARS + 40)
        long_line = "error: " + "y" * 5000
        (d / "native-build.log").write_text(long_line + "\n", encoding="utf-8")
        check("длинная строка укорочена", all(len(x) <= MAX_LINE_CHARS + 1 for x in key_lines(long_line)))

    for name in failures:
        print("САМОПРОВЕРКА: не прошло:", name)
    print("САМОПРОВЕРКА ci_build_status:", "ОШИБКИ" if failures else "всё прошло")
    return 1 if failures else 0


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description="Отчёт о сбое сборки для запасного APK")
    parser.add_argument("--core", default="skipped")
    parser.add_argument("--ndk", default="skipped")
    parser.add_argument("--native", default="skipped")
    parser.add_argument("--verify", default="skipped")
    parser.add_argument("--log-dir", default="ci-logs")
    parser.add_argument("--out")
    parser.add_argument("--run", default="")
    parser.add_argument("--sha", default="")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)

    if args.self_test:
        return self_test()
    if not args.out:
        parser.error("нужен --out")

    outcomes = {"core": args.core, "ndk": args.ndk, "native": args.native, "verify": args.verify}
    text = render(outcomes, Path(args.log_dir), args.run, args.sha)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
