#!/usr/bin/env bash
# Ставит NDK нужной версии через sdkmanager (нужна версия из апстрима: нативный код проверен именно с ней).
# Вынесено из workflow: файл workflow лежит в репозитории отдельно от zip с проектом и меняется вручную, а этот
# скрипт приезжает вместе с проектом, так что его можно чинить обычным обновлением zip.
# Использование: bash scripts/ci_install_ndk.sh [версия]   (по умолчанию 25.2.9519653)
set -uo pipefail

VERSION="${1:-25.2.9519653}"
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/usr/local/lib/android/sdk}}"
echo "Android SDK: $SDK"

if [ -f "$SDK/ndk/$VERSION/ndk-build" ]; then
  echo "NDK $VERSION уже установлен: $SDK/ndk/$VERSION"
  exit 0
fi

SDKMANAGER="$(command -v sdkmanager || true)"
if [ -z "$SDKMANAGER" ]; then
  for candidate in "$SDK"/cmdline-tools/latest/bin/sdkmanager "$SDK"/cmdline-tools/*/bin/sdkmanager "$SDK"/tools/bin/sdkmanager; do
    if [ -x "$candidate" ]; then SDKMANAGER="$candidate"; break; fi
  done
fi
if [ -z "$SDKMANAGER" ]; then
  echo "sdkmanager не найден. Содержимое $SDK:"
  ls -la "$SDK" || true
  echo "ERROR: sdkmanager not found"
  exit 1
fi
echo "sdkmanager: $SDKMANAGER"

# Лицензии: без них sdkmanager не ставит пакеты. `yes` получает SIGPIPE, когда sdkmanager дочитал, — это не ошибка.
yes | "$SDKMANAGER" --licenses > /dev/null 2>&1 || true

if ! "$SDKMANAGER" --install "ndk;$VERSION"; then
  echo "ERROR: sdkmanager failed to install ndk;$VERSION"
  exit 1
fi

if [ ! -f "$SDK/ndk/$VERSION/ndk-build" ]; then
  echo "ERROR: после установки нет $SDK/ndk/$VERSION/ndk-build. Установленные NDK:"
  ls -la "$SDK/ndk" || true
  exit 1
fi
echo "NDK $VERSION установлен: $SDK/ndk/$VERSION"
