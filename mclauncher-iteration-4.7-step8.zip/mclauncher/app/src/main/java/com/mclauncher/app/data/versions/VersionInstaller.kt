package com.mclauncher.app.data.versions

import com.mclauncher.app.data.net.HttpSource
import com.mclauncher.app.launch.GameDirectories
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

enum class InstallPhase { PREPARING, VERSION_FILE, ASSET_INDEX, DOWNLOADING, FINISHING }

/** Прогресс установки. [bytesTotal] и [filesTotal] — только то, что нужно скачать (уже имеющиеся файлы не считаются). */
data class InstallProgress(
    val phase: InstallPhase,
    val filesDone: Int = 0,
    val filesTotal: Int = 0,
    val bytesDone: Long = 0,
    val bytesTotal: Long = 0,
) {
    /** Доля от 0 до 1 или `null`, пока размер неизвестен. */
    val fraction: Float?
        get() = if (bytesTotal > 0) (bytesDone.toFloat() / bytesTotal).coerceIn(0f, 1f) else null
}

enum class UnsupportedReason {
    /** Профиль модлоадера (Fabric, Forge): наследует другую версию. Установка модлоадеров — этап 7. */
    MOD_LOADER_PROFILE,

    /** Версии со старой раскладкой ассетов (индекс с `virtual` или `map_to_resources`): читают звуки не по хэшам. Пока не поддерживаются. */
    LEGACY_ASSETS,
}

/** Почему установка не удалась. Тексты для пользователя подбирает UI-слой. */
sealed interface InstallError {
    data class Network(val detail: String?) : InstallError
    data class Server(val status: Int) : InstallError
    data class BadData(val detail: String?) : InstallError
    data class NotEnoughSpace(val neededBytes: Long, val freeBytes: Long) : InstallError
    data class Storage(val detail: String?) : InstallError
    data class Unsupported(val reason: UnsupportedReason) : InstallError
}

sealed interface InstallResult {
    data class Installed(val version: InstalledVersion) : InstallResult
    data class Failed(val error: InstallError) : InstallResult
}

private class InstallAbort(val error: InstallError) : Exception()

/**
 * Устанавливает версию игры: описание → индекс ассетов → клиентский jar, библиотеки, ассеты (параллельно, с проверкой
 * SHA-1) → метка установки. Уже имеющиеся и целые файлы не скачиваются, поэтому прерванную установку можно просто
 * запустить заново — она докачает остальное.
 *
 * Не бросает ничего, кроме отмены корутины: сбои возвращаются как [InstallResult.Failed]. При отмене недокачанные
 * файлы (`.part`) удаляются, целые остаются.
 *
 * Прогресс сообщается не чаще раза в [progressIntervalMs] и всегда — при смене стадии и в конце.
 */
class VersionInstaller(
    private val directories: GameDirectories,
    http: HttpSource,
    env: OsEnvironment,
    private val layout: VersionLayout = VersionLayout(directories),
    private val store: VersionStore = VersionStore(layout),
    private val planner: InstallPlanner = InstallPlanner(layout, env),
    private val downloader: FileDownloader = FileDownloader(http),
    private val concurrency: Int = DEFAULT_CONCURRENCY,
    private val largeFileConcurrency: Int = DEFAULT_LARGE_FILE_CONCURRENCY,
    private val largeFileThreshold: Long = DownloadSchedule.DEFAULT_THRESHOLD_BYTES,
    private val freeSpace: (File) -> Long = { it.usableSpace },
    private val clock: () -> Long = System::currentTimeMillis,
    private val progressIntervalMs: Long = 150L,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) {
    init {
        require(concurrency >= 1) { "concurrency must be at least 1" }
        require(largeFileConcurrency >= 1) { "largeFileConcurrency must be at least 1" }
        require(largeFileThreshold >= 1) { "largeFileThreshold must be at least 1" }
    }

    suspend fun install(entry: ManifestEntry, onProgress: (InstallProgress) -> Unit = {}): InstallResult =
        try {
            InstallResult.Installed(doInstall(entry, ProgressTracker(onProgress)))
        } catch (e: CancellationException) {
            throw e
        } catch (e: InstallAbort) {
            InstallResult.Failed(e.error)
        } catch (e: DownloadException) {
            InstallResult.Failed(e.toInstallError())
        } catch (e: VersionParseException) {
            InstallResult.Failed(InstallError.BadData(e.message))
        } catch (e: PlanException) {
            InstallResult.Failed(InstallError.BadData(e.message))
        } catch (e: IOException) {
            InstallResult.Failed(InstallError.Storage(e.message))
        } catch (e: SecurityException) {
            InstallResult.Failed(InstallError.Storage(e.message))
        }

    private suspend fun doInstall(entry: ManifestEntry, tracker: ProgressTracker): InstalledVersion {
        tracker.phase(InstallPhase.PREPARING)
        val jsonTask = planner.versionJsonTask(entry) // заодно проверяет id и адрес
        withContext(ioDispatcher) { directories.ensureCreated() }

        // 1. Описание версии.
        tracker.phase(InstallPhase.VERSION_FILE)
        downloader.download(jsonTask)
        val version = withContext(ioDispatcher) { VersionParser.parseVersion(jsonTask.target.readText()) }
        if (version.inheritsFrom != null) throw InstallAbort(InstallError.Unsupported(UnsupportedReason.MOD_LOADER_PROFILE))

        // 2. Индекс ассетов.
        tracker.phase(InstallPhase.ASSET_INDEX)
        val indexTask = planner.assetIndexTask(version)
        downloader.download(indexTask)
        val index = withContext(ioDispatcher) { VersionParser.parseAssetIndex(indexTask.target.readText()) }
        if (index.virtual || index.mapToResources) {
            throw InstallAbort(InstallError.Unsupported(UnsupportedReason.LEGACY_ASSETS))
        }

        // 3. Что ещё нужно скачать.
        val tasks = planner.coreTasks(version) + planner.assetTasks(index)
        val pending = withContext(ioDispatcher) { tasks.filterNot { downloader.isUpToDate(it) } }
        val bytesTotal = pending.sumOf { it.size.coerceAtLeast(0) }

        if (pending.isNotEmpty()) {
            val needed = bytesTotal + SPACE_MARGIN_BYTES
            val free = withContext(ioDispatcher) { freeSpace(directories.root) }
            if (free < needed) throw InstallAbort(InstallError.NotEnoughSpace(needed, free))
        }

        // 4. Загрузка.
        tracker.startDownload(filesTotal = pending.size, bytesTotal = bytesTotal)
        val schedule = DownloadSchedule.of(pending, largeFileThreshold)
        coroutineScope {
            // Две очереди работают одновременно: мелких файлов — много параллельно, больших — немного и с самых крупных.
            val smallGate = Semaphore(concurrency)
            val largeGate = Semaphore(largeFileConcurrency)
            fun CoroutineScope.launchAll(tasks: List<DownloadTask>, gate: Semaphore) = tasks.map { task ->
                async {
                    gate.withPermit {
                        downloader.download(task, assumeMissing = true, onBytes = tracker::addBytes)
                        tracker.fileDone()
                    }
                }
            }
            (launchAll(schedule.large, largeGate) + launchAll(schedule.small, smallGate)).awaitAll()
        }

        // 5. Метка — только когда всё скачано.
        tracker.phase(InstallPhase.FINISHING)
        val installed = InstalledVersion(
            id = entry.id,
            type = version.type,
            mainClass = version.mainClass,
            assetsId = version.assets,
            javaMajor = version.java.majorVersion,
            releaseTime = version.releaseTime ?: entry.releaseTime,
            installedAt = clock(),
        )
        withContext(ioDispatcher) { store.writeMarker(installed) }
        tracker.finish()
        return installed
    }

    private fun DownloadException.toInstallError(): InstallError = when (reason) {
        DownloadException.Reason.HTTP -> InstallError.Server(status ?: 0)
        DownloadException.Reason.NETWORK -> InstallError.Network(message)
        DownloadException.Reason.HASH, DownloadException.Reason.SIZE -> InstallError.BadData(message)
        DownloadException.Reason.STORAGE -> InstallError.Storage(message)
    }

    /** Собирает счётчики из нескольких потоков и сообщает прогресс с ограничением частоты. */
    private inner class ProgressTracker(private val sink: (InstallProgress) -> Unit) {
        @Volatile private var current = InstallPhase.PREPARING
        @Volatile private var filesTotal = 0
        @Volatile private var bytesTotal = 0L
        private val bytes = AtomicLong()
        private val files = AtomicInteger()
        private val lastEmit = AtomicLong(Long.MIN_VALUE)

        fun phase(phase: InstallPhase) {
            current = phase
            emit(force = true)
        }

        fun startDownload(filesTotal: Int, bytesTotal: Long) {
            this.filesTotal = filesTotal
            this.bytesTotal = bytesTotal
            current = InstallPhase.DOWNLOADING
            emit(force = true)
        }

        fun addBytes(delta: Long) {
            bytes.addAndGet(delta)
            emit(force = false)
        }

        fun fileDone() {
            files.incrementAndGet()
            emit(force = false)
        }

        fun finish() = emit(force = true)

        private fun emit(force: Boolean) {
            val now = clock()
            val last = lastEmit.get()
            if (!force && now - last < progressIntervalMs) return
            if (!force && !lastEmit.compareAndSet(last, now)) return
            if (force) lastEmit.set(now)
            sink(
                InstallProgress(
                    phase = current,
                    filesDone = files.get(),
                    filesTotal = filesTotal,
                    bytesDone = bytes.get().coerceAtLeast(0),
                    bytesTotal = bytesTotal,
                ),
            )
        }
    }

    companion object {
        /** Одновременных загрузок мелких файлов (ассеты): их время — это задержка, а не канал. */
        const val DEFAULT_CONCURRENCY = 16

        /** Одновременных загрузок больших файлов: их время — это канал, больше соединений не быстрее. */
        const val DEFAULT_LARGE_FILE_CONCURRENCY = 3

        /** Запас места сверх размера файлов: описания, метки и неточные размеры. */
        private const val SPACE_MARGIN_BYTES = 50L * 1024 * 1024
    }
}
