package com.mclauncher.engine.launch

import java.io.File
import java.io.IOException

/**
 * Итог работы процесса игры, который он оставляет лаунчеру. Процесс игры завершается сразу после выхода JVM
 * (нативный код вызывает `System.exit`), поэтому всё нужное записывается в файл ещё до этого, синхронно.
 *
 * Два файла в папке журналов:
 *  * [SESSION_FILE] — «игра запущена»: пишется при старте, удаляется при нормальном выходе JVM;
 *  * [EXIT_FILE] — «игра завершилась»: код выхода, сигнал, сообщение.
 * Если остался только первый, а процесса игры уже нет, — игра упала так, что JVM не успела сообщить (SIGSEGV и т. п.).
 */
data class GameExitReport(
    val exitCode: Int,
    val isSignal: Boolean,
    /** Пояснение для поддержки (например, текст исключения до старта JVM); одна строка. */
    val message: String? = null,
    /** Путь к журналу игры. */
    val logFile: String? = null,
    val timeMillis: Long = 0L,
) {
    /** Выход с кодом 0 — игрок закрыл игру сам. */
    val isNormal: Boolean get() = exitCode == 0 && !isSignal

    fun format(): String = buildString {
        appendLine("exit_code=$exitCode")
        appendLine("signal=$isSignal")
        appendLine("time=$timeMillis")
        if (logFile != null) appendLine("log=${escape(logFile)}")
        if (message != null) appendLine("message=${escape(message)}")
    }

    companion object {
        const val EXIT_FILE = "game-exit.txt"
        const val SESSION_FILE = "game-session.txt"

        /** Разбирает [format]. `null`, если в тексте нет кода выхода (файл оборван или чужой). */
        fun parse(text: String): GameExitReport? {
            val values = HashMap<String, String>()
            for (line in text.lineSequence()) {
                val index = line.indexOf('=')
                if (index <= 0) continue
                values[line.substring(0, index)] = line.substring(index + 1)
            }
            val code = values["exit_code"]?.trim()?.toIntOrNull() ?: return null
            return GameExitReport(
                exitCode = code,
                isSignal = values["signal"]?.trim() == "true",
                message = values["message"]?.let(::unescape),
                logFile = values["log"]?.let(::unescape),
                timeMillis = values["time"]?.trim()?.toLongOrNull() ?: 0L,
            )
        }

        /** Пишет отчёт во временный файл и переименовывает: читатель никогда не увидит половину файла. */
        fun write(dir: File, report: GameExitReport) {
            dir.mkdirs()
            val target = File(dir, EXIT_FILE)
            val temp = File(dir, "$EXIT_FILE.tmp")
            temp.writeText(report.format())
            if (!temp.renameTo(target)) {
                target.writeText(report.format())
                temp.delete()
            }
        }

        fun markSessionStarted(dir: File, timeMillis: Long) {
            dir.mkdirs()
            File(dir, EXIT_FILE).delete()
            File(dir, SESSION_FILE).writeText("started=$timeMillis\n")
        }

        fun clearSessionMarker(dir: File) {
            File(dir, SESSION_FILE).delete()
        }

        /**
         * Забирает итог игры для показа игроку: удаляет файлы, чтобы он показывался один раз.
         *
         * @param isGameProcessAlive жив ли ещё процесс игры (проверяет приложение)
         * @return итог или `null`, если игра ещё идёт, не запускалась или закончилась нормально
         */
        fun consume(dir: File, isGameProcessAlive: () -> Boolean): GameExitReport? {
            val exit = File(dir, EXIT_FILE)
            val session = File(dir, SESSION_FILE)
            try {
                if (exit.isFile) {
                    val report = parse(exit.readText())
                    exit.delete()
                    session.delete()
                    return report?.takeUnless { it.isNormal }
                        ?: if (report == null) GameExitReport(exitCode = -1, isSignal = false, message = "Unreadable exit report") else null
                }
                if (session.isFile && !isGameProcessAlive()) {
                    session.delete()
                    return GameExitReport(exitCode = -1, isSignal = true, message = "The game process ended without a report (crash)")
                }
            } catch (e: IOException) {
                return null
            }
            return null
        }

        private fun escape(value: String): String =
            value.replace("\\", "\\\\").replace("\n", "\\n").replace("\r", "\\r")

        private fun unescape(value: String): String {
            val out = StringBuilder(value.length)
            var i = 0
            while (i < value.length) {
                val c = value[i]
                if (c == '\\' && i + 1 < value.length) {
                    when (value[i + 1]) {
                        'n' -> out.append('\n')
                        'r' -> out.append('\r')
                        '\\' -> out.append('\\')
                        else -> out.append(c).append(value[i + 1])
                    }
                    i += 2
                } else {
                    out.append(c)
                    i++
                }
            }
            return out.toString()
        }
    }
}
