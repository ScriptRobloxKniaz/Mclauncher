package com.mclauncher.engine.launch

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class GameExitReportTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val dir by lazy { File(tmp.root, "logs") }

    @Test
    fun formatAndParseRoundTrip() {
        val report = GameExitReport(exitCode = 134, isSignal = true, message = "line one\nline two\\end", logFile = "/g/logs/latest.log", timeMillis = 1234L)

        assertEquals(report, GameExitReport.parse(report.format()))
    }

    @Test
    fun parseRejectsTextWithoutAnExitCode() {
        assertNull(GameExitReport.parse(""))
        assertNull(GameExitReport.parse("signal=true\n"))
        assertNull(GameExitReport.parse("exit_code=abc\n"))
    }

    @Test
    fun onlyCodeZeroWithoutSignalIsNormal() {
        assertTrue(GameExitReport(0, false).isNormal)
        assertFalse(GameExitReport(0, true).isNormal)
        assertFalse(GameExitReport(1, false).isNormal)
    }

    @Test
    fun writeLeavesNoTemporaryFile() {
        GameExitReport.write(dir, GameExitReport(1, false))

        assertTrue(File(dir, GameExitReport.EXIT_FILE).isFile)
        assertFalse(File(dir, GameExitReport.EXIT_FILE + ".tmp").exists())
    }

    @Test
    fun aCrashedExitIsReportedOnceAndThenForgotten() {
        GameExitReport.markSessionStarted(dir, 10L)
        GameExitReport.write(dir, GameExitReport(exitCode = 1, isSignal = false, message = "boom"))

        val first = GameExitReport.consume(dir) { true }
        val second = GameExitReport.consume(dir) { true }

        assertNotNull(first)
        assertEquals(1, first!!.exitCode)
        assertEquals("boom", first.message)
        assertNull(second)
        assertFalse(File(dir, GameExitReport.SESSION_FILE).exists())
    }

    @Test
    fun aNormalExitProducesNothing() {
        GameExitReport.markSessionStarted(dir, 10L)
        GameExitReport.write(dir, GameExitReport(exitCode = 0, isSignal = false))

        assertNull(GameExitReport.consume(dir) { false })
        assertFalse(File(dir, GameExitReport.EXIT_FILE).exists())
        assertFalse(File(dir, GameExitReport.SESSION_FILE).exists())
    }

    @Test
    fun aRunningGameIsNotReported() {
        GameExitReport.markSessionStarted(dir, 10L)

        assertNull(GameExitReport.consume(dir) { true })
        assertTrue("the marker must stay while the game runs", File(dir, GameExitReport.SESSION_FILE).isFile)
    }

    @Test
    fun aVanishedProcessWithOnlyTheMarkerIsACrash() {
        GameExitReport.markSessionStarted(dir, 10L)

        val report = GameExitReport.consume(dir) { false }

        assertNotNull(report)
        assertTrue(report!!.isSignal)
        assertFalse(report.isNormal)
        assertFalse(File(dir, GameExitReport.SESSION_FILE).exists())
        assertNull(GameExitReport.consume(dir) { false })
    }

    @Test
    fun nothingHappenedWhenTheGameNeverStarted() {
        assertNull(GameExitReport.consume(dir) { false })
    }

    @Test
    fun anUnreadableReportIsStillReported() {
        dir.mkdirs()
        File(dir, GameExitReport.EXIT_FILE).writeText("garbage")

        val report = GameExitReport.consume(dir) { false }

        assertNotNull(report)
        assertFalse(report!!.isNormal)
        assertFalse(File(dir, GameExitReport.EXIT_FILE).exists())
    }

    @Test
    fun startingANewSessionDropsAStaleExitReport() {
        GameExitReport.write(dir, GameExitReport(1, false))

        GameExitReport.markSessionStarted(dir, 20L)

        assertFalse(File(dir, GameExitReport.EXIT_FILE).exists())
        assertTrue(File(dir, GameExitReport.SESSION_FILE).isFile)
    }

    @Test
    fun clearingTheMarkerIsSafeWhenThereIsNone() {
        GameExitReport.clearSessionMarker(dir)
        GameExitReport.markSessionStarted(dir, 1L)
        GameExitReport.clearSessionMarker(dir)

        assertFalse(File(dir, GameExitReport.SESSION_FILE).exists())
    }
}
