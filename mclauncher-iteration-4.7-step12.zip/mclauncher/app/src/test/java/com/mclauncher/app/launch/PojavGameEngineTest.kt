package com.mclauncher.app.launch

import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.account.AccountType
import com.mclauncher.app.data.versions.EngineLibraryPolicy
import com.mclauncher.app.data.versions.Fixtures
import com.mclauncher.app.data.versions.InstallPlanner
import com.mclauncher.app.data.versions.OsEnvironment
import com.mclauncher.app.data.versions.VersionLayout
import com.mclauncher.app.data.versions.VersionParser
import com.mclauncher.engine.EngineEnvironment
import com.mclauncher.engine.EngineLayout
import com.mclauncher.engine.LwjglVersion
import com.mclauncher.engine.launch.NativeLaunchPlan
import com.mclauncher.engine.launch.RendererProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class PojavGameEngineTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val dirs by lazy { GameDirectories(File(tmp.root, ".minecraft")).also { it.ensureCreated() } }
    private val layout by lazy { VersionLayout(dirs) }
    private val account = Account(1, AccountType.OFFLINE, "Steve", "5627dd98-e6be-3c21-b8a8-e92344183641", true, 0L)

    private val engineLayout by lazy {
        EngineLayout(
            componentsDir = File(tmp.root, "components"),
            runtimesDir = File(tmp.root, "runtimes"),
            nativeLibraryDir = File(tmp.root, "lib"),
            abi = "arm64-v8a",
        )
    }

    /** Планы, которые движок передал на запуск игры. */
    private val started = ArrayList<NativeLaunchPlan>()
    private var gameRunning = false

    private fun engine(layoutProvider: () -> EngineLayout? = { engineLayout }): PojavGameEngine {
        val env = OsEnvironment.LINUX_ARM64
        return PojavGameEngine(
            specFactory = LaunchSpecFactory(
                layout = layout,
                env = env,
                planner = InstallPlanner(layout, env, libraryFilter = EngineLibraryPolicy::isNeeded, libraryReplacement = EngineLibraryPolicy::replacement),
                launcherName = "MCLauncher",
                launcherVersion = "0.1.0",
            ),
            readVersion = { id -> VersionParser.parseVersion(layout.versionJson(id).readText()) },
            layout = layoutProvider,
            environment = { d ->
                EngineEnvironment(
                    gameDir = d.root, userHome = tmp.root, cacheDir = File(tmp.root, "cache"),
                    timezone = "Asia/Baku", androidRelease = "15", screenWidth = 2400, screenHeight = 1080, cpuCores = 8,
                )
            },
            startGame = { plan -> started += plan },
            isGameRunning = { gameRunning },
            currentPath = { "/system/bin" },
            ioDispatcher = Dispatchers.Unconfined,
        )
    }

    private fun touch(file: File) {
        file.parentFile.mkdirs()
        file.writeText("x")
    }

    /** Ядро для версии `version_modern.json` (LWJGL 3.3.3, Java 21) целиком на месте. */
    private fun installCore() {
        touch(File(engineLayout.nativeLibraryDir, "libpojavexec.so"))
        touch(File(engineLayout.nativeLibraryDir, "libopenal.so"))
        touch(File(engineLayout.nativeLibraryDir, "libgl4es_114.so"))
        val lwjgl = LwjglVersion.V3_3_3
        touch(File(engineLayout.lwjglDir(lwjgl), "lwjgl.jar"))
        touch(File(engineLayout.lwjglNativesDir(lwjgl), "liblwjgl.so"))
        touch(engineLayout.launchWrapperJar)
        touch(engineLayout.libPatcherJar)
        touch(engineLayout.javaExecutable(21))
        touch(File(engineLayout.javaHome(21), "lib/aarch64/server/libjvm.so"))
    }

    private fun request(versionId: String = "1.21.1", renderer: RendererProfile = RendererProfile.GL4ES) =
        LaunchRequest(account, versionId, ramMb = 2048, directories = dirs, renderer = renderer)

    private fun installVersionJson(id: String, text: String) {
        layout.versionDir(id).mkdirs()
        layout.versionJson(id).writeText(text)
    }

    private fun launch(
        engine: PojavGameEngine = engine(),
        versionId: String = "1.21.1",
        renderer: RendererProfile = RendererProfile.GL4ES,
    ) = runBlocking { engine.launch(request(versionId, renderer)) }

    private fun failure(result: LaunchResult): LaunchFailure =
        (result as? LaunchResult.Failed)?.failure ?: error("Expected Failed but got $result")

    private val reportFile get() = File(dirs.logs, PojavGameEngine.PREVIEW_FILE_NAME)

    @Test
    fun aCoreThatIsNotReadyIsReportedAndTheGameIsNotStarted() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))

        val failure = failure(launch()) as LaunchFailure.CoreNotReady

        assertTrue(failure.missing!!.contains("libpojavexec.so"))
        assertTrue(failure.missing!!.contains("libgl4es_114.so"))
        assertTrue(started.isEmpty())
        assertTrue("the report must be written even when the core is missing", reportFile.isFile)
    }

    @Test
    fun aReadyCoreStartsTheGameWithAPlan() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        installCore()

        val result = launch()

        assertEquals(LaunchResult.Started(placeholder = false, note = File(dirs.logs, "latest.log").path), result)
        val plan = started.single()
        assertEquals(engineLayout.javaExecutable(21).path, plan.argv.first())
        assertTrue("-Dorg.lwjgl.opengl.libname=libgl4es_114.so" in plan.argv)
        assertEquals(dirs.root.path, plan.workingDir)
        assertEquals(File(dirs.logs, "latest.log").path, plan.logFile)
        assertEquals(dirs.logs.path, plan.reportDir)
        assertEquals("1.21.1", plan.versionId)
        assertEquals("/system/bin", plan.environment.getValue("PATH").substringAfter(':'))
        assertTrue(File(tmp.root, "cache").isDirectory)
    }

    @Test
    fun theReportIsWrittenForAReadyCoreToo() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        installCore()

        launch()

        val report = reportFile.readText()
        assertTrue(report.contains("Core: ready"))
        assertTrue(report.contains("the game is being started"))
    }

    @Test
    fun aGameThatIsStillRunningBlocksASecondLaunch() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        installCore()
        gameRunning = true

        val result = launch()

        assertEquals(LaunchFailure.AlreadyLaunching, failure(result))
        assertTrue(started.isEmpty())
    }

    @Test
    fun aMissingRendererLibraryAloneBlocksTheLaunch() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        installCore()
        File(engineLayout.nativeLibraryDir, "libgl4es_114.so").delete()

        val failure = failure(launch()) as LaunchFailure.CoreNotReady

        assertTrue(failure.missing!!.contains("GL4ES"))
        assertTrue(started.isEmpty())
    }

    @Test
    fun theChosenRendererIsWhatTheGameStartsWith() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        installCore()
        touch(File(engineLayout.nativeLibraryDir, "libmobileglues.so"))

        val result = launch(renderer = RendererProfile.MOBILEGLUES)

        assertEquals(LaunchResult.Started(placeholder = false, note = File(dirs.logs, "latest.log").path), result)
        val plan = started.single()
        assertTrue("-Dorg.lwjgl.opengl.libname=libmobileglues.so" in plan.argv)
        assertEquals("opengles3_mobileglues", plan.environment.getValue("POJAV_RENDERER"))
        assertEquals("MobileGlues", plan.rendererName)
        assertTrue(reportFile.readText().contains("Renderer:  MobileGlues (opengles3_mobileglues, libmobileglues.so)"))
    }

    @Test
    fun theRendererPrivateFolderIsCreatedBeforeTheStart() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        installCore()
        touch(File(engineLayout.nativeLibraryDir, "libmobileglues.so"))
        val folder = File(tmp.root, "mobileglues")
        assertFalse(folder.exists())

        launch(renderer = RendererProfile.MOBILEGLUES)

        assertTrue(folder.isDirectory)
        assertEquals(folder.path, started.single().environment.getValue("MG_DIR_PATH"))
    }

    @Test
    fun theDefaultRendererNeedsNoPrivateFolder() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        installCore()

        launch()

        assertFalse(File(tmp.root, "mobileglues").exists())
    }

    @Test
    fun aMissingLibraryOfTheChosenRendererBlocksTheLaunchAndNamesTheRenderer() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        installCore() // GL4ES на месте, а у MobileGlues файла нет

        val failure = failure(launch(renderer = RendererProfile.MOBILEGLUES)) as LaunchFailure.CoreNotReady

        assertTrue(failure.missing!!.contains("MobileGlues"))
        assertTrue(failure.missing!!.contains("libmobileglues.so"))
        assertTrue(started.isEmpty())
    }

    @Test
    fun anUncreatableCacheFolderIsAnEngineError() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        installCore()
        File(tmp.root, "cache").writeText("this is a file, not a folder")

        val failure = failure(launch()) as LaunchFailure.EngineError

        assertTrue(failure.detail!!.contains("cache directory"))
        assertTrue(started.isEmpty())
    }

    @Test
    fun theReportHasTheCommandAndTheMissingCoreParts() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))

        launch()

        val report = reportFile.readText()
        assertTrue(report.contains("the game is NOT started"))
        assertTrue(report.contains("Version:   1.21.1"))
        assertTrue(report.contains("Core: NOT READY"))
        assertTrue(report.contains("LWJGL 3.3.3 natives for arm64-v8a"))
        assertTrue(report.contains("Command (one argument per line):"))
        assertTrue(report.contains("-Djava.library.path=${engineLayout.lwjglNativesDir(LwjglVersion.V3_3_3).path}"))
        assertTrue(report.contains("mio.Wrapper"))
    }

    @Test
    fun theReportNeverContainsTheAccessToken() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))

        launch()

        val lines = reportFile.readLines().map { it.trim() }
        val token = lines.indexOf("--accessToken")
        assertTrue(token >= 0)
        assertEquals("********", lines[token + 1])
    }

    @Test
    fun theReportListsFilesMissingOnDisk() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))

        launch()

        val report = reportFile.readText()
        assertTrue(report.contains("Files missing on disk"))
        assertTrue(report.contains("gson-2.10.1.jar"))
    }

    @Test
    fun anUnsupportedProcessorMeansTheEngineIsUnavailable() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))

        val result = launch(engine { null })

        assertEquals(LaunchFailure.EngineUnavailable, failure(result))
        assertFalse(reportFile.exists())
    }

    @Test
    fun aBrokenVersionDescriptionIsAnEngineError() {
        installVersionJson("1.21.1", "{ not json")

        val failure = failure(launch()) as LaunchFailure.EngineError

        assertTrue(failure.detail!!.contains("Cannot read the version description"))
        assertTrue(started.isEmpty())
    }

    @Test
    fun aMissingVersionFileIsAnEngineError() {
        val failure = failure(launch(versionId = "9.9.9")) as LaunchFailure.EngineError

        assertTrue(failure.detail!!.contains("Cannot read or write game files"))
    }

    @Test
    fun aJavaNewerThanTheRuntimesIsAnEngineError() {
        val text = Fixtures.text("version_modern.json").replace("\"majorVersion\": 21", "\"majorVersion\": 99")
        assertTrue(text.contains("99"))
        installVersionJson("1.21.1", text)

        val failure = failure(launch()) as LaunchFailure.EngineError

        assertTrue(failure.detail!!.contains("Cannot build the launch command"))
        assertTrue(failure.detail!!.contains("99"))
    }

    @Test
    fun anUnwritableLogsFolderIsReportedNotSwallowed() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        dirs.logs.deleteRecursively()
        dirs.logs.writeText("this is a file, not a folder")

        val failure = failure(launch()) as LaunchFailure.EngineError

        assertTrue(failure.detail!!.contains("Cannot read or write game files"))
    }

    @Test
    fun theWholeLauncherPathStartsTheGameWhenTheCoreIsReady() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        installCore()
        val launcher = GameLauncher(engine(), dirs, isVersionInstalled = { true }, ioDispatcher = Dispatchers.Unconfined)

        val result = runBlocking { launcher.launch(account, "1.21.1") }

        assertEquals(LaunchResult.Started(placeholder = false, note = File(dirs.logs, "latest.log").path), result)
        assertNotNull(started.singleOrNull())
    }

    @Test
    fun theWholeLauncherPathReportsAnIncompleteCore() {
        installVersionJson("1.21.1", Fixtures.text("version_modern.json"))
        val launcher = GameLauncher(engine(), dirs, isVersionInstalled = { true }, ioDispatcher = Dispatchers.Unconfined)

        val result = runBlocking { launcher.launch(account, "1.21.1") }

        assertTrue(failure(result) is LaunchFailure.CoreNotReady)
        assertNull(started.firstOrNull())
    }
}
