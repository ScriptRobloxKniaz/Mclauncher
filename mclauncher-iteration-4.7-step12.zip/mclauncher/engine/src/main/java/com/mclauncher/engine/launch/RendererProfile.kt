package com.mclauncher.engine.launch

import java.io.File
import java.io.Serializable

/*
 * Рендерер игры: какая библиотека переводит вызовы OpenGL игры в то, что умеет телефон, и какие переменные окружения
 * ей нужны. Значения портированы из ZalithLauncher 2 (`game/renderer/renderers/{GL4ES,NGGL4ES,MobileGlues,KopperZink}Renderer.kt`
 * и `setRendererEnv` в `game/launch/GameLauncher.kt`), GPL-3.0, Copyright (C) 2025-2026 MovTery and contributors —
 * см. THIRD_PARTY_NOTICES.md.
 */

/**
 * @property id значение `POJAV_RENDERER` и `SDL_OPENGL_LIBRARY`; по нему нативный код (`egl_bridge.c`) выбирает путь работы;
 * @property library имя файла библиотеки в папке нативных библиотек приложения; передаётся игре как
 *   `-Dorg.lwjgl.opengl.libname` и подгружается через `dlopen` до старта JVM;
 * @property env переменные окружения именно этого рендерера (общие для немесовых рендереров добавляет [environment]);
 * @property mesaBased библиотека собрана на основе Mesa: ей не нужны переменные Zink;
 * @property eglLibrary своя библиотека EGL (`POJAVEXEC_EGL` и `SDL_EGL_LIBRARY`), если рендерер приносит её с собой;
 *   `null` — берётся системная `libEGL.so`;
 * @property extraLibraries остальные файлы, которые рендерер подгружает сам и без которых он не заработает;
 * @property dataDirName имя личной папки рендерера внутри домашней папки игры (см. [dataDir]) или `null`, если она не нужна;
 * @property dataDirVariable переменная окружения, в которую кладётся путь к этой папке.
 */
data class RendererProfile(
    val id: String,
    val displayName: String,
    val library: String,
    val env: Map<String, String> = emptyMap(),
    val mesaBased: Boolean = false,
    val eglLibrary: String? = null,
    val extraLibraries: List<String> = emptyList(),
    val dataDirName: String? = null,
    val dataDirVariable: String? = null,
) : Serializable {

    /** Все файлы, которые должны лежать в папке нативных библиотек приложения. Без повторов, порядок стабильный. */
    val requiredLibraries: List<String>
        get() = (listOf(library) + listOfNotNull(eglLibrary) + extraLibraries).distinct()

    /** Копия с дополнительными переменными окружения; одноимённые значения заменяются. */
    fun withEnv(vararg more: Pair<String, String>): RendererProfile = copy(env = env + more)

    /** Личная папка рендерера (`null`, если ему она не нужна). [userHome] — домашняя папка игры. */
    fun dataDir(userHome: File): File? = dataDirName?.let { File(userHome, it) }

    /**
     * Полный набор переменных окружения рендерера, как у апстрима.
     * @param cacheDir папка для кэша шейдеров Mesa
     * @param nativeLibraryDir папка нативных библиотек приложения: по ней ищется своя EGL рендерера; `null` — не искать
     * @param dataDir личная папка рендерера (см. [dataDir]); передаётся в [dataDirVariable]
     */
    fun environment(cacheDir: String, nativeLibraryDir: File? = null, dataDir: File? = null): Map<String, String> {
        val result = LinkedHashMap<String, String>()
        result["SDL_OPENGL_LIBRARY"] = id
        if (id.startsWith("opengles2")) {
            result["LIBGL_ES"] = "2"
            result["LIBGL_MIPMAP"] = "3"
            result["LIBGL_NOERROR"] = "1"
            result["LIBGL_NOINTOVLHACK"] = "1"
            result["LIBGL_NORMALIZE"] = "1"
        }
        result.putAll(env)
        if (dataDirVariable != null && dataDir != null) result[dataDirVariable] = dataDir.path

        if (eglLibrary != null) {
            result["POJAVEXEC_EGL"] = eglLibrary
            // Как у апстрима: путь к EGL подсказывается SDL только если файл действительно лежит на месте.
            val file = nativeLibraryDir?.let { File(it, eglLibrary) }
            if (file != null && file.isFile) result["SDL_EGL_LIBRARY"] = file.path
        }
        result["POJAV_RENDERER"] = id

        if (!mesaBased) {
            // Апстрим выставляет это всем рендерерам не на Mesa — и GL4ES тоже; на GL4ES эти переменные ничего не меняют.
            result["MESA_LOADER_DRIVER_OVERRIDE"] = "zink"
            result["MESA_GLSL_CACHE_DIR"] = cacheDir
            result["MESA_GL_VERSION_OVERRIDE"] = "4.6"
            result["MESA_GLSL_VERSION_OVERRIDE"] = "460"
            result["force_glsl_extensions_warn"] = "true"
            result["allow_higher_compat_version"] = "true"
            result["allow_glsl_extension_directive_midshader"] = "true"
            result["LIB_MESA_NAME"] = library
        }
        return result
    }

    companion object {
        /**
         * GL4ES: OpenGL ES 2 → OpenGL 2.1. Самый простой и совместимый рендерер; подходит для версий примерно до 1.21.4
         * (так у апстрима).
         */
        val GL4ES = RendererProfile(
            id = "opengles2",
            displayName = "GL4ES",
            library = "libgl4es_114.so",
        )

        /**
         * Krypton Wrapper (NG-GL4ES): развитие GL4ES на OpenGL ES 3, показывает игре OpenGL 3.1. Идёт тем же путём
         * в `egl_bridge.c`, что и GL4ES (идентификатор начинается с `opengles`), поэтому нативный код менять не нужно.
         */
        val KRYPTON = RendererProfile(
            id = "opengles3",
            displayName = "Krypton Wrapper",
            library = "libng_gl4es.so",
            env = mapOf(
                "LIBGL_USE_MC_COLOR" to "1",
                "LIBGL_GL" to "31",
                "LIBGL_ES" to "3",
                "LIBGL_NORMALIZE" to "1",
                "LIBGL_NOERROR" to "1",
            ),
        )

        /**
         * MobileGlues: OpenGL 4.x поверх OpenGL ES 3 (у апстрима — «OpenGL 4.0»), для Minecraft от 1.17. Приносит свою EGL
         * (`libmobileglues.so` играет обе роли), читает настройки из `MG_DIR_PATH/config.json`; файл мы не пишем —
         * действуют значения самой библиотеки по умолчанию.
         *
         * Не передаётся `MG_COUNT_LAUNCH`, который у апстрима по умолчанию включён: что он делает, мы не выяснили.
         */
        val MOBILEGLUES = RendererProfile(
            id = "opengles3_mobileglues",
            displayName = "MobileGlues",
            library = "libmobileglues.so",
            env = mapOf(
                "LIBGL_ES" to "3",
                "LIBGL_EGL" to "libmobileglues.so",
            ),
            eglLibrary = "libmobileglues.so",
            dataDirName = "mobileglues",
            dataDirVariable = "MG_DIR_PATH",
        )

        /**
         * Zink (Kopper): OpenGL поверх Vulkan через Mesa. Нужен телефон с Vulkan 1.1+. Системный драйвер Vulkan
         * выбирается явно (`POJAV_ZINK_PREFER_SYSTEM_DRIVER`): свои драйверы (Turnip) лаунчер пока не ставит, а без
         * пути к ним нативный код всё равно вернулся бы к системному.
         */
        val ZINK = RendererProfile(
            id = "opengles3_desktopgl_zink_kopper",
            displayName = "Zink (Kopper)",
            library = "libglxshim.so",
            env = mapOf(
                "LIBGL_ES" to "3",
                "POJAV_ZINK_PREFER_SYSTEM_DRIVER" to "1",
            ),
            mesaBased = true,
            eglLibrary = "libEGL_mesa.so",
            extraLibraries = listOf("libzink_dri.so", "libglapi.so", "libcutils.so"),
        )

        /** Все рендереры, которые умеет запускать ядро. */
        val ALL: List<RendererProfile> = listOf(GL4ES, KRYPTON, MOBILEGLUES, ZINK)
    }
}
