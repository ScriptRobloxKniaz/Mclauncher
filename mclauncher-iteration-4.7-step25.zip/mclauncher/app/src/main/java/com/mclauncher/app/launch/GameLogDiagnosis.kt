package com.mclauncher.app.launch

import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

/** Вероятная причина, которую можно подсказать по журналу игры. */
enum class LogHint {
    /** Не хватило памяти или система не смогла выделить столько, сколько запросили. */
    MEMORY,

    /** Версия Java не подходит версии игры. */
    JAVA_VERSION,

    /** Не загрузилась нативная библиотека. */
    NATIVE_LIBRARY,

    /** Ошибка графики: окно или контекст OpenGL не создались. */
    GRAPHICS,

    /** Упала сама виртуальная машина Java (HotSpot написал `hs_err`): не ошибка игры, а сбой JVM на этом устройстве. */
    JVM_CRASH,

    /** Теги указателей Android (`Pointer tag … truncated`, `Field too big for insn`): в манифесте должно быть отключено. */
    POINTER_TAGGING,
}

/**
 * Разбор журнала игры (`logs/latest.log`) после вылета: хвост журнала для показа и подсказки по известным признакам.
 * Признаки — устойчивые сообщения самой Java и LWJGL/GLFW; подсказка лишь предположение, поэтому формулируется осторожно.
 */
object GameLogDiagnosis {

    const val DEFAULT_MAX_LINES = 40
    const val DEFAULT_MAX_BYTES = 24 * 1024

    /**
     * Последние [maxLines] строк файла (читаются не больше [maxBytes] с конца) или `null`, если файла нет, он пуст или
     * не читается. Работа с диском: вызывать вне главного потока.
     */
    fun tail(file: File?, maxLines: Int = DEFAULT_MAX_LINES, maxBytes: Int = DEFAULT_MAX_BYTES): String? {
        if (file == null || maxLines <= 0 || maxBytes <= 0) return null
        return try {
            if (!file.isFile) return null
            RandomAccessFile(file, "r").use { raf ->
                val length = raf.length()
                if (length <= 0L) return null
                val start = (length - maxBytes).coerceAtLeast(0L)
                val bytes = ByteArray((length - start).toInt())
                raf.seek(start)
                raf.readFully(bytes)
                var text = String(bytes, Charsets.UTF_8)
                // Начало могло оказаться посреди строки (или посреди символа): неполную первую строку отбрасываем.
                if (start > 0L) text = text.substringAfter('\n', missingDelimiterValue = "")
                val lines = text.trimEnd().lines()
                lines.takeLast(maxLines).joinToString("\n").ifBlank { null }
            }
        } catch (e: IOException) {
            null
        }
    }

    /** Подсказки по тексту журнала; порядок стабильный, без повторов. */
    fun hints(text: String?): List<LogHint> {
        if (text.isNullOrBlank()) return emptyList()
        val lower = text.lowercase()
        val result = ArrayList<LogHint>()
        if ("outofmemoryerror" in lower || "could not reserve enough space" in lower ||
            "insufficient memory for the java runtime" in lower || "cannot allocate memory" in lower
        ) {
            result += LogHint.MEMORY
        }
        if ("unsupportedclassversionerror" in lower || "more recent version of the java runtime" in lower) {
            result += LogHint.JAVA_VERSION
        }
        if ("unsatisfiedlinkerror" in lower) result += LogHint.NATIVE_LIBRARY
        if ("a fatal error has been detected by the java runtime environment" in lower || "hs_err_pid" in lower) {
            result += LogHint.JVM_CRASH
        }
        if ("pointer tag for" in lower || "field too big for insn" in lower) result += LogHint.POINTER_TAGGING
        if ("glfw error" in lower || "failed to create the glfw window" in lower || "unable to create opengl" in lower ||
            "failed to create window" in lower
        ) {
            result += LogHint.GRAPHICS
        }
        return result
    }

    // --- Отчёт о падении JVM (hs_err) ---

    private val HS_ERR_PATH = Regex("""(/[^\s#]*hs_err_pid\d+\.log)""")
    private val HS_ERR_NAME = Regex("""hs_err_pid\d+\.log""")

    /** Путь к `hs_err_pid<N>.log`, который Java назвала в журнале («An error report file … is saved as»). */
    fun hsErrPath(logText: String?): String? = logText?.let { HS_ERR_PATH.findAll(it).lastOrNull()?.groupValues?.get(1) }

    /**
     * Самый свежий `hs_err_pid*.log` в [gameDir], изменённый не раньше [notBeforeMs]: запасной путь, если в хвосте журнала
     * имя файла не уместилось. `null`, если такого нет.
     */
    fun newestHsErr(gameDir: File?, notBeforeMs: Long): File? {
        val files = gameDir?.listFiles() ?: return null
        return files.filter { it.isFile && HS_ERR_NAME.matches(it.name) && it.lastModified() >= notBeforeMs }
            .maxByOrNull { it.lastModified() }
    }

    /** Выдержка из `hs_err` файла [file] (см. [hsErrExcerpt]); `null`, если файла нет или он не читается. */
    fun hsErrExcerpt(file: File?, maxChars: Int = HS_ERR_MAX_CHARS): String? {
        if (file == null) return null
        return try {
            if (!file.isFile) return null
            // Важное лежит в начале файла; хвост (список библиотек, переменные окружения) огромен и не нужен.
            val text = RandomAccessFile(file, "r").use { raf ->
                val bytes = ByteArray(minOf(raf.length(), HS_ERR_READ_BYTES.toLong()).toInt())
                raf.readFully(bytes)
                String(bytes, Charsets.UTF_8)
            }
            hsErrExcerpt(text, maxChars)
        } catch (e: IOException) {
            null
        }
    }

    /**
     * Самое полезное из текста `hs_err`: заголовок (что и где упало, версия JVM), строки `Stack:`, `jvm_args:`, `Memory:` (в ней
     * размер страницы памяти), `uname:`, `CPU:`, `OS:` и первые кадры стека. Остальное для поддержки не нужно.
     */
    fun hsErrExcerpt(text: String, maxChars: Int = HS_ERR_MAX_CHARS): String? {
        if (text.isBlank()) return null
        val lines = text.lineSequence().map { it.trimEnd() }.toList()
        val picked = ArrayList<String>()
        // Заголовок: от начала до первой строки «--- T H R E A D ---».
        for (line in lines.take(HS_ERR_HEADER_LINES)) {
            if (line.startsWith("---------------")) break
            if (line.isNotBlank() && line != "#") picked += line
        }
        val wanted = listOf("Current thread", "Stack:", "jvm_args:", "java_command:", "Memory:", "uname:", "libc:", "CPU:", "OS:", "vm_info:", "siginfo:")
        val seen = HashSet<String>()
        for (line in lines) {
            val key = wanted.firstOrNull { line.startsWith(it) } ?: continue
            if (seen.add(key)) picked += line.take(HS_ERR_LINE_CHARS)
        }
        // Первые кадры стека: «V  [libjvm.so+0x…]», «C  [libc.so+0x…]», «j  java.lang…».
        val frames = lines.filter { it.length > 3 && it[1] == ' ' && it[2] == ' ' && it[3] == '[' && it[0] in "VCvj" }
            .take(HS_ERR_FRAMES)
        if (frames.isNotEmpty()) {
            picked += "Native frames:"
            picked += frames.map { it.take(HS_ERR_LINE_CHARS) }
        }
        if (picked.isEmpty()) return null
        val joined = picked.joinToString("\n")
        return if (joined.length <= maxChars) joined else joined.take(maxChars - 1).trimEnd() + "…"
    }

    /**
     * Собирает текст для окна и для «Скопировать отчёт»: конец журнала, выдержка из `hs_err` и данные об устройстве. Пустые
     * части пропускаются; если ничего нет — `null`.
     */
    fun withExtras(tail: String?, hsErr: String?, device: String?): String? {
        val parts = ArrayList<String>()
        tail?.takeIf { it.isNotBlank() }?.let { parts += it }
        hsErr?.takeIf { it.isNotBlank() }?.let { parts += "— hs_err (выдержка) —\n$it" }
        device?.takeIf { it.isNotBlank() }?.let { parts += "— устройство —\n$it" }
        return parts.joinToString("\n\n").ifBlank { null }
    }

    private const val HS_ERR_MAX_CHARS = 3500
    private const val HS_ERR_READ_BYTES = 96 * 1024
    private const val HS_ERR_HEADER_LINES = 40
    private const val HS_ERR_LINE_CHARS = 300
    private const val HS_ERR_FRAMES = 12
}
