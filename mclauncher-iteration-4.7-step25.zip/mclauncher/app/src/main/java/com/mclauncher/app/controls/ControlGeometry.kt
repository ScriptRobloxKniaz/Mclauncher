package com.mclauncher.app.controls

/** Прямоугольник в пикселях экрана. */
data class PxRect(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f

    fun contains(x: Float, y: Float): Boolean = x >= left && x <= right && y >= top && y <= bottom
}

/**
 * Где на экране стоит кнопка и куда попал палец. Чистая математика без Android: одни и те же правила используют игра и редактор,
 * поэтому кнопка, которую видно, и кнопка, которая нажимается, всегда совпадают.
 *
 * Положение кнопки — доля экрана для левого верхнего угла, размер — в dp (см. [ControlButton]); [density] переводит dp в пиксели.
 * Перед расчётом кнопку стоит привести к экрану ([fitted]): на узком экране кнопка у правого края иначе вылезла бы за него.
 */
object ControlGeometry {

    /** Кнопка, сдвинутая так, чтобы целиком помещаться на экране [screenWidthPx] × [screenHeightPx]. */
    fun fitted(button: ControlButton, screenWidthPx: Float, screenHeightPx: Float, density: Float): ControlButton {
        if (density <= 0f) return button
        return button.clampedTo(screenWidthPx / density, screenHeightPx / density)
    }

    fun rectOf(button: ControlButton, screenWidthPx: Float, screenHeightPx: Float, density: Float): PxRect {
        val left = button.x * screenWidthPx
        val top = button.y * screenHeightPx
        return PxRect(left, top, left + button.widthDp * density, top + button.heightDp * density)
    }

    /** Попал ли палец в кнопку. Для круглой кнопки попадание считается по эллипсу, вписанному в прямоугольник. */
    fun hits(button: ControlButton, x: Float, y: Float, screenWidthPx: Float, screenHeightPx: Float, density: Float): Boolean {
        val rect = rectOf(fitted(button, screenWidthPx, screenHeightPx, density), screenWidthPx, screenHeightPx, density)
        if (!rect.contains(x, y)) return false
        if (button.shape != ButtonShape.CIRCLE) return true
        val rx = rect.width / 2f
        val ry = rect.height / 2f
        if (rx <= 0f || ry <= 0f) return false
        val dx = (x - rect.centerX) / rx
        val dy = (y - rect.centerY) / ry
        return dx * dx + dy * dy <= 1f
    }

    /** Самая верхняя кнопка под пальцем (в списке она последняя: рисуется поверх остальных) или `null`. */
    fun topmostAt(buttons: List<ControlButton>, x: Float, y: Float, screenWidthPx: Float, screenHeightPx: Float, density: Float): ControlButton? =
        buttons.lastOrNull { hits(it, x, y, screenWidthPx, screenHeightPx, density) }

    /**
     * Попал ли палец в «уголок» изменения размера у правого нижнего угла [rect]: квадрат со стороной [handlePx], на две трети внутри кнопки
     * и на треть снаружи, чтобы за него можно было ухватиться и у маленькой кнопки.
     */
    fun onResizeHandle(rect: PxRect, x: Float, y: Float, handlePx: Float): Boolean {
        val inside = handlePx * 2f / 3f
        val outside = handlePx / 3f
        return x >= rect.right - inside && x <= rect.right + outside && y >= rect.bottom - inside && y <= rect.bottom + outside
    }
}

/**
 * Новый размер кнопки [id]. У круглой кнопки стороны всегда равны (берётся среднее), иначе она стала бы овалом. Размер и положение
 * приводятся к допустимым, как при любой другой правке.
 */
fun ControlLayout.withSize(id: String, widthDp: Float, heightDp: Float, screenWidthDp: Float, screenHeightDp: Float): ControlLayout =
    changed(id, screenWidthDp, screenHeightDp) { button ->
        if (button.shape == ButtonShape.CIRCLE) {
            val side = Math.round((widthDp + heightDp) / 2f)
            button.copy(widthDp = side, heightDp = side)
        } else {
            button.copy(widthDp = Math.round(widthDp), heightDp = Math.round(heightDp))
        }
    }
