package com.mclauncher.app.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.controls.ControlEditorActivity
import com.mclauncher.app.ui.components.NeonButton
import com.mclauncher.app.ui.components.NeonCard

/**
 * Раздел «Управление в игре»: короткое пояснение и кнопка, открывающая редактор раскладки экранных кнопок ([ControlEditorActivity]).
 * Сама раскладка лежит в файле ([com.mclauncher.app.controls.ControlLayoutStore]); раздел ничего не хранит и в настройках DataStore не участвует.
 */
@Composable
fun ControlsSection(modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    val context = LocalContext.current

    NeonCard(modifier = modifier) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Build,
                    contentDescription = null,
                    tint = colors.primary,
                    modifier = Modifier.size(24.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.settings_controls_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.onSurface,
                    )
                    Text(
                        text = stringResource(R.string.settings_controls_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                    )
                }
            }

            Text(
                text = stringResource(R.string.settings_controls_note),
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
            )

            NeonButton(
                text = stringResource(R.string.settings_controls_edit),
                onClick = { context.startActivity(ControlEditorActivity.intent(context)) },
                icon = Icons.Filled.Build,
            )
        }
    }
}
