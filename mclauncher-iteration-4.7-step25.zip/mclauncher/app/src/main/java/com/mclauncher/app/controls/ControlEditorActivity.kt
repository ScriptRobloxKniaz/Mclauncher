package com.mclauncher.app.controls

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputFilter
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.mclauncher.app.R

/**
 * Редактор раскладки экранного управления. Открывается из «Настроек → Управление в игре» в основном процессе лаунчера, игра для него
 * не нужна: раскладку можно настроить заранее и проверять, не запуская Minecraft.
 *
 * Все кнопки на экране — тот же [ControlsView], что и в игре, только в режиме редактора: кнопку выбирают касанием, двигают пальцем,
 * размер меняют уголком справа внизу. Сверху по центру панель: добавить, копия, удалить, свойства, сброс, выход. Каждая правка сразу
 * сохраняется в [ControlLayoutStore], отдельной кнопки «Сохранить» нет. Игра читает файл при запуске.
 *
 * Правки раскладки делает чистая логика ([ControlLayout]), здесь только окна и вызовы. На устройстве не проверялся (собирается в CI).
 */
class ControlEditorActivity : ComponentActivity(), ControlsView.EditListener {

    private lateinit var store: ControlLayoutStore
    private lateinit var controls: ControlsView
    private lateinit var hintView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ControlLayoutStore.forFilesDir(filesDir)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(BACKGROUND))
        enterImmersiveMode()

        controls = ControlsView(this).apply {
            editMode = true
            layout = store.load()
            editor = this@ControlEditorActivity
        }
        val root = FrameLayout(this).apply { setBackgroundColor(BACKGROUND) }
        root.addView(controls, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 32, 36, 42))
                cornerRadius = dp(22).toFloat()
            }
            setPadding(dp(6), 0, dp(6), 0)
            elevation = dp(6).toFloat()
        }
        val size = dp(44)
        bar.addView(toolButton("✚", R.string.controls_editor_add) { addButton() }, LinearLayout.LayoutParams(size, size))
        bar.addView(toolButton("❐", R.string.controls_editor_duplicate) { duplicateSelected() }, LinearLayout.LayoutParams(size, size))
        bar.addView(toolButton("✕", R.string.controls_editor_delete) { deleteSelected() }, LinearLayout.LayoutParams(size, size))
        bar.addView(toolButton("⚙", R.string.controls_editor_properties) { propertiesOfSelected() }, LinearLayout.LayoutParams(size, size))
        bar.addView(toolButton("↺", R.string.controls_editor_reset) { confirmReset() }, LinearLayout.LayoutParams(size, size))
        bar.addView(toolButton("✓", R.string.controls_editor_done) { finish() }, LinearLayout.LayoutParams(size, size))
        root.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = dp(8)
            },
        )

        // Подсказка под панелью. Касания она не перехватывает (не clickable), поэтому кнопки под ней можно двигать.
        hintView = TextView(this).apply {
            text = getString(R.string.controls_editor_hint)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(Color.argb(230, 255, 255, 255))
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
            gravity = Gravity.CENTER
        }
        root.addView(
            hintView,
            FrameLayout.LayoutParams(dp(420), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = dp(64)
            },
        )
        setContentView(root)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    private fun enterImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ---------------------------------------------------------------- ControlsView.EditListener

    override fun onSelected(buttonId: String?) {
        // Игрок разобрался с редактором, подсказка больше не нужна.
        if (buttonId != null) hintView.visibility = View.GONE
    }

    override fun onLayoutChanged(layout: ControlLayout) = Unit

    override fun onGestureFinished(layout: ControlLayout) {
        save(layout)
    }

    // ---------------------------------------------------------------- действия панели

    private fun screenWidthDp(): Float = (if (controls.width > 0) controls.width else resources.displayMetrics.widthPixels).toFloat() / resources.displayMetrics.density

    private fun screenHeightDp(): Float = (if (controls.height > 0) controls.height else resources.displayMetrics.heightPixels).toFloat() / resources.displayMetrics.density

    private fun selectedButton(): ControlButton? = controls.selectedId?.let { controls.layout.find(it) }

    private fun save(layout: ControlLayout) {
        if (!store.save(layout)) Toast.makeText(this, R.string.controls_editor_save_failed, Toast.LENGTH_LONG).show()
    }

    /** Применяет новую раскладку: показ и запись на диск. */
    private fun commitLayout(layout: ControlLayout, select: String? = controls.selectedId) {
        controls.layout = layout
        controls.selectedId = select
        save(layout)
    }

    private fun addButton() {
        pickTarget { target ->
            val added = controls.layout.withNewButton(target.id, screenWidthDp(), screenHeightDp())
            if (added == null) {
                Toast.makeText(this, getString(R.string.controls_editor_limit, ControlLayout.MAX_BUTTONS), Toast.LENGTH_SHORT).show()
            } else {
                hintView.visibility = View.GONE
                commitLayout(added.first, select = added.second.id)
            }
        }
    }

    private fun duplicateSelected() {
        val selected = selectedButton()
        if (selected == null) {
            Toast.makeText(this, R.string.controls_editor_select_first, Toast.LENGTH_SHORT).show()
            return
        }
        val copy = controls.layout.withDuplicate(selected.id, screenWidthDp(), screenHeightDp())
        if (copy == null) {
            Toast.makeText(this, getString(R.string.controls_editor_limit, ControlLayout.MAX_BUTTONS), Toast.LENGTH_SHORT).show()
        } else {
            commitLayout(copy.first, select = copy.second.id)
        }
    }

    private fun deleteSelected() {
        val selected = selectedButton()
        if (selected == null) {
            Toast.makeText(this, R.string.controls_editor_select_first, Toast.LENGTH_SHORT).show()
            return
        }
        commitLayout(controls.layout.without(selected.id), select = null)
    }

    private fun propertiesOfSelected() {
        val selected = selectedButton()
        if (selected == null) {
            Toast.makeText(this, R.string.controls_editor_select_first, Toast.LENGTH_SHORT).show()
            return
        }
        showProperties(selected)
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle(R.string.controls_editor_reset_title)
            .setMessage(R.string.controls_editor_reset_message)
            .setPositiveButton(R.string.controls_editor_reset_yes) { _, _ ->
                // Файл удаляется, а не перезаписывается: у игрока снова «раскладка по умолчанию», какой бы она ни была в будущих версиях.
                store.reset()
                controls.layout = ControlLayout.default()
                controls.selectedId = null
            }
            .setNegativeButton(R.string.controls_editor_cancel, null)
            .setOnDismissListener { enterImmersiveMode() }
            .show()
    }

    // ---------------------------------------------------------------- выбор действия

    /** Два шага: раздел, потом действие из него. */
    private fun pickTarget(onPicked: (ControlTarget) -> Unit) {
        val groups = TargetGroup.values()
        val names = Array(groups.size) { getString(groupName(groups[it])) }
        AlertDialog.Builder(this)
            .setTitle(R.string.controls_editor_pick_group)
            .setItems(names) { _, which ->
                val targets = ControlTargets.inGroup(groups[which])
                val titles = Array(targets.size) { targetTitle(targets[it]) }
                AlertDialog.Builder(this)
                    .setTitle(R.string.controls_editor_pick_action)
                    .setItems(titles) { _, index -> onPicked(targets[index]) }
                    .setNegativeButton(R.string.controls_editor_cancel, null)
                    .setOnDismissListener { enterImmersiveMode() }
                    .show()
            }
            .setNegativeButton(R.string.controls_editor_cancel, null)
            .setOnDismissListener { enterImmersiveMode() }
            .show()
    }

    /** Подпись кнопки может быть значком («␣», «⇧»), поэтому рядом пишется и идентификатор действия: `key.space`. */
    private fun targetTitle(target: ControlTarget): String = "${target.label}   ·   ${target.id}"

    private fun groupName(group: TargetGroup): Int = when (group) {
        TargetGroup.MOVEMENT -> R.string.controls_group_movement
        TargetGroup.MOUSE -> R.string.controls_group_mouse
        TargetGroup.FUNCTION -> R.string.controls_group_function
        TargetGroup.SPECIAL -> R.string.controls_group_special
        TargetGroup.LETTERS -> R.string.controls_group_letters
        TargetGroup.DIGITS -> R.string.controls_group_digits
        TargetGroup.ACTIONS -> R.string.controls_group_actions
    }

    // ---------------------------------------------------------------- свойства кнопки

    private fun showProperties(button: ControlButton) {
        var targetId = button.targetId
        var widthDp = button.widthDp
        var heightDp = button.heightDp
        var opacityPercent = Math.round(button.opacity * 100f).coerceIn(Math.round(ControlButton.MIN_OPACITY * 100f), 100)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(0))
        }

        val labelInput = EditText(this).apply {
            setText(button.label)
            setSingleLine()
            hint = getString(R.string.controls_editor_label)
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(ControlButton.MAX_LABEL_LENGTH))
        }
        content.addView(labelInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val actionButton = android.widget.Button(this)
        fun showAction() {
            val title = ControlTargets.find(targetId)?.let { targetTitle(it) } ?: targetId
            actionButton.text = getString(R.string.controls_editor_action, title)
        }
        showAction()
        actionButton.setOnClickListener {
            pickTarget { picked ->
                targetId = picked.id
                showAction()
            }
        }
        content.addView(actionButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val circle = CheckBox(this).apply {
            text = getString(R.string.controls_editor_circle)
            isChecked = button.shape == ButtonShape.CIRCLE
        }
        content.addView(circle)
        val toggle = CheckBox(this).apply {
            text = getString(R.string.controls_editor_toggle)
            isChecked = button.mode == PressMode.TOGGLE
        }
        content.addView(toggle)

        content.addView(
            sliderRow(R.string.controls_editor_width, ControlButton.MIN_SIZE_DP, ControlButton.MAX_SIZE_DP, widthDp) { widthDp = it },
        )
        content.addView(
            sliderRow(R.string.controls_editor_height, ControlButton.MIN_SIZE_DP, ControlButton.MAX_SIZE_DP, heightDp) { heightDp = it },
        )
        content.addView(
            sliderRow(R.string.controls_editor_opacity, Math.round(ControlButton.MIN_OPACITY * 100f), 100, opacityPercent) { opacityPercent = it },
        )

        val scroll = ScrollView(this).apply { addView(content) }
        AlertDialog.Builder(this)
            .setTitle(R.string.controls_editor_props_title)
            .setView(scroll)
            .setPositiveButton(R.string.controls_editor_apply) { _, _ ->
                val round = circle.isChecked
                // У круглой кнопки стороны равны: иначе она станет овалом.
                val side = Math.round((widthDp + heightDp) / 2f)
                val updated = controls.layout.changed(button.id, screenWidthDp(), screenHeightDp()) {
                    it.copy(
                        label = labelInput.text.toString().trim(),
                        targetId = targetId,
                        shape = if (round) ButtonShape.CIRCLE else ButtonShape.SQUARE,
                        mode = if (toggle.isChecked) PressMode.TOGGLE else PressMode.HOLD,
                        widthDp = if (round) side else widthDp,
                        heightDp = if (round) side else heightDp,
                        opacity = opacityPercent / 100f,
                    )
                }
                commitLayout(updated, select = button.id)
            }
            .setNegativeButton(R.string.controls_editor_cancel, null)
            .setOnDismissListener { enterImmersiveMode() }
            .show()
    }

    /** Подпись с числом и ползунок под ней. [format] получает текущее значение; [onChange] вызывается при каждом движении. */
    private fun sliderRow(format: Int, min: Int, max: Int, value: Int, onChange: (Int) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        val caption = TextView(this).apply { text = getString(format, value) }
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = (value - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(
                object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                        val current = min + progress
                        caption.text = getString(format, current)
                        onChange(current)
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar) = Unit

                    override fun onStopTrackingTouch(seekBar: SeekBar) = Unit
                },
            )
        }
        row.addView(caption)
        row.addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return row
    }

    // ---------------------------------------------------------------- мелочи

    private fun toolButton(symbol: String, description: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = symbol
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = getString(description)
            setOnClickListener { onClick() }
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        private val BACKGROUND = Color.rgb(16, 20, 24)

        fun intent(context: Context): Intent = Intent(context, ControlEditorActivity::class.java)
    }
}
