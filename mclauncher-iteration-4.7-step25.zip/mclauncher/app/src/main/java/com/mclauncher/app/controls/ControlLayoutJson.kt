package com.mclauncher.app.controls

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.floatOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject

/**
 * Файл раскладки: JSON `{"version":1,"buttons":[{"id":"b1","label":"W","target":"key.w","x":0.12,"y":0.5,"w":52,"h":52,"shape":"circle","mode":"hold","opacity":0.55}]}`.
 *
 * Чтение терпимое: файл могли править руками или записать другой версией. Кнопка с неизвестным действием пропускается, числа приводятся к допустимым
 * (см. [sanitized]), повторяющиеся id заменяются новыми, лишние кнопки сверх [ControlLayout.MAX_BUTTONS] отбрасываются.
 * Если файл вообще не разобрать, [decode] возвращает `null`, а не пустую раскладку: пустая раскладка — это осознанный выбор игрока, а не ошибка чтения.
 */
object ControlLayoutJson {
    const val VERSION = 1

    /** Файл больше этого размера не читаем: настоящая раскладка занимает единицы килобайт. */
    const val MAX_BYTES = 256 * 1024

    private val json = Json { prettyPrint = true }

    fun encode(layout: ControlLayout): String {
        val buttons = layout.buttons.map { b ->
            JsonObject(
                linkedMapOf(
                    "id" to JsonPrimitive(b.id),
                    "label" to JsonPrimitive(b.label),
                    "target" to JsonPrimitive(b.targetId),
                    "x" to JsonPrimitive(b.x),
                    "y" to JsonPrimitive(b.y),
                    "w" to JsonPrimitive(b.widthDp),
                    "h" to JsonPrimitive(b.heightDp),
                    "shape" to JsonPrimitive(b.shape.name.lowercase()),
                    "mode" to JsonPrimitive(b.mode.name.lowercase()),
                    "opacity" to JsonPrimitive(b.opacity),
                ),
            )
        }
        val root = JsonObject(linkedMapOf("version" to JsonPrimitive(VERSION), "buttons" to JsonArray(buttons)))
        return json.encodeToString(JsonElement.serializer(), root)
    }

    fun decode(text: String): ControlLayout? {
        if (text.length > MAX_BYTES) return null
        val root = try {
            json.parseToJsonElement(text).jsonObject
        } catch (e: Exception) {
            return null
        }
        val array = root["buttons"] as? JsonArray ?: return null
        val result = ArrayList<ControlButton>()
        val usedIds = HashSet<String>()
        for (element in array) {
            if (result.size >= ControlLayout.MAX_BUTTONS) break
            val obj = element as? JsonObject ?: continue
            val targetId = obj.string("target") ?: continue
            if (ControlTargets.find(targetId) == null) continue
            val default = ControlTargets.find(targetId)!!
            var id = obj.string("id")?.takeIf { it.isNotBlank() && it.length <= 32 } ?: "b${result.size + 1}"
            var n = result.size + 1
            while (id in usedIds) id = "b${n++}"
            usedIds += id
            result += ControlButton(
                id = id,
                label = obj.string("label") ?: default.label,
                targetId = targetId,
                x = obj.float("x") ?: 0f,
                y = obj.float("y") ?: 0f,
                widthDp = obj.int("w") ?: ControlButton.DEFAULT_SIZE_DP,
                heightDp = obj.int("h") ?: ControlButton.DEFAULT_SIZE_DP,
                shape = ButtonShape.values().firstOrNull { it.name.equals(obj.string("shape"), ignoreCase = true) } ?: ButtonShape.SQUARE,
                mode = PressMode.values().firstOrNull { it.name.equals(obj.string("mode"), ignoreCase = true) } ?: PressMode.HOLD,
                opacity = obj.float("opacity") ?: ControlButton.DEFAULT_OPACITY,
            ).sanitized()
        }
        return ControlLayout(result)
    }

    private fun JsonObject.string(key: String): String? = (this[key] as? JsonPrimitive)?.takeIf { it.isString }?.contentOrNull

    private fun JsonObject.float(key: String): Float? = (this[key] as? JsonPrimitive)?.takeIf { !it.isString }?.floatOrNull

    private fun JsonObject.int(key: String): Int? = (this[key] as? JsonPrimitive)?.takeIf { !it.isString }?.let { it.intOrNull ?: it.floatOrNull?.toInt() }
}
