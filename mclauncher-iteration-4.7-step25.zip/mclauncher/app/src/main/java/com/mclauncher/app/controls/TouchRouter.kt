package com.mclauncher.app.controls

/**
 * Раздаёт касания по пальцам: каждый палец принадлежит либо кнопке, на которую он попал, либо «камере» ([LookPad]). Так можно одновременно
 * держать «W» одним пальцем и вертеть камеру другим.
 *
 * - Палец, начавший на кнопке, остаётся её пальцем, даже если уедет с неё; кнопка отпускается, когда палец поднят.
 * - Палец вне кнопок становится камерой, но только первый: второй свободный палец игнорируется (иначе камера прыгала бы между ними).
 * - Положения приходят в пикселях вида; камере они пересчитываются в пиксели окна игры ([scaleX], [scaleY]).
 *
 * Все вызовы — из одного потока (главного).
 */
class TouchRouter(
    private val tracker: ControlPressTracker,
    private val look: LookPad,
    private val buttonAt: (Float, Float) -> ControlButton?,
) {
    /** Во сколько раз окно игры больше (или меньше) вида по ширине и по высоте. */
    var scaleX: Float = 1f
    var scaleY: Float = 1f

    private sealed class Owner {
        class Pressing(val button: ControlButton) : Owner()
        object Looking : Owner()
    }

    private val owners = HashMap<Int, Owner>()
    private var lookPointer: Int? = null

    init {
        // Пока палец держит ЛКМ или ПКМ на экране, свободный палец не должен ещё и щёлкать: иначе правый щелчок станет левым и правым сразу.
        look.mouseButtonHeld = { tracker.holdsMouseButton() }
    }

    /** Есть палец, который сейчас крутит камеру или щёлкает по меню: нужно звать [poll] для долгого нажатия. */
    val isLooking: Boolean get() = lookPointer != null

    /** Кнопки, которые сейчас нажаты (для подсветки). */
    val heldIds: Set<String> get() = tracker.heldIds

    fun down(pointerId: Int, x: Float, y: Float, timeMillis: Long) {
        if (pointerId in owners) return
        val button = buttonAt(x, y)
        if (button != null) {
            owners[pointerId] = Owner.Pressing(button)
            tracker.press(button)
        } else if (lookPointer == null) {
            owners[pointerId] = Owner.Looking
            lookPointer = pointerId
            look.down(x * scaleX, y * scaleY, timeMillis)
        }
    }

    fun move(pointerId: Int, x: Float, y: Float, timeMillis: Long) {
        if (owners[pointerId] === Owner.Looking) look.move(x * scaleX, y * scaleY, timeMillis)
    }

    fun up(pointerId: Int, x: Float, y: Float, timeMillis: Long) {
        when (val owner = owners.remove(pointerId)) {
            is Owner.Pressing -> tracker.release(owner.button)
            Owner.Looking -> {
                lookPointer = null
                look.up(x * scaleX, y * scaleY, timeMillis)
            }

            null -> Unit
        }
    }

    /** Все касания прерваны: отпускаются и кнопки (в том числе включённые «переключателем»), и камера. */
    fun cancelAll() {
        owners.clear()
        lookPointer = null
        tracker.releaseAll()
        look.cancel()
    }

    fun poll(timeMillis: Long) = look.poll(timeMillis)
}
