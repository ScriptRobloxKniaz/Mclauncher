package com.mclauncher.app.controls

/** Куда уходит текст с экранной клавиатуры: в игре — символы и клавиши GLFW, в тестах — запись вызовов. */
interface TextSink {
    fun typeChar(c: Char)
    fun backspace()
    fun enter()
}

/**
 * Превращает то, что присылает экранная клавиатура Android (подсказки, ввод с исправлением, удаление), в символы и нажатия клавиш для игры.
 *
 * Клавиатура может сначала прислать слово «в черновике» (composing), потом заменить его целиком: игре эти замены надо показать как удаление
 * лишнего и ввод недостающего, иначе в чате окажется «приветпривет». Совпадающее начало слова не трогается.
 *
 * Символы вне базовой плоскости Unicode (эмодзи) игре отправить нельзя: канал ввода принимает один `Char`. Они пропускаются.
 * Все вызовы — из одного потока (главного).
 */
class ImeTextTranslator(private val sink: TextSink) {
    private var composing = ""

    /** Черновик: замена прежнего черновика этим текстом. */
    fun setComposing(text: CharSequence?) = replaceComposing(text?.toString().orEmpty())

    /** Окончательный текст: заменяет черновик и закрывает его. */
    fun commit(text: CharSequence?) {
        replaceComposing(text?.toString().orEmpty())
        composing = ""
    }

    /** Клавиатура закончила черновик, оставив его как есть. */
    fun finishComposing() {
        composing = ""
    }

    /** Удалить [count] символов перед курсором (в игре — столько раз «Backspace»). */
    fun deleteBefore(count: Int) {
        if (count <= 0) return
        repeat(count) { sink.backspace() }
        composing = composing.dropLast(count)
    }

    fun enter() {
        composing = ""
        sink.enter()
    }

    fun backspace() = deleteBefore(1)

    private fun replaceComposing(new: String) {
        var common = 0
        val limit = minOf(composing.length, new.length)
        while (common < limit && composing[common] == new[common]) common++
        repeat(composing.length - common) { sink.backspace() }
        for (i in common until new.length) {
            val c = new[i]
            when {
                c == '\n' -> sink.enter()
                Character.isSurrogate(c) -> Unit
                else -> sink.typeChar(c)
            }
        }
        composing = new
    }
}
