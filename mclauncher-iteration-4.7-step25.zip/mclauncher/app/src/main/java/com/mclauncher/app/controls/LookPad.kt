package com.mclauncher.app.controls

/** Куда [LookPad] отправляет движения мыши игры. В игре это `CallbackBridge`, в тестах — запись вызовов. Все координаты — в пикселях окна игры. */
interface LookOutput {
    /** Поставить курсор в точку. */
    fun moveCursor(x: Float, y: Float)

    fun leftButton(down: Boolean)
}

/**
 * Палец на свободной части экрана — это мышь. Правила те же, что у Pojav и Zalith:
 *
 * - **В меню** (курсор виден): палец ставит курсор под себя и зажимает левую кнопку, пока он на экране, поэтому работают и щелчок,
 *   и перетаскивание предметов или ползунков.
 * - **В мире** (игра захватила мышь): движение пальца поворачивает камеру; быстрое касание без движения — один щелчок левой кнопкой
 *   (удар, постановка), долгое касание без движения — левая кнопка зажата, пока палец не уберут (ломаем блок).
 *
 * **Режим «мышь»** ([touchpad]): в меню палец не ставит курсор под себя, а двигает его, как тачпад, на расстояние своего движения;
 * курсор виден на экране. Палец сам ничего не зажимает: быстрое касание — левый щелчок там, где стоит курсор, долгое касание без
 * движения — левая кнопка зажата, пока палец не уберут (перетащить предмет). Правый щелчок, шифт-щелчок и т. п. делают кнопки на
 * экране; пока на экране нажата кнопка мыши ([mouseButtonHeld]), касание свой щелчок не добавляет, так что можно держать ПКМ одним
 * пальцем и водить курсором другим (раздать стопку по ячейкам). В мире режим ничего не меняет: камера работает как обычно.
 *
 * Время передаётся в вызовах ([down], [move], [up], [poll]) в миллисекундах: так класс не зависит от часов и проверяется тестами.
 * Все вызовы — из одного потока.
 *
 * @param isGrabbing захватила ли игра мышь сейчас;
 * @param cursor текущее положение курсора игры;
 * @param sensitivity во сколько раз поворот камеры быстрее движения пальца.
 */
class LookPad(
    private val output: LookOutput,
    private val isGrabbing: () -> Boolean,
    private val cursor: () -> Pair<Float, Float>,
    var sensitivity: Float = 1f,
) {
    /** Режим «мышь» включён (см. выше). Действует только в меню. */
    var touchpad: Boolean = false

    /** Во сколько раз курсор в режиме «мышь» движется быстрее пальца. */
    var touchpadSensitivity: Float = 1f

    /** Размер окна игры в пикселях: курсор в режиме «мышь» за него не выходит. `null` — не ограничивать. */
    var windowSize: () -> Pair<Float, Float>? = { null }

    /** Нажата ли сейчас кнопка мыши на экране; подключает [TouchRouter]. */
    var mouseButtonHeld: () -> Boolean = { false }

    private var active = false
    private var moved = false
    private var holding = false
    private var clicking = false
    private var startX = 0f
    private var startY = 0f
    private var startTime = 0L
    private var lastX = 0f
    private var lastY = 0f

    /** Палец сейчас лежит на экране. */
    val isActive: Boolean get() = active

    fun down(x: Float, y: Float, timeMillis: Long) {
        if (active) cancel()
        active = true
        moved = false
        holding = false
        clicking = false
        startX = x
        startY = y
        lastX = x
        lastY = y
        startTime = timeMillis
        // Прямое касание (без режима «мышь»): курсор под пальцем, левая кнопка зажата, пока палец на экране.
        if (!isGrabbing() && !touchpad) {
            output.moveCursor(x, y)
            output.leftButton(true)
            clicking = true
        }
    }

    fun move(x: Float, y: Float, @Suppress("UNUSED_PARAMETER") timeMillis: Long) {
        if (!active) return
        if (!moved && Math.hypot((x - startX).toDouble(), (y - startY).toDouble()) > TAP_SLOP_PX) moved = true
        if (isGrabbing()) {
            val (cx, cy) = cursor()
            output.moveCursor(cx + (x - lastX) * sensitivity, cy + (y - lastY) * sensitivity)
        } else if (touchpad) {
            val (cx, cy) = cursor()
            val (nx, ny) = clampToWindow(cx + (x - lastX) * touchpadSensitivity, cy + (y - lastY) * touchpadSensitivity)
            output.moveCursor(nx, ny)
        } else {
            output.moveCursor(x, y)
        }
        lastX = x
        lastY = y
    }

    fun up(x: Float, y: Float, timeMillis: Long) {
        if (!active) return
        active = false
        when {
            clicking -> {
                output.moveCursor(x, y)
                output.leftButton(false)
            }

            holding -> output.leftButton(false)

            // Быстрое касание в мире — щелчок. Курсор при этом не двигаем: в мире положение курсора ни на что не влияет.
            isGrabbing() && !moved && timeMillis - startTime < TAP_MAX_MILLIS -> {
                output.leftButton(true)
                output.leftButton(false)
            }

            // Режим «мышь»: быстрое касание — левый щелчок там, где стоит курсор (если ЛКМ/ПКМ на экране сейчас не держат другим пальцем).
            touchpad && !moved && timeMillis - startTime < TAP_MAX_MILLIS && !mouseButtonHeld() -> {
                output.leftButton(true)
                output.leftButton(false)
            }
        }
        clicking = false
        holding = false
    }

    /** Касание прервано (скрыли управление, свернули игру): всё, что палец держал, отпускается. */
    fun cancel() {
        if (!active) return
        active = false
        if (clicking || holding) output.leftButton(false)
        clicking = false
        holding = false
    }

    /** Вызывать, пока палец лежит: по истечении [LONG_PRESS_MILLIS] без движения в мире зажимает левую кнопку. */
    fun poll(timeMillis: Long) {
        if (!active || moved || holding || clicking) return
        // Долгое касание нужно в мире (ломать блок) и в режиме «мышь» (перетаскивать предмет); при прямом касании левая кнопка уже зажата.
        if (!isGrabbing() && !touchpad) return
        if (!isGrabbing() && mouseButtonHeld()) return
        if (timeMillis - startTime >= LONG_PRESS_MILLIS) {
            holding = true
            output.leftButton(true)
        }
    }

    private fun clampToWindow(x: Float, y: Float): Pair<Float, Float> {
        val size = windowSize() ?: return x to y
        val cx = if (size.first > 0f) x.coerceIn(0f, size.first) else x
        val cy = if (size.second > 0f) y.coerceIn(0f, size.second) else y
        return cx to cy
    }

    companion object {
        /** Сдвиг пальца (пиксели окна игры), меньше которого касание ещё считается неподвижным. */
        const val TAP_SLOP_PX = 14f
        const val TAP_MAX_MILLIS = 250L
        const val LONG_PRESS_MILLIS = 350L
    }
}
