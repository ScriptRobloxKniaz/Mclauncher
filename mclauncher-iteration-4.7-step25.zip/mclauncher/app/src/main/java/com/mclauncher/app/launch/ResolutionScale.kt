package com.mclauncher.app.launch

import com.mclauncher.engine.EngineEnvironment
import kotlin.math.roundToInt

/**
 * Разрешение игры в процентах от экрана телефона. Самый действенный рычаг FPS на телефонах: видеочип рисует меньше пикселей, а готовый
 * кадр растягивает система (размер буфера и размер окна игры берутся из [EngineEnvironment.screenWidth] и `screenHeight`, касания
 * пересчитываются в окно игры — см. `GameActivity`). 100% — как раньше, без изменений.
 *
 * Эффект на FPS **не измерен**: он зависит от телефона, рендерера и версии игры; картинка при уменьшении становится мягче.
 */
object ResolutionScale {
    const val MIN_PERCENT = 50
    const val MAX_PERCENT = 100
    const val STEP_PERCENT = 5
    const val DEFAULT_PERCENT = 100

    /** Допустимое значение: в пределах [MIN_PERCENT]..[MAX_PERCENT], кратное [STEP_PERCENT]; пусто или мусор — [DEFAULT_PERCENT]. */
    fun clamp(percent: Int?): Int {
        if (percent == null) return DEFAULT_PERCENT
        val stepped = (percent.toDouble() / STEP_PERCENT).roundToInt() * STEP_PERCENT
        return stepped.coerceIn(MIN_PERCENT, MAX_PERCENT)
    }

    /** Размер окна игры для экрана [width]×[height] при [percent]. Стороны чётные (так делают видеодрайверы), не меньше 2; 100% возвращает экран как есть. */
    fun apply(width: Int, height: Int, percent: Int): Pair<Int, Int> {
        val p = clamp(percent)
        if (p == MAX_PERCENT) return width to height
        return evenScaled(width, p) to evenScaled(height, p)
    }

    private fun evenScaled(side: Int, percent: Int): Int = maxOf(2, (side * percent / 100.0 / 2.0).roundToInt() * 2)
}

/** Окружение движка с экраном, уменьшенным до [percent] (см. [ResolutionScale]). */
fun EngineEnvironment.withResolutionPercent(percent: Int): EngineEnvironment {
    val (w, h) = ResolutionScale.apply(screenWidth, screenHeight, percent)
    return if (w == screenWidth && h == screenHeight) this else copy(screenWidth = w, screenHeight = h)
}
