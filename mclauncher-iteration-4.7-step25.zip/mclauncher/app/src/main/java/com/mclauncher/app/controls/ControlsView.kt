package com.mclauncher.app.controls

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View

/**
 * Экранные кнопки поверх игры, а в режиме редактора — те же кнопки, которые можно двигать и растягивать.
 *
 * Вид только рисует и переводит касания в вызовы чистой логики: в игре это [TouchRouter], в редакторе — правки [ControlLayout]
 * через [editor]. Положение кнопок и попадания считает [ControlGeometry], поэтому нарисованное и нажимаемое всегда совпадает.
 * Все вызовы — из главного потока.
 */
class ControlsView(context: Context) : View(context) {

    /** Слушатель правок в режиме редактора. */
    interface EditListener {
        /** Выбрана кнопка (или `null`, если нажали на пустое место). */
        fun onSelected(buttonId: String?)

        /** Раскладка изменилась во время перетаскивания или изменения размера (ещё не закончено). */
        fun onLayoutChanged(layout: ControlLayout)

        /** Жест закончился: раскладку можно сохранять. */
        fun onGestureFinished(layout: ControlLayout)
    }

    private val density = resources.displayMetrics.density

    var layout: ControlLayout = ControlLayout.default()
        set(value) {
            field = value
            invalidate()
        }

    /** Режим редактора: кнопки всегда хорошо видны, касания их двигают, а не нажимают. */
    var editMode: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var selectedId: String? = null
        set(value) {
            field = value
            invalidate()
        }

    /** Показаны ли кнопки в игре. Скрытые не рисуются и не нажимаются; камера работает всегда. */
    var buttonsVisible: Boolean = true
        set(value) {
            if (field != value) router?.cancelAll()
            field = value
            invalidate()
        }

    /** Включён режим «мышь» (см. [LookPad.touchpad]): кнопка «Мышь» подсвечена, пока он включён, а курсор перерисовывается сам. */
    var mouseModeOn: Boolean = false
        set(value) {
            if (field == value) return
            field = value
            invalidate()
            restartCursorTicker()
        }

    /**
     * Откуда брать курсор для рисования: положение в пикселях вида или `null`, если курсор сейчас не нужен (не режим «мышь», игра
     * захватила мышь, игра ещё не показывает кадры). Рисуется поверх кнопок и остаётся, даже когда кнопки скрыты.
     */
    var cursorSource: (() -> Pair<Float, Float>?)? = null

    /** Принимает ли игра ввод. Пока нет (она ещё загружается), касания гасятся. */
    var inputEnabled: () -> Boolean = { true }

    /** Раздача касаний в игре; в редакторе не нужна. */
    var router: TouchRouter? = null

    var editor: EditListener? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()

    // Курсор — стрелка в квадрате 20 на 20 условных единиц, масштабируется до CURSOR_SIZE_DP.
    private val cursorPath = Path().apply {
        moveTo(0f, 0f)
        lineTo(0f, 16.5f)
        lineTo(4.2f, 12.8f)
        lineTo(7.2f, 19.5f)
        lineTo(9.8f, 18.4f)
        lineTo(6.9f, 11.8f)
        lineTo(12.2f, 11.8f)
        close()
    }
    private val cursorFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = WHITE
    }
    private val cursorOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.3f
        strokeJoin = Paint.Join.ROUND
        color = BLACK
    }
    private val cursorScale = CURSOR_SIZE_DP * density / 20f

    private val cursorTicker = object : Runnable {
        override fun run() {
            invalidate()
            if (mouseModeOn) postDelayed(this, CURSOR_REFRESH_MILLIS)
        }
    }

    private val handlePx = 22f * density
    private val cornerPx = 8f * density

    private val poll = object : Runnable {
        override fun run() {
            val r = router ?: return
            r.poll(SystemClock.uptimeMillis())
            if (r.isLooking) postDelayed(this, POLL_MILLIS)
        }
    }

    // ---------------------------------------------------------------- рисование

    override fun onDraw(canvas: Canvas) {
        if (editMode || buttonsVisible) drawButtons(canvas)
        if (!editMode) drawCursor(canvas)
    }

    private fun drawCursor(canvas: Canvas) {
        val (x, y) = cursorSource?.invoke() ?: return
        canvas.save()
        canvas.translate(x, y)
        canvas.scale(cursorScale, cursorScale)
        canvas.drawPath(cursorPath, cursorFill)
        canvas.drawPath(cursorPath, cursorOutline)
        canvas.restore()
    }

    private fun drawButtons(canvas: Canvas) {
        val held: Set<String> = if (editMode) emptySet<String>() else router?.heldIds.orEmpty()
        val screenW = width.toFloat()
        val screenH = height.toFloat()
        for (button in layout.buttons) {
            val fitted = ControlGeometry.fitted(button, screenW, screenH, density)
            val r = ControlGeometry.rectOf(fitted, screenW, screenH, density)
            rect.set(r.left, r.top, r.right, r.bottom)
            val opacity = if (editMode) EDIT_OPACITY else button.opacity
            // «Мышь» — переключатель: подсвечена, пока режим включён, а не только пока палец на кнопке.
            val pressed = button.id in held || (!editMode && mouseModeOn && button.targetId == ControlTargets.MOUSE_MODE)
            val selected = editMode && button.id == selectedId

            fill.color = WHITE
            fill.alpha = (255 * opacity * if (pressed) 0.65f else 0.22f).toInt()
            stroke.color = if (selected) ACCENT else WHITE
            stroke.alpha = if (selected) 255 else (255 * opacity).toInt()
            stroke.strokeWidth = (if (selected) 3f else 1.5f) * density
            if (button.shape == ButtonShape.CIRCLE) {
                canvas.drawOval(rect, fill)
                canvas.drawOval(rect, stroke)
            } else {
                canvas.drawRoundRect(rect, cornerPx, cornerPx, fill)
                canvas.drawRoundRect(rect, cornerPx, cornerPx, stroke)
            }

            text.color = WHITE
            text.alpha = (255 * (0.35f + 0.65f * opacity)).toInt()
            drawLabel(canvas, button.label, r)

            if (selected) {
                fill.color = ACCENT
                fill.alpha = 255
                canvas.drawRect(r.right - handlePx * 2f / 3f, r.bottom - handlePx * 2f / 3f, r.right + handlePx / 3f, r.bottom + handlePx / 3f, fill)
            }
        }
    }

    /** Подпись по центру; длинная подпись сжимается, чтобы уместиться в кнопку. */
    private fun drawLabel(canvas: Canvas, label: String, r: PxRect) {
        if (label.isEmpty()) return
        var size = minOf(r.width, r.height) * 0.38f
        text.textSize = size
        val maxWidth = r.width * 0.86f
        val measured = text.measureText(label)
        if (measured > maxWidth && measured > 0f) {
            size *= maxWidth / measured
            text.textSize = size
        }
        val baseline = r.centerY - (text.descent() + text.ascent()) / 2f
        canvas.drawText(label, r.centerX, baseline, text)
    }

    // ---------------------------------------------------------------- касания

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (editMode) return editTouch(event)
        val r = router ?: return false
        if (!inputEnabled()) {
            if (event.actionMasked == MotionEvent.ACTION_CANCEL || event.actionMasked == MotionEvent.ACTION_UP) r.cancelAll()
            return true
        }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = event.actionIndex
                r.down(event.getPointerId(i), event.getX(i), event.getY(i), event.eventTime)
            }

            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) r.move(event.getPointerId(i), event.getX(i), event.getY(i), event.eventTime)
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = event.actionIndex
                r.up(event.getPointerId(i), event.getX(i), event.getY(i), event.eventTime)
            }

            MotionEvent.ACTION_CANCEL -> r.cancelAll()
        }
        if (r.isLooking) {
            removeCallbacks(poll)
            postDelayed(poll, POLL_MILLIS)
        }
        invalidate()
        return true
    }

    /** Кнопка под пальцем (для роутера в игре). `null`, если кнопки скрыты. */
    fun buttonAt(x: Float, y: Float): ControlButton? =
        if (buttonsVisible) ControlGeometry.topmostAt(layout.buttons, x, y, width.toFloat(), height.toFloat(), density) else null

    /** Размер окна игры относительно вида: камере нужны пиксели окна, а не вида. */
    fun updateWindowScale(windowWidth: Int, windowHeight: Int) {
        val r = router ?: return
        if (width > 0 && height > 0) {
            r.scaleX = windowWidth.toFloat() / width
            r.scaleY = windowHeight.toFloat() / height
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        onSizeReady?.invoke(w, h)
    }

    /** Вызывается при каждом изменении размера вида: игре нужно пересчитать масштаб камеры. */
    var onSizeReady: ((Int, Int) -> Unit)? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        restartCursorTicker()
    }

    /** Пока режим «мышь» включён, вид сам перерисовывается: игра может отпустить мышь (открыла инвентарь), и курсор должен появиться. */
    private fun restartCursorTicker() {
        removeCallbacks(cursorTicker)
        if (mouseModeOn && isAttachedToWindow) post(cursorTicker)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(cursorTicker)
        removeCallbacks(poll)
        router?.cancelAll()
        super.onDetachedFromWindow()
    }

    // ---------------------------------------------------------------- редактор

    private var dragId: String? = null
    private var resizing = false
    private var changedInGesture = false
    private var lastX = 0f
    private var lastY = 0f
    private var resizeStartX = 0f
    private var resizeStartY = 0f
    private var resizeStartWidthDp = 0
    private var resizeStartHeightDp = 0

    private fun editTouch(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        val screenW = width.toFloat()
        val screenH = height.toFloat()
        val screenWdp = screenW / density
        val screenHdp = screenH / density
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                changedInGesture = false
                val selected = selectedId?.let { layout.find(it) }
                val onHandle = selected != null && ControlGeometry.onResizeHandle(
                    ControlGeometry.rectOf(ControlGeometry.fitted(selected, screenW, screenH, density), screenW, screenH, density),
                    x, y, handlePx,
                )
                if (selected != null && onHandle) {
                    resizing = true
                    dragId = selected.id
                    resizeStartX = x
                    resizeStartY = y
                    resizeStartWidthDp = selected.widthDp
                    resizeStartHeightDp = selected.heightDp
                } else {
                    val hit = ControlGeometry.topmostAt(layout.buttons, x, y, screenW, screenH, density)
                    resizing = false
                    dragId = hit?.id
                    if (hit?.id != selectedId) {
                        selectedId = hit?.id
                        editor?.onSelected(hit?.id)
                    }
                }
                lastX = x
                lastY = y
            }

            MotionEvent.ACTION_MOVE -> {
                val id = dragId ?: return true
                if (resizing) {
                    val newWidth = resizeStartWidthDp + (x - resizeStartX) / density
                    val newHeight = resizeStartHeightDp + (y - resizeStartY) / density
                    layout = layout.withSize(id, newWidth, newHeight, screenWdp, screenHdp)
                } else {
                    layout = layout.dragged(id, (x - lastX) / density, (y - lastY) / density, screenWdp, screenHdp)
                }
                changedInGesture = true
                lastX = x
                lastY = y
                editor?.onLayoutChanged(layout)
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragId = null
                resizing = false
                if (changedInGesture) editor?.onGestureFinished(layout)
                changedInGesture = false
            }
        }
        return true
    }

    private companion object {
        const val WHITE = 0xFFFFFFFF.toInt()
        const val BLACK = 0xFF000000.toInt()
        const val ACCENT = 0xFF4FC3F7.toInt()
        const val EDIT_OPACITY = 0.9f
        const val POLL_MILLIS = 60L
        const val CURSOR_REFRESH_MILLIS = 100L
        const val CURSOR_SIZE_DP = 24f
    }
}
