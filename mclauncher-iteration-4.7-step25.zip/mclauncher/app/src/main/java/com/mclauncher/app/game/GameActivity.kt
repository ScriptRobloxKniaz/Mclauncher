package com.mclauncher.app.game

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.app.AlertDialog
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.mclauncher.app.R
import com.mclauncher.app.controls.ControlLayoutStore
import com.mclauncher.app.controls.ControlPressTracker
import com.mclauncher.app.controls.ControlSink
import com.mclauncher.app.controls.ControlsView
import com.mclauncher.app.controls.GameTextInput
import com.mclauncher.app.controls.GlfwKeys
import com.mclauncher.app.controls.ImeTextTranslator
import com.mclauncher.app.controls.LookOutput
import com.mclauncher.app.controls.LookPad
import com.mclauncher.app.controls.TextSink
import com.mclauncher.app.controls.TouchRouter
import com.mclauncher.engine.launch.GameExitReport
import com.mclauncher.engine.launch.GameRunner
import com.mclauncher.engine.launch.NativeLaunchPlan
import com.movtery.zalithlauncher.bridge.ZLBridge
import com.movtery.zalithlauncher.bridge.ZLNativeInvoker
import org.lwjgl.glfw.CallbackBridge
import java.io.File

/**
 * Экран игры. Работает в отдельном процессе `:game` (см. манифест): JVM игры живёт в нём и вместе с ним завершается,
 * а лаунчер остаётся целым и после вылета игры показывает его причину ([GameExitReport]).
 *
 * Последовательность: лаунчер кладёт [NativeLaunchPlan] в Intent → здесь создаётся `TextureView` → когда его
 * поверхность готова, в фоновом потоке запускается `GameRunner` → JVM рисует в эту поверхность через `libpojavexec`.
 * Поверхность может пересоздаваться (свернули и вернулись): тогда окну игры отдаётся новая, а JVM продолжает работать.
 *
 * Управление: поверх игры лежит [ControlsView] с экранными кнопками из раскладки игрока ([ControlLayoutStore], редактор —
 * `ControlEditorActivity`). Палец вне кнопок — мышь ([LookPad]: в меню щелчок и перетаскивание, в мире поворот камеры, касание —
 * удар, долгое касание — зажатая левая кнопка). Сверху по центру — кнопка меню и счётчик кадров, а пока игра загружается — окно
 * «Игра запускается» с крестиком. Двойное «Назад» закрывает игру. Всё проверено только чтением кода и тестами логики
 * (`controls/`): на устройстве этот экран ещё не запускался.
 */
class GameActivity : ComponentActivity(), TextureView.SurfaceTextureListener, ZLNativeInvoker.Host {

    private var plan: NativeLaunchPlan? = null
    private var textureView: TextureView? = null
    private var surface: Surface? = null

    /** JVM уже запущена в этом процессе. Вторую в нём создать нельзя, поэтому запуск делается ровно один раз. */
    private var gameThreadStarted = false

    /** Игра начала выводить кадры: до этого касания ей не отправляем. */
    @Volatile
    private var rendering = false

    private var lastBackMillis = 0L

    private var controls: ControlsView? = null
    private var lookPad: LookPad? = null
    private var textInput: GameTextInput? = null
    private var launchCard: View? = null
    private var fpsLabel: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private val fpsTicker = object : Runnable {
        override fun run() {
            if (rendering) {
                val fps = try {
                    CallbackBridge.getCurrentFps()
                } catch (e: UnsatisfiedLinkError) {
                    0
                }
                fpsLabel?.text = getString(R.string.game_fps, fps)
            }
            handler.postDelayed(this, FPS_INTERVAL_MS)
        }
    }

    @Suppress("DEPRECATION") // типизированный getSerializableExtra есть только с API 33, а minSdk 26
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val received = intent?.getSerializableExtra(EXTRA_PLAN) as? NativeLaunchPlan
        if (received == null) {
            // Экран открыли без плана (например, система восстановила его после смерти процесса): играть нечем.
            finish()
            return
        }
        plan = received
        // Метка «игра запущена» — до всего остального: если процесс упадёт раньше, чем дойдёт до JVM, лаунчер всё равно
        // узнает об этом и покажет диалог (иначе вылет в самом начале не оставлял бы никакого следа).
        try {
            GameExitReport.markSessionStarted(File(received.reportDir), System.currentTimeMillis())
            GameExitReport.noteStage(File(received.reportDir), "game screen created")
        } catch (e: Exception) {
            // Не получилось записать — не повод не запускать игру.
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.BLACK))
        enterImmersiveMode()

        val view = TextureView(this).apply {
            isOpaque = true
            surfaceTextureListener = this@GameActivity
        }
        textureView = view
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(view, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        buildOverlay(root, received)
        setContentView(root)

        // Без сенсорных элементов управления у игрока нет другого способа выйти, кроме двойного «Назад».
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastBackMillis <= BACK_CONFIRM_MS) {
                        closeByPlayer()
                    } else {
                        lastBackMillis = now
                        Toast.makeText(this@GameActivity, R.string.game_back_again, Toast.LENGTH_SHORT).show()
                    }
                }
            },
        )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    private fun enterImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ---------------------------------------------------------------- поверхность

    override fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int) {
        val current = plan ?: return
        // Буфер всегда размера окна игры, а не размера вида: игра рисует в нём, а система масштабирует на экран.
        texture.setDefaultBufferSize(current.windowWidth, current.windowHeight)
        val newSurface = Surface(texture)
        surface = newSurface

        if (gameThreadStarted) {
            // Поверхность пересоздана, JVM продолжает работать: отдаём окну игры новую.
            ZLBridge.setupBridgeWindow(newSurface)
            CallbackBridge.sendUpdateWindowSize(current.windowWidth, current.windowHeight)
            return
        }
        gameThreadStarted = true
        val appContext = applicationContext
        Thread({ runGame(appContext, current, newSurface) }, "MCLauncher-game").start()
    }

    override fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int) {
        val current = plan ?: return
        texture.setDefaultBufferSize(current.windowWidth, current.windowHeight)
    }

    override fun onSurfaceTextureDestroyed(texture: SurfaceTexture): Boolean {
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(texture: SurfaceTexture) = Unit

    /** Поток игры. Блокируется до выхода JVM, а обычно и не возвращается: процесс завершает нативный код. */
    private fun runGame(appContext: Context, current: NativeLaunchPlan, gameSurface: Surface) {
        GameRunner.run(appContext, current, this, gameSurface) {
            rendering = true
            // Первый кадр нарисован: окно «Игра запускается» больше не нужно.
            runOnUiThread { launchCard?.visibility = View.GONE }
        }
        // Сюда попадаем, только если JVM не запустилась или вернула управление сама. Отчёт уже записан.
        runOnUiThread { finishAndEndProcess() }
    }

    // ---------------------------------------------------------------- управление и окна поверх игры

    /** Слой кнопок, текстовый ввод, кнопка меню со счётчиком кадров и окно «Игра запускается». Порядок важен: что позже, то выше. */
    private fun buildOverlay(root: FrameLayout, current: NativeLaunchPlan) {
        val controlsView = ControlsView(this).apply {
            layout = ControlLayoutStore.forFilesDir(filesDir).load()
            inputEnabled = { rendering }
        }
        val look = LookPad(
            output = object : LookOutput {
                override fun moveCursor(x: Float, y: Float) = CallbackBridge.sendCursorPos(x, y)
                override fun leftButton(down: Boolean) = CallbackBridge.sendMouseButton(CallbackBridge.GLFW_MOUSE_BUTTON_LEFT, down)
            },
            isGrabbing = { CallbackBridge.isGrabbing() },
            cursor = { CallbackBridge.mouseX to CallbackBridge.mouseY },
        )
        // В режиме «мышь» курсор не уходит за окно игры.
        look.windowSize = { current.windowWidth.toFloat() to current.windowHeight.toFloat() }
        lookPad = look
        // Курсор рисует вид: в режиме «мышь», в меню (мышь не захвачена) и когда игра уже показывает кадры.
        controlsView.cursorSource = {
            val router = controlsView.router
            val sx = router?.scaleX ?: 1f
            val sy = router?.scaleY ?: 1f
            if (look.touchpad && rendering && !CallbackBridge.isGrabbing() && sx > 0f && sy > 0f) {
                CallbackBridge.mouseX / sx to CallbackBridge.mouseY / sy
            } else {
                null
            }
        }
        val tracker = ControlPressTracker(
            object : ControlSink {
                override fun key(glfwKey: Int, down: Boolean) = CallbackBridge.sendKey(glfwKey, 0, down)
                override fun mouseButton(button: Int, down: Boolean) = CallbackBridge.sendMouseButton(button, down)
                override fun scroll(steps: Int) = CallbackBridge.sendScroll(0.0, steps.toDouble())
                override fun toggleKeyboard() {
                    textInput?.toggle()
                }

                override fun toggleMouseMode() = setMouseMode(!look.touchpad)
            },
        )
        controlsView.router = TouchRouter(tracker, look, controlsView::buttonAt)
        controlsView.onSizeReady = { _, _ -> controlsView.updateWindowScale(current.windowWidth, current.windowHeight) }
        controls = controlsView
        root.addView(controlsView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val input = GameTextInput(
            this,
            ImeTextTranslator(
                object : TextSink {
                    override fun typeChar(c: Char) = CallbackBridge.sendChar(c)
                    override fun backspace() = tapKey(GlfwKeys.BACKSPACE)
                    override fun enter() = tapKey(GlfwKeys.ENTER)
                },
            ),
        )
        textInput = input
        root.addView(input, FrameLayout.LayoutParams(1, 1))

        // Кнопка меню и счётчик кадров — сверху по центру, как у Zalith.
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val menuSize = GameOverlay.menuButtonSize(this)
        bar.addView(GameOverlay.menuButton(this, getString(R.string.game_menu_description)) { showMenu() }, LinearLayout.LayoutParams(menuSize, menuSize))
        val fps = GameOverlay.fpsLabel(this).apply { text = getString(R.string.game_fps, 0) }
        fpsLabel = fps
        bar.addView(fps, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = GameOverlay.dpToPx(this@GameActivity, 8)
            },
        )

        val card = GameOverlay.launchCard(
            this,
            title = getString(R.string.game_starting_title),
            version = getString(R.string.game_starting_version, current.versionId),
            info = getString(R.string.game_starting_info, current.versionId, current.rendererName),
            closeDescription = getString(R.string.game_starting_close),
            onClose = { launchCard?.visibility = View.GONE },
        )
        launchCard = card
        root.addView(
            card,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = (resources.displayMetrics.heightPixels * 0.30f).toInt()
                val side = GameOverlay.dpToPx(this@GameActivity, 24)
                leftMargin = side
                rightMargin = side
            },
        )
    }

    /** Включает или выключает режим «мышь» (курсор-тачпад в меню и инвентаре) и сообщает об этом коротким уведомлением. */
    private fun setMouseMode(on: Boolean) {
        val pad = lookPad ?: return
        pad.touchpad = on
        controls?.mouseModeOn = on
        Toast.makeText(this, if (on) R.string.game_mouse_on else R.string.game_mouse_off, Toast.LENGTH_SHORT).show()
    }

    /** Нажать и отпустить клавишу (для текстового ввода: Backspace, Enter). */
    private fun tapKey(glfwKey: Int) {
        CallbackBridge.sendKey(glfwKey, 0, true)
        CallbackBridge.sendKey(glfwKey, 0, false)
    }

    private fun showMenu() {
        // Окно меню забирает касания: всё, что палец держал в игре, отпускаем, иначе клавиши залипнут.
        controls?.router?.cancelAll()
        val hidden = controls?.buttonsVisible == false
        val items = arrayOf(
            getString(if (hidden) R.string.game_menu_show_controls else R.string.game_menu_hide_controls),
            getString(R.string.game_menu_keyboard),
            getString(if (lookPad?.touchpad == true) R.string.game_menu_mouse_disable else R.string.game_menu_mouse_enable),
            getString(R.string.game_menu_close_game),
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.game_menu_title)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> controls?.buttonsVisible = hidden
                    1 -> textInput?.toggle()
                    2 -> setMouseMode(lookPad?.touchpad != true)
                    3 -> closeByPlayer()
                }
            }
            .setOnDismissListener { enterImmersiveMode() }
            .show()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(fpsTicker)
        handler.postDelayed(fpsTicker, FPS_INTERVAL_MS)
    }

    override fun onPause() {
        // Свернули игру: кнопки, которые держал палец, отпускаем.
        controls?.router?.cancelAll()
        handler.removeCallbacks(fpsTicker)
        super.onPause()
    }

    // ---------------------------------------------------------------- выход

    /** Игрок закрыл игру сам: пишем нормальный итог, чтобы лаунчер не принял это за вылет. */
    private fun closeByPlayer() {
        plan?.let { current ->
            GameRunner.recordExit(
                File(current.reportDir),
                GameExitReport(exitCode = 0, isSignal = false, message = "Closed by the player", logFile = current.logFile, timeMillis = System.currentTimeMillis()),
            )
        }
        finishAndEndProcess()
    }

    private fun finishAndEndProcess() {
        finish()
        // JVM нельзя создать заново в том же процессе, поэтому процесс игры не оставляем: следующий запуск получит чистый.
        Process.killProcess(Process.myPid())
    }

    override fun onDestroy() {
        super.onDestroy()
        // Экран игры закрыт (в том числе системой): без него игре некуда рисовать. Итог — либо уже записанный
        // нормальный, либо его нет, и тогда лаунчер сообщит о вылете.
        if (plan != null) Process.killProcess(Process.myPid())
    }

    // ---------------------------------------------------------------- ZLNativeInvoker.Host (вызывается из нативного кода)

    override fun onJvmExit(exitCode: Int, isSignal: Boolean) {
        // После возврата отсюда нативный код вызывает System.exit(0): всё нужное записываем сейчас и синхронно.
        val current = plan ?: return
        GameRunner.recordExit(
            File(current.reportDir),
            GameExitReport(exitCode, isSignal, logFile = current.logFile, timeMillis = System.currentTimeMillis()),
        )
    }

    override fun openLink(link: String?) {
        val uri = link?.let { runCatching { Uri.parse(it) }.getOrNull() } ?: return
        // Игра присылает ссылки из чата и меню: открываем только веб-адреса, чтобы файлы и intent: не уходили в систему.
        if (uri.scheme != "http" && uri.scheme != "https") return
        runOnUiThread {
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    override fun querySystemClipboard() {
        val text = readClipboardText() ?: return
        ZLBridge.clipboardReceived(text, "plain")
    }

    override fun putClipboardData(data: String?, mimeType: String?) {
        if (data != null) writeClipboardText(data)
    }

    override fun accessClipboard(type: Int, text: String?): String? = when (type) {
        CallbackBridge.CLIPBOARD_COPY -> {
            writeClipboardText(text ?: "")
            null
        }

        CallbackBridge.CLIPBOARD_PASTE -> readClipboardText().orEmpty()
        else -> null
    }

    private fun clipboard(): ClipboardManager? = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager

    private fun readClipboardText(): String? = runCatching {
        val clip = clipboard()?.primaryClip
        if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this)?.toString() else null
    }.getOrNull()

    private fun writeClipboardText(text: String) {
        runCatching { clipboard()?.setPrimaryClip(ClipData.newPlainText("Minecraft", text)) }
    }

    companion object {
        const val EXTRA_PLAN = "com.mclauncher.app.game.PLAN"

        /** Двойное «Назад» в пределах этого времени закрывает игру. */
        private const val BACK_CONFIRM_MS = 2_000L

        /** Как часто обновляется счётчик кадров. */
        private const val FPS_INTERVAL_MS = 500L

        fun intent(context: Context, plan: NativeLaunchPlan): Intent =
            Intent(context, GameActivity::class.java)
                .putExtra(EXTRA_PLAN, plan)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
