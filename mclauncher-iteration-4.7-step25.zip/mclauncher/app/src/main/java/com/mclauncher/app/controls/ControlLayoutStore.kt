package com.mclauncher.app.controls

import java.io.File
import java.io.IOException

/**
 * Хранит раскладку управления в одном файле. Читают его оба процесса (лаунчер и игра), пишет редактор.
 *
 * Запись атомарная: сначала во временный файл рядом, потом переименование. Оборванная запись (убили процесс) не портит прежний файл.
 * Нет файла или он не читается — берётся раскладка по умолчанию: управление в игре не должно пропадать из-за испорченного файла.
 */
class ControlLayoutStore(private val file: File) {

    /** Есть ли сохранённая раскладка (иначе используется раскладка по умолчанию). */
    fun hasSaved(): Boolean = file.isFile

    fun load(): ControlLayout {
        if (!file.isFile || file.length() > ControlLayoutJson.MAX_BYTES) return ControlLayout.default()
        return try {
            ControlLayoutJson.decode(file.readText(Charsets.UTF_8)) ?: ControlLayout.default()
        } catch (e: IOException) {
            ControlLayout.default()
        }
    }

    /** @return `true`, если записано. Ошибка диска не бросается: редактор сообщит игроку, что сохранить не удалось. */
    fun save(layout: ControlLayout): Boolean {
        return try {
            file.parentFile?.mkdirs()
            val temp = File(file.parentFile, file.name + ".tmp")
            temp.writeText(ControlLayoutJson.encode(layout), Charsets.UTF_8)
            if (!temp.renameTo(file)) {
                // На некоторых файловых системах переименование поверх существующего не работает.
                file.delete()
                if (!temp.renameTo(file)) {
                    temp.delete()
                    return false
                }
            }
            true
        } catch (e: IOException) {
            false
        }
    }

    /** Забыть сохранённую раскладку: дальше снова раскладка по умолчанию. */
    fun reset() {
        file.delete()
    }

    companion object {
        /** Файл раскладки внутри папки данных приложения. */
        fun forFilesDir(filesDir: File): ControlLayoutStore = ControlLayoutStore(File(File(filesDir, "controls"), "layout.json"))
    }
}
