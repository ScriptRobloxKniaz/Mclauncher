package com.mclauncher.app.game

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Мелкие элементы поверх экрана игры, которые собираются кодом: окно «Игра запускается», кнопка меню и счётчик кадров.
 * Они не зависят от раскладки управления и всегда на месте.
 */
internal object GameOverlay {

    private val CARD_BACKGROUND = Color.rgb(250, 247, 245)
    private val INK = Color.rgb(27, 27, 31)

    private fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    /**
     * Окно «Игра запускается…»: заголовок, версия и сведения об игре, справа крестик. Крестик закрывает окно ([onClose]); игра при этом
     * продолжает запускаться. Само окно убирает [GameActivity], когда игра нарисовала первый кадр.
     */
    fun launchCard(context: Context, title: String, version: String, info: String, closeDescription: String, onClose: () -> Unit): View {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(context.dp(24), context.dp(14), context.dp(10), context.dp(14))
            background = GradientDrawable().apply {
                setColor(CARD_BACKGROUND)
                cornerRadius = context.dp(30).toFloat()
            }
            elevation = context.dp(8).toFloat()
            // Касания по самому окну не должны проваливаться к кнопкам управления под ним.
            isClickable = true
        }

        val texts = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(line(context, title, 17f, bold = false))
        texts.addView(line(context, version, 14f, bold = true, topMarginDp = 6))
        texts.addView(line(context, info, 14f, bold = true, topMarginDp = 2))
        card.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val close = TextView(context).apply {
            text = "✕"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            setTextColor(INK)
            gravity = Gravity.CENTER
            contentDescription = closeDescription
            setOnClickListener { onClose() }
        }
        card.addView(close, LinearLayout.LayoutParams(context.dp(48), context.dp(48)).apply { leftMargin = context.dp(12) })
        return card
    }

    private fun line(context: Context, text: String, sizeSp: Float, bold: Boolean, topMarginDp: Int = 0): TextView =
        TextView(context).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
            setTextColor(INK)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = context.dp(topMarginDp)
            }
        }

    /** Круглая кнопка меню игры («три полоски»). */
    fun menuButton(context: Context, description: String, onClick: () -> Unit): TextView =
        TextView(context).apply {
            text = "☰"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = description
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(110, 0, 0, 0))
            }
            setOnClickListener { onClick() }
        }

    /** Счётчик кадров рядом с кнопкой меню. */
    fun fpsLabel(context: Context): TextView =
        TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.argb(220, 255, 255, 255))
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
            setPadding(context.dp(10), 0, context.dp(10), 0)
        }

    /** Размер кнопки меню в пикселях. */
    fun menuButtonSize(context: Context): Int = context.dp(44)

    fun dpToPx(context: Context, dp: Int): Int = context.dp(dp)
}
