package com.mclauncher.app.controls

import android.content.Context
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/**
 * Невидимый «текстовый редактор» для экранной клавиатуры: когда он в фокусе и клавиатура открыта, всё, что вводит игрок,
 * приходит сюда и через [ImeTextTranslator] уходит в игру (чат, команды, таблички, переименование).
 *
 * Сам виджет текста не хранит: клавиатуре отдаётся «пустое» соединение, а ввод сразу пересылается дальше.
 * Подсказки и автоисправление отключены ([InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS]): игре нужен именно то, что нажато.
 */
class GameTextInput(context: Context, private val translator: ImeTextTranslator) : View(context) {

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN or EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_ACTION_SEND
        return Connection(this)
    }

    private inner class Connection(view: View) : BaseInputConnection(view, false) {
        override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
            translator.commit(text)
            return true
        }

        override fun setComposingText(text: CharSequence?, newCursorPosition: Int): Boolean {
            translator.setComposing(text)
            return true
        }

        override fun finishComposingText(): Boolean {
            translator.finishComposing()
            return true
        }

        override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
            translator.deleteBefore(beforeLength)
            return true
        }

        override fun sendKeyEvent(event: KeyEvent): Boolean {
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DEL -> translator.backspace()
                    KeyEvent.KEYCODE_ENTER -> translator.enter()
                }
            }
            return true
        }

        override fun performEditorAction(actionCode: Int): Boolean {
            translator.enter()
            return true
        }
    }

    private fun inputMethods(): InputMethodManager? = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager

    private fun isKeyboardVisible(): Boolean =
        ViewCompat.getRootWindowInsets(this)?.isVisible(WindowInsetsCompat.Type.ime()) ?: false

    fun show() {
        requestFocus()
        post { inputMethods()?.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT) }
    }

    fun hide() {
        inputMethods()?.hideSoftInputFromWindow(windowToken, 0)
    }

    /** Показать клавиатуру, если её нет, иначе спрятать. */
    fun toggle() {
        if (isKeyboardVisible()) hide() else show()
    }
}
