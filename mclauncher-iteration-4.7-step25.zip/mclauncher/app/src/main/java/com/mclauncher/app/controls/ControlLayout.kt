package com.mclauncher.app.controls

/** Форма кнопки на экране. */
enum class ButtonShape { SQUARE, CIRCLE }

/** Как кнопка нажимает действие: пока держат (HOLD) или «нажал — включено, нажал ещё раз — выключено» (TOGGLE, как приседание). */
enum class PressMode { HOLD, TOGGLE }

/**
 * Одна кнопка экранного управления.
 *
 * Положение — доля экрана (0..1) для левого верхнего угла, размер — в dp: так кнопки остаются удобными для пальца на любом
 * экране, а раскладка переносится между устройствами с разным соотношением сторон.
 *
 * @property id уникален в пределах раскладки;
 * @property targetId действие из [ControlTargets];
 * @property opacity прозрачность кнопки в игре (в редакторе кнопки всегда хорошо видны).
 */
data class ControlButton(
    val id: String,
    val label: String,
    val targetId: String,
    val x: Float,
    val y: Float,
    val widthDp: Int,
    val heightDp: Int,
    val shape: ButtonShape = ButtonShape.SQUARE,
    val mode: PressMode = PressMode.HOLD,
    val opacity: Float = DEFAULT_OPACITY,
) {
    companion object {
        const val DEFAULT_OPACITY = 0.55f
        const val MIN_OPACITY = 0.15f
        const val MAX_OPACITY = 1f
        const val MIN_SIZE_DP = 28
        const val MAX_SIZE_DP = 160
        const val DEFAULT_SIZE_DP = 56
        const val MAX_LABEL_LENGTH = 8
    }
}

/**
 * Раскладка экранного управления: набор кнопок. Неизменяемая; все правки возвращают новую раскладку.
 *
 * Чистая логика без Android: проверяется тестами. Хранение — [ControlLayoutStore] и [ControlLayoutJson], показ — Compose.
 */
data class ControlLayout(val buttons: List<ControlButton>) {

    fun find(id: String): ControlButton? = buttons.firstOrNull { it.id == id }

    /** Новая кнопка с подходящим действием и подписью по умолчанию в середине экрана. `null`, если кнопок уже [MAX_BUTTONS]. */
    fun withNewButton(targetId: String, screenWidthDp: Float, screenHeightDp: Float): Pair<ControlLayout, ControlButton>? {
        if (buttons.size >= MAX_BUTTONS) return null
        val target = ControlTargets.find(targetId) ?: return null
        val size = ControlButton.DEFAULT_SIZE_DP
        val button = ControlButton(
            id = nextId(),
            label = target.label.take(ControlButton.MAX_LABEL_LENGTH),
            targetId = targetId,
            x = 0.5f,
            y = 0.5f,
            widthDp = size,
            heightDp = size,
        ).clampedTo(screenWidthDp, screenHeightDp)
        return ControlLayout(buttons + button) to button
    }

    /** Копия кнопки [id] со смещением, чтобы её было видно поверх оригинала. `null`, если кнопки нет или достигнут предел. */
    fun withDuplicate(id: String, screenWidthDp: Float, screenHeightDp: Float): Pair<ControlLayout, ControlButton>? {
        val source = find(id) ?: return null
        if (buttons.size >= MAX_BUTTONS) return null
        val offset = 0.04f
        val copy = source.copy(id = nextId(), x = source.x + offset, y = source.y + offset).clampedTo(screenWidthDp, screenHeightDp)
        return ControlLayout(buttons + copy) to copy
    }

    fun without(id: String): ControlLayout = ControlLayout(buttons.filterNot { it.id == id })

    /** Заменяет кнопку [id] результатом [change]; положение и размер приводятся к допустимым. Нет такой кнопки — раскладка прежняя. */
    fun changed(id: String, screenWidthDp: Float, screenHeightDp: Float, change: (ControlButton) -> ControlButton): ControlLayout {
        if (find(id) == null) return this
        return ControlLayout(buttons.map { if (it.id == id) change(it).sanitized().clampedTo(screenWidthDp, screenHeightDp) else it })
    }

    /** Сдвиг кнопки на ([dxDp], [dyDp]) при перетаскивании. Выйти за экран кнопка не может. */
    fun dragged(id: String, dxDp: Float, dyDp: Float, screenWidthDp: Float, screenHeightDp: Float): ControlLayout =
        changed(id, screenWidthDp, screenHeightDp) {
            it.copy(
                x = if (screenWidthDp > 0f) it.x + dxDp / screenWidthDp else it.x,
                y = if (screenHeightDp > 0f) it.y + dyDp / screenHeightDp else it.y,
            )
        }

    private fun nextId(): String {
        val used = buttons.mapTo(HashSet()) { it.id }
        var n = buttons.size + 1
        while ("b$n" in used) n++
        return "b$n"
    }

    companion object {
        /** Предел числа кнопок: больше не нужно, а лишнее замедляет перерисовку. */
        const val MAX_BUTTONS = 60

        val EMPTY = ControlLayout(emptyList())

        /**
         * Раскладка по умолчанию в духе Zalith Launcher 2: слева внизу движение, справа внизу действия, сверху служебные клавиши.
         * Подписи — краткие обозначения клавиш, не требуют перевода.
         */
        fun default(): ControlLayout {
            val buttons = ArrayList<ControlButton>()
            fun add(label: String, target: String, x: Float, y: Float, size: Int = 52, shape: ButtonShape = ButtonShape.SQUARE, mode: PressMode = PressMode.HOLD) {
                buttons += ControlButton("b${buttons.size + 1}", label, target, x, y, size, size, shape, mode)
            }
            // Служебные клавиши сверху слева: два ряда по три.
            add("Esc", "key.esc", 0.02f, 0.03f)
            add("F3", "key.f3", 0.02f + 0.075f, 0.03f)
            add("F5", "key.f5", 0.02f + 0.15f, 0.03f)
            add("Tab", "key.tab", 0.02f, 0.03f + 0.15f)
            add("T", "key.t", 0.02f + 0.075f, 0.03f + 0.15f)
            add("IME", ControlTargets.IME, 0.02f + 0.15f, 0.03f + 0.15f)
            // Режим «мышь»: курсор-тачпад для меню и инвентаря (пока режим включён, кнопка подсвечена).
            add("Мышь", ControlTargets.MOUSE_MODE, 0.02f + 0.225f, 0.03f + 0.15f)
            // Сверху справа: скрыть интерфейс игры и перебор предметов в панели.
            add("GUI", "key.f1", 0.92f, 0.03f)
            add("◄", "scroll.up", 0.70f, 0.03f)
            add("►", "scroll.down", 0.78f, 0.03f)
            // Движение: крест из W A S D и Ctrl для бега.
            add("W", "key.w", 0.12f, 0.50f, shape = ButtonShape.CIRCLE)
            add("A", "key.a", 0.04f, 0.66f, shape = ButtonShape.CIRCLE)
            add("S", "key.s", 0.12f, 0.82f, shape = ButtonShape.CIRCLE)
            add("D", "key.d", 0.20f, 0.66f, shape = ButtonShape.CIRCLE)
            add("Ctrl", "key.lctrl", 0.04f, 0.50f, mode = PressMode.TOGGLE)
            // Действия справа: прыжок, приседание, атака, использование, инвентарь, выбросить.
            add("␣", "key.space", 0.86f, 0.62f, size = 64, shape = ButtonShape.CIRCLE)
            add("⇧", "key.lshift", 0.86f, 0.82f, mode = PressMode.TOGGLE)
            add("ЛКМ", "mouse.left", 0.74f, 0.70f, size = 60, shape = ButtonShape.CIRCLE)
            add("ПКМ", "mouse.right", 0.66f, 0.82f, size = 60, shape = ButtonShape.CIRCLE)
            add("E", "key.e", 0.92f, 0.46f)
            add("Q", "key.q", 0.92f, 0.30f)
            return ControlLayout(buttons.map { it.sanitized() })
        }
    }
}

/** Приводит значения к допустимым: размер и прозрачность в пределах, подпись не длиннее предела, положение в 0..1. */
fun ControlButton.sanitized(): ControlButton = copy(
    label = label.take(ControlButton.MAX_LABEL_LENGTH),
    x = if (x.isNaN()) 0f else x.coerceIn(0f, 1f),
    y = if (y.isNaN()) 0f else y.coerceIn(0f, 1f),
    widthDp = widthDp.coerceIn(ControlButton.MIN_SIZE_DP, ControlButton.MAX_SIZE_DP),
    heightDp = heightDp.coerceIn(ControlButton.MIN_SIZE_DP, ControlButton.MAX_SIZE_DP),
    opacity = if (opacity.isNaN()) ControlButton.DEFAULT_OPACITY else opacity.coerceIn(ControlButton.MIN_OPACITY, ControlButton.MAX_OPACITY),
)

/**
 * Сдвигает кнопку так, чтобы она целиком помещалась на экране размером [screenWidthDp] × [screenHeightDp].
 * Если экран ещё неизвестен (0), положение только ограничивается долей 0..1.
 */
fun ControlButton.clampedTo(screenWidthDp: Float, screenHeightDp: Float): ControlButton {
    val maxX = if (screenWidthDp > 0f) (1f - widthDp / screenWidthDp).coerceAtLeast(0f) else 1f
    val maxY = if (screenHeightDp > 0f) (1f - heightDp / screenHeightDp).coerceAtLeast(0f) else 1f
    return copy(x = x.coerceIn(0f, maxX), y = y.coerceIn(0f, maxY))
}
