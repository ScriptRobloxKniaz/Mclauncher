package com.mclauncher.app.launch

import com.mclauncher.engine.CoreStatus
import com.mclauncher.engine.EngineLaunchSpec
import com.mclauncher.engine.LaunchCommand
import com.mclauncher.engine.launch.RendererProfile
import java.io.File

/**
 * Текстовый отчёт о запуске: какая команда будет выполнена, чего не хватает ядру, какие файлы classpath
 * отсутствуют. Его можно открыть из папки игры и приложить к сообщению об ошибке. Токен доступа скрыт.
 */
object LaunchPreview {

    fun render(
        spec: EngineLaunchSpec,
        command: LaunchCommand,
        status: CoreStatus,
        renderer: RendererProfile = RendererProfile.GL4ES,
        switchedFrom: RendererProfile? = null,
        /** Java, которую требует версия игры; если она отличается от [EngineLaunchSpec.javaMajor], выбрана в настройках. */
        requiredJava: Int = spec.javaMajor,
        /** Окно игры (ширина, высота, процент) и экран телефона (ширина, высота); `null` — не писать. */
        window: Pair<Triple<Int, Int, Int>, Pair<Int, Int>>? = null,
    ): String = buildString {
        appendLine("MCLauncher launch report")
        appendLine(if (status.isReady) "Status:    the core is ready; the game is being started" else "Status:    the core is NOT ready; the game is NOT started")
        appendLine()
        appendLine("Version:   ${spec.versionId}")
        appendLine("Main class: ${spec.mainClass}")
        appendLine("Java:      ${spec.javaMajor} (runtime: ${command.javaHome.path})")
        if (requiredJava != spec.javaMajor) {
            appendLine("           the game asks for Java $requiredJava; Java ${spec.javaMajor} was chosen in Settings")
        }
        appendLine("LWJGL:     ${spec.lwjgl.lwjgl.dirName}${if (spec.lwjgl.legacyLwjgl2) " (+ LWJGL 2 compatibility layer)" else ""}")
        appendLine("Natives:   ${command.nativesDir.path}")
        appendLine("Memory:    ${spec.ramMb} MB")
        if (window != null) {
            val (game, screen) = window
            appendLine("Window:    ${game.first}x${game.second} (${game.third}% of the screen ${screen.first}x${screen.second})")
        }
        appendLine("Renderer:  ${renderer.displayName} (${renderer.id}, ${renderer.requiredLibraries.joinToString(", ")})")
        if (switchedFrom != null) {
            appendLine("           replaced ${switchedFrom.displayName}: it does not support this Minecraft version")
        }
        appendLine()

        if (status.isReady) {
            appendLine("Core: ready")
        } else {
            appendLine("Core: NOT READY — ${status.missing.size} item(s) missing:")
            status.missing.forEach { appendLine("  - $it") }
            appendLine("  Runtimes, LWJGL and launch components: Settings → Game core → Install.")
            appendLine("  Native libraries (libpojavexec.so, the renderer libraries, ...) come only with the APK \"with core and natives\".")
        }
        appendLine()

        if (command.warnings.isNotEmpty()) {
            appendLine("Warnings:")
            command.warnings.forEach { appendLine("  - $it") }
            appendLine()
        }

        val missingLibraries = spec.libraryJars.filterNot { File(it).exists() }
        if (missingLibraries.isNotEmpty() || !File(spec.clientJar).exists()) {
            appendLine("Files missing on disk (skipped in classpath):")
            missingLibraries.forEach { appendLine("  - $it") }
            if (!File(spec.clientJar).exists()) appendLine("  - ${spec.clientJar}")
            appendLine()
        }

        appendLine("Command (one argument per line):")
        command.redacted().forEach { appendLine("  $it") }
        appendLine()
        appendLine("Classpath (${command.classpath.size} entries):")
        command.classpath.forEach { appendLine("  $it") }
    }
}
