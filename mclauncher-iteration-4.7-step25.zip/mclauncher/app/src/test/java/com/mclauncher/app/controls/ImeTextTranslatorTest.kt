package com.mclauncher.app.controls

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ImeTextTranslatorTest {

    private val events = ArrayList<String>()
    private val sink = object : TextSink {
        override fun typeChar(c: Char) { events += "char $c" }
        override fun backspace() { events += "bs" }
        override fun enter() { events += "enter" }
    }
    private val ime = ImeTextTranslator(sink)

    @Test
    fun committedTextIsTypedCharacterByCharacter() {
        ime.commit("hi")

        assertEquals(listOf("char h", "char i"), events)
    }

    @Test
    fun aGrowingDraftOnlyTypesTheNewLetters() {
        ime.setComposing("h")
        ime.setComposing("he")
        ime.setComposing("hel")

        assertEquals(listOf("char h", "char e", "char l"), events)
    }

    @Test
    fun aReplacedDraftDeletesOnlyWhatDiffers() {
        ime.setComposing("helo")
        events.clear()

        ime.setComposing("hello")

        assertEquals(listOf("bs", "char l", "char o"), events)
    }

    @Test
    fun committingTheSameDraftTypesNothingMore() {
        ime.setComposing("привет")
        events.clear()

        ime.commit("привет")

        assertTrue(events.isEmpty())
    }

    @Test
    fun aNewWordAfterACommitStartsFromScratch() {
        ime.commit("ab")
        events.clear()

        ime.setComposing("cd")

        assertEquals(listOf("char c", "char d"), events)
    }

    @Test
    fun deletingSendsBackspacesAndShortensTheDraft() {
        ime.setComposing("abc")
        events.clear()

        ime.deleteBefore(2)
        ime.setComposing("a")

        assertEquals(listOf("bs", "bs"), events)
    }

    @Test
    fun anEmptyDraftErasesTheOldOne() {
        ime.setComposing("abc")
        events.clear()

        ime.setComposing("")

        assertEquals(listOf("bs", "bs", "bs"), events)
    }

    @Test
    fun aNewlineIsEnter() {
        ime.commit("a\nb")

        assertEquals(listOf("char a", "enter", "char b"), events)
    }

    @Test
    fun enterAndBackspaceKeysPassThroughAndForgetTheDraft() {
        ime.setComposing("ab")
        events.clear()

        ime.enter()
        ime.setComposing("c")

        assertEquals(listOf("enter", "char c"), events)
    }

    @Test
    fun emojiCannotBeSentAndAreSkipped() {
        ime.commit("a😀b")

        assertEquals(listOf("char a", "char b"), events)
    }

    @Test
    fun nonPositiveDeleteDoesNothing() {
        ime.deleteBefore(0)
        ime.deleteBefore(-3)

        assertTrue(events.isEmpty())
    }

    @Test
    fun nullTextIsTreatedAsEmpty() {
        ime.commit(null)
        ime.setComposing(null)

        assertTrue(events.isEmpty())
    }

    @Test
    fun finishingADraftKeepsItsLettersAndLetsTheNextOneStartFresh() {
        ime.setComposing("ab")
        ime.finishComposing()
        events.clear()

        ime.setComposing("cd")

        assertEquals(listOf("char c", "char d"), events)
    }
}
