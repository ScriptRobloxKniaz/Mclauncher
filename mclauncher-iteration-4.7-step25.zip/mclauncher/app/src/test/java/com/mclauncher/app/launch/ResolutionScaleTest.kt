package com.mclauncher.app.launch

import com.mclauncher.engine.EngineEnvironment
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ResolutionScaleTest {

    private fun env(width: Int = 2400, height: Int = 1080) = EngineEnvironment(
        gameDir = File("/g"), userHome = File("/h"), cacheDir = File("/c"),
        timezone = "Asia/Baku", androidRelease = "15", screenWidth = width, screenHeight = height, cpuCores = 8,
    )

    @Test
    fun theDefaultIsTheFullScreen() {
        assertEquals(100, ResolutionScale.DEFAULT_PERCENT)
        assertEquals(100, ResolutionScale.clamp(null))
    }

    @Test
    fun valuesAreCutToTheRangeAndRoundedToTheStep() {
        assertEquals(50, ResolutionScale.clamp(0))
        assertEquals(50, ResolutionScale.clamp(-30))
        assertEquals(50, ResolutionScale.clamp(10))
        assertEquals(100, ResolutionScale.clamp(500))
        assertEquals(100, ResolutionScale.clamp(Int.MAX_VALUE))
        assertEquals(75, ResolutionScale.clamp(74))
        assertEquals(75, ResolutionScale.clamp(76))
        assertEquals(70, ResolutionScale.clamp(72))
        assertEquals(80, ResolutionScale.clamp(78))
        assertEquals(60, ResolutionScale.clamp(60))
    }

    @Test
    fun everyAllowedValueIsItsOwnFixedPoint() {
        for (p in ResolutionScale.MIN_PERCENT..ResolutionScale.MAX_PERCENT step ResolutionScale.STEP_PERCENT) {
            assertEquals(p, ResolutionScale.clamp(p))
        }
    }

    @Test
    fun theFullScreenIsReturnedAsIs() {
        assertEquals(2401 to 1079, ResolutionScale.apply(2401, 1079, 100))
        assertEquals(2400 to 1080, ResolutionScale.apply(2400, 1080, 100))
    }

    @Test
    fun aSmallerWindowHasEvenSidesInProportion() {
        assertEquals(1800 to 810, ResolutionScale.apply(2400, 1080, 75))
        assertEquals(1200 to 540, ResolutionScale.apply(2400, 1080, 50))
        val (w, h) = ResolutionScale.apply(2401, 1079, 70)
        assertTrue("even width: $w", w % 2 == 0)
        assertTrue("even height: $h", h % 2 == 0)
        // 70% от 2401 и 1079 — 1680,7 и 755,3: ближайшие чётные
        assertEquals(1680 to 756, w to h)
    }

    @Test
    fun aTinyScreenNeverCollapsesToNothing() {
        assertEquals(2 to 2, ResolutionScale.apply(1, 1, 50))
        assertEquals(2 to 2, ResolutionScale.apply(0, 0, 50))
    }

    @Test
    fun anOutOfRangePercentIsTreatedAsTheNearestAllowedOne() {
        assertEquals(ResolutionScale.apply(2400, 1080, 50), ResolutionScale.apply(2400, 1080, 3))
        assertEquals(2400 to 1080, ResolutionScale.apply(2400, 1080, 900))
    }

    @Test
    fun theEnvironmentKeepsEverythingButTheWindowSize() {
        val scaled = env().withResolutionPercent(75)

        assertEquals(1800, scaled.screenWidth)
        assertEquals(810, scaled.screenHeight)
        assertEquals(env().copy(screenWidth = 1800, screenHeight = 810), scaled)
    }

    @Test
    fun theFullScreenReturnsTheSameEnvironmentObject() {
        val e = env()

        assertSame(e, e.withResolutionPercent(100))
    }
}
