package com.mclauncher.app.controls

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ControlGeometryTest {

    // Экран 1000 × 500 пикселей при плотности 2: это 500 × 250 dp.
    private val w = 1000f
    private val h = 500f
    private val density = 2f

    private fun button(id: String, x: Float, y: Float, size: Int = 50, shape: ButtonShape = ButtonShape.SQUARE) =
        ControlButton(id, id, "key.w", x, y, size, size, shape)

    @Test
    fun theRectangleStartsAtTheFractionAndHasTheSizeInPixels() {
        val rect = ControlGeometry.rectOf(button("a", 0.1f, 0.2f, 50), w, h, density)

        assertEquals(100f, rect.left, 0.001f)
        assertEquals(100f, rect.top, 0.001f)
        assertEquals(200f, rect.right, 0.001f)
        assertEquals(200f, rect.bottom, 0.001f)
        assertEquals(150f, rect.centerX, 0.001f)
    }

    @Test
    fun aSquareButtonIsHitEverywhereInsideItAndNowhereOutside() {
        val b = button("a", 0.1f, 0.2f)

        assertTrue(ControlGeometry.hits(b, 101f, 101f, w, h, density))
        assertTrue(ControlGeometry.hits(b, 199f, 199f, w, h, density))
        assertFalse(ControlGeometry.hits(b, 99f, 150f, w, h, density))
        assertFalse(ControlGeometry.hits(b, 150f, 201f, w, h, density))
    }

    @Test
    fun aRoundButtonIsNotHitInTheCorners() {
        val b = button("a", 0.1f, 0.2f, shape = ButtonShape.CIRCLE)

        assertTrue(ControlGeometry.hits(b, 150f, 150f, w, h, density))
        assertTrue(ControlGeometry.hits(b, 105f, 150f, w, h, density))
        assertFalse("the corner of the bounding box is outside the circle", ControlGeometry.hits(b, 102f, 102f, w, h, density))
    }

    @Test
    fun theTopmostButtonWinsWhereTwoOverlap() {
        val under = button("under", 0.1f, 0.2f)
        val over = button("over", 0.12f, 0.22f)

        assertEquals("over", ControlGeometry.topmostAt(listOf(under, over), 150f, 150f, w, h, density)?.id)
        assertEquals("under", ControlGeometry.topmostAt(listOf(over, under), 150f, 150f, w, h, density)?.id)
        assertNull(ControlGeometry.topmostAt(listOf(under, over), 900f, 400f, w, h, density))
    }

    @Test
    fun aButtonNearTheRightEdgeIsPulledBackOnScreenForDrawingAndHitting() {
        // x = 0.98 при ширине 50 dp = 100 px вылезла бы за экран; видимая кнопка стоит у самого края, и нажимается именно она.
        val b = button("edge", 0.98f, 0.1f)

        val fitted = ControlGeometry.fitted(b, w, h, density)
        val rect = ControlGeometry.rectOf(fitted, w, h, density)

        assertEquals(w, rect.right, 0.01f)
        assertTrue(ControlGeometry.hits(b, 990f, 80f, w, h, density))
    }

    @Test
    fun anUnknownDensityLeavesTheButtonAlone() {
        val b = button("a", 0.98f, 0.1f)

        assertEquals(b, ControlGeometry.fitted(b, w, h, 0f))
    }

    @Test
    fun theResizeHandleSitsAtTheBottomRightCorner() {
        val rect = PxRect(100f, 100f, 200f, 200f)

        assertTrue(ControlGeometry.onResizeHandle(rect, 195f, 195f, 30f))
        assertTrue("a little outside the corner still grabs it", ControlGeometry.onResizeHandle(rect, 205f, 205f, 30f))
        assertFalse(ControlGeometry.onResizeHandle(rect, 150f, 150f, 30f))
        assertFalse(ControlGeometry.onResizeHandle(rect, 195f, 120f, 30f))
    }

    // ---------------------------------------------------------------- размер

    private val layout = ControlLayout(
        listOf(
            button("sq", 0.1f, 0.1f, 50),
            button("ci", 0.5f, 0.1f, 50, ButtonShape.CIRCLE),
        ),
    )

    @Test
    fun aSquareButtonTakesBothSizes() {
        val resized = layout.withSize("sq", 80f, 40f, 500f, 250f).find("sq")!!

        assertEquals(80, resized.widthDp)
        assertEquals(40, resized.heightDp)
    }

    @Test
    fun aRoundButtonStaysRoundWhateverTheDragDirection() {
        val resized = layout.withSize("ci", 90f, 50f, 500f, 250f).find("ci")!!

        assertEquals(70, resized.widthDp)
        assertEquals(70, resized.heightDp)
    }

    @Test
    fun theSizeIsKeptWithinTheLimits() {
        val big = layout.withSize("sq", 5000f, 5000f, 5000f, 5000f).find("sq")!!
        val small = layout.withSize("sq", 1f, 1f, 500f, 250f).find("sq")!!

        assertEquals(ControlButton.MAX_SIZE_DP, big.widthDp)
        assertEquals(ControlButton.MIN_SIZE_DP, small.heightDp)
    }

    @Test
    fun aGrownButtonIsPushedBackIntoTheScreen() {
        val moved = ControlLayout(listOf(button("edge", 0.9f, 0.1f, 50)))

        val grown = moved.withSize("edge", 100f, 100f, 500f, 250f).find("edge")!!

        assertTrue(grown.x * 500f + grown.widthDp <= 500.01f)
    }

    @Test
    fun resizingAnUnknownButtonChangesNothing() {
        assertEquals(layout, layout.withSize("nope", 80f, 80f, 500f, 250f))
    }
}
