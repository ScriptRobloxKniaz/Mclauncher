package com.mclauncher.app.controls

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class ControlLayoutJsonTest {

    @get:Rule
    val tmp = TemporaryFolder()

    @Test
    fun theDefaultLayoutSurvivesARoundTrip() {
        val layout = ControlLayout.default()

        val back = ControlLayoutJson.decode(ControlLayoutJson.encode(layout))

        assertEquals(layout, back)
    }

    @Test
    fun everyKindOfSettingSurvivesARoundTrip() {
        val layout = ControlLayout(
            listOf(ControlButton("x1", "Прыг", "key.space", 0.33f, 0.44f, 77, 66, ButtonShape.CIRCLE, PressMode.TOGGLE, 0.8f)),
        )

        assertEquals(layout, ControlLayoutJson.decode(ControlLayoutJson.encode(layout)))
    }

    @Test
    fun anEmptyLayoutIsAValidChoice() {
        val back = ControlLayoutJson.decode(ControlLayoutJson.encode(ControlLayout.EMPTY))

        assertNotNull(back)
        assertTrue(back!!.buttons.isEmpty())
    }

    @Test
    fun garbageIsNotALayout() {
        assertNull(ControlLayoutJson.decode("not json"))
        assertNull(ControlLayoutJson.decode("[]"))
        assertNull(ControlLayoutJson.decode("""{"version":1}"""))
        assertNull(ControlLayoutJson.decode(""))
        assertNull(ControlLayoutJson.decode("x".repeat(ControlLayoutJson.MAX_BYTES + 1)))
    }

    @Test
    fun badButtonsAreSkippedAndTheRestIsKept() {
        val text = """
            {"version":1,"buttons":[
              {"id":"a","label":"W","target":"key.w","x":0.1,"y":0.1,"w":50,"h":50},
              {"id":"b","label":"?","target":"key.does-not-exist","x":0.1,"y":0.1},
              "string instead of object",
              {"label":"no target"},
              {"id":"c","target":"mouse.left"}
            ]}
        """.trimIndent()

        val layout = ControlLayoutJson.decode(text)!!

        assertEquals(listOf("a", "c"), layout.buttons.map { it.id })
        assertEquals("ЛКМ", layout.find("c")!!.label)
        assertEquals(ControlButton.DEFAULT_SIZE_DP, layout.find("c")!!.widthDp)
    }

    @Test
    fun outOfRangeNumbersAreBroughtBack() {
        val text = """{"buttons":[{"id":"a","label":"WWWWWWWWWWWWWWWWWW","target":"key.w","x":9,"y":-4,"w":5000,"h":1,"opacity":7}]}"""

        val b = ControlLayoutJson.decode(text)!!.buttons.single()

        assertEquals(ControlButton.MAX_LABEL_LENGTH, b.label.length)
        assertEquals(1f, b.x, 0f)
        assertEquals(0f, b.y, 0f)
        assertEquals(ControlButton.MAX_SIZE_DP, b.widthDp)
        assertEquals(ControlButton.MIN_SIZE_DP, b.heightDp)
        assertEquals(ControlButton.MAX_OPACITY, b.opacity, 0f)
    }

    @Test
    fun duplicateIdsGetNewOnes() {
        val text = """{"buttons":[{"id":"a","target":"key.w"},{"id":"a","target":"key.a"},{"id":"a","target":"key.s"}]}"""

        val ids = ControlLayoutJson.decode(text)!!.buttons.map { it.id }

        assertEquals(3, ids.toSet().size)
    }

    @Test
    fun aHugeListIsCutAtTheLimit() {
        val one = """{"target":"key.w"}"""
        val text = """{"buttons":[${List(ControlLayout.MAX_BUTTONS + 25) { one }.joinToString(",")}]}"""

        assertEquals(ControlLayout.MAX_BUTTONS, ControlLayoutJson.decode(text)!!.buttons.size)
    }

    @Test
    fun unknownShapeAndModeFallBackToTheDefaults() {
        val b = ControlLayoutJson.decode("""{"buttons":[{"target":"key.w","shape":"hexagon","mode":"sticky"}]}""")!!.buttons.single()

        assertEquals(ButtonShape.SQUARE, b.shape)
        assertEquals(PressMode.HOLD, b.mode)
    }

    @Test
    fun wholeNumbersWrittenAsFloatsAreAccepted() {
        val b = ControlLayoutJson.decode("""{"buttons":[{"target":"key.w","w":52.0,"h":60.4}]}""")!!.buttons.single()

        assertEquals(52, b.widthDp)
        assertEquals(60, b.heightDp)
    }

    // ---------------------------------------------------------------- файл

    private fun store() = ControlLayoutStore.forFilesDir(tmp.root)

    @Test
    fun withoutAFileTheDefaultLayoutIsUsed() {
        assertEquals(ControlLayout.default(), store().load())
        assertTrue(!store().hasSaved())
    }

    @Test
    fun savedLayoutComesBack() {
        val layout = ControlLayout(listOf(ControlButton("z", "Z", "key.z", 0.5f, 0.5f, 60, 60)))

        assertTrue(store().save(layout))

        assertTrue(store().hasSaved())
        assertEquals(layout, store().load())
    }

    @Test
    fun savingTwiceReplacesTheFileAndLeavesNoTempFile() {
        store().save(ControlLayout.EMPTY)
        val second = ControlLayout(listOf(ControlButton("z", "Z", "key.z", 0.1f, 0.1f, 60, 60)))

        assertTrue(store().save(second))

        assertEquals(second, store().load())
        assertEquals(listOf("layout.json"), File(tmp.root, "controls").list()!!.toList())
    }

    @Test
    fun aCorruptFileFallsBackToTheDefault() {
        File(tmp.root, "controls").mkdirs()
        File(tmp.root, "controls/layout.json").writeText("{ this is not json")

        assertEquals(ControlLayout.default(), store().load())
    }

    @Test
    fun resetBringsTheDefaultBack() {
        store().save(ControlLayout.EMPTY)

        store().reset()

        assertTrue(!store().hasSaved())
        assertEquals(ControlLayout.default(), store().load())
    }
}
