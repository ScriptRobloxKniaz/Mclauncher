package com.mclauncher.app.data.versions

/** Описание версии содержит что-то небезопасное или непригодное (путь за пределами папки, адрес не по HTTPS, плохой хэш). */
class PlanException(message: String) : Exception(message)

/**
 * Превращает описание версии в список файлов для загрузки: что скачать, куда положить, чем проверить.
 * Здесь же отбираются библиотеки по правилам ОС и архитектуры и отбрасывается всё небезопасное.
 *
 * @param includeNativeJars нужны ли jar'ы с нативными библиотеками (`natives-*`). На Android их заменяет движок
 *   (этап 4.7), поэтому по умолчанию они не скачиваются.
 * @param libraryFilter дополнительный отбор — например, движок может отказаться от стандартных LWJGL.
 * @param libraryReplacement подмена устаревшей библиотеки другой (с её адресом, хэшем и размером) или `null`, если
 *   подменять нечего; применяется после [libraryFilter]. Для приложения оба хука задаёт [EngineLibraryPolicy].
 * @param allowInsecureHttp только для тестов с локальным сервером: в приложении всё скачивается по HTTPS.
 */
class InstallPlanner(
    private val layout: VersionLayout,
    private val env: OsEnvironment,
    private val includeNativeJars: Boolean = false,
    private val libraryFilter: (Library) -> Boolean = { true },
    private val assetBaseUrl: String = DEFAULT_ASSET_BASE_URL,
    private val allowInsecureHttp: Boolean = false,
    private val libraryReplacement: (Library) -> Library? = { null },
) {

    fun versionJsonTask(entry: ManifestEntry): DownloadTask {
        if (!SafePaths.isSafeName(entry.id)) throw PlanException("Unsafe version id: ${entry.id}")
        return DownloadTask(
            url = secure(entry.url),
            target = layout.versionJson(entry.id),
            sha1 = entry.sha1?.takeIf { SafePaths.isSha1(it) },
            size = 0L,
            kind = FileKind.VERSION_JSON,
        )
    }

    fun assetIndexTask(version: GameVersion): DownloadTask {
        val ref = version.assetIndex
        val target = layout.assetIndex(ref.id) ?: throw PlanException("Unsafe asset index id: ${ref.id}")
        return DownloadTask(
            url = secure(ref.url),
            target = target,
            sha1 = ref.sha1?.takeIf { SafePaths.isSha1(it) },
            size = ref.size,
            kind = FileKind.ASSET_INDEX,
        )
    }

    /** Библиотеки, которые идут в classpath на этом устройстве, без повторов. */
    fun selectLibraries(version: GameVersion): List<Library> =
        version.libraries
            .filter { RuleEvaluator.isAllowed(it.rules, env) }
            .filter { it.artifact != null }
            .filter { includeNativeJars || !isNativeClassifier(it.name) }
            .filter(libraryFilter)
            .map { library -> libraryReplacement(library) ?: library }

    /** Клиентский jar, библиотеки и конфигурация логов. Индекс ассетов и сами ассеты — отдельно. */
    fun coreTasks(version: GameVersion): List<DownloadTask> {
        val tasks = ArrayList<DownloadTask>()
        tasks += DownloadTask(
            url = secure(version.client.url),
            target = layout.clientJar(version.id),
            sha1 = version.client.sha1?.takeIf { SafePaths.isSha1(it) },
            size = version.client.size,
            kind = FileKind.CLIENT_JAR,
        )

        val seen = HashSet<String>()
        for (library in selectLibraries(version)) {
            val artifact = checkNotNull(library.artifact)
            val path = artifact.path ?: throw PlanException("Library ${library.name} has no path")
            if (!seen.add(path)) continue
            tasks += DownloadTask(
                url = secure(artifact.url),
                target = layout.library(path) ?: throw PlanException("Unsafe library path: $path"),
                sha1 = artifact.sha1?.takeIf { SafePaths.isSha1(it) },
                size = artifact.size,
                kind = FileKind.LIBRARY,
            )
        }

        version.logging?.let { logging ->
            tasks += DownloadTask(
                url = secure(logging.file.url),
                target = layout.logConfig(logging.fileId) ?: throw PlanException("Unsafe log config id: ${logging.fileId}"),
                sha1 = logging.file.sha1?.takeIf { SafePaths.isSha1(it) },
                size = logging.file.size,
                kind = FileKind.LOGGING,
            )
        }
        return tasks
    }

    /** Ассеты хранятся по хэшу: одинаковые файлы под разными именами скачиваются один раз. */
    fun assetTasks(index: AssetIndex): List<DownloadTask> {
        val base = assetBaseUrl.trimEnd('/')
        val seen = HashSet<String>()
        val tasks = ArrayList<DownloadTask>(index.objects.size)
        for (item in index.objects) {
            if (!SafePaths.isSha1(item.hash)) throw PlanException("Bad asset hash for '${item.name}'")
            val hash = item.hash.lowercase()
            if (!seen.add(hash)) continue
            tasks += DownloadTask(
                url = secure("$base/${hash.substring(0, 2)}/$hash"),
                target = layout.assetObject(hash) ?: throw PlanException("Bad asset hash for '${item.name}'"),
                sha1 = hash,
                size = item.size,
                kind = FileKind.ASSET_OBJECT,
                verifyExisting = false,
            )
        }
        return tasks
    }

    private fun secure(url: String): String {
        val ok = url.startsWith("https://") || (allowInsecureHttp && url.startsWith("http://"))
        if (!ok) throw PlanException("Refusing to download over an insecure or unknown scheme: $url")
        return url
    }

    /** Классификатор — четвёртая часть Maven-имени: `org.lwjgl:lwjgl:3.3.3:natives-linux`. */
    private fun isNativeClassifier(name: String): Boolean =
        name.substringBefore('@').split(':').getOrNull(3)?.startsWith("natives") == true

    companion object {
        const val DEFAULT_ASSET_BASE_URL = "https://resources.download.minecraft.net"
    }
}
