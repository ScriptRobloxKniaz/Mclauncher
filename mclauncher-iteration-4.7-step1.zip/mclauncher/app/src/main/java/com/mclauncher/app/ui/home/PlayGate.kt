package com.mclauncher.app.ui.home

import com.mclauncher.app.data.versions.VersionLibraryState
import com.mclauncher.app.ui.common.ActiveAccountState

/** Что делать, когда игрок нажал «Запустить». Чистая логика без Android — проверяется JVM-тестами. */
enum class PlayDecision {
    /** Всё готово: запускаем. */
    LAUNCH,

    /** Нет аккаунта: подсказать и открыть экран аккаунтов. */
    NEED_ACCOUNT,

    /** Нет ни одной установленной версии: подсказать и открыть экран версий. */
    NEED_VERSION,

    /** Версии есть, но ни одна не выбрана (нажата большая кнопка): попросить выбрать. */
    PICK_VERSION,

    /** Аккаунт или список версий ещё читаются с диска: повторное нажатие сработает через мгновение. */
    WAIT,
}

/**
 * [versionId] — версия, чья карточка нажата; `null` — нажата большая кнопка, запускается выбранная.
 * Сначала проверяется аккаунт: без него остальное бессмысленно.
 */
fun decidePlay(
    account: ActiveAccountState,
    library: VersionLibraryState?,
    versionId: String?,
): PlayDecision = when {
    account == ActiveAccountState.None -> PlayDecision.NEED_ACCOUNT
    account !is ActiveAccountState.Selected || library == null -> PlayDecision.WAIT
    library.installed.isEmpty() -> PlayDecision.NEED_VERSION
    versionId == null && library.selected == null -> PlayDecision.PICK_VERSION
    versionId != null && library.installed.none { it.id == versionId } -> PlayDecision.PICK_VERSION
    else -> PlayDecision.LAUNCH
}
