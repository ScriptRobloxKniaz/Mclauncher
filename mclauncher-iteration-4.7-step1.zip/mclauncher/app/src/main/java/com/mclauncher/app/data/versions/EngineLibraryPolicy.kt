package com.mclauncher.app.data.versions

/**
 * Что делать с библиотеками из описания версии, когда игру запускает ядро Pojav/Zalith (этап 4.7).
 *
 * Правила взяты из того, как это делает ZalithLauncher 2 (`game/version/download/_LibraryReplacement.kt`, ревизия
 * закреплена в `engine/UPSTREAM`), и описаны в `docs/ENGINE.md`:
 *
 * 1. **LWJGL и его нативы приносит ядро.** Обычные jar'ы `org.lwjgl*` из манифеста Mojang в classpath не нужны: ядро
 *    ставит впереди свои, пропатченные под Android, а нативы (`.so`) берёт только из собственной папки и подменяет ею
 *    `-Djava.library.path`. Нативы внутри jar'ов Mojang (`natives-*`) игнорируются — они собраны под glibc, а на
 *    Android другая libc. Поэтому такие библиотеки не скачиваются вовсе.
 * 2. **Три старые библиотеки заменяются** версиями, которые работают на Android (см. [replacement]).
 *
 * Объект без состояния и без Android: [InstallPlanner] использует его при установке, а при запуске (4.7b) classpath
 * строится по тому же [InstallPlanner.selectLibraries] — установленное и запускаемое не разойдутся.
 */
object EngineLibraryPolicy {

    /** Артефакты, которые не нужны вообще (платформенные обвязки старых версий). */
    private val DROPPED_ARTIFACTS = setOf("jinput-platform", "twitch-platform")

    /**
     * `true` — библиотека остаётся в classpath. `false` — её приносит ядро (LWJGL) или она бесполезна на Android.
     * Группа `org.lwjgl` и подгруппы (`org.lwjgl.lwjgl` у LWJGL 2) сравниваются целиком, а не по подстроке.
     */
    fun isNeeded(library: Library): Boolean {
        val coordinates = Coordinates.parse(library.name) ?: return true
        if (coordinates.group == "org.lwjgl" || coordinates.group.startsWith("org.lwjgl.")) return false
        return coordinates.artifact !in DROPPED_ARTIFACTS
    }

    /**
     * Замена для библиотеки или `null`, если трогать её не нужно. Заменяется только обычный jar (без классификатора),
     * у которого есть собственный артефакт; правила (`rules`) сохраняются.
     */
    fun replacement(library: Library): Library? {
        if (library.artifact == null) return null
        val coordinates = Coordinates.parse(library.name) ?: return null
        if (coordinates.classifier != null) return null
        val version = parseVersion(coordinates.version) ?: return null

        val target = REPLACEMENTS.firstOrNull { it.group == coordinates.group && it.artifact == coordinates.artifact }
            ?: return null
        if (!target.applies(version)) return null

        return library.copy(
            name = target.name,
            artifact = RemoteFile(url = target.url, sha1 = target.sha1, size = target.size, path = target.path),
            classifiers = emptyMap(),
            natives = emptyMap(),
            extractExcludes = emptyList(),
        )
    }

    /** Артефакт, на который заменяется старая библиотека. Публичен ради проверки по Maven Central (см. `ReplacementArtifactsOnlineTest`). */
    class ReplacementArtifact internal constructor(
        val group: String,
        val artifact: String,
        val version: String,
        val sha1: String,
        val size: Long,
        private val appliesTo: (List<Int>) -> Boolean,
    ) {
        val name: String get() = "$group:$artifact:$version"
        val path: String get() = "${group.replace('.', '/')}/$artifact/$version/$artifact-$version.jar"
        val url: String get() = "https://repo1.maven.org/maven2/$path"

        internal fun applies(version: List<Int>): Boolean = appliesTo(version)
    }

    /**
     * Значения (SHA-1, размер) перенесены из исходников Zalith 2 и **не сверялись** с Maven Central при написании
     * (из среды разработки хост недоступен). Их проверяет `ReplacementArtifactsOnlineTest` на CI.
     * Размер важен: устаревший размер из манифеста обрезал бы или забраковал новый файл.
     */
    val REPLACEMENTS: List<ReplacementArtifact> = listOf(
        // JNA старше 5.13 не знает Android/aarch64 как следует. Версии 5.13 и новее не трогаем.
        ReplacementArtifact(
            group = "net.java.dev.jna", artifact = "jna", version = "5.13.0",
            sha1 = "1200e7ebeedbe0d10062093f32925a912020e747", size = 1_879_325L,
            appliesTo = { v -> compare(v, listOf(5, 13)) < 0 },
        ),
        // OSHI 6.2.x ломается на Android; апстрим заменяет только ветку 6.2.
        ReplacementArtifact(
            group = "com.github.oshi", artifact = "oshi-core", version = "6.3.0",
            sha1 = "9e98cf55be371cafdb9c70c35d04ec2a8c2b42ac", size = 957_945L,
            appliesTo = { v -> v.getOrElse(0) { 0 } == 6 && v.getOrElse(1) { 0 } == 2 },
        ),
        // asm-all 4.x и старше (его тянут очень старые версии) заменяется на 5.0.4.
        ReplacementArtifact(
            group = "org.ow2.asm", artifact = "asm-all", version = "5.0.4",
            sha1 = "e6244859997b3d4237a552669279780876228909", size = 241_810L,
            appliesTo = { v -> v.getOrElse(0) { 0 } < 5 },
        ),
    )

    /** Числовая часть версии: `5.12.1` → `[5, 12, 1]`, `6.2.2-beta` → `[6, 2, 2]`. `null`, если цифр в начале нет. */
    internal fun parseVersion(version: String): List<Int>? {
        val parts = ArrayList<Int>()
        for (segment in version.split('.')) {
            val digits = segment.takeWhile { it.isDigit() }
            if (digits.isEmpty()) break
            parts += digits.toIntOrNull() ?: return null
            if (digits.length != segment.length) break // «2-beta»: дальше версия не продолжается
        }
        return parts.takeIf { it.isNotEmpty() }
    }

    /** Сравнение по общим позициям; недостающие считаются нулями: `5.13` == `5.13.0`. */
    internal fun compare(a: List<Int>, b: List<Int>): Int {
        for (i in 0 until maxOf(a.size, b.size)) {
            val diff = a.getOrElse(i) { 0 }.compareTo(b.getOrElse(i) { 0 })
            if (diff != 0) return diff
        }
        return 0
    }

    /** `group:artifact:version[:classifier][@ext]`. */
    internal data class Coordinates(
        val group: String,
        val artifact: String,
        val version: String,
        val classifier: String?,
    ) {
        companion object {
            fun parse(name: String): Coordinates? {
                val parts = name.substringBefore('@').split(':')
                if (parts.size < 3 || parts.take(3).any { it.isEmpty() }) return null
                return Coordinates(parts[0], parts[1], parts[2], parts.getOrNull(3)?.takeIf { it.isNotEmpty() })
            }
        }
    }
}
