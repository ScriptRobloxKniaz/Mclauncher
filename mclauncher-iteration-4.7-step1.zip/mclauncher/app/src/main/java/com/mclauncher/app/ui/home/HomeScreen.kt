package com.mclauncher.app.ui.home

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.settings.BackgroundPreset
import com.mclauncher.app.data.settings.BackgroundSelection
import com.mclauncher.app.data.versions.VersionLibraryState
import com.mclauncher.app.launch.LaunchPhase
import com.mclauncher.app.ui.common.ActiveAccountState
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.navigation.Destination

/**
 * Главный экран в альбомной ориентации из двух зон: слева шапка и сетка установленных версий (у каждой своя
 * кнопка «Запустить»), справа панель профиля — скин, ник, статус, выбранная версия и большая кнопка запуска.
 * Стадии запуска показывают сами кнопки, итог — диалог в корне UI.
 *
 * Если окно вдруг узкое (разделённый экран), зоны ставятся друг под другом.
 */
@Composable
fun HomeScreen(
    activeAccount: ActiveAccountState,
    library: VersionLibraryState?,
    launchPhase: LaunchPhase,
    /** `null` — запустить выбранную версию, иначе — именно эту (её сначала выбирают). */
    onPlay: (versionId: String?) -> Unit,
    onSelectVersion: (String) -> Unit,
    backgroundSelection: BackgroundSelection,
    customBackgroundPreview: ImageBitmap?,
    onSelectPreset: (BackgroundPreset) -> Unit,
    onPickCustomBackground: (Uri) -> Unit,
    onNavigate: (Destination) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var showBackgroundSheet by rememberSaveable { mutableStateOf(false) }

    // SAF: системный выбор картинки. Права на чтение действуют на один этот вызов — этого достаточно,
    // потому что картинка сразу копируется в хранилище приложения.
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            showBackgroundSheet = false
            onPickCustomBackground(uri)
        }
    }

    // Общая проверка для всех кнопок «Запустить»: аккаунт и версия должны быть, иначе объясняем и ведём куда нужно.
    val play: (String?) -> Unit = { versionId ->
        when (decidePlay(activeAccount, library, versionId)) {
            PlayDecision.LAUNCH -> onPlay(versionId)

            PlayDecision.NEED_ACCOUNT -> {
                Toast.makeText(context, R.string.play_need_account, Toast.LENGTH_SHORT).show()
                onNavigate(Destination.Accounts)
            }

            PlayDecision.NEED_VERSION -> {
                Toast.makeText(context, R.string.play_need_version, Toast.LENGTH_SHORT).show()
                onNavigate(Destination.Versions)
            }

            PlayDecision.PICK_VERSION ->
                Toast.makeText(context, R.string.play_pick_version, Toast.LENGTH_SHORT).show()

            PlayDecision.WAIT -> Unit
        }
    }

    val installed = library?.installed.orEmpty()
    val canLaunch = launchPhase == LaunchPhase.IDLE

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        // Размеры берём в локальные переменные: внутри вложенных лямбд так надёжнее, чем обращаться к scope.
        val availableWidth = maxWidth
        val availableHeight = maxHeight
        // Две зоны, пока окно шире, чем выше (альбомная ориентация закреплена в манифесте). Друг под другом их ставим
        // только в «высоком» или совсем узком окне — например, в разделённом экране.
        val narrow = availableWidth < availableHeight || availableWidth < 420.dp
        val panelWidth = when {
            availableWidth > 900.dp -> 340.dp
            availableWidth >= 640.dp -> 290.dp
            else -> 250.dp
        }
        // Фигура скина занимает всё свободное место по высоте, но в разумных пределах.
        val skinHeight: Dp = if (narrow) 96.dp else (availableHeight - 250.dp).coerceIn(72.dp, 170.dp)

        val header: @Composable () -> Unit = {
            HomeHeader(
                onOpenAssistant = { onNavigate(Destination.Assistant) },
                onOpenVersions = { onNavigate(Destination.Versions) },
                onChangeBackground = { showBackgroundSheet = true },
            )
        }
        val grid: @Composable (Modifier) -> Unit = { gridModifier ->
            VersionGrid(
                installed = installed,
                selectedId = library?.selected?.id,
                loaded = library != null,
                canLaunch = canLaunch,
                onSelect = onSelectVersion,
                onLaunch = { versionId -> play(versionId) },
                onOpenVersions = { onNavigate(Destination.Versions) },
                modifier = gridModifier,
            )
        }
        val panel: @Composable (Modifier) -> Unit = { panelModifier ->
            ProfilePanel(
                account = activeAccount,
                version = library?.selected,
                launchPhase = launchPhase,
                onPlay = { play(null) },
                onOpenAccounts = { onNavigate(Destination.Accounts) },
                onOpenVersions = { onNavigate(Destination.Versions) },
                modifier = panelModifier,
                skinHeight = skinHeight,
            )
        }

        if (narrow) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                header()
                // Панель прокручивается внутри себя, поэтому её можно ограничить: сетка версий не уедет за экран.
                panel(Modifier.fillMaxWidth().heightIn(max = availableHeight * 0.55f))
                grid(Modifier.weight(1f))
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    header()
                    grid(Modifier.weight(1f))
                }
                panel(
                    Modifier
                        .width(panelWidth)
                        .fillMaxHeight(),
                )
            }
        }
    }

    if (showBackgroundSheet) {
        BackgroundSheet(
            selection = backgroundSelection,
            customPreview = customBackgroundPreview,
            onSelectPreset = onSelectPreset,
            onPickFromGallery = { imagePicker.launch(arrayOf("image/*")) },
            onDismiss = { showBackgroundSheet = false },
        )
    }
}

@Composable
private fun HomeHeader(
    onOpenAssistant: () -> Unit,
    onOpenVersions: () -> Unit,
    onChangeBackground: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text = stringResource(R.string.app_name),
            // Заголовок лежит прямо на картинке, поэтому белый с тенью — читается на любом фоне.
            style = MaterialTheme.typography.headlineSmall.merge(
                TextStyle(
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    shadow = Shadow(color = Color(0x99000000), offset = Offset(0f, 2f), blurRadius = 8f),
                ),
            ),
            modifier = Modifier.weight(1f),
        )
        HeaderButton(LauncherIcons.Sparkle, stringResource(R.string.assistant_title), onOpenAssistant)
        HeaderButton(LauncherIcons.Versions, stringResource(R.string.versions_title), onOpenVersions)
        HeaderButton(LauncherIcons.Image, stringResource(R.string.background_change), onChangeBackground)
    }
}

@Composable
private fun HeaderButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    FilledTonalIconButton(
        onClick = onClick,
        colors = IconButtonDefaults.filledTonalIconButtonColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
        ),
    ) {
        Icon(imageVector = icon, contentDescription = description)
    }
}
