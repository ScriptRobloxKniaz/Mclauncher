package com.mclauncher.app.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val PlayTop = Color(0xFF9BE37A)
private val PlayBottom = Color(0xFF4F9A3C)
private val PlayContent = Color(0xFF0E2A08)

/**
 * Большая кнопка «Играть»: «блочная» в духе игры (тёмная нижняя грань, светлая рамка),
 * но с современными материалами — скругления, тень, ripple и пружинное нажатие.
 */
@Composable
fun PlayButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 112.dp,
    /** Идёт подготовка/запуск: вместо стрелки крутится индикатор, нажатия игнорируются. */
    busy: Boolean = false,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "playButtonScale",
    )
    // Невысокая кнопка (панель профиля в альбомной ориентации) получает более мелкий шрифт и иконки.
    val compact = height < 80.dp
    val shape = RoundedCornerShape(if (compact) 22.dp else 28.dp)

    Box(
        modifier = modifier
            .widthIn(max = 420.dp) // порядок важен: сначала предел, потом заполнение
            .fillMaxWidth()
            .height(height)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(
                elevation = if (pressed) 4.dp else 16.dp,
                shape = shape,
                ambientColor = PlayBottom,
                spotColor = PlayBottom,
            )
            .background(Brush.verticalGradient(listOf(PlayTop, PlayBottom)), shape)
            .drawBehind {
                // Тёмная «нижняя грань» блока
                val edge = (if (compact) 6.dp else 8.dp).toPx()
                drawRect(
                    color = Color(0x33000000),
                    topLeft = Offset(0f, size.height - edge),
                    size = Size(size.width, edge),
                )
            }
            .border(2.dp, Color(0x66FFFFFF), shape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = Color.White),
                enabled = !busy,
                role = Role.Button,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (busy) {
                CircularProgressIndicator(
                    color = PlayContent,
                    strokeWidth = if (compact) 3.dp else 4.dp,
                    modifier = Modifier.size(if (compact) 26.dp else 36.dp),
                )
            } else {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = null,
                    tint = PlayContent,
                    modifier = Modifier.size(if (compact) 32.dp else 44.dp),
                )
            }
            Text(
                text = label.uppercase(),
                color = PlayContent,
                style = (if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineLarge).copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = if (compact) 1.5.sp else 3.sp,
                ),
                maxLines = 1,
            )
        }
    }
}
