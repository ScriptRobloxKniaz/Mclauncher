package com.mclauncher.app.ui.skins

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.skin.SkinLayout
import com.mclauncher.app.data.skin.SkinModel
import com.mclauncher.app.data.skin.ViewSide

/**
 * Мини-рендер скина: персонаж спереди и сзади, плоскими «пикселями» без размытия.
 * Первый слой рисуется целиком, затем второй (шляпа, куртка, рукава, штаны). Куски текстуры и их места
 * берутся из [SkinLayout.previewParts]. Если [skin] = `null`, рисуется нейтральный силуэт с учётом [model].
 *
 * [skin] — текстура 64×64 (старые 64×32 уже преобразованы).
 */
@Composable
fun SkinPreview(
    skin: ImageBitmap?,
    model: SkinModel,
    modifier: Modifier = Modifier,
    viewHeight: Dp = 240.dp,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SkinView(
            skin = skin,
            model = model,
            side = ViewSide.FRONT,
            description = stringResource(R.string.skins_view_front),
            modifier = Modifier.height(viewHeight),
        )
        SkinView(
            skin = skin,
            model = model,
            side = ViewSide.BACK,
            description = stringResource(R.string.skins_view_back),
            modifier = Modifier.height(viewHeight),
        )
    }
}

/** Одна фигура спереди — для панели профиля на главном экране. Ширина получается из [height]. */
@Composable
fun SkinFront(
    skin: ImageBitmap?,
    model: SkinModel,
    modifier: Modifier = Modifier,
    height: Dp = 160.dp,
) {
    SkinView(
        skin = skin,
        model = model,
        side = ViewSide.FRONT,
        description = stringResource(R.string.skins_view_front),
        modifier = modifier.height(height),
    )
}

@Composable
private fun SkinView(
    skin: ImageBitmap?,
    model: SkinModel,
    side: ViewSide,
    description: String,
    modifier: Modifier = Modifier,
) {
    val parts = remember(side, model) { SkinLayout.previewParts(side, model) }
    val silhouette = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.16f)

    Canvas(
        modifier = modifier
            .aspectRatio(SkinLayout.PREVIEW_WIDTH.toFloat() / SkinLayout.PREVIEW_HEIGHT)
            .semantics { contentDescription = description },
    ) {
        // Целый масштаб (1 пиксель скина = unit экранных пикселей): края остаются чёткими.
        val unit = minOf(
            size.width / SkinLayout.PREVIEW_WIDTH,
            size.height / SkinLayout.PREVIEW_HEIGHT,
        ).toInt().coerceAtLeast(1)
        val originX = ((size.width - unit * SkinLayout.PREVIEW_WIDTH) / 2f).toInt()
        val originY = ((size.height - unit * SkinLayout.PREVIEW_HEIGHT) / 2f).toInt()

        for (part in parts) {
            val dstOffset = IntOffset(originX + part.destX * unit, originY + part.destY * unit)
            val dstSize = IntSize(part.source.width * unit, part.source.height * unit)
            if (skin != null) {
                drawImage(
                    image = skin,
                    srcOffset = IntOffset(part.source.x, part.source.y),
                    srcSize = IntSize(part.source.width, part.source.height),
                    dstOffset = dstOffset,
                    dstSize = dstSize,
                    filterQuality = FilterQuality.None, // ближайший сосед: без размытия «пикселей»
                )
            } else if (!part.isOverlay) {
                drawRect(
                    color = silhouette,
                    topLeft = Offset(dstOffset.x.toFloat(), dstOffset.y.toFloat()),
                    size = Size(dstSize.width.toFloat(), dstSize.height.toFloat()),
                )
            }
        }
    }
}
