package com.mclauncher.app.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mclauncher.app.R
import com.mclauncher.app.data.versions.InstalledVersion
import com.mclauncher.app.ui.components.LauncherIcons
import com.mclauncher.app.ui.versions.labelRes
import com.mclauncher.app.ui.versions.releaseDate

/**
 * Сетка карточек установленных версий. Нажатие на карточку выбирает версию, кнопка на ней запускает именно её.
 * В конце — карточка «Установить версию». Если версий ещё нет, вместо сетки — подсказка с кнопкой.
 */
@Composable
fun VersionGrid(
    installed: List<InstalledVersion>,
    selectedId: String?,
    loaded: Boolean,
    canLaunch: Boolean,
    onSelect: (String) -> Unit,
    onLaunch: (String) -> Unit,
    onOpenVersions: () -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 200.dp),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        when {
            // Пока список читается с диска, не показываем ни «пусто», ни кнопку установки: иначе она мигнёт.
            !loaded -> Unit

            installed.isEmpty() -> item(key = "empty", span = { GridItemSpan(maxLineSpan) }) {
                EmptyVersions(onOpenVersions = onOpenVersions)
            }

            else -> {
                items(installed, key = { it.id }) { version ->
                    VersionCard(
                        version = version,
                        selected = version.id == selectedId,
                        canLaunch = canLaunch,
                        onSelect = { onSelect(version.id) },
                        onLaunch = { onLaunch(version.id) },
                    )
                }
                item(key = "install") { InstallCard(onClick = onOpenVersions) }
            }
        }
    }
}

@Composable
private fun VersionCard(
    version: InstalledVersion,
    selected: Boolean,
    canLaunch: Boolean,
    onSelect: () -> Unit,
    onLaunch: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val date = releaseDate(version.releaseTime)
    Surface(
        onClick = onSelect,
        shape = RoundedCornerShape(22.dp),
        color = colors.surface.copy(alpha = 0.86f),
        border = if (selected) BorderStroke(2.dp, colors.primary) else null,
        shadowElevation = 6.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = colors.primaryContainer,
                    modifier = Modifier.size(44.dp),
                ) {
                    Icon(
                        imageVector = LauncherIcons.Cube,
                        contentDescription = null,
                        tint = colors.onPrimaryContainer,
                        modifier = Modifier.padding(9.dp),
                    )
                }
                Spacer(Modifier.size(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = version.id,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = listOfNotNull(stringResource(version.type.labelRes), date).joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (selected) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = stringResource(R.string.versions_selected),
                        tint = colors.primary,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
            Button(
                onClick = onLaunch,
                enabled = canLaunch,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(6.dp))
                Text(stringResource(R.string.play))
            }
        }
    }
}

@Composable
private fun InstallCard(onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        color = colors.surface.copy(alpha = 0.60f),
        border = BorderStroke(1.dp, colors.outline.copy(alpha = 0.6f)),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 118.dp),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = null,
                tint = colors.primary,
                modifier = Modifier.size(30.dp),
            )
            Text(
                text = stringResource(R.string.home_install_version),
                style = MaterialTheme.typography.labelLarge,
                color = colors.onSurface,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun EmptyVersions(onOpenVersions: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f),
        shadowElevation = 6.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(
                imageVector = LauncherIcons.Cube,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(40.dp),
            )
            Text(
                text = stringResource(R.string.home_no_versions_title),
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
            )
            Text(
                text = stringResource(R.string.home_no_versions_message),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Button(onClick = onOpenVersions) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(6.dp))
                Text(stringResource(R.string.home_install_version))
            }
        }
    }
}
