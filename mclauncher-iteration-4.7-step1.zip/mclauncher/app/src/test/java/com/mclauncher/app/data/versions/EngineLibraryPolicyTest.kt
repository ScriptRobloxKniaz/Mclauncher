package com.mclauncher.app.data.versions

import com.mclauncher.app.launch.GameDirectories
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule as JUnitRule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class EngineLibraryPolicyTest {

    @get:JUnitRule
    val tmp = TemporaryFolder()

    private val oldHash = "0123456789abcdef0123456789abcdef01234567"

    private fun lib(
        name: String,
        withArtifact: Boolean = true,
        rules: List<Rule> = emptyList(),
    ): Library {
        // Имя может быть заведомо кривым («a:b», пустым): тесту нужна просто какая-то правдоподобная запись пути.
        val parts = name.substringBefore('@').split(':')
        fun part(i: Int) = parts.getOrElse(i) { "x" }
        val path = "${part(0).replace('.', '/')}/${part(1)}/${part(2)}/${part(1)}-${part(2)}.jar"
        return Library(
            name = name,
            artifact = if (withArtifact) RemoteFile("https://libraries.minecraft.net/$path", oldHash, 111L, path) else null,
            classifiers = emptyMap(),
            natives = emptyMap(),
            extractExcludes = emptyList(),
            rules = rules,
        )
    }

    private fun needed(name: String) = EngineLibraryPolicy.isNeeded(lib(name))

    private fun replaced(name: String) = EngineLibraryPolicy.replacement(lib(name))?.name

    // ---- Что ядро приносит само ---------------------------------------------------------------

    @Test
    fun lwjgl3LibrariesAreDroppedBecauseTheEngineBringsItsOwn() {
        assertFalse(needed("org.lwjgl:lwjgl:3.3.3"))
        assertFalse(needed("org.lwjgl:lwjgl-glfw:3.3.3"))
        assertFalse(needed("org.lwjgl:lwjgl-opengl:3.3.3:natives-linux-arm64"))
    }

    @Test
    fun lwjgl2LibrariesAreDroppedToo() {
        assertFalse(needed("org.lwjgl.lwjgl:lwjgl:2.9.4-nightly-20150209"))
        assertFalse(needed("org.lwjgl.lwjgl:lwjgl_util:2.9.4-nightly-20150209"))
        assertFalse(needed("org.lwjgl.lwjgl:lwjgl-platform:2.9.4-nightly-20150209:natives-linux"))
    }

    @Test
    fun platformBindingsOfOldVersionsAreDropped() {
        assertFalse(needed("net.java.jinput:jinput-platform:2.0.5"))
        assertFalse(needed("com.mojang:twitch-platform:5.16"))
    }

    @Test
    fun everythingElseStays() {
        assertTrue(needed("com.google.code.gson:gson:2.10.1"))
        assertTrue(needed("net.java.jinput:jinput:2.0.5")) // сама jinput нужна, не нужна только платформенная часть
        assertTrue(needed("io.netty:netty-all:4.1.82.Final"))
    }

    @Test
    fun matchingIsByGroupNotBySubstring() {
        assertTrue(needed("org.lwjglx:lwjglx:1.0"))
        assertTrue(needed("com.example:org.lwjgl-helper:1.0"))
        assertTrue(needed("org.lwjglish:thing:1.0"))
    }

    @Test
    fun unparsableNamesAreKept() {
        assertTrue(needed("no-colons"))
        assertTrue(needed("a:b"))
        assertTrue(needed(""))
    }

    // ---- Замены ---------------------------------------------------------------------------------

    @Test
    fun oldJnaIsReplacedWith5_13_0() {
        assertEquals("net.java.dev.jna:jna:5.13.0", replaced("net.java.dev.jna:jna:5.12.1"))
        assertEquals("net.java.dev.jna:jna:5.13.0", replaced("net.java.dev.jna:jna:4.4.0"))
        assertEquals("net.java.dev.jna:jna:5.13.0", replaced("net.java.dev.jna:jna:5.9"))
    }

    @Test
    fun jnaFrom5_13IsLeftAlone() {
        assertNull(replaced("net.java.dev.jna:jna:5.13.0"))
        assertNull(replaced("net.java.dev.jna:jna:5.14.0"))
        assertNull(replaced("net.java.dev.jna:jna:5.13"))
        assertNull(replaced("net.java.dev.jna:jna:6.0.0")) // новее — не заменять старой
        assertNull(replaced("net.java.dev.jna:jna:10.0.0"))
    }

    @Test
    fun otherJnaArtifactsAreNotTouched() {
        assertNull(replaced("net.java.dev.jna:jna-platform:5.12.1"))
    }

    @Test
    fun onlyOshi6_2IsReplaced() {
        assertEquals("com.github.oshi:oshi-core:6.3.0", replaced("com.github.oshi:oshi-core:6.2.2"))
        assertEquals("com.github.oshi:oshi-core:6.3.0", replaced("com.github.oshi:oshi-core:6.2.0"))
        assertNull(replaced("com.github.oshi:oshi-core:6.1.6"))
        assertNull(replaced("com.github.oshi:oshi-core:6.3.0"))
        assertNull(replaced("com.github.oshi:oshi-core:6.4.0"))
        assertNull(replaced("com.github.oshi:oshi-core:5.8.6"))
    }

    @Test
    fun asmAllBefore5IsReplaced() {
        assertEquals("org.ow2.asm:asm-all:5.0.4", replaced("org.ow2.asm:asm-all:4.1"))
        assertEquals("org.ow2.asm:asm-all:5.0.4", replaced("org.ow2.asm:asm-all:3.3.1"))
        assertNull(replaced("org.ow2.asm:asm-all:5.0.3"))
        assertNull(replaced("org.ow2.asm:asm-all:9.5"))
    }

    @Test
    fun replacementCarriesItsOwnUrlHashSizeAndPath() {
        val result = EngineLibraryPolicy.replacement(lib("net.java.dev.jna:jna:5.12.1"))
        val artifact = result?.artifact
        assertNotNull(artifact)
        assertEquals("https://repo1.maven.org/maven2/net/java/dev/jna/jna/5.13.0/jna-5.13.0.jar", artifact!!.url)
        assertEquals("net/java/dev/jna/jna/5.13.0/jna-5.13.0.jar", artifact.path)
        assertEquals("1200e7ebeedbe0d10062093f32925a912020e747", artifact.sha1)
        assertEquals(1_879_325L, artifact.size) // старые 111 не должны остаться: из-за них файл считался бы повреждённым
    }

    @Test
    fun replacementKeepsTheRules() {
        val rule = Rule(RuleAction.ALLOW, OsRule(name = "linux", arch = null, version = null), emptyMap())
        val result = EngineLibraryPolicy.replacement(lib("net.java.dev.jna:jna:5.12.1", rules = listOf(rule)))
        assertEquals(listOf(rule), result?.rules)
    }

    @Test
    fun classifierOrMissingArtifactMeansNoReplacement() {
        assertNull(replaced("net.java.dev.jna:jna:5.12.1:natives-linux"))
        assertNull(EngineLibraryPolicy.replacement(lib("net.java.dev.jna:jna:5.12.1", withArtifact = false)))
    }

    @Test
    fun unparsableVersionsAreLeftAlone() {
        assertNull(replaced("net.java.dev.jna:jna:LATEST"))
        assertNull(replaced("net.java.dev.jna:jna"))
    }

    @Test
    fun everyReplacementArtifactIsWellFormed() {
        for (item in EngineLibraryPolicy.REPLACEMENTS) {
            assertTrue(item.name, SafePaths.isSha1(item.sha1))
            assertTrue(item.name, item.size > 0)
            assertTrue(item.url, item.url.startsWith("https://"))
            assertTrue(item.path, SafePaths.resolveInside(File(tmp.root, "libraries"), item.path) != null)
        }
    }

    // ---- Версии ---------------------------------------------------------------------------------

    @Test
    fun versionParsing() {
        assertEquals(listOf(5, 13, 0), EngineLibraryPolicy.parseVersion("5.13.0"))
        assertEquals(listOf(6, 2, 2), EngineLibraryPolicy.parseVersion("6.2.2-beta"))
        assertEquals(listOf(4, 1), EngineLibraryPolicy.parseVersion("4.1.Final"))
        assertEquals(listOf(5), EngineLibraryPolicy.parseVersion("5"))
        assertNull(EngineLibraryPolicy.parseVersion("LATEST"))
        assertNull(EngineLibraryPolicy.parseVersion(""))
    }

    @Test
    fun versionComparisonTreatsMissingPartsAsZero() {
        assertEquals(0, EngineLibraryPolicy.compare(listOf(5, 13), listOf(5, 13, 0)))
        assertTrue(EngineLibraryPolicy.compare(listOf(5, 12, 1), listOf(5, 13)) < 0)
        assertTrue(EngineLibraryPolicy.compare(listOf(6), listOf(5, 13)) > 0)
        assertTrue(EngineLibraryPolicy.compare(listOf(5, 13, 1), listOf(5, 13)) > 0)
    }

    // ---- Вместе с планировщиком --------------------------------------------------------------

    private fun planner() = InstallPlanner(
        layout = VersionLayout(GameDirectories(File(tmp.root, ".minecraft"))),
        env = OsEnvironment.LINUX_ARM64,
        libraryFilter = EngineLibraryPolicy::isNeeded,
        libraryReplacement = EngineLibraryPolicy::replacement,
    )

    @Test
    fun plannerSkipsLwjglAndReplacesOldLibraries() {
        val base = VersionParser.parseVersion(Fixtures.text("version_modern.json"))
        val version = base.copy(
            libraries = base.libraries + lib("net.java.dev.jna:jna:5.12.1") + lib("com.github.oshi:oshi-core:6.2.2"),
        )

        val names = planner().selectLibraries(version).map { it.name }

        assertEquals(
            listOf("com.google.code.gson:gson:2.10.1", "net.java.dev.jna:jna:5.13.0", "com.github.oshi:oshi-core:6.3.0"),
            names,
        )
    }

    @Test
    fun plannerDownloadsTheReplacementNotTheOldFile() {
        val base = VersionParser.parseVersion(Fixtures.text("version_modern.json"))
        val version = base.copy(libraries = base.libraries + lib("net.java.dev.jna:jna:5.12.1"))

        val tasks = planner().coreTasks(version).filter { it.kind == FileKind.LIBRARY }

        val jna = tasks.single { it.url.contains("/jna/") }
        assertEquals("https://repo1.maven.org/maven2/net/java/dev/jna/jna/5.13.0/jna-5.13.0.jar", jna.url)
        assertEquals("1200e7ebeedbe0d10062093f32925a912020e747", jna.sha1)
        assertEquals(1_879_325L, jna.size)
        assertTrue(jna.target.path.endsWith("net/java/dev/jna/jna/5.13.0/jna-5.13.0.jar"))
        assertTrue(tasks.none { it.url.contains("lwjgl") })
    }

    @Test
    fun twoVersionsReplacedByTheSameArtifactAreDownloadedOnce() {
        val base = VersionParser.parseVersion(Fixtures.text("version_modern.json"))
        val version = base.copy(
            libraries = base.libraries + lib("net.java.dev.jna:jna:5.12.1") + lib("net.java.dev.jna:jna:5.9.0"),
        )

        val tasks = planner().coreTasks(version).filter { it.url.contains("/jna/") }

        assertEquals(1, tasks.size)
    }
}
