package com.mclauncher.app.data.versions

import org.junit.Assert.assertEquals
import org.junit.Assume.assumeNoException
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.IOException
import java.net.URL
import java.security.MessageDigest

/**
 * Сверяет таблицу замен [EngineLibraryPolicy.REPLACEMENTS] с настоящим Maven Central. Включается переменной
 * окружения `MCLAUNCHER_ONLINE_TESTS=1` (на CI она задана); без неё тест пропускается, как и `RealFixturesTest`.
 * Если сеть недоступна — тоже пропуск; падает он только тогда, когда файл скачался, а хэш или размер не сошлись.
 */
class ReplacementArtifactsOnlineTest {

    @Test
    fun hashesAndSizesMatchMavenCentral() {
        assumeTrue("MCLAUNCHER_ONLINE_TESTS is not set", System.getenv("MCLAUNCHER_ONLINE_TESTS") == "1")

        for (item in EngineLibraryPolicy.REPLACEMENTS) {
            val sha1 = MessageDigest.getInstance("SHA-1")
            var size = 0L
            try {
                val connection = URL(item.url).openConnection().apply {
                    connectTimeout = 15_000
                    readTimeout = 30_000
                }
                connection.getInputStream().use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        sha1.update(buffer, 0, read)
                        size += read
                    }
                }
            } catch (e: IOException) {
                assumeNoException("Maven Central is not reachable: ${item.url}", e)
            }
            val actual = sha1.digest().joinToString("") { "%02x".format(it) }
            assertEquals("SHA-1 of ${item.name}", item.sha1, actual)
            assertEquals("size of ${item.name}", item.size, size)
        }
    }
}
