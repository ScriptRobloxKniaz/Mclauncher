package com.mclauncher.app.ui.home

import com.mclauncher.app.data.account.Account
import com.mclauncher.app.data.account.AccountType
import com.mclauncher.app.data.versions.InstalledVersion
import com.mclauncher.app.data.versions.VersionLibraryState
import com.mclauncher.app.data.versions.VersionType
import com.mclauncher.app.ui.common.ActiveAccountState
import org.junit.Assert.assertEquals
import org.junit.Test

class PlayGateTest {

    private val account = ActiveAccountState.Selected(
        Account(1, AccountType.OFFLINE, "Steve", "5627dd98-e6be-3c21-b8a8-e92344183641", true, 0L),
    )

    private fun version(id: String) = InstalledVersion(id, VersionType.RELEASE, "Main", "17", 21, null, 1L)

    private fun library(selected: String?, vararg installed: String) =
        VersionLibraryState(installed.map(::version), selected)

    @Test
    fun launchesTheSelectedVersionFromTheBigButton() {
        assertEquals(PlayDecision.LAUNCH, decidePlay(account, library("1.21.1", "1.21.1", "1.20.1"), null))
    }

    @Test
    fun launchesAnInstalledVersionFromItsCardEvenIfAnotherIsSelected() {
        assertEquals(PlayDecision.LAUNCH, decidePlay(account, library("1.21.1", "1.21.1", "1.20.1"), "1.20.1"))
    }

    @Test
    fun launchesFromACardWhenNothingIsSelectedYet() {
        assertEquals(PlayDecision.LAUNCH, decidePlay(account, library(null, "1.21.1"), "1.21.1"))
    }

    @Test
    fun bigButtonAsksToPickWhenVersionsExistButNoneIsSelected() {
        assertEquals(PlayDecision.PICK_VERSION, decidePlay(account, library(null, "1.21.1"), null))
    }

    @Test
    fun staleSelectionCountsAsNotSelected() {
        // Выбрана версия, которой нет на диске: selected == null, большая кнопка просит выбрать другую.
        assertEquals(PlayDecision.PICK_VERSION, decidePlay(account, library("1.8.9", "1.21.1"), null))
    }

    @Test
    fun cardOfAVersionThatDisappearedAsksToPick() {
        assertEquals(PlayDecision.PICK_VERSION, decidePlay(account, library("1.21.1", "1.21.1"), "1.7.10"))
    }

    @Test
    fun noInstalledVersionsSendsToTheVersionsScreen() {
        assertEquals(PlayDecision.NEED_VERSION, decidePlay(account, library(null), null))
        assertEquals(PlayDecision.NEED_VERSION, decidePlay(account, library(null), "1.21.1"))
    }

    @Test
    fun noAccountComesFirst() {
        assertEquals(PlayDecision.NEED_ACCOUNT, decidePlay(ActiveAccountState.None, library("1.21.1", "1.21.1"), null))
        assertEquals(PlayDecision.NEED_ACCOUNT, decidePlay(ActiveAccountState.None, library(null), null))
        assertEquals(PlayDecision.NEED_ACCOUNT, decidePlay(ActiveAccountState.None, null, null))
    }

    @Test
    fun waitsWhileSomethingIsStillLoading() {
        assertEquals(PlayDecision.WAIT, decidePlay(ActiveAccountState.Loading, library("1.21.1", "1.21.1"), null))
        assertEquals(PlayDecision.WAIT, decidePlay(account, null, null))
        assertEquals(PlayDecision.WAIT, decidePlay(ActiveAccountState.Loading, null, "1.21.1"))
    }
}
