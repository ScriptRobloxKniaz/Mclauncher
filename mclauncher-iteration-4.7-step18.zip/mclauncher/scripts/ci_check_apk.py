#!/usr/bin/env python3
"""Проверяет собранный APK: есть ли в нём всё, без чего игра не запустится.

Gradle может завершиться успешно, хотя нативная часть в APK не попала (например, ndk-build ничего не собрал под нужную
архитектуру). Без этой проверки CI выложил бы такой APK как «полный». Шаг в workflow падает, если чего-то не хватает, и
печатает строки `MISSING: …` — их подхватывает scripts/ci_build_status.py.

Использование: python3 -I scripts/ci_check_apk.py <файл.apk>
             python3 -I scripts/ci_check_apk.py --self-test
"""
from __future__ import annotations

import sys
import tempfile
import zipfile
from pathlib import Path

ABI = "lib/arm64-v8a/"

# Что обязано лежать в APK. Нативные библиотеки: мост (libpojavexec) и то, от чего он зависит или что Java загружает по
# имени (NativeLibraryLoader): exithook, pojavexec_awt; driver_helper и bytehook подтягиваются как зависимости; OpenAL
# приходит из файлов ядра (scripts/fetch_core.py --install), а не из ndk-build.
REQUIRED = [
    "assets/core/core-manifest.txt",
    ABI + "libpojavexec.so",
    ABI + "libexithook.so",
    ABI + "libpojavexec_awt.so",
    ABI + "libdriver_helper.so",
    ABI + "libbytehook.so",
    ABI + "libopenal.so",
]


def check(apk: Path) -> tuple[list[str], list[str]]:
    """Возвращает (строки листинга, недостающие записи)."""
    with zipfile.ZipFile(apk) as zf:
        infos = {i.filename: i for i in zf.infolist()}
    listing = [f"{name}  {info.file_size} байт" for name, info in sorted(infos.items()) if name.startswith("lib/")]
    missing = [name for name in REQUIRED if name not in infos]
    return listing, missing


def main(argv: list[str]) -> int:
    if argv and argv[0] == "--self-test":
        return self_test()
    if len(argv) != 1:
        print(__doc__)
        return 2
    apk = Path(argv[0])
    if not apk.is_file():
        print(f"MISSING: сам APK не найден: {apk}")
        return 1
    try:
        listing, missing = check(apk)
    except zipfile.BadZipFile:
        print(f"MISSING: {apk} — не zip/APK")
        return 1
    print(f"APK: {apk.name}, {apk.stat().st_size / 1_048_576:.1f} МБ")
    print("Нативные библиотеки в APK (lib/…):")
    print("\n".join("  " + x for x in listing) if listing else "  (нет ни одной)")
    for name in missing:
        print(f"MISSING: в APK нет {name}")
    print("Проверка APK:", "НЕ ПРОЙДЕНА" if missing else "пройдена")
    return 1 if missing else 0


def self_test() -> int:
    failures: list[str] = []

    def make(tmp: Path, names: list[str]) -> Path:
        path = tmp / f"t{len(list(tmp.iterdir()))}.apk"
        with zipfile.ZipFile(path, "w") as zf:
            for n in names:
                zf.writestr(n, "x")
        return path

    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        _, missing = check(make(tmp, list(REQUIRED)))
        if missing:
            failures.append(f"полный набор признан неполным: {missing}")
        _, missing = check(make(tmp, [r for r in REQUIRED if not r.endswith("libpojavexec.so")]))
        if missing != [ABI + "libpojavexec.so"]:
            failures.append(f"не найден пропуск libpojavexec.so: {missing}")
        _, missing = check(make(tmp, ["classes.dex"]))
        if len(missing) != len(REQUIRED):
            failures.append("обычный APK без ядра должен не пройти по всем пунктам")
        # lib другой архитектуры не засчитывается
        _, missing = check(make(tmp, [r.replace("arm64-v8a", "x86_64") for r in REQUIRED]))
        if ABI + "libpojavexec.so" not in missing:
            failures.append("библиотека не той архитектуры засчитана")
    for f in failures:
        print("САМОПРОВЕРКА: не прошло:", f)
    print("САМОПРОВЕРКА ci_check_apk:", "ОШИБКИ" if failures else "всё прошло")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
